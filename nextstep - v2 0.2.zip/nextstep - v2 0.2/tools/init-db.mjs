// Inicializa la base de datos de NEXTSTEP. Se puede correr cuando se quiera; el servidor también
// la crea sola al arrancar. Este script solo confirma dónde quedó y que el esquema está listo.
import { getDbPath } from '../src/db.js';

console.log('Base de datos de NEXTSTEP lista en:');
console.log('  ' + getDbPath());
console.log('El esquema se crea automáticamente al importar la base de datos.');