// Autenticación de NEXTSTEP: registro, login, sesión con cookie httpOnly y hash de contraseña con scrypt.
import crypto from 'node:crypto';
import { createUser, getUserByEmail, getUserById, createSession, getSession, deleteSession, deleteExpiredSessions } from './db.js';

export const SESSION_COOKIE = 'ns_session';
const SESSION_DAYS = Number(process.env.SESSION_DAYS) || 30;
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');

// ---------- Passwords ----------
export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt:${salt}:${hash}`;
}
export function verifyPassword(password, stored) {
  try {
    const [scheme, salt, hash] = String(stored).split(':');
    if (scheme !== 'scrypt' || !salt || !hash) return false;
    const candidate = crypto.scryptSync(password, salt, 64);
    const expected = Buffer.from(hash, 'hex');
    return candidate.length === expected.length && crypto.timingSafeEqual(candidate, expected);
  } catch {
    return false;
  }
}

// ---------- Sesiones ----------
function newToken() { return crypto.randomBytes(32).toString('base64url'); }

export function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export function sessionCookie(token) {
  const expires = new Date(Date.now() + SESSION_DAYS * 86400_000).toUTCString();
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Expires=${expires}`;
}
export function clearCookie() {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Expires=Thu, 01 Jan 1970 00:00:00 GMT`;
}

export async function createLoginSession(userId) {
  deleteExpiredSessions();
  const token = newToken();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400_000).toISOString();
  createSession(token, userId, expiresAt);
  return token;
}

// Middleware de Express: mete req.user si la cookie es válida.
export function authUser(req, _res, next) {
  const token = parseCookies(req.headers.cookie || '')[SESSION_COOKIE];
  if (token) {
    const s = getSession(token);
    if (s && s.expires_at > new Date().toISOString()) {
      const u = getUserById(s.user_id);
      if (u) req.user = u;
    } else if (s) deleteSession(token);
  }
  next();
}
export function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Necesitás iniciar sesión.' });
  next();
}

// ---------- Validación ----------
export function cleanUserInput(body) {
  const name = String(body.name || '').trim().slice(0, 60);
  const email = String(body.email || '').trim().toLowerCase().slice(0, 120);
  const password = String(body.password || '');
  if (!name) return { error: 'Poné tu nombre.' };
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return { error: 'El email no es válido.' };
  if (password.length < 8) return { error: 'La contraseña tiene que tener al menos 8 caracteres.' };
  if (password.length > 200) return { error: 'La contraseña es demasiado larga.' };
  return { name, email, password };
}

// Solo para montar el token en el contexto del backend; no se usa para firmar.
export { SESSION_SECRET };