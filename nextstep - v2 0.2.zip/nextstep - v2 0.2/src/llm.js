// Router de IA de NEXTSTEP.
//
// NEXTSTEP puede usar, en orden de prioridad, a varias empresas de IA a la vez:
//   1) Claude  (Anthropic)  -> ANTHROPIC_API_KEY
//   2) ChatGPT (OpenAI)     -> OPENAI_API_KEY   (o un servidor local compatible, ej. Ollama, con OPENAI_BASE_URL)
//   3) Gemini  (Google)     -> GEMINI_API_KEY
//
// El orden se controla con PROVIDER_ORDER (por defecto "anthropic,openai,gemini").
// Cuando un proveedor falla por cupo/tokens, límite de uso, saturación o problemas de red, se lo
// "pausa" un rato y se pasa al siguiente automáticamente. Cada intento y su gasto de tokens quedan
// registrados en la base (llm_usage), y el estado de la pausa en provider_state.
import Anthropic from '@anthropic-ai/sdk';
import { recordLlmUsage, markProviderOk, markProviderFail, getProviderState, listProviderStates } from './db.js';

const MAX_TOKENS = Number(process.env.MAX_TOKENS) || 2000;
const COOLDOWN_MS = (Number(process.env.PROVIDER_COOLDOWN_SEC) || 120) * 1000;

/* ============================ Definición de proveedores ============================ */
const PROVIDERS = {
  anthropic: {
    id: 'anthropic', label: 'Claude', company: 'Anthropic',
    key() { return process.env.ANTHROPIC_API_KEY; },
    model() { return process.env.ANTHROPIC_MODEL || process.env.MODEL || 'claude-sonnet-5-5'; },
    ready() { return Boolean(this.key()); },
    missing: 'Claude: falta ANTHROPIC_API_KEY.',
    run({ system, messages, signal, onText, onUsage }) {
      anthropic ??= new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
      const stream = anthropic.messages.stream({ model: this.model(), max_tokens: MAX_TOKENS, system, messages }, { signal });
      stream.on('text', onText);
      return stream.finalMessage().then(final => {
        if (final?.usage) onUsage?.({ tokensIn: final.usage.input_tokens || 0, tokensOut: final.usage.output_tokens || 0 });
      });
    },
  },
  openai: {
    id: 'openai', label: 'ChatGPT', company: 'OpenAI',
    key() { return process.env.OPENAI_API_KEY; },
    base() { return (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, ''); },
    model() { return process.env.OPENAI_MODEL || process.env.MODEL || 'gpt-4o-mini'; },
    // Con una base local (Ollama) no hace falta clave; contra api.openai.com sí.
    ready() { return Boolean(this.key()) || Boolean(process.env.OPENAI_BASE_URL); },
    missing: 'ChatGPT: falta OPENAI_API_KEY (o una OPENAI_BASE_URL local).',
    async run({ system, messages, signal, onText, onUsage }) {
      const headers = { 'Content-Type': 'application/json' };
      if (this.key()) headers.Authorization = `Bearer ${this.key()}`;
      const body = {
        model: this.model(), stream: true, max_tokens: MAX_TOKENS,
        stream_options: { include_usage: true },
        messages: [{ role: 'system', content: system }, ...messages],
      };
      const r = await fetch(`${this.base()}/chat/completions`, { method: 'POST', headers, signal, body: JSON.stringify(body) });
      if (!r.ok) throw await httpError(r, this.label);
      await readSSE(r.body, raw => {
        const line = raw.trim();
        if (!line.startsWith('data:')) return true;
        const data = line.slice(5).trim();
        if (data === '[DONE]') return false;
        try {
          const j = JSON.parse(data);
          const t = j.choices?.[0]?.delta?.content;
          if (t) onText(t);
          if (j.usage) onUsage?.({ tokensIn: j.usage.prompt_tokens || 0, tokensOut: j.usage.completion_tokens || 0 });
        } catch { /* línea parcial */ }
        return true;
      });
    },
  },
  gemini: {
    id: 'gemini', label: 'Gemini', company: 'Google',
    key() { return process.env.GEMINI_API_KEY; },
    base() { return (process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta').replace(/\/$/, ''); },
    model() { return process.env.GEMINI_MODEL || 'gemini-2.0-flash'; },
    ready() { return Boolean(this.key()); },
    missing: 'Gemini: falta GEMINI_API_KEY.',
    async run({ system, messages, signal, onText, onUsage }) {
      const contents = messages.map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }));
      const body = { systemInstruction: { parts: [{ text: system }] }, contents, generationConfig: { maxOutputTokens: MAX_TOKENS } };
      const url = `${this.base()}/models/${encodeURIComponent(this.model())}:streamGenerateContent?alt=sse&key=${encodeURIComponent(this.key())}`;
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, signal, body: JSON.stringify(body) });
      if (!r.ok) throw await httpError(r, this.label);
      await readSSE(r.body, raw => {
        const line = raw.trim();
        if (!line.startsWith('data:')) return true;
        const data = line.slice(5).trim();
        if (!data || data === '[DONE]') return true;
        try {
          const j = JSON.parse(data);
          const parts = j.candidates?.[0]?.content?.parts;
          if (parts) for (const p of parts) if (p.text) onText(p.text);
          const u = j.usageMetadata;
          if (u) onUsage?.({ tokensIn: u.promptTokenCount || 0, tokensOut: u.candidatesTokenCount || 0 });
        } catch { /* línea parcial */ }
        return true;
      });
    },
  },
};

let anthropic = null;

/* ============================ Utilidades de streaming ============================ */
async function readSSE(body, onLine) {
  const reader = body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i);
      buf = buf.slice(i + 1);
      if (onLine(line) === false) return;
    }
  }
}
async function httpError(r, label) {
  let txt = '';
  try { txt = await r.text(); } catch { /* sin cuerpo */ }
  let detail = '';
  try { const j = JSON.parse(txt); detail = j?.error?.message || j?.error || ''; } catch { detail = txt.slice(0, 200); }
  const e = new Error(`${label} respondió ${r.status}${detail ? ': ' + String(detail).slice(0, 160) : ''}`);
  e.status = r.status;
  return e;
}

/* ============================ Orden y estado ============================ */
export function orderIds() {
  const raw = process.env.PROVIDER_ORDER;
  const ids = (raw || 'anthropic,openai,gemini').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
  return ids.filter(id => PROVIDERS[id]);
}
export function readyProviders() { return orderIds().map(id => PROVIDERS[id]).filter(p => p.ready()); }

function isPaused(id) {
  const s = getProviderState(id);
  return Boolean(s?.paused_until) && new Date(s.paused_until).getTime() > Date.now();
}

// Abortar por el usuario (cerró la pestaña o tocó "Parar"): no cambiamos de proveedor, cortamos.
function isAbort(e) { return e?.name === 'AbortError' || e?.name === 'APIUserAbortError' || e?.name === 'TimeoutError'; }

// ¿Conviene pasar al siguiente proveedor con este error? (cupo agotado, límite, saturación, red, clave).
export function shouldShift(e) {
  const s = Number(e?.status);
  if ([401, 403, 408, 409, 425, 429, 500, 502, 503, 504, 529].includes(s)) return true;
  const msg = String(e?.message || '').toLowerCase();
  return /quota|insufficient|billing|rate ?limit|exhaust|resource_exhausted|overloaded|capacity|too many|tokens/.test(msg);
}

/* ============================ API pública ============================ */
// Envía la charla al primer proveedor disponible; si falla por cupo/saturación, prueba el siguiente.
// onProvider(id, label, model) avisa cuál está respondiendo.
export async function streamChat(opts) {
  const list = readyProviders();
  if (!list.length) throw missingConfigError();
  let lastErr = null;
  for (const p of list) {
    if (isPaused(p.id)) { lastErr = new Error(`${p.label} está en pausa por límite de uso.`); continue; }
    try {
      let usage = null;
      opts.onProvider?.(p.id, p.label, p.model());
      await p.run({ ...opts, onUsage: u => { usage = u; } });
      markProviderOk(p.id);
      recordLlmUsage({ provider: p.id, model: p.model(), tokensIn: usage?.tokensIn || 0, tokensOut: usage?.tokensOut || 0, ok: 1 });
      return;
    } catch (e) {
      if (isAbort(e)) throw e;
      const shift = shouldShift(e);
      markProviderFail(p.id, { reason: e?.message, cooldownMs: shift ? COOLDOWN_MS : 5000 });
      recordLlmUsage({ provider: p.id, model: p.model(), ok: 0, reason: String(e?.message || '').slice(0, 160) });
      lastErr = e;
      if (!shift) throw e;
      console.warn(`[ia] ${p.label} no pudo responder (${e?.status || '?'}): cambio al siguiente proveedor.`);
    }
  }
  throw lastErr || missingConfigError();
}

// Pide un JSON con forma definida (evaluaciones, rutas) y lo devuelve parseado.
export async function completeJson({ system, prompt, signal, attempts = 2 }) {
  let lastErr = null;
  for (let i = 0; i < attempts; i++) {
    let text = '';
    await streamChat({ system, messages: [{ role: 'user', content: prompt }], signal, onText: t => { text += t; } });
    const json = extractJson(text);
    if (json) return json;
    lastErr = new Error('La IA no devolvió un JSON válido.');
  }
  throw lastErr || new Error('No se pudo generar con la IA.');
}

function extractJson(text) {
  const s = String(text || '');
  const fenced = s.match(/```(?:json)?\s*([\s\S]*?)```/);
  const candidate = fenced ? fenced[1] : s;
  const start = candidate.indexOf('{');
  const end = candidate.lastIndexOf('}');
  if (start >= 0 && end > start) {
    try { return JSON.parse(candidate.slice(start, end + 1)); } catch { /* seguir buscando */ }
  }
  try { return JSON.parse(s); } catch { return null; }
}

/* ============================ Informe para la app ============================ */
export function routerInfo() {
  const states = Object.fromEntries(listProviderStates().map(s => [s.provider, s]));
  const providers = orderIds().map(id => {
    const p = PROVIDERS[id], st = states[id] || {};
    const paused = Boolean(st.paused_until) && new Date(st.paused_until).getTime() > Date.now();
    return {
      id, label: p.label, company: p.company, model: p.model(), ready: p.ready(),
      paused, pausedUntil: paused ? st.paused_until : null,
      ok: st.ok_count || 0, fail: st.fail_count || 0, lastError: st.last_error || null,
    };
  });
  const usable = providers.filter(p => p.ready && !p.paused);
  return { ready: usable.length > 0, active: usable[0] || null, providers, order: orderIds() };
}
export function providerInfo() {
  const r = routerInfo();
  const a = r.active || r.providers.find(p => p.ready) || r.providers[0] || null;
  return { provider: a?.id || null, model: a?.model || null, ready: r.ready, router: r };
}
export function missingConfigMessage() {
  const missing = orderIds().map(id => PROVIDERS[id]).filter(p => !p.ready()).map(p => p.missing);
  return missing.length
    ? `No hay ninguna IA configurada en el servidor. ${missing.join(' ')} Cargá al menos una clave en el .env (Claude, ChatGPT o Gemini).`
    : 'Ninguna IA está disponible ahora (todas en pausa por límite de uso o falta de red).';
}
function missingConfigError() { const e = new Error(missingConfigMessage()); e.status = 503; return e; }

export const PROVIDER_META = PROVIDERS;
