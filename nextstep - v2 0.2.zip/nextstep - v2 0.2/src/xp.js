// Reglas de experiencia, niveles, racha y logros de NEXTSTEP.
// Las asigna el backend con estas reglas: el frontend jamás decide cuánta XP vale algo.
import { getProfile, updateProfile, addXp, awardAchievement, statsOverview, listGoals, listSubjects } from './db.js';

export const RULES = {
  chat_message: 5,          // mandar un mensaje en una sesión de estudio
  exercise_correct: 15,     // resolver bien un ejercicio
  evaluation_ok: 40,        // completar una evaluación (independiente del puntaje)
  goal_task_done: 10,       // marcar una tarea de objetivo
  path_activity: 25,        // completar una actividad de ruta
  module_done: 40,          // completar un módulo de ruta
  study_10min: 5,           // por cada 10 minutos de estudio
};

// Diario: actualiza la racha de estudio según la fecha de hoy. La racha no borra progreso: es solo
// un indicador de constancia.
export function touchStreak(userId, today = new Date()) {
  const p = getProfile(userId);
  const todays = today.toISOString().slice(0, 10);
  if (p.last_study_date === todays) return { streak: p.streak, new: false };
  const yesterday = new Date(today.getTime() - 86400_000).toISOString().slice(0, 10);
  const streak = p.last_study_date === yesterday ? p.streak + 1 : 1;
  updateProfile(userId, { streak, last_study_date: todays, best_streak: Math.max(p.best_streak, streak) });
  return { streak, new: true };
}

export function earn(userId, rule, source = null) {
  const amount = RULES[rule] || 0;
  const { xp, level } = addXp(userId, amount, rule, source);
  const st = touchStreak(userId);
  maybeAchievements(userId);
  return { amount, xp, level, streak: st.streak, newDay: st.new };
}

// Logros por constancia y objetivos. Se otorgan solo acá, con datos reales del backend.
function maybeAchievements(userId) {
  const p = getProfile(userId);
  if (p.best_streak >= 3) awardAchievement(userId, 'racha_3', 'Tercer día seguido', 'Estudiaste 3 días seguidos.');
  if (p.best_streak >= 7) awardAchievement(userId, 'racha_7', 'Una semana entera', 'Estudiaste 7 días seguidos.');
  if (p.best_streak >= 30) awardAchievement(userId, 'racha_30', 'Mes de estudio', 'Estudiaste 30 días seguidos.');
  if (p.xp >= 500) awardAchievement(userId, 'xp_500', 'Primer hito de constancia', 'Sumaste 500 puntos de experiencia.');
  if (p.xp >= 5000) awardAchievement(userId, 'xp_5000', 'Máquina de estudio', 'Sumaste 5000 puntos de experiencia.');
  const s = statsOverview(userId);
  if (Number(s.evaluations) >= 1) awardAchievement(userId, 'eval_1', 'Primer evaluación', 'Completaste tu primera evaluación.');
  if (Number(s.activities) >= 25) awardAchievement(userId, 'act_25', '25 actividades', 'Completaste 25 actividades.');
  if (listGoals(userId).some(g => g.status === 'logrado')) awardAchievement(userId, 'meta_1', 'Objetivo cumplido', 'Lograste un objetivo completo.');
  if (listSubjects(userId).some(su => su.mastery >= 90)) awardAchievement(userId, 'master_1', 'Casi experto', 'Llegaste a 90% de dominio en una materia.');
}