# NEXTSTEP

Profesor particular virtual con IA: te conoce, evalúa tu nivel real, te arma un camino de aprendizaje,
te explica, te hace practicar, corrige tus errores y lleva el seguimiento de tu progreso.

## Estado actual

Aplicación web completa con cuenta por alumno y persistencia en SQLite (sin base de datos externa):

- **Cuentas**: registro, login y sesiones (cookie httpOnly, contraseñas con scrypt).
- **Profesor IA**: chat con streaming (es la pantalla principal de la app), modo de estudio
  (explicar / practicar / evaluar / proyecto), respuestas que se adaptan a las preferencias del alumno.
- **Materias y temas**: catálogo de materias de la secundaria para crearlas en un toque, o la que no esté
  en la lista la escribís vos y el profesor IA igual aprende sus temas. El dominio por materia se mide con
  evaluaciones reales.
- **Rutas de aprendizaje**: se crean automáticamente al agregar una materia, o las diseña la IA.
- **Evaluaciones**: con banco de preguntas verificado a mano (o generadas por IA si hay clave) y corrección
  con explicación de cada respuesta.
- **Seguimiento**: XP, niveles, racha, estadísticas, logros y sesiones de estudio.
- **Temas visuales**: 10 paletas aplicables a todo el sitio (focus, bosque, lavanda, cálido, océano, rosa,
  alto contraste, enfoque oscuro, claro simple y personalizado), con modo claro/oscuro y densidad.

## Arrancar

1. Instalá **Node.js 22.5 o más nuevo** (usa el módulo `node:sqlite` integrado, no hace falta compilar nada).
2. En esta carpeta: `npm install`
3. Copiá `.env.example` como `.env` y cargá al menos **una** clave de IA (cuanto más cargues, más robusto):
   `ANTHROPIC_API_KEY` (Claude), `OPENAI_API_KEY` (ChatGPT) o `GEMINI_API_KEY` (Gemini).
   También generá un `SESSION_SECRET`.
4. `npm start` y abrí http://localhost:3000

La base `data/nextstep.db` se crea sola (está en `.gitignore`). Probá `http://localhost:3000/api/health`:
si dice `"ia":true`, hay al menos una IA disponible y te muestra cuál está respondiendo.

## Comandos

| Comando | Qué hace |
|---|---|
| `npm start` | Levanta el servidor en http://localhost:3000 |
| `npm run dev` | Igual, pero se reinicia solo al guardar (`node --watch`) |
| `npm run init-db` | Crea/verifica la base de datos |
| `npm test` | Corre las pruebas (`node --test "test/*.test.mjs"`) |

## Qué IA usa por detrás

La app corre en tu servidor: los alumnos nunca entran a ninguna cuenta ajena. NEXTSTEP tiene **varias IA
cargadas a la vez y las usa en cadena**:

| Proveedor | Clave en `.env` | Cuándo conviene |
|---|---|---|
| Claude (Anthropic) | `ANTHROPIC_API_KEY` | Mejor calidad para enseñar. Cuesta por uso. |
| ChatGPT (OpenAI) | `OPENAI_API_KEY` | Alternativa sólida; con `OPENAI_BASE_URL` apuntás a Ollama u otro compatible y corre en tu compu. |
| Gemini (Google) | `GEMINI_API_KEY` | Otra nube, a veces con cupo gratis. |

- El orden se arma con `PROVIDER_ORDER` (por defecto `anthropic,openai,gemini`).
- **Si una se queda sin tokens/cupo o falla, el servidor pasa solo a la siguiente** y pausa a la que falló
  unos minutos (`PROVIDER_COOLDOWN_SEC`). El chat te muestra con qué IA te respondió.
- Todo eso se ve en Configuración → Inteligencia artificial: proveedores, cuál está activa y cuántos tokens
  se usaron.

## Estructura

- `server.js`: API REST completa (auth, dashboard, chat SSE, materias, rutas, evaluaciones, objetivos,
  estadísticas, recursos, perfil) + SPA fallback.
- `src/db.js`: esquema y acceso a SQLite (`node:sqlite`). Toda la persistencia está acá.
- `src/auth.js`: scrypt, sesiones y cookie.
- `src/xp.js`: reglas de XP y racha.
- `src/llm.js`: router de IA (Claude / ChatGPT / Gemini) con streaming, JSON, cambio automático de proveedor.
- `src/prompt.js`: el "cerebro" del profesor: estilo, proceso, etiquetas de control, preferencias del alumno.
- `src/data.js`: banco de preguntas verificadas (`TOPICS`), recursos (`COURSES`), plantillas de rutas
  (`TEMPLATES`) y catálogo de materias de secundaria (`SUBJECTS`).
- `public/`: SPA sin framework (`index.html`, `css/style.css`, `js/{api,store,ui,themes,modals,app}.js`,
  `js/views/*`). Rutas con hash: `#/chat`, `#/aprendizaje`, `#/rutas`, `#/evaluaciones`, `#/objetivos`,
  `#/estadisticas`, `#/recursos`, `#/config`.

## Pruebas manuales rápidas

- `GET /api/health` → `{"ok":true,"ia":false,...}` sin claves; `"ia":true` con al menos una clave cargada.
- Crear cuenta y entrar → arranca en el chat con el profesor (la pantalla principal).
- Agregar una materia → se crea sola su ruta de aprendizaje (y podés elegirla del catálogo).
- Hacer una evaluación → cambia el dominio de la materia y deja temas "dominado/dificultad".

## Costos y seguridad

- Las claves van solo en `.env` (gitignore). Si se filtra, generá una nueva.
- El servidor limita los pedidos por minuto y corta la llamada si cerrás la pestaña.
- Los links de `src/data.js` conviene revisarlos: pueden cambiar precios o condiciones.