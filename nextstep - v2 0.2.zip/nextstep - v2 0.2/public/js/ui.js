// Componentes y utilidades de interfaz compartidos por las vistas.
import { esc } from './api.js';

export function toast(msg, kind = '') {
  const wrap = document.getElementById('toasts');
  const el = document.createElement('div');
  el.className = 'toast' + (kind ? ' ' + kind : '');
  el.textContent = msg;
  wrap.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .3s';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 320);
  }, kind === 'err' ? 5200 : 3200);
}

let modalCleanup = null;
export function openModal(html, { onMount, closable = true } = {}) {
  const m = document.getElementById('modal');
  const box = document.getElementById('modalBox');
  box.innerHTML = html;
  m.hidden = false;
  if (modalCleanup) { try { modalCleanup(); } catch { /* */ } }
  modalCleanup = onMount ? () => onMount(box) : null;
  const first = box.querySelector('input,select,textarea,button:not(.mclose)');
  if (first) setTimeout(() => first.focus(), 30);
  if (!closable) return box;
  const onKey = e => { if (e.key === 'Escape') closeModal(); };
  document.addEventListener('keydown', onKey);
  const prevCb = modalCleanup;
  modalCleanup = () => { try { prevCb && prevCb(box); } catch { /* */ } document.removeEventListener('keydown', onKey); };
  return box;
}
export function closeModal() {
  const m = document.getElementById('modal');
  m.hidden = true;
  if (modalCleanup) { try { modalCleanup(); } catch { /* */ } }
  modalCleanup = null;
}

export function openOnboard(html, onMount) {
  const o = document.getElementById('onboard');
  document.getElementById('onboardBody').innerHTML = html;
  o.hidden = false;
  if (onMount) onMount(document.getElementById('onboardBody'));
}
export function closeOnboard() {
  document.getElementById('onboard').hidden = true;
}

/* ---------- Etiquetas HTML reutilizables ---------- */
export function card(inner, cls = '') { return `<div class="card ${cls}">${inner}</div>`; }
export function bar(pct, cls = '') {
  const v = Math.max(0, Math.min(100, Math.round(pct || 0)));
  return `<div class="bar ${cls}" role="progressbar" aria-valuenow="${v}" aria-valuemin="0" aria-valuemax="100"><i style="width:${v}%"></i></div>`;
}
export function empty(ico, title, sub = '') {
  return `<div class="empty"><span class="ico">${ico}</span><b>${esc(title)}</b>${sub ? `<span class="sub">${esc(sub)}</span>` : ''}</div>`;
}
export function stateTag(state) {
  const labels = {
    dominado: 'Ya dominás', aprendiendo: 'Estás aprendiendo', dificultad: 'Te cuesta', pendiente: 'Pendiente',
    activa: 'Activa', pausada: 'Pausada', finalizada: 'Finalizada',
    activo: 'Activo', logrado: 'Logrado', cancelado: 'Cancelado',
    pendiente_m: 'Pendiente', en_curso: 'En curso', completado: 'Completado',
    en_curso_ev: 'En curso', completada: 'Completada',
  };
  const map = { pendiente_m: 'pendiente', en_curso: 'en_curso', en_curso_ev: 'en_curso' };
  return `<span class="tag ${map[state] || state}">${labels[state] || state}</span>`;
}
export function stat(ico, value, label) {
  return `<div class="stat"><div class="ico">${ico}</div><div><b>${value}</b><span>${esc(label)}</span></div></div>`;
}
export function skeleton(lines = 3) {
  let h = '';
  for (let i = 0; i < lines; i++) h += `<div class="skeleton" style="height:14px;margin:8px 0;width:${100 - i * 12}%"></div>`;
  return `<div class="card">${h}</div>`;
}

/* ---------- Gráfico de barras (SVG/CSS) ---------- */
export function barchart(points, { label = v => v, fmt = v => v, height = 120 } = {}) {
  const max = Math.max(1, ...points.map(p => Number(p.value) || 0));
  const cols = points.map(p => {
    const pct = (Number(p.value) || 0) / max * 100;
    const cls = Number(p.value) > 0 ? '' : 'empty';
    return `<div class="bcol ${cls}" title="${esc(fmt(p.value))}"><div class="bbar" style="height:${pct}%"></div><span class="bl">${esc(label(p.day))}</span></div>`;
  }).join('');
  return `<div class="bars" style="height:${height}px">${cols}</div>`;
}
export function donut(pct) {
  const v = Math.max(0, Math.min(100, Math.round(pct || 0)));
  return `<div class="donut" style="background:conic-gradient(var(--accent) ${v * 3.6}deg, var(--track) 0deg)" aria-label="${v}%">
    <div class="donut-hole"><b>${v}%</b></div></div>`;
}

/* ---------- Formato de respuestas de la IA ---------- */
export function stripTags(t) {
  let s = String(t || '').replace(/<opciones>[\s\S]*?<\/opciones>/g, '').replace(/<perfil>[\s\S]*?<\/perfil>/g, '').replace(/<resumen>[\s\S]*?<\/resumen>/g, '');
  const i = s.search(/<(opciones|perfil|resumen)/);
  if (i >= 0) s = s.slice(0, i);
  const m = s.match(/<[a-z]{0,8}$/);
  if (m && /^<(opciones|perfil|resumen)/.test(m[0])) s = s.slice(0, m.index);
  return s;
}
let META_URLS = [];
const setAllowedUrls = urls => { META_URLS = urls; };
function linkify(escaped) {
  return escaped.replace(/https?:\/\/[^\s<]+/g, raw => {
    const m = raw.match(/[.,;:!?)]+$/), tail = m ? m[0] : '', url = tail ? raw.slice(0, -tail.length) : raw;
    const plain = url.replace(/&amp;/g, '&');
    return META_URLS.some(u => plain.startsWith(u))
      ? `<a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>${tail}` : raw;
  });
}
export function fmt(t) {
  const parts = stripTags(t).split('```');
  return parts.map((part, i) => {
    if (i % 2 === 1) {
      const code = part.replace(/^[a-zA-Z+#.\-]{0,15}\n/, '').replace(/\n$/, '');
      return `<pre><code>${esc(code)}</code></pre>`;
    }
    let txt = part.replace(/^#+\s*/gm, '');
    if (i > 0) txt = txt.replace(/^\n/, '');
    if (i < parts.length - 1) txt = txt.replace(/\n$/, '');
    if (i === 0) txt = txt.replace(/^\s+/, '');
    if (i === parts.length - 1) txt = txt.replace(/\s+$/, '');
    const safe = esc(txt).replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
    return linkify(safe);
  }).join('');
}
export function readTags(t) {
  const op = String(t || '').match(/<opciones>([\s\S]*?)<\/opciones>/);
  return op ? op[1].split('|').map(s => s.trim()).filter(Boolean).slice(0, 4).map(s => s.slice(0, 40)) : [];
}

export { setAllowedUrls };