// NEXTSTEP app shell: arranque, router de hash, autenticación y chrome de la SPA.
import { api } from './api.js';
import { toast, setAllowedUrls, closeModal, openOnboard, closeOnboard } from './ui.js';
import { store, loadMeta, loadMe } from './store.js';
import { applyAppearance, watchAutoTheme } from './themes.js';
import dashboard from './views/dashboard.js';
import chat from './views/chat.js';
import aprendizaje from './views/aprendizaje.js';
import rutas from './views/rutas.js';
import evaluaciones from './views/evaluaciones.js';
import objetivos from './views/objetivos.js';
import estadisticas from './views/estadisticas.js';
import recursos from './views/recursos.js';
import configuracion from './views/configuracion.js';

const VIEWS = { dashboard, chat, aprendizaje, rutas, evaluaciones, objetivos, estadisticas, recursos, configuracion };
const NAV = [
  { path: '#/chat', label: 'Profesor IA', ico: '🧑‍🏫', key: 'chat' },
  { path: '#/', label: 'Inicio', ico: '🏠', key: 'dashboard' },
  { path: '#/aprendizaje', label: 'Materias', ico: '📚', key: 'aprendizaje' },
  { path: '#/rutas', label: 'Rutas', ico: '🗺️', key: 'rutas' },
  { path: '#/evaluaciones', label: 'Evaluaciones', ico: '📝', key: 'evaluaciones' },
  { path: '#/objetivos', label: 'Objetivos', ico: '🎯', key: 'objetivos' },
  { path: '#/estadisticas', label: 'Estadísticas', ico: '📊', key: 'estadisticas' },
  { path: '#/recursos', label: 'Recursos', ico: '🔗', key: 'recursos' },
  { path: '#/config', label: 'Configuración', ico: '⚙️', key: 'config' },
];
const GOAL_KINDS = [
  ['comprender', '💡 Entender un tema'],
  ['examen', '📝 Rendir un examen'],
  ['habilidad', '🛠️ Aprender una habilidad'],
  ['proyecto', '🎨 Hacer un proyecto'],
];
const PREF_METHODS = [
  ['preguntas', '❓ Preguntas'], ['ejemplos', '🧩 Ejemplos'], ['esquemas', '🗺️ Esquemas'],
  ['resumenes', '📝 Resúmenes'], ['problemas', '🧮 Problemas'],
];

let currentView = null;
let busy = false;

/* ================= ROUTER ================= */
function parseRoute() {
  const h = location.hash || '#/';
  const parts = h.slice(1).split('/').filter(Boolean);
  if (!parts.length) return { key: 'chat', params: {} };
  const key = VIEWS[parts[0]] ? parts[0] : 'chat';
  const params = {};
  if (parts[1]) { const n = Number(parts[1]); params.id = Number.isFinite(n) ? n : parts[1]; }
  return { key, params };
}
async function renderRoute() {
  if (!store.me) return;
  const app = document.getElementById('app');
  try { currentView?.hide?.(); } catch { /* */ }
  const { key, params } = parseRoute();
  currentView = VIEWS[key];
  document.getElementById('topTitle').textContent = currentView.title || 'NEXTSTEP';
  highlightNav(key);
  app.innerHTML = `<div class="stack"><div class="card"><div class="skeleton" style="height:160px"></div></div></div>`;
  try {
    await currentView.show(app, params);
    app.scrollTop = 0; app.focus({ preventScroll: true });
  } catch (e) {
    console.error('[route]', e);
    app.innerHTML = `<div class="card pad center">😵‍💫<b style="display:block;margin-top:8px">Algo salió mal al abrir esta sección.</b>
      <span class="sub" style="display:block;margin-top:4px">${String(e?.message || e).slice(0, 200)}</span>
      <button class="btn primary" style="margin-top:12px" onclick="location.reload()">Recargar</button></div>`;
  }
}
function highlightNav(key) {
  document.querySelectorAll('.snav .navitem').forEach(b => b.classList.toggle('on', b.dataset.nav === key));
}
function renderNav() {
  const nav = document.getElementById('nav');
  if (!nav.dataset.built) {
    nav.innerHTML = NAV.map(n => `<button class="navitem" data-nav="${n.key}"><span>${n.ico}</span><b>${n.label}</b></button>`).join('');
    nav.querySelectorAll('[data-nav]').forEach(b => b.addEventListener('click', () => {
      const item = NAV.find(n => n.key === b.dataset.nav);
      if (item) location.hash = item.path;
      closeSidebar();
    }));
    nav.dataset.built = '1';
  }
}
function closeSidebar() {
  const sb = document.getElementById('sidebar');
  const menu = document.getElementById('menuBtn');
  if (sb.classList.contains('open')) { sb.classList.remove('open'); menu.setAttribute('aria-expanded', 'false'); }
}

/* ================= HEADER / PERFIL ================= */
function updateHeader() {
  const me = store.me; if (!me) return;
  const p = me.profile;
  const nick = (p.nickname || me.user.name || '?').trim();
  document.getElementById('navAvatar').textContent = (nick[0] || '?').toUpperCase();
  document.getElementById('navName').textContent = nick;
  document.getElementById('navLevel').textContent = `Nivel ${p.level} · ${p.xp} XP`;
  document.getElementById('topXp').textContent = p.xp;
  document.getElementById('topLvl').textContent = p.level;
  document.getElementById('topStreak').textContent = p.streak;
}

/* ================= AUTH ================= */
function currentAuthMode() { return document.querySelector('[data-auth-tab].on')?.dataset?.authTab || 'login'; }
function renderAuthFields() {
  const mode = currentAuthMode();
  const el = document.getElementById('authFields');
  el.innerHTML = mode === 'signup'
    ? `<div class="field"><span class="flabel">Nombre</span><input class="input" name="name" required autocomplete="name" placeholder="Cómo te llamamos"></div>
       <div class="field"><span class="flabel">Email</span><input class="input" name="email" type="email" required autocomplete="email" placeholder="vos@ejemplo.com"></div>
       <div class="field"><span class="flabel">Contraseña (mín. 6)</span><input class="input" name="password" type="password" required minlength="6" autocomplete="new-password"></div>`
    : `<div class="field"><span class="flabel">Email</span><input class="input" name="email" type="email" required autocomplete="email" placeholder="vos@ejemplo.com"></div>
       <div class="field"><span class="flabel">Contraseña</span><input class="input" name="password" type="password" required autocomplete="current-password"></div>`;
  document.getElementById('authSubmit').textContent = mode === 'signup' ? 'Crear cuenta' : 'Ingresar';
}
function wireAuth() {
  document.querySelectorAll('[data-auth-tab]').forEach(t => t.addEventListener('click', () => {
    document.querySelectorAll('[data-auth-tab]').forEach(x => x.classList.remove('on'));
    t.classList.add('on');
    document.getElementById('authError').textContent = '';
    renderAuthFields();
  }));
  document.getElementById('authForm').addEventListener('submit', async e => {
    e.preventDefault();
    if (busy) return;
    const err = document.getElementById('authError');
    const form = e.currentTarget;
    const mode = currentAuthMode();
    const fd = Object.fromEntries(new FormData(form).entries());
    err.textContent = '';
    if (mode === 'signup') {
      fd.name = (fd.name || '').trim();
      if (!fd.name) return err.textContent = 'Poné tu nombre.';
    }
    busy = true;
    const btn = document.getElementById('authSubmit');
    btn.disabled = true;
    btn.textContent = 'Un momento…';
    try {
      await api('/api/auth/' + (mode === 'signup' ? 'signup' : 'login'), { method: 'POST', body: fd });
      await loadMe();
      if (!store.me) throw new Error('No se pudo iniciar sesión.');
      sessionStorage.removeItem('ns_quick_subject');
      enterApp();
    } catch (ex) {
      err.textContent = ex.message;
      btn.disabled = false; btn.textContent = mode === 'signup' ? 'Crear cuenta' : 'Ingresar';
    } finally { busy = false; }
  });
  renderAuthFields();
}
function showAuth() {
  document.getElementById('authView').hidden = false;
  document.getElementById('appShell').hidden = true;
  closeSidebar();
}
function enterApp() {
  document.getElementById('authView').hidden = true;
  document.getElementById('appShell').hidden = false;
  applyAppearance(store.me.profile.appearance || {});
  updateHeader();
  renderNav();
  closeModal();
  if (!store.me.profile.onboarding_done) runOnboarding();
  else renderRoute();
}
async function doLogout(callServer) {
  try { if (callServer) await api('/api/auth/logout', { method: 'POST' }); } catch { /* sin red */ }
  store.me = null;
  currentView = null;
  showAuth();
  renderAuthFields();
  toast('Cerraste sesión. ¡Hasta la próxima!');
}

/* ================= ONBOARDING ================= */
function runOnboarding() {
  const pr = store.me.profile.preferences || {};
  const methodChips = PREF_METHODS.map(([v, l]) => `<button type="button" class="chip ${(pr.methods || []).includes(v) ? 'on' : ''}" data-v="${v}">${l}</button>`).join('');
  openOnboard(`
    <div class="onbody">
      <div class="onsteps"><span class="on"></span><span class="on"></span><span class="on"></span></div>
      <h2>👋 ¡Hola! Contanos un toque para arrancar bien.</h2>
      <p class="sub">Todo esto se puede cambiar después en Configuración.</p>
      <div class="field"><span class="flabel">¿Cómo te llamamos?</span>
        <input class="input" id="obNick" maxlength="60" value="${esc(store.me.profile.nickname || '')}" placeholder="Tu nombre"></div>
      <div class="field"><span class="flabel">¿Para qué vas a usar NEXTSTEP?</span>
        <div class="chips" id="obGoal">${GOAL_KINDS.map(([v, l]) => `<button type="button" class="chip ${pr.goalKind === v ? 'on' : ''}" data-v="${v}">${l}</button>`).join('')}</div></div>
      <div class="field"><span class="flabel">¿Qué tan desafiantes al principio?</span>
        <div class="chips" id="obDiff">
          <button type="button" class="chip ${!pr.difficulty || pr.difficulty === 'facil' ? 'on' : ''}" data-v="facil">Suave</button>
          <button type="button" class="chip ${pr.difficulty === 'intermedio' ? 'on' : ''}" data-v="intermedio">Intermedio</button>
          <button type="button" class="chip ${pr.difficulty === 'avanzado' ? 'on' : ''}" data-v="avanzado">Fuerte</button>
        </div></div>
      <div class="field"><span class="flabel">Tu método favorito (podés elegir varios)</span>
        <div class="chips" id="obMethods">${methodChips}</div></div>
      <button class="btn primary block" id="obStart">Comenzar 📚</button>
    </div>`, body => {
    body.querySelectorAll('#obGoal .chip, #obDiff .chip, #obMethods .chip').forEach(b => b.addEventListener('click', () => {
      const chip = b.closest('.chip'); chip.classList.toggle('on');
    }));
    body.querySelector('#obStart').addEventListener('click', async () => {
      const goal = [...body.querySelectorAll('#obGoal .on')].map(x => x.dataset.v)[0];
      const diff = [...body.querySelectorAll('#obDiff .on')].map(x => x.dataset.v)[0];
      const methods = [...body.querySelectorAll('#obMethods .on')].map(x => x.dataset.v);
      const nickname = body.querySelector('#obNick').value.trim();
      try {
        await api('/api/profile', { method: 'PATCH', body: {
          nickname: nickname || undefined,
          onboarding_done: true,
          preferences: { ...pr, goalKind: goal, difficulty: diff, methods },
        } });
        store.me.profile.nickname = nickname || store.me.profile.nickname;
        store.me.profile.onboarding_done = true;
        store.me.profile.preferences = { ...pr, goalKind: goal, difficulty: diff, methods };
        closeOnboard();
        updateHeader();
        toast('¡Listo! A estudiar 🚀', 'ok');
        if (location.hash === '#/chat') renderRoute();
        else location.hash = '#/chat';
      } catch (e) { toast(e.message, 'err'); }
    });
  });
}
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

/* ================= ARRANQUE ================= */
async function boot() {
  watchAutoTheme(() => store.me?.profile?.appearance || {});
  applyAppearance({});
  renderNav();
  setAllowedUrls([]);
  document.getElementById('menuBtn').addEventListener('click', () => {
    const sb = document.getElementById('sidebar');
    const open = !sb.classList.contains('open');
    sb.classList.toggle('open', open);
    document.getElementById('menuBtn').setAttribute('aria-expanded', String(open));
  });
  document.getElementById('logoutBtn').addEventListener('click', () => doLogout(true));
  window.addEventListener('hashchange', renderRoute);
  window.addEventListener('profile-updated', e => { if (e.detail) store.me = e.detail; updateHeader(); });
  window.addEventListener('unauthorized', () => { toast('Tu sesión expiró. Ingresá de nuevo.', 'err'); doLogout(false); });
  window.addEventListener('signout', () => doLogout(false));

  await Promise.all([loadMeta(), loadMe()]);
  setAllowedUrls(store.meta.allowedUrls || []);
  if (store.me) applyAppearance(store.me.profile.appearance || {});

  if (!location.hash) location.hash = '#/chat';
  if (store.me) { enterApp(); } else { showAuth(); wireAuth(); }
}

boot();