// Sistema de temas de NEXTSTEP. Las paletas definen los tokens de color; el navegador los aplica
// como variables CSS en :root. Funciona en todo el sitio, no por pantalla.
//
// Ojo: los colores NO "garantizan" concentración ni memoria (cada persona es distinta). Acá corremos
// criterios de legibilidad, contraste y preferencia personal.
export const DEFAULT_APPEARANCE = {
  theme: 'focus',
  mode: 'auto',
  buttonStyle: 'pill',
  contrast: 'normal',
  textSize: 'md',
  density: 'comfortable',
  animations: true,
  custom: {},
};

// highlight: cómo se pinta la tarjeta de vista previa del tema.
function P(dark, light, highlight) {
  return { palettes: { dark, light }, highlight };
}

export const THEMES = {
  focus: P(
    { bg: '#0E1626', surface: '#17223A', surface2: '#1D2A46', ink: '#E9EEFB', muted: '#9AA8C7', line: '#2A3858', accent: '#6C8DFF', accent2: '#3EC5FF', good: '#3CCB93', warn: '#FFB43B', danger: '#FF5D6C' },
    { bg: '#F2F5FB', surface: '#FFFFFF', surface2: '#F7F9FE', ink: '#14213D', muted: '#5A6785', line: '#D9E0EE', accent: '#2F5BEA', accent2: '#0E9ADB', good: '#1E9E6A', warn: '#C97700', danger: '#D64550' },
    ['#6C8DFF', '#3EC5FF']
  ),
  forest: P(
    { bg: '#0D1913', surface: '#15241C', surface2: '#1B2E22', ink: '#EAF6EE', muted: '#93B5A0', line: '#274335', accent: '#4CD08A', accent2: '#A8E063', good: '#4CD08A', warn: '#E6C15C', danger: '#E7696E' },
    { bg: '#F1F7F1', surface: '#FFFFFF', surface2: '#F4FAF4', ink: '#14241A', muted: '#56705F', line: '#D3E4D6', accent: '#1F9D5F', accent2: '#6DBE3C', good: '#1F9D5F', warn: '#C4921B', danger: '#C45355' },
    ['#4CD08A', '#A8E063']
  ),
  lavender: P(
    { bg: '#171425', surface: '#211C36', surface2: '#2A2447', ink: '#EFEAFB', muted: '#A79ECB', line: '#352F55', accent: '#9D8CFF', accent2: '#C79BFF', good: '#7FE3B0', warn: '#F0C05A', danger: '#FB7C93' },
    { bg: '#F6F4FC', surface: '#FFFFFF', surface2: '#FAF8FF', ink: '#241D3E', muted: '#6A5F8F', line: '#E1DAF2', accent: '#6C5CE7', accent2: '#A06BD6', good: '#1E9E6A', warn: '#C9A227', danger: '#D6456A' },
    ['#9D8CFF', '#C79BFF']
  ),
  warm: P(
    { bg: '#1B1610', surface: '#262019', surface2: '#322A21', ink: '#F6EDDE', muted: '#B5A38A', line: '#3F3629', accent: '#F2A23E', accent2: '#E97E4A', good: '#8FCB6B', warn: '#E2C15C', danger: '#E56B5F' },
    { bg: '#FBF4E8', surface: '#FFFDF7', surface2: '#F8F0E1', ink: '#3A2D1B', muted: '#8A7658', line: '#EADDC6', accent: '#C97418', accent2: '#D05A2A', good: '#4E9A3E', warn: '#B07A14', danger: '#C74B40' },
    ['#F2A23E', '#E97E4A']
  ),
  ocean: P(
    { bg: '#0C1A1C', surface: '#14272A', surface2: '#1A3033', ink: '#EAF6F6', muted: '#8FB6B9', line: '#27454A', accent: '#3ED6C8', accent2: '#4FA9FF', good: '#54D6A0', warn: '#E8C160', danger: '#F57B86' },
    { bg: '#EFF7F7', surface: '#FFFFFF', surface2: '#F2FAFA', ink: '#0F2A2B', muted: '#4F7376', line: '#C9E2E2', accent: '#0EA99B', accent2: '#2F7FE0', good: '#1E9E6A', warn: '#C99A17', danger: '#D64A5A' },
    ['#3ED6C8', '#4FA9FF']
  ),
  rose: P(
    { bg: '#1D1520', surface: '#281C2B', surface2: '#34233A', ink: '#FBEEF6', muted: '#C79AB5', line: '#482F47', accent: '#EF7FB0', accent2: '#F0A6C4', good: '#9BD88B', warn: '#E9C766', danger: '#F07580' },
    { bg: '#FDF3F8', surface: '#FFFFFF', surface2: '#FFF7FB', ink: '#3A1E30', muted: '#8C6480', line: '#F0D5E4', accent: '#D95A90', accent2: '#E47FAE', good: '#4E9A4E', warn: '#C6951B', danger: '#D6456A' },
    ['#EF7FB0', '#F0A6C4']
  ),
  hc: P(
    { bg: '#000000', surface: '#101010', surface2: '#1B1B1B', ink: '#FFFFFF', muted: '#DBDBDB', line: '#5A5A5A', accent: '#00E0FF', accent2: '#FFE333', good: '#3CF28C', warn: '#FFC53D', danger: '#FF5A6E' },
    { bg: '#FFFFFF', surface: '#FFFFFF', surface2: '#F2F2F2', ink: '#000000', muted: '#2B2B2B', line: '#111111', accent: '#004EFF', accent2: '#7A1FA2', good: '#006B3C', warn: '#7A5800', danger: '#C40012' },
    ['#00E0FF', '#FFE333']
  ),
  dafocus: P(
    { bg: '#0B0E14', surface: '#131720', surface2: '#1A1F2C', ink: '#EDF1FA', muted: '#8A93A6', line: '#232B3D', accent: '#5E7CFF', accent2: '#00B8D9', good: '#2EBD85', warn: '#E8A84B', danger: '#FF5D6C' },
    { bg: '#EEF1F7', surface: '#FFFFFF', surface2: '#F4F6FB', ink: '#131A2A', muted: '#5C6679', line: '#C9D2E2', accent: '#3457E0', accent2: '#0B8FB0', good: '#1E9E6A', warn: '#B97E14', danger: '#C94452' },
    ['#5E7CFF', '#00B8D9']
  ),
  light: P(
    { bg: '#15161A', surface: '#1E2027', surface2: '#262931', ink: '#F0F1F5', muted: '#9CA2B3', line: '#33363F', accent: '#B9BFD3', accent2: '#8A93B8', good: '#6FC79A', warn: '#E3B457', danger: '#E06A72' },
    { bg: '#FAFAFC', surface: '#FFFFFF', surface2: '#F3F4F8', ink: '#17181C', muted: '#6B6F7B', line: '#E2E4EC', accent: '#3B3F4E', accent2: '#8A93B8', good: '#2E8B5F', warn: '#C8921B', danger: '#C9484F' },
    ['#B9BFD3', '#8A93B8']
  ),
  custom: {
    palettes: {
      dark: { bg: '#0E1626', surface: '#17223A', surface2: '#1D2A46', ink: '#E9EEFB', muted: '#9AA8C7', line: '#2A3858', accent: '#6C8DFF', accent2: '#3EC5FF', good: '#3CCB93', warn: '#FFB43B', danger: '#FF5D6C' },
      light: { bg: '#F2F5FB', surface: '#FFFFFF', surface2: '#F7F9FE', ink: '#14213D', muted: '#5A6785', line: '#D9E0EE', accent: '#2F5BEA', accent2: '#0E9ADB', good: '#1E9E6A', warn: '#C97700', danger: '#D64550' },
    },
    highlight: ['#6C8DFF', '#3EC5FF'],
  },
};
export const THEME_LIST = Object.keys(THEMES);

// ---------- Utilidades de color ----------
function hexToRgb(h) {
  let s = String(h || '#888888').replace('#', '');
  if (s.length === 3) s = s.split('').map(c => c + c).join('');
  const n = parseInt(s, 16);
  if (Number.isNaN(n)) return { r: 136, g: 136, b: 136 };
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}
function rgbToHex(r, g, b) {
  const c = v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0');
  return '#' + c(r) + c(g) + c(b);
}
export function mix(a, b, t) {
  const A = hexToRgb(a), B = hexToRgb(b);
  return rgbToHex(A.r + (B.r - A.r) * t, A.g + (B.g - A.g) * t, A.b + (B.b - A.b) * t);
}
export function lum(hex) {
  const { r, g, b } = hexToRgb(hex);
  const f = v => { const c = v / 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
}
export function contrastRatio(a, b) {
  const l1 = lum(a), l2 = lum(b);
  const [hi, lo] = l1 >= l2 ? [l1, l2] : [l2, l1];
  return (hi + 0.05) / (lo + 0.05);
}
export function accentInk(accent) {
  return lum(accent) > 0.45 ? '#0B0B0D' : '#FFFFFF';
}

function resolveMode(m) {
  if (m === 'light' || m === 'dark') return m;
  return window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
}

export function currentPalette(appearance = {}) {
  const theme = appearance.theme || DEFAULT_APPEARANCE.theme;
  const mode = resolveMode(appearance.mode || DEFAULT_APPEARANCE.mode);
  const base = (THEMES[theme] || THEMES.focus).palettes[mode] || (THEMES[theme] || THEMES.focus).palettes.dark;
  const out = { ...base };
  if (theme === 'custom') {
    const c = appearance.custom || {};
    if (c.accent) out.accent = c.accent;
    if (c.accent2) out.accent2 = c.accent2;
    if (c.bg) out.bg = c.bg;
    if (c.surface) out.surface = c.surface;
    if (c.ink) out.ink = c.ink;
    if (c.muted) out.muted = c.muted;
    if (c.line) out.line = c.line;
    if (c.good) out.good = c.good;
    if (c.warn) out.warn = c.warn;
    if (c.danger) out.danger = c.danger;
    if (!c.surface) out.surface = mode === 'dark' ? mix(out.bg, '#ffffff', 0.09) : out.surface;
    if (!c.line) out.line = mode === 'dark' ? mix(out.bg, '#ffffff', 0.16) : mix(out.bg, '#000000', 0.14);
    out.surface2 = mix(out.surface, out.accent, mode === 'dark' ? 0.06 : 0.03);
    out.track = mix(out.accent, out.bg, 0.8);
  } else {
    out.track = mix(out.accent, out.bg, 0.8);
  }
  return out;
}

let prefersListener = null;
export function applyAppearance(appearance = {}) {
  const ap = { ...DEFAULT_APPEARANCE, ...appearance, custom: { ...(appearance.custom || {}) } };
  const mode = resolveMode(ap.mode);
  const pal = currentPalette(ap);
  pal.accent_ink = accentInk(pal.accent);
  const root = document.documentElement;
  root.setAttribute('data-mode', mode);
  root.setAttribute('data-inited', '1');
  for (const [k, v] of Object.entries(pal)) root.style.setProperty('--' + k, v);
  const scale = { sm: 0.92, md: 1, lg: 1.12 }[ap.textSize] || 1;
  root.style.setProperty('--text-scale', scale);
  const density = { compact: 0.88, comfortable: 1, spacious: 1.14 }[ap.density] || 1;
  root.style.setProperty('--density', density);
  const radiusBtn = { sharp: '8px', round: '14px', pill: '999px' }[ap.buttonStyle] || '999px';
  root.style.setProperty('--radius-btn', radiusBtn);
  root.classList.toggle('contrast', ap.contrast === 'high');
  root.classList.toggle('no-anim', ap.animations === false);
  emitThemeEvent(ap, pal, mode);
}

// El sistema reacciona al cambio automático claro/oscuro del sistema.
export function watchAutoTheme(appearanceRef) {
  if (prefersListener) window.removeEventListener('change', prefersListener);
  prefersListener = () => {
    const ap = { ...DEFAULT_APPEARANCE, ...appearanceRef() };
    if ((ap.mode || 'auto') === 'auto') applyAppearance(ap);
  };
  window.matchMedia('(prefers-color-scheme: light)').addEventListener('change', prefersListener);
}

const listeners = new Set();
export function onTheme(cb) { listeners.add(cb); return () => listeners.delete(cb); }
function emitThemeEvent(...args) { listeners.forEach(cb => { try { cb(...args); } catch { /* */ } }); }

// Chequea que el texto contra el fondo cumpla contraste (WCAG AA: >= 4.5).
export function contrastWarning(pal) {
  const ratio = contrastRatio(pal.ink, pal.bg);
  return ratio < 4.5 ? { ratio, ok: false } : { ratio, ok: true };
}