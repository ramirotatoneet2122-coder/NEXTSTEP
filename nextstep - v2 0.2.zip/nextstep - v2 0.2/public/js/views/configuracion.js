import { api, esc } from '../api.js';
import { toast, openModal, closeModal } from '../ui.js';
import { THEMES, THEME_LIST, applyAppearance, currentPalette, contrastWarning, DEFAULT_APPEARANCE } from '../themes.js';
import { store } from '../store.js';

let el;
let profile = null;
let appearance = {};
let preferences = {};
let settings = {};
let iaInfo = null;

export default {
  title: 'Configuración',
  async show(root) {
    el = root;
    root.innerHTML = '<div class="card"><div class="skeleton" style="height:140px"></div></div>';
    try { profile = await api('/api/profile'); } catch (e) { root.innerHTML = 'No pude cargar la configuración.'; return; }
    try { iaInfo = await api('/api/ia'); } catch { /* el servidor puede no reportar aún */ }
    preference_appearance_init();
    render();
  },
};

function preference_appearance_init() {
  preferences = { ...(profile.preferences || {}) };
  appearance = { ...DEFAULT_APPEARANCE, ...(profile.appearance || {}) };
  settings = { ...(profile.settings || {}) };
}

function render() {
  const labels = groupLabels();
  el.innerHTML = `
    <h1 class="h1 mb16">Configuración</h1>
    <div class="grid grid-main">${[cardProfile(), cardIa(), cardPrefs(labels), cardMethods(), cardAppearance(), cardSettings(), cardData()].join('')}</div>`;
  wireProfile();
  wirePrefs();
  wireMethods();
  wireAppearance();
  wireSettings();
  wireData();
}

function groupLabels() {
  return {
    explanationLength: { breve: 'Corta (respuestas al grano)', detallada: 'Detallada (a fondo)' },
    explanationLevel: { basica: 'Básica (sin tecnicismos)', intermedia: 'Intermedia', avanzada: 'Avanzada (términos técnicos)' },
    languageStyle: { simple: 'Lenguaje simple', tecnico: 'Lenguaje técnico' },
    examples: { practicos: 'Ejemplos prácticos', teoricos: 'Ejemplos teóricos' },
    sequence: { paso_a_paso: 'Paso a paso', panorama: 'Panorama general primero' },
    difficulty: { facil: 'Fácil', intermedio: 'Intermedio', avanzado: 'Desafiante' },
    practiceMix: { mas_practica: 'Más práctica', mas_explicacion: 'Más explicación' },
    hints: { progresivas: 'Pistas progresivas', directas: 'Pistas directas' },
    sessionLength: { corta: 'Sesiones cortas', prolongada: 'Sesiones largas' },
    pace: { tranquilo: 'Tranquilo', equilibrado: 'Equilibrado', intensivo: 'Intensivo' },
    teachingForm: { mas_ejemplos: 'Más ejemplos', mas_teoria: 'Más teoría', mas_ejercicios: 'Más ejercicios', equilibrado: 'Equilibrado' },
    correction: { pistas: 'Corregime con pistas', completa: 'Corregime explicando todo' },
    autonomy: { guiada: 'Preferís ir guiado', libre: 'Preferís libertad' },
    goalKind: { comprender: 'Comprender el tema', examen: 'Rendir un examen', habilidad: 'Aprender una habilidad', proyecto: 'Hacer un proyecto' },
    tone: { neutral: 'Tono neutral', cercano: 'Tono cercano', motivador: 'Tono motivador' },
  };
}

function cardProfile() {
  return `
  <div class="card">
    <h3 class="h2 mb8">Perfil</h3>
    <div class="field"><span class="flabel">Email</span><b>${esc(profile.user.email)}</b></div>
    <div class="field"><span class="flabel">Nombre (para que el profesor te llame)</span>
      <input class="input" id="pfNick" value="${esc(profile.nickname)}"></div>
    <button class="btn primary" data-ac="saveNick">Guardar</button>
  </div>`;
}

async function wireProfile() {
  el.querySelector('[data-ac="saveNick"]').addEventListener('click', async () => {
    const nickname = el.querySelector('#pfNick').value.trim();
    if (!nickname) return toast('Poné un nombre.', 'err');
    try {
      await api('/api/profile', { method: 'PATCH', body: { nickname } });
      store.me.profile.nickname = nickname;
      window.dispatchEvent(new CustomEvent('profile-updated', { detail: store.me }));
      toast('Perfil guardado', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  });
}

function cardIa() {
  const provs = (iaInfo?.providers && iaInfo.providers.length ? iaInfo.providers : store.ia.providers || []);
  const rows = provs.map(p => `
    <div class="between" style="padding:5px 0">
      <span><b>${esc(p.label)}</b> ${p.paused ? `<span class="tag pausada">en pausa por límite</span>` : ''}</span>
      <span class="tag ${p.ready ? 'activa' : 'dificultad'}">${p.ready ? (p.paused ? 'Pausada' : 'Lista') : 'Sin clave'}</span>
    </div>`).join('');
  const u = iaInfo?.usage;
  const usageTxt = u ? `${fmtInt((u.total_in || 0) + (u.total_out || 0))} tokens · ${u.calls} llamadas (30 días)` : '';
  return `
  <div class="card">
    <h3 class="h2 mb8">Inteligencia artificial</h3>
    <p class="sub" style="margin-bottom:10px">NEXTSTEP usa varias IA en cadena: si una se queda sin cupo o falla, sigue sola con la próxima.</p>
    ${iaInfo ? `<div class="stack" style="gap:0">${rows}</div><p class="sub" style="margin-top:8px">${usageTxt}</p>` : '<p class="sub">El servidor no reportó estado de la IA.</p>'}
  </div>`;
  function fmtInt(n) { n = Number(n) || 0; if (n < 1000) return String(n); if (n < 1e6) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'k'; return (n / 1e6).toFixed(1) + 'M'; }
}

function cardPrefs(labels) {
  const rows = Object.entries({
    explanationLength: 'Longitud de las respuestas',
    explanationLevel: 'Nivel de profundidad',
    languageStyle: 'Cómo explicarte',
    examples: 'Tipo de ejemplos',
    sequence: 'Cómo organizar el contenido',
    teachingForm: 'Formato preferido',
    practiceMix: 'Equilibrio práctica/teoría',
    difficulty: 'Dificultad de los ejercicios',
    hints: 'Cómo darte pistas',
    correction: 'Cómo corregirte',
    sessionLength: 'Duración de las sesiones',
    pace: 'Ritmo de avance',
    autonomy: 'Autonomía',
    tone: 'Tono',
  }).map(([k, label]) => `
    <div class="field"><span class="flabel">${label}</span>
      <select class="select" data-pref="${k}">${Object.entries(labels[k]).map(([v, l]) => `<option value="${v}" ${preferences[k] === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
    </div>`).join('');
  return `
  <div class="card">
    <h3 class="h2 mb8">Preferencias de aprendizaje</h3>
    <p class="sub" style="margin-bottom:10px">Esto cambia cómo te explica el profesor IA en cada respuesta.</p>
    ${rows}
  </div>`;
}

function wirePrefs() {
  el.querySelectorAll('[data-pref]').forEach(sel => sel.addEventListener('change', savePrefs));
  async function savePrefs() {
    el.querySelectorAll('[data-pref]').forEach(s => preferences[s.dataset.pref] = s.value);
    try {
      await api('/api/profile', { method: 'PATCH', body: { preferences } });
      store.me.profile.preferences = preferences;
      window.dispatchEvent(new CustomEvent('prefs-changed'));
      toast('Preferencias guardadas', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  }
}

function cardMethods() {
  const methods = ['preguntas', 'ejemplos', 'esquemas', 'resumenes', 'problemas'];
  const selected = preferences.methods || [];
  return `
  <div class="card">
    <h3 class="h2 mb8">Métodos que más te sirven</h3>
    <p class="sub" style="margin-bottom:10px">El profesor combina estos formatos en sus explicaciones.</p>
    <div class="chips">
      ${methods.map(m => `<button type="button" class="chip ${selected.includes(m) ? 'on' : ''}" data-method="${m}">${methodLabel(m)}</button>`).join('')}
    </div>
  </div>`;
  function methodLabel(m) { return { preguntas: '❓ Preguntas', ejemplos: '🧩 Ejemplos', esquemas: '🗺️ Esquemas', resumenes: '📝 Resúmenes', problemas: '🧮 Problemas' }[m] || m; }
}

function wireMethods() {
  el.querySelectorAll('[data-method]').forEach(b => b.addEventListener('click', async () => {
    b.classList.toggle('on');
    preferences.methods = [...el.querySelectorAll('[data-method].on')].map(x => x.dataset.method);
    try {
      await api('/api/profile', { method: 'PATCH', body: { preferences } });
      store.me.profile.preferences = preferences;
      window.dispatchEvent(new CustomEvent('prefs-changed'));
    } catch (e) { toast(e.message, 'err'); }
  }));
}

function cardAppearance() {
  const themes = THEME_LIST.map(t => {
    const hl = (THEMES[t].highlight || ['#888', '#ccc']);
    const sel = appearance.theme === t ? 'on' : '';
    const name = { focus: 'Enfoque', forest: 'Bosque', lavender: 'Lavanda', warm: 'Cálido', ocean: 'Océano', rose: 'Rosa', hc: 'Alto contraste', dafocus: 'Enfoque oscuro', light: 'Claro simple', custom: 'Personalizado' }[t] || t;
    return `<button type="button" class="theme-btn ${sel}" data-theme="${t}" title="${name}">
      <span class="th-1" style="background:${hl[0]}"></span><span class="th-2" style="background:${hl[1]}"></span>
      <span class="th-name">${name}</span></button>`;
  }).join('');
  const seg = (name, opts) => `<div class="seg" data-seg="${name}">${opts.map(([v, l]) => `<button type="button" class="segbtn ${appearance[name] === v || (!appearance[name] && v === DEFAULT_APPEARANCE[name]) ? 'on' : ''}" data-v="${v}">${l}</button>`).join('')}</div>`;
  return `
  <div class="card">
    <h3 class="h2 mb8">Apariencia</h3>
    <div class="field"><span class="flabel">Tema</span><div class="theme-grid">${themes}</div></div>
    <div class="field"><span class="flabel">Modo</span>${seg('mode', [['auto', 'Auto'], ['light', 'Claro'], ['dark', 'Oscuro']])}</div>
    <div class="field"><span class="flabel">Tipo de letra</span>${seg('textSize', [['sm', 'Chica'], ['md', 'Mediana'], ['lg', 'Grande']])}</div>
    <div class="field"><span class="flabel">Densidad</span>${seg('density', [['compact', 'Compacta'], ['comfortable', 'Cómoda'], ['spacious', 'Amplia']])}</div>
    <div class="field"><span class="flabel">Botones</span>${seg('buttonStyle', [['sharp', 'Rectos'], ['round', 'Redondeados'], ['pill', 'Píldora']])}</div>
    <div class="field"><span class="flabel">Contraste</span>${seg('contrast', [['normal', 'Normal'], ['high', 'Alto']])}</div>
    <label class="chk"><input type="checkbox" id="anims" ${appearance.animations !== false ? 'checked' : ''}> <span>Animaciones</span></label>
    <p class="sub" style="margin-top:8px" data-warn hidden></p>
  </div>`;
}

function wireAppearance() {
  el.querySelectorAll('[data-theme]').forEach(b => b.addEventListener('click', () => {
    el.querySelectorAll('[data-theme]').forEach(x => x.classList.remove('on'));
    b.classList.add('on');
    appearance.theme = b.dataset.theme;
    saveAppearance();
  }));
  el.querySelectorAll('[data-seg]').forEach(seg => seg.addEventListener('click', e => {
    const b = e.target.closest('[data-v]'); if (!b) return;
    seg.querySelectorAll('.segbtn').forEach(x => x.classList.remove('on'));
    b.classList.add('on');
    appearance[seg.dataset.seg] = b.dataset.v;
    saveAppearance();
  }));
  el.querySelector('#anims').addEventListener('change', e => { appearance.animations = e.target.checked; saveAppearance(); });
  async function saveAppearance() {
    applyAppearance(appearance);
    try {
      await api('/api/profile', { method: 'PATCH', body: { appearance } });
      store.me.profile.appearance = appearance;
      const pal = currentPalette(appearance);
      const w = contrastWarning(pal);
      const elw = el.querySelector('[data-warn]');
      if (elw) { elw.hidden = w.ok; if (!w.ok) elw.textContent = `⚠️ Contraste bajo (${w.ratio.toFixed(1)}:1). Probá el tema Alto contraste.`; }
      toast('Apariencia aplicada', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  }
}

function cardSettings() {
  const s = settings;
  const chk = 'chk';
  return `
  <div class="card">
    <h3 class="h2 mb8">Ajustes</h3>
    <label class="${chk}"><input type="checkbox" data-set="notifications" ${s.notifications ? 'checked' : ''}> <span>Recordatorios de estudio</span></label>
    <label class="${chk}"><input type="checkbox" data-set="privacy" ${s.privacy ? 'checked' : ''}> <span>No compartir datos de uso</span></label>
    <div class="field"><span class="flabel">Idioma de la app</span>
      <select class="select" data-set="language">
        <option value="es" ${s.language !== 'en' ? 'selected' : ''}>Español</option>
        <option value="en" ${s.language === 'en' ? 'selected' : ''}>English</option>
      </select></div>
  </div>`;
}
async function wireSettings() {
  el.querySelectorAll('[data-set]').forEach(c => c.addEventListener('change', async () => {
    el.querySelectorAll('[data-set]').forEach(x => {
      if (x.type === 'checkbox') settings[x.dataset.set] = x.checked;
      else settings[x.dataset.set] = x.value;
    });
    try { await api('/api/profile', { method: 'PATCH', body: { settings } }); toast('Ajustes guardados', 'ok'); }
    catch (e) { toast(e.message, 'err'); }
  }));
}

function cardData() {
  return `
  <div class="card" style="border-color:var(--line)">
    <h3 class="h2 mb8">Tus datos</h3>
    <p class="sub" style="margin-bottom:10px">Tenés derecho a llevar tus datos y a borrarlos.</p>
    <div class="row">
      <button class="btn soft" data-ac="export">⬇️ Exportar todo (JSON)</button>
      <button class="btn soft danger-b" data-ac="wipe">🗑 Borrar todos mis datos</button>
    </div>
    <p class="sub" style="margin-top:8px">Nivel ${profile.level} · ${profile.xp} XP · ${profile.streak} días de racha.</p>
  </div>`;
}
async function wireData() {
  el.querySelector('[data-ac="export"]').addEventListener('click', async () => {
    try {
      const data = await api('/api/profile/data');
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = 'nextstep-datos.json'; a.click();
      URL.revokeObjectURL(url);
      toast('Exportación lista', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  });
  el.querySelector('[data-ac="wipe"]').addEventListener('click', () => {
    const box = openModal(`<div class="modal-head"><h3>Borrar todos tus datos</h3><button class="mclose" type="button" data-mc>✕</button></div>
      <div class="modal-body">
        <p>Esto borra materias, chats, rutas, evaluaciones, objetivos, recursos y XP de forma permanente. No se puede deshacer.</p>
        <div class="field"><span class="flabel">Escribí <b>BORRAR</b> para confirmar</span>
          <input class="input" id="wipeConfirm" autocomplete="off"></div>
      </div>
      <div class="modal-foot"><button class="btn ghost" type="button" data-mc>Cancelar</button>
        <button class="btn primary" type="button" data-ok>Borrar todo</button></div>`, {
        onMount: b => b.querySelectorAll('[data-mc]').forEach(x => x.onclick = closeModal),
    });
    box.querySelector('[data-ok]').onclick = async () => {
      const v = box.querySelector('#wipeConfirm').value;
      if (v !== 'BORRAR') return toast('Escribí BORRAR tal cual.', 'err');
      box.querySelector('[data-ok]').disabled = true;
      try {
        await api('/api/profile/data', { method: 'DELETE', body: { confirm: 'BORRAR', all: 1 } });
        store.me = null;
        window.dispatchEvent(new CustomEvent('signout'));
        toast('Tus datos fueron borrados.', 'ok');
      } catch (e) { box.querySelector('[data-ok]').disabled = false; toast(e.message, 'err'); }
    };
  });
}