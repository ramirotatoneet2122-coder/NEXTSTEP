import { api, esc } from '../api.js';
import { toast, bar, empty, openModal, closeModal } from '../ui.js';
import { chrome, subjectOptions, loadSubjects, createEval, createPath, RANKS } from '../modals.js';
import { store } from '../store.js';

const EMOJIS = ['📐', '💻', '🌐', '☕', '📊', '🧮', '📚', '🎨', '🔬', '🌍', '🎵', '🏃', '🗣️', '💼', '⚙️', '🧠'];
const TOPIC_STATE = { pendiente: 'Pendiente', aprendiendo: 'Aprendiendo', dominado: 'Dominado', dificultad: 'A reforzar' };

let el;
let subjects = [];

export default {
  title: 'Mi aprendizaje',
  async show(root) {
    el = root;
    root.innerHTML = '<div class="card"><div class="skeleton" style="height:120px"></div></div>';
    try { subjects = await api('/api/subjects'); } catch (e) { root.innerHTML = empty('📚', 'No pude cargar tus materias.'); return; }
    render();
  },
};

function render() {
  const order = [...subjects.filter(s => s.status === 'activa'), ...subjects.filter(s => s.status !== 'activa')];
  el.innerHTML = `
    <div class="between mb8 wrap">
      <h1 class="h1">Mi aprendizaje</h1>
      <div class="row">
        <button class="btn soft" data-ac="addsubject">＋ Materia</button>
        <button class="btn soft" data-ac="addpath">🗺 Ruta</button>
        <button class="btn soft" data-ac="addeval">📝 Evaluación</button>
      </div>
    </div>
    ${subjects.length ? `<div class="grid cols2">${order.map(subjectCard).join('')}</div>` : `
      <div class="card pad center">
        ${empty('📚', 'Todavía no sumaste materias', 'Agregá la primera y armemos tu plan.')}
        <button class="btn primary" data-ac="addsubject">Agregar mi primera materia</button>
      </div>`}`;
  wire();
}

function subjectCard(s) {
  const topics = (s.topics || []);
  const chips = topics.length ? topics.slice(0, 8).map(t =>
    `<span class="chip t-${t.state}" title="${esc(TOPIC_STATE[t.state] || t.state)}">${esc(t.name)}</span>`).join('')
    : '<span class="muted">Sin temas registrados todavía.</span>';
  return `
  <div class="card">
    <div class="between">
      <div class="row" style="align-items:baseline">
        <span class="tsubj">${esc(s.emoji)}</span>
        <div>
          <b class="h2">${esc(s.name)}</b>
          <div class="row" style="margin-top:4px">
            ${s.current_level ? `<span class="chip">${esc(s.current_level)}</span>` : ''}
            ${s.status === 'activa' ? '' : `<span class="chip">${s.status === 'pausada' ? 'Pausada' : 'Finalizada'}</span>`}
          </div>
        </div>
      </div>
      <div style="text-align:right"><div class="label">Dominio</div>
        <b class="h2" style="color:var(--accent)">${Math.round(s.mastery)}%</b></div>
    </div>
    ${s.goal ? `<p class="muted" style="margin:8px 0">${esc(s.goal)}</p>` : ''}
    ${bar(s.mastery, 'grad')}
    <div class="chips" style="margin:12px 0">${chips}</div>
    <div class="row">
      <button class="btn tiny soft" data-ac="eval" data-sid="${s.id}">📝 Evaluar</button>
      <button class="btn tiny soft" data-ac="path" data-sid="${s.id}">🗺 Ruta</button>
      <button class="btn tiny soft" data-ac="chat" data-sid="${s.id}">💬 Practicar</button>
      <span style="flex:1"></span>
      <button class="iconbtn" data-ac="edit" data-sid="${s.id}" title="Editar">✏️</button>
      <button class="iconbtn danger" data-ac="del" data-sid="${s.id}" title="Borrar">🗑</button>
    </div>
  </div>`;
}

function wire() {
  el.querySelectorAll('[data-ac]').forEach(b => b.addEventListener('click', async () => {
    const ac = b.dataset.ac, sid = Number(b.dataset.sid) || null;
    if (ac === 'addsubject') openSubject();
    if (ac === 'addpath') createPath();
    if (ac === 'addeval') createEval();
    if (ac === 'eval') createEval(sid);
    if (ac === 'path') createPath(sid);
    if (ac === 'chat') { sessionStorage.setItem('ns_quick_subject', sid); location.hash = '#/chat'; }
    if (ac === 'edit') openSubject(subjects.find(s => s.id === sid));
    if (ac === 'del') {
      const s = subjects.find(x => x.id === sid);
      if (!confirm(`¿Borrar ${s?.name}? Se elimina todo lo relacionado.`)) return;
      try { await api('/api/subjects/' + sid, { method: 'DELETE' }); toast('Materia borrada', 'ok'); reload(); }
      catch (e) { toast(e.message, 'err'); }
    }
  }));
}

function openSubject(subject) {
  const isEdit = Boolean(subject);
  const cats = (store.meta.subjects || []).map(s => `<option value="${esc(s.key)}">${esc(s.emoji)} ${esc(s.name)}</option>`).join('');
  const catBlock = isEdit ? '' : `<div class="field"><span class="flabel">¿Es de la secundaria? Elegila del catálogo y se completa sola</span>
      <select class="select" data-cat>
        <option value="">— Elegí del catálogo (opcional) —</option>
        ${cats}
        <option value="__libre">✍️ Otra materia (la escribo yo, el profe la aprende)</option>
      </select></div>`;
  const box = chrome(isEdit ? 'Editar materia' : 'Nueva materia', `
    ${catBlock}
    <div class="field"><span class="flabel">Nombre *</span>
      <input class="input" data-f="name" value="${isEdit ? esc(subject.name) : ''}" placeholder="Ej.: Programación"></div>
    <div class="field"><span class="flabel">Nivel actual</span>
      <select class="select" data-f="level"><option value="">Sin especificar</option>
        ${RANKS.map(r => `<option ${isEdit && subject.current_level === r ? 'selected' : ''}>${r}</option>`).join('')}</select></div>
    <div class="field"><span class="flabel">Emoji</span>
      <div class="chips" data-emojis>${EMOJIS.map(e => `<button type="button" class="chip ${isEdit && subject.emoji === e ? 'on' : ''}" data-e="${e}">${e}</button>`).join('')}</div></div>
    <div class="field"><span class="flabel">Objetivo (opcional)</span>
      <input class="input" data-f="goal" value="${isEdit ? esc(subject.goal || '') : ''}" placeholder="¿Para qué estudiás esto?"></div>
    <div class="field"><span class="flabel">Temas que querés cubrir (opcional, separados por coma)</span>
      <textarea class="textarea" data-f="topics" rows="2" placeholder="Ej.: variables, bucles, funciones">${isEdit ? esc((subject.topics || []).map(t => t.name).join(', ')) : ''}</textarea></div>
    ${isEdit ? `<div class="field"><span class="flabel">Estado</span>
      <select class="select" data-f="status">
        <option value="activa" ${isEdit && subject.status === 'activa' ? 'selected' : ''}>Activa</option>
        <option value="pausada" ${isEdit && subject.status === 'pausada' ? 'selected' : ''}>Pausada</option>
        <option value="finalizada" ${isEdit && subject.status === 'finalizada' ? 'selected' : ''}>Finalizada</option>
      </select></div>` : ''}`, isEdit ? 'Guardar cambios' : 'Agregar materia');

  let emoji = isEdit ? subject.emoji : '📐';
  box.querySelectorAll('[data-e]').forEach(c => c.onclick = () => {
    box.querySelectorAll('[data-e]').forEach(x => x.classList.remove('on'));
    c.classList.add('on'); emoji = c.dataset.e;
  });
  box.querySelector('[data-cat]').onchange = () => {
    const key = box.querySelector('[data-cat]').value;
    if (!key || key === '__libre') return;
    const cat = (store.meta.subjects || []).find(s => s.key === key);
    if (!cat) return;
    box.querySelector('[data-f="name"]').value = cat.name;
    emoji = cat.emoji;
    box.querySelectorAll('[data-e]').forEach(x => x.classList.toggle('on', x.dataset.e === emoji));
    box.querySelector('[data-f="topics"]').value = (cat.topics || []).join(', ');
    box.querySelector('[data-f="name"]').focus();
  };
  box.querySelector('[data-ok]').onclick = async () => {
    const name = box.querySelector('[data-f="name"]').value.trim();
    if (!name) return toast('Poné el nombre.', 'err');
    const payload = { name, emoji, current_level: box.querySelector('[data-f="level"]').value, goal: box.querySelector('[data-f="goal"]').value.trim() };
    if (isEdit) payload.status = box.querySelector('[data-f="status"]').value;
    try {
      if (isEdit) await api('/api/subjects/' + subject.id, { method: 'PATCH', body: payload });
      else {
        payload.topics = box.querySelector('[data-f="topics"]').value;
        await api('/api/subjects', { method: 'POST', body: payload });
      }
      closeModal(); toast(isEdit ? 'Guardado' : 'Materia creada', 'ok'); reload();
    } catch (e) { toast(e.message, 'err'); }
  };
}

async function reload() {
  subjects = await api('/api/subjects').catch(() => []);
  render();
}