import { api, esc, fmtDate } from '../api.js';
import { toast, bar, empty, barchart, stat } from '../ui.js';

let el;

export default {
  title: 'Estadísticas',
  async show(root) {
    el = root;
    root.innerHTML = '<div class="card"><div class="skeleton" style="height:160px"></div></div>';
    let s;
    try { s = await api('/api/stats'); } catch (e) { root.innerHTML = empty('📊', 'No pude cargar tus estadísticas.', e.message); return; }
    render(s);
  },
};

function dayLabel(day) { return day ? day.slice(8, 10) + '/' + day.slice(5, 7) : ''; }

function render(s) {
  const p = s.profile;
  const kindLabel = { ruta: 'Ruta', evaluacion: 'Evaluación', objetivo: 'Objetivo', chat: 'Estudio' };
  const xp = (s.xp_by_day || []).map(x => ({ day: dayLabel(x.day), value: Number(x.xp) }));
  const week = (s.week_minutes || []).map(x => ({ day: dayLabel(x.day), value: Number(x.minutes) }));
  const month = (s.month_minutes || []).map(x => ({ day: dayLabel(x.day), value: Number(x.minutes) }));

  el.innerHTML = `
    <h1 class="h1 mb16">Estadísticas</h1>
    <div class="statgrid">
      ${stat('⭐', p.xp, 'XP totales')}
      ${stat('🚀', p.level, 'Nivel')}
      ${stat('🔥', p.streak, 'Racha actual')}
      ${stat('🏆', p.best_streak, 'Mejor racha')}
      ${stat('⌛', fmtMin(p.total_minutes), 'Tiempo estudiado')}
      ${stat('✅', `${s.overall.correct}/${s.overall.activities}`, 'Aciertos / actividades')}
    </div>

    <div class="grid cols2 mb16">
      <div class="card"><h3 class="h2 mb8">XP (últimos 14 días)</h3>
        ${xp.length ? barchart(xp, { fmt: v => v + ' XP' }) : empty('⭐', 'Sin XP registrado todavía')}</div>
      <div class="card"><h3 class="h2 mb8">Minutos esta semana</h3>
        ${week.length ? barchart(week, { fmt: v => v + ' min' }) : empty('⌛', 'Sin sesiones esta semana')}</div>
    </div>

    <div class="card mb16"><h3 class="h2 mb8">Minutos (últimos 30 días)</h3>
      ${month.length ? barchart(month, { fmt: v => v + ' min', height: 140 }) : empty('📅', 'Sin datos del mes')}</div>

    <div class="grid cols2 mb16">
      <div class="card"><h3 class="h2 mb8">Dominio por materia</h3>
        ${s.subjects.length ? s.subjects.map(x => `
          <div class="mb8"><div class="between"><span>${esc(x.name)} ${x.level ? `<span class="chip">${esc(x.level)}</span>` : ''}</span><b class="pct">${Math.round(x.mastery)}%</b></div>${bar(x.mastery, 'grad')}</div>`).join('')
        : empty('📚', 'Sin materias todavía')}</div>
      <div class="card"><h3 class="h2 mb8">Historial de evaluaciones</h3>
        ${s.evaluations.length ? s.evaluations.map(e => `
          <div class="listrow" style="cursor:default"><span>${e.score >= 60 ? '✅' : '⚠️'}</span>
            <span style="flex:1;min-width:0"><b>${esc(e.title || (e.kind === 'inicial' ? 'Diagnóstica' : 'Seguimiento'))}</b>
            <small class="muted">${fmtDate(e.created_at)}</small></span>
            <b class="pct">${e.score == null ? '—' : Math.round(e.score) + '%'}</b></div>`).join('')
        : empty('📝', 'Sin evaluaciones hechas')}</div>
    </div>

    <div class="grid cols2 mb16">
      <div class="card"><h3 class="h2 mb8">Aciertos por tipo</h3>
        <div class="chips">${Object.entries(s.correct_by_kind || {}).map(([k, v]) => `<span class="chip">${esc(kindLabel[k] || k)}: <b>${v}</b></span>`).join('') || '<span class="muted">Sin datos.</span>'}</div>
        <h3 class="h2 mb8" style="margin-top:16px">Fortalezas</h3>
        <div class="chips">${s.strengths.length ? s.strengths.map(x => `<span class="chip t-dominado">${esc(x)}</span>`).join('') : '<span class="muted">Aún sin fortalezas marcadas.</span>'}</div>
        <h3 class="h2 mb8" style="margin-top:16px">Para reforzar</h3>
        <div class="chips">${s.needs_refuerzo.length ? s.needs_refuerzo.map(x => `<span class="chip t-dificultad">${esc(x)}</span>`).join('') : '<span class="muted">Nada pendiente. 👌</span>'}</div>
      </div>
      <div class="card"><h3 class="h2 mb8">Logros (${s.achievements.length})</h3>
        ${s.achievements.length ? `<div class="grid ach">${s.achievements.map(a => `
          <div class="ach-item"><span class="medal">🏅</span><div><b>${esc(a.title)}</b><small class="muted">${esc(a.description || '')}</small>
          <small class="muted">· ${fmtDate(a.earned_at)}</small></div></div>`).join('')}</div>`
        : empty('🏅', 'Todavía no desbloqueaste logros')}</div>
    </div>

    <div class="card"><h3 class="h2 mb8">Actividad reciente</h3>
      ${s.recent_activities.length ? `<div class="stack">${s.recent_activities.map(a => `
        <div class="listrow" style="cursor:default"><span>${a.correct === 1 ? '✅' : a.correct === 0 ? '❌' : '•'}</span>
          <span style="flex:1;min-width:0"><b>${esc(a.title)}</b><small class="muted">${esc(kindLabel[a.kind] || a.kind)} · ${fmtDate(a.created_at)}</small></span>
          <span class="chip">+${a.xp} XP</span></div>`).join('')}</div>`
      : empty('🕓', 'Sin actividad todavía')}</div>`;
}

function fmtMin(min) {
  min = Number(min) || 0;
  if (min < 60) return `${min}m`;
  return `${Math.round(min / 6) / 10}h`;
}