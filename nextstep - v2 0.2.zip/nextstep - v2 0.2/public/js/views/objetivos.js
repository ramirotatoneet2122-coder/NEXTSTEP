import { api, esc, fmtDate } from '../api.js';
import { toast, bar, empty, closeModal } from '../ui.js';
import { chrome, loadSubjects, subjectOptions } from '../modals.js';

let el;

export default {
  title: 'Objetivos',
  async show(root) {
    el = root;
    root.innerHTML = '<div class="card"><div class="skeleton" style="height:120px"></div></div>';
    let goals;
    try { goals = await api('/api/goals'); } catch (e) { root.innerHTML = empty('🎯', 'No pude cargar tus objetivos.', e.message); return; }
    render(goals);
  },
};

async function render(goals) {
  const subjects = await loadSubjects().catch(() => []);
  const nameOf = sid => subjects.find(s => s.id === sid)?.name || '';
  const active = goals.filter(g => g.status === 'activo');
  const rest = goals.filter(g => g.status !== 'activo');
  el.innerHTML = `
    <div class="between mb8 wrap">
      <h1 class="h1">Objetivos</h1>
      <button class="btn primary" data-ac="new">＋ Nuevo objetivo</button>
    </div>
    <p class="sub mb16">Metas con plazo y pasos concretos. Al completar cada tarea suena el progreso.</p>
    ${[...active, ...rest].length ? `
      <div class="grid cols2">${[...active, ...rest].map(g => goalCard(g, nameOf(g.subject_id))).join('')}</div>`
      : `<div class="card pad center">${empty('🎯', 'Sin objetivos todavía', 'Por ejemplo: "rendir el examen de JavaScript en 3 semanas".')}
        <button class="btn primary" data-ac="new">Crear mi primer objetivo</button></div>`}`;
  wire(goals);
}

function goalCard(g, subjName) {
  const overdue = g.status === 'activo' && g.due_date && g.due_date.slice(0, 10) < new Date().toISOString().slice(0, 10);
  return `
  <div class="card">
    <div class="between">
      <div>
        <b class="h2">${esc(g.title)}</b>
        <div class="row" style="margin-top:4px">
          ${subjName ? `<span class="chip">${esc(subjName)}</span>` : ''}
          <span class="chip ${overdue ? 't-warn' : ''}">${g.due_date ? `Vence ${fmtDate(g.due_date)}${overdue ? ' ⚠️' : ''}` : 'Sin plazo'}</span>
        </div>
      </div>
      ${g.status === 'logrado' ? '<span class="tag dominado">Logrado 🏅</span>' : g.status === 'cancelado' ? '<span class="tag pendiente">Cancelado</span>' : ''}
    </div>
    ${g.description ? `<p class="muted" style="margin:8px 0">${esc(g.description)}</p>` : ''}
    <div class="between mb8"><span class="sub">Progreso</span><b class="pct">${g.progress}%</b></div>
    ${bar(g.progress, g.status === 'logrado' ? 'done' : 'grad')}
    <div class="tasks">${(g.tasks || []).map(t => `
      <label class="task ${t.done ? 'done' : ''}">
        <input type="checkbox" data-task="${t.id}" ${t.done ? 'checked' : ''} ${g.status === 'logrado' ? 'disabled' : ''}> <span>${esc(t.title)}</span>
        ${t.done ? '<small class="muted">· hecha</small>' : ''}
        <span style="flex:1"></span>
        <button class="iconbtn danger mini" type="button" data-dtask="${t.id}" title="Quitar tarea" ${g.status === 'logrado' ? 'disabled' : ''}>✕</button>
      </label>`).join('')}</div>
    <div class="row" style="margin-top:10px">
      <input class="input tiny" data-addtask="${g.id}" placeholder="Agregar una tarea…">
      <button class="btn tiny" data-oktask="${g.id}" ${g.status === 'logrado' ? 'disabled' : ''}>＋</button>
      <span style="flex:1"></span>
      ${g.status === 'activo' ? `<button class="btn tiny soft" data-cc="${g.id}">Cancelar</button>` : ''}
      <button class="iconbtn danger" data-dgoal="${g.id}" title="Borrar objetivo">🗑</button>
    </div>
  </div>`;
}

async function wire(goals) {
  el.querySelector('[data-ac="new"]')?.addEventListener('click', openNew);
  el.querySelectorAll('[data-task]').forEach(c => c.addEventListener('change', async () => {
    const tid = Number(c.dataset.task);
    try {
      await api('/api/goals/tasks/' + tid, { method: 'PATCH', body: { done: c.checked } });
      const fresh = await api('/api/goals'); render(fresh);
      window.dispatchEvent(new CustomEvent('profile-updated'));
    } catch (e) { toast(e.message, 'err'); c.checked = !c.checked; }
  }));
  el.querySelectorAll('[data-dtask]').forEach(b => b.addEventListener('click', async () => {
    try { await api('/api/goals/tasks/' + b.dataset.dtask, { method: 'DELETE' }); const fresh = await api('/api/goals'); render(fresh); }
    catch (e) { toast(e.message, 'err'); }
  }));
  el.querySelectorAll('[data-oktask]').forEach(b => b.addEventListener('click', async () => {
    const title = el.querySelector(`[data-addtask="${b.dataset.oktask}"]`).value.trim();
    if (!title) return;
    try { await api('/api/goals/' + b.dataset.oktask + '/tasks', { method: 'POST', body: { title } }); const fresh = await api('/api/goals'); render(fresh); }
    catch (e) { toast(e.message, 'err'); }
  }));
  el.querySelectorAll('[data-addtask]').forEach(inp => inp.addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); el.querySelector(`[data-oktask="${inp.dataset.addtask}"]`)?.click(); }
  }));
  el.querySelectorAll('[data-dgoal]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm('¿Borrar este objetivo y sus tareas?')) return;
    try { await api('/api/goals/' + b.dataset.dgoal, { method: 'DELETE' }); const fresh = await api('/api/goals'); render(fresh); toast('Objetivo borrado', 'ok'); }
    catch (e) { toast(e.message, 'err'); }
  }));
  el.querySelectorAll('[data-cc]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm('¿Cancelar este objetivo?')) return;
    try { await api('/api/goals/' + b.dataset.cc, { method: 'PATCH', body: { status: 'cancelado' } }); const fresh = await api('/api/goals'); render(fresh); }
    catch (e) { toast(e.message, 'err'); }
  }));
}

function openNew() {
  loadSubjects().then(subjects => {
    const box = chrome('Nuevo objetivo', `
      <div class="field"><span class="flabel">Qué querés lograr *</span>
        <input class="input" data-f="title" placeholder="Ej.: terminar el módulo de arrays"></div>
      <div class="picker-row">
        <div class="field"><span class="flabel">Materia</span>${subjectOptions(subjects, 0, false)}</div>
        <div class="field"><span class="flabel">Para cuándo</span><input class="input" type="date" data-f="due"></div>
      </div>
      <div class="field"><span class="flabel">Por qué / descripción (opcional)</span>
        <textarea class="textarea" data-f="desc" rows="2"></textarea></div>
      <div class="field"><span class="flabel">Pasos (uno por línea)</span>
        <textarea class="textarea" data-f="tasks" rows="4" placeholder="Repasar apuntes&#10;Hacer 5 ejercicios&#10;Evaluación de práctica"></textarea></div>`, 'Crear objetivo');
    box.querySelector('[data-ok]').onclick = async () => {
      const title = box.querySelector('[data-f="title"]').value.trim();
      if (!title) return toast('Poné el título.', 'err');
      const tasks = box.querySelector('[data-f="tasks"]').value.split('\n').map(s => s.trim()).filter(Boolean);
      try {
        await api('/api/goals', { method: 'POST', body: {
          title,
          subject_id: Number(box.querySelector('[data-sel="subject"]').value) || null,
          due_date: box.querySelector('[data-f="due"]').value || null,
          description: box.querySelector('[data-f="desc"]').value.trim(),
          tasks,
        } });
        closeModal();
        el.innerHTML = '<div class="card"><div class="skeleton" style="height:120px"></div></div>';
        const fresh = await api('/api/goals');
        render(fresh);
        toast('Objetivo creado', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
  });
}