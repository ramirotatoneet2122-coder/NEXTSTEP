import { api, esc, fmtDate } from '../api.js';
import { toast, empty } from '../ui.js';
import { loadSubjects } from '../modals.js';

let el;
let params = {};

export default {
  title: 'Evaluaciones',
  async show(root, p) {
    el = root; params = p || {};
    if (params.id) await showDetail();
    else await showList();
  },
};

async function showList() {
  el.innerHTML = '<div class="stack"><div class="card"><div class="skeleton" style="height:120px"></div></div></div>';
  let evals, subjects;
  try { [evals, subjects] = await Promise.all([api('/api/evaluations'), loadSubjects()]); }
  catch (e) { el.innerHTML = empty('📝', 'No pude cargar tus evaluaciones.', e.message); return; }
  const nameOf = sid => subjects.find(s => s.id === sid)?.name || '';
  const emojOf = sid => subjects.find(s => s.id === sid)?.emoji || '📘';
  const pending = evals.filter(e => e.status === 'en_curso');
  const done = evals.filter(e => e.status === 'completada');

  const pendingHTML = pending.length ? pending.map(e => `
    <div class="card between">
      <div class="row"><span style="font-size:1.4rem">${emojOf(e.subject_id)}</span>
        <div>
          <b>${esc(emojOf(e.subject_id))} ${esc(nameOf(e.subject_id))} · ${e.kind === 'inicial' ? 'Diagnóstica inicial' : 'Seguimiento'}</b>
          <p class="muted">Creada el ${fmtDate(e.created_at)}</p>
        </div></div>
      <a class="btn primary" href="#/evaluaciones/${e.id}">Continuar →</a>
    </div>`).join('') : '';

  const doneHTML = done.length ? done.map(e => `
    <a class="card hover listrow" href="#/evaluaciones/${e.id}">
      <div class="row" style="flex:1;min-width:0">
        <span class="tsubj">${emojOf(e.subject_id)}</span>
        <div style="flex:1;min-width:0">
          <b style="display:block">${esc(nameOf(e.subject_id)) || 'Evaluación'} <span class="chip ${e.kind === 'inicial' ? 't-ia' : ''}">${e.kind === 'inicial' ? 'Inicial' : 'Seguimiento'}</span></b>
          <small class="muted">${e.title ? esc(e.title) : 'Corregida el ' + fmtDate(e.completed_at)} · ${e.source === 'ia' ? 'generada con IA' : 'banco verificado'}</small>
        </div>
      </div>
      <div class="row"><b class="pct">${Math.round(e.score ?? 0)}%</b><span style="color:var(--accent)">→</span></div>
    </a>`).join('') : '';

  el.innerHTML = `
    <div class="between mb8 wrap">
      <h1 class="h1">Evaluaciones</h1>
      <button class="btn primary" data-ac="new">＋ Nueva evaluación</button>
    </div>
    ${pending.length ? `<h3 class="h2 mb8">En curso</h3><div class="stack">${pendingHTML}</div>` : ''}
    ${done.length ? `<h3 class="h2 mb8" style="margin-top:20px">Corregidas</h3><div class="stack">${doneHTML}</div>` : empty('📝', 'Todavía no hiciste ninguna evaluación', 'Medirá tu nivel con preguntas reales.')}`;
  el.querySelector('[data-ac="new"]')?.addEventListener('click', () => import('../modals.js').then(m => m.createEval()));
}

async function showDetail() {
  el.innerHTML = '<div class="card"><div class="skeleton" style="height:140px"></div></div>';
  let ev;
  try { ev = await api('/api/evaluations/' + params.id); }
  catch (e) { el.innerHTML = empty('📝', 'No encontré esa evaluación.', e.message); return; }
  const subjects = await loadSubjects().catch(() => []);
  const subj = subjects.find(s => s.id === ev.subject_id);
  const items = ev.items || [];

  if (ev.status === 'en_curso') renderTake(ev, subj, items);
  else renderResult(ev, subj, items);
}

function renderTake(ev, subj, items) {
  el.innerHTML = `
    <a href="#/evaluaciones" class="sub">← Evaluaciones</a>
    <div class="card mb16">
      <div class="between wrap"><div class="row"><span class="tsubj">${esc(subj?.emoji || '📘')}</span>
        <div><b class="h1">${esc(subj?.name || 'Evaluación')}</b>
        <p class="sub">${ev.kind === 'inicial' ? 'Diagnóstica inicial' : 'De seguimiento'} · ${items.length} preguntas</p></div></div>
        <span class="tag en_curso">En curso</span></div>
    </div>
    <form id="evalForm" class="stack">
      ${items.map((it, i) => `
      <div class="card qcard" data-item="${it.id}">
        <div class="between"><b>${i + 1}. ${esc(it.question)}</b>
          <span class="chip t-dif${it.difficulty}">Dificultad ${'●'.repeat(it.difficulty || 1)}${'○'.repeat(3 - (it.difficulty || 1))}</span></div>
        ${it.options ? `
          <div class="stack" style="margin-top:10px">
            ${it.options.map((o, oi) => `<label class="opt"><input type="radio" name="q_${it.id}" value="${oi}"> <span>${esc(o)}</span></label>`).join('')}
          </div>
          <p class="err" hidden>Elegí una opción para continuar.</p>`
        : `<div class="field mt"><span class="flabel">Tu respuesta</span>
            <textarea class="textarea" data-text="${it.id}" rows="2" placeholder="Escribí la respuesta en una o dos líneas…"></textarea>
            <p class="err" hidden>Escribí tu respuesta.</p></div>`}
      </div>`).join('')}
      <button class="btn primary block" type="submit">Terminar y corregir</button>
    </form>`;
  el.querySelector('#evalForm').addEventListener('submit', async e => {
    e.preventDefault();
    const answers = {};
    let ok = true;
    items.forEach(it => {
      if (it.options) {
        const r = el.querySelector(`input[name="q_${it.id}"]:checked`);
        if (!r) { ok = false; el.querySelector(`[data-item="${it.id}"] .err`).hidden = false; }
        else answers[it.id] = Number(r.value);
      } else {
        const v = el.querySelector(`[data-text="${it.id}"]`).value.trim();
        if (!v) { ok = false; el.querySelector(`[data-item="${it.id}"] .err`).hidden = false; }
        else answers[it.id] = v;
      }
    });
    if (!ok) { toast('Completá todas las preguntas.', 'err'); return; }
    try {
      const r = await api('/api/evaluations/' + ev.id + '/submit', { method: 'POST', body: { answers } });
      sessionStorage.setItem('ns_eval_result', JSON.stringify(r));
      showDetail();
    } catch (err) { toast(err.message, 'err'); }
  });
}

function renderResult(ev, subj, items) {
  const saved = JSON.parse(sessionStorage.getItem('ns_eval_result') || 'null');
  sessionStorage.removeItem('ns_eval_result');
  const result = saved || { score: ev.score, correct: items.filter(i => i.is_correct === 1).length, mastery: null, summary: ev.summary, weak_topics: [], xp: { earned: 0 } };
  const pct = Math.round(result.score ?? 0);
  el.innerHTML = `
    <a href="#/evaluaciones" class="sub">← Evaluaciones</a>
    <div class="card pad-lg center mb16">
      <div class="donut" style="background:conic-gradient(var(--accent) ${pct * 3.6}deg, var(--track) 0deg);margin:0 auto"><div class="donut-hole"><b>${pct}%</b></div></div>
      <h2 class="h1" style="margin-top:10px">${result.badge ? esc(result.badge) + ' · ' : ''}${result.score >= 60 ? '¡Bien! 👏' : 'Seguí practicando 💪'}</h2>
      <p class="sub">${esc(result.summary || ev.summary || '')}</p>
      <div class="row center" style="justify-content:center;flex-wrap:wrap">
        <span class="chip">Correctas: <b>${result.correct}/${items.length}</b></span>
        ${result.mastery != null ? `<span class="chip">Dominio de la materia: <b>${result.mastery}%</b></span>` : ''}
        <span class="chip">+${result.xp?.earned || 0} XP</span>
      </div>
      ${(result.weak_topics && result.weak_topics.length) ? `<p class="muted" style="margin-top:8px">Para reforzar: ${result.weak_topics.map(esc).join(', ')}</p>` : ''}
    </div>
    <h3 class="h2 mb8">Tus respuestas</h3>
    <div class="stack">
      ${items.map((it, i) => reviewCard(ev, it, i + 1)).join('')}
    </div>`;
}

function reviewCard(ev, it, n) {
  const opts = it.options || [];
  const userIdx = it.answer_idx;
  const userHtml = it.options ? (userIdx != null && opts[userIdx] ? esc(opts[userIdx]) : '<em>Sin responder</em>') : esc(it.answer_text || 'Sin responder');
  const correctHtml = it.options ? esc(opts[it.correct_idx] ?? '') : esc(it.correct_text || '');
  const state = it.is_correct === 1 ? 'correcta' : it.is_correct === 0 ? 'incorrecta' : 'sinresponder';
  return `
  <div class="card qcard">
    <div class="between"><b>${n}. ${esc(it.question)}</b>${stateIcon(state)}</div>
    <div class="row" style="align-items:flex-start;margin-top:10px;gap:8px;flex-wrap:wrap">
      <div style="flex:1;min-width:180px"><span class="label">Tu respuesta</span><p class="ans ${state}">${userHtml}</p></div>
      <div style="flex:1;min-width:180px"><span class="label">Correcta</span><p class="ans correcta">${correctHtml}</p></div>
    </div>
    ${it.topic ? `<div class="chips" style="margin-top:8px"><span class="chip">Tema: ${esc(it.topic)}</span></div>` : ''}
    ${it.explanation ? `<p class="sub" style="margin-top:8px;color:var(--good)">💡 ${esc(it.explanation)}</p>` : ''}
  </div>`;
  function stateIcon(s) {
    if (s === 'correcta') return '<span class="tag dominado">✓ Correcta</span>';
    if (s === 'incorrecta') return '<span class="tag dificultad">✗ Incorrecta</span>';
    return '<span class="tag pendiente">Sin responder</span>';
  }
}