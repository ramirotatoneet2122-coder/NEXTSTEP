import { api, esc, fmtDate } from '../api.js';
import { bar, stat, empty, barchart } from '../ui.js';

function levelProgress(xp, level) {
  const prev = 100 * (level - 1) * (level - 1);
  const cur = 100 * level * level;
  return { pct: Math.round((xp - prev) / Math.max(1, (cur - prev)) * 100), toNext: cur - xp };
}
function greeting() {
  const h = new Date().getHours();
  if (h < 6) return 'Buenas noches';
  if (h < 12) return 'Buenos días';
  if (h < 19) return 'Buenas tardes';
  return 'Buenas noches';
}
function nextCta(next) {
  if (!next) return null;
  const href = next.type === 'ruta' ? `#/rutas/${next.path_id || ''}` : next.type === 'evaluacion' ? '#/evaluaciones' : next.type === 'repaso' ? '#/aprendizaje' : '#/objetivos';
  const text = next.type === 'ruta' ? `Seguir con "${esc(next.title)}"` : next.type === 'evaluacion' ? 'Hacer una evaluación' : 'Ir a verlo';
  return `<a class="btn primary" href="${href}">${text} →</a>`;
}

export default {
  title: 'Inicio',
  async show(el) {
    el.innerHTML = '<div class="stack">' + Array.from({ length: 4 }).map(() => '<div class="card"><div class="skeleton" style="height:120px"></div></div>').join('') + '</div>';
    let d;
    try { d = await api('/api/dashboard'); }
    catch (e) { el.innerHTML = `<div class="empty">😕<b>No pude cargar tu inicio.</b><span class="sub">${esc(e.message || '')}</span><button class="btn mt" data-action="reload">Reintentar</button></div>`; return; }
    const p = d.profile;
    const lp = levelProgress(p.xp, p.level);
    const today = new Date().toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long' });

    const subjects = d.subjects.length ? d.subjects.filter(s => s.status === 'activa').slice(0, 5).map(s => `
      <div class="mb8">
        <div class="between mb8"><span><b>${esc(s.emoji)} ${esc(s.name)}</b> ${s.current_level ? `<span class="tag">${esc(s.current_level)}</span>` : ''}</span><b class="pct">${Math.round(s.mastery)}%</b></div>
        ${bar(s.mastery, 'grad')}
        ${s.goal ? `<p class="sub" style="margin-top:6px">${esc(s.goal)}</p>` : ''}
      </div>`).join('') : empty('📚', 'Todavía no tenés materias', 'Agregá tu primera materia en "Mi aprendizaje".');

    const goals = d.goals.length ? d.goals.slice(0, 4).map(g => `
      <a class="listrow" href="#/objetivos">
        <span style="flex:1;min-width:0"><b style="display:block">${esc(g.title)}</b>
        <small class="muted">${g.due_date ? 'Para el ' + esc(g.due_date.slice(0,10)) : 'Sin fecha límite'} · avance ${g.progress}%</small></span>
        <span class="pct">${g.progress}%</span>
      </a>`).join('') : empty('🎯', 'Sin objetivos activos', 'Creá uno en "Objetivos".');

    const weekLbl = { 0: 'D', 1: 'L', 2: 'M', 3: 'M', 4: 'J', 5: 'V', 6: 'S' };
    const emptyWeek = Array.from({ length: 7 }, (_, i) => { const dt = new Date(); dt.setDate(dt.getDate() - (6 - i)); return { day: weekLbl[dt.getDay()], value: 0 }; });
    const byDay = {};
    d.minutes_by_day.forEach(x => { byDay[x.day] = Number(x.minutes); });
    const week = emptyWeek.map(x => ({ ...x, value: byDay[x.day] || 0 }));

    const active = d.studied_today ? 'Ya estudiaste hoy 💪' : 'Todavía no estudiaste hoy. ¡10 minutos alcanzan para arrancar!';

    el.innerHTML = `
    <div class="grid grid-main">
      <div class="stack">
        <div class="card pad-lg">
          <div class="between">
            <div>
              <p class="label" style="text-transform:capitalize">${esc(today)}</p>
              <h2 class="h1" style="margin:4px 0 6px">${greeting()}, ${esc(p.nickname.split(' ')[0])} 👋</h2>
              <p class="sub">${active}</p>
            </div>
            <div style="display:flex;gap:14px;align-items:center">
              <a class="btn soft sm" href="#/chat">💬 Profesor</a>
              <div class="center"><div class="label">Racha</div><b class="h1" style="color:var(--warn)">${p.streak}🔥</b></div>
              <div class="center"><div class="label">Nivel</div><b class="h1" style="color:var(--accent)">${p.level}</b></div>
            </div>
          </div>
          <div class="mt">
            <div class="between mb8"><span class="sub">Experiencia · nivel ${p.level}</span>
              <span class="sub"><b>${p.xp} XP</b> · te faltan ${lp.toNext} para el ${p.level + 1}</span></div>
            ${bar(lp.pct, 'grad')}
          </div>
        </div>

        <div class="statgrid">
          ${stat('⌛', fmtMin(p.total_minutes), 'tiempo estudiado')}
          ${stat('🔥', p.streak, 'días seguidos')}
          ${stat('✅', d.stats.total_activities, 'actividades')}
          ${stat('📝', d.stats.evaluations, 'evaluaciones')}
        </div>

        <div class="card between">
          <div>
            <p class="label">Próxima actividad</p>
            ${d.next_activity ? `<b style="display:block;margin:4px 0">${esc(d.next_activity.title)}</b>
              <small class="muted">${esc(d.next_activity.module || '')}</small>` : '<b>Todo al día 🎉</b>'}
          </div>
          ${nextCta(d.next_activity) || `<a class="btn primary" href="#/chat">Empezar a estudiar →</a>`}
        </div>

        <div class="card">
          <div class="between mb8"><h3 class="h2">Recomendaciones de tu profesor</h3></div>
          ${d.recommendations.length ? d.recommendations.map(r => `<div class="listrow" style="cursor:default">
            <span>${r.kind === 'ruta' ? '🗺' : r.kind === 'evaluacion' ? '📝' : r.kind === 'repaso' ? '🔁' : '🎯'}</span>
            <span style="flex:1">${esc(r.text)}</span></div>`).join('') : empty('💡', 'Sin recomendaciones por ahora')}
        </div>

        ${d.last_conversation ? `<a class="card hover listrow" href="#/chat/${d.last_conversation.id}" style="align-items:flex-start">
          <span style="font-size:1.3rem">💬</span>
          <span style="flex:1;min-width:0"><span class="label">Continuar tu última sesión</span>
          <b style="display:block;margin:3px 0">${esc(d.last_conversation.title)}</b>
          <small class="muted">${d.last_conversation.summary ? esc(d.last_conversation.summary.slice(0, 90)) + '…' : 'Actualizada ' + fmtDate(d.last_conversation.updated_at)}</small></span>
          <span style="color:var(--accent)">→</span></a>` : ''}
      </div>

      <div class="stack">
        <div class="card">
          <div class="between mb8"><h3 class="h2">Tus materias</h3><a href="#/aprendizaje" class="sub">Ver todo →</a></div>
          ${subjects}
        </div>
        <div class="card">
          <div class="between mb8"><h3 class="h2">Objetivos activos</h3><a href="#/objetivos" class="sub">Ver todo →</a></div>
          ${goals}
        </div>
        <div class="card">
          <div class="between mb8"><h3 class="h2">Progreso semanal</h3><a href="#/estadisticas" class="sub">Estadísticas →</a></div>
          ${d.week_minutes || d.week_minutes === 0 ? barchart(week, { label: v => v, fmt: v => `${v} min` }) : empty('📊', 'Sin datos todavía')}
          <p class="sub center">${d.week_minutes} minutos esta semana</p>
        </div>
      </div>
    </div>`;
  },
};
function fmtMin(min) {
  min = Number(min) || 0;
  if (min < 60) return `${min}m`;
  if (min < 600) return `${Math.round(min / 60 * 10) / 10}h`;
  return `${Math.round(min / 60)}h`;
}