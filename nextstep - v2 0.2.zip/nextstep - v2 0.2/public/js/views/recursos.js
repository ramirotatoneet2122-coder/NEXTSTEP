import { api, esc } from '../api.js';
import { toast, empty } from '../ui.js';
import { addResource, loadSubjects } from '../modals.js';
import { store } from '../store.js';

const KIND_LABEL = { curso: 'Curso', documentacion: 'Documentación', tutorial: 'Tutorial', video: 'Video', libro: 'Libro', otro: 'Otro' };
const KIND_ICO = { curso: '🎓', documentacion: '📄', tutorial: '🧭', video: '🎬', libro: '📕', otro: '🔗' };

let el;

export default {
  title: 'Recursos',
  async show(root) {
    el = root;
    root.innerHTML = '<div class="card"><div class="skeleton" style="height:120px"></div></div>';
    await load();
    const onCh = () => load();
    el._onCh = onCh;
    window.addEventListener('resources-changed', onCh);
  },
  hide() { if (el?._onCh) window.removeEventListener('resources-changed', el._onCh); },
};

async function load() {
  let data, subjects;
  try { [data, subjects] = await Promise.all([api('/api/resources'), loadSubjects()]); }
  catch (e) { el.innerHTML = empty('🔗', 'No pude cargar tus recursos.', e.message); return; }
  const nameOf = sid => subjects.find(s => s.id === sid)?.name || '';
  const { mine = [], suggested = [] } = data;

  el.innerHTML = `
    <div class="between mb8 wrap">
      <h1 class="h1">Recursos</h1>
      <button class="btn primary" data-ac="new">＋ Agregar recurso</button>
    </div>
    ${!store.iaReady ? `<div class="contrast-warn mb16">💡 El profesor también puede sugerirte cursos y links verificados desde el chat.</div>` : ''}
    <h3 class="h2 mb8">Mis recursos</h3>
    ${mine.length ? `<div class="grid cols2 mb16">${mine.map(mineCard).join('')}</div>`
      : `<div class="card pad center mb16">${empty('🔗', 'Todavía no guardaste recursos', 'Cursos, apuntes, videos: todo en un lugar.')}</div>`}
    <h3 class="h2 mb8" style="margin-top:20px">Sugeridos para tus materias</h3>
    ${suggested.length ? `<div class="grid cols2">${suggested.map(sugCard).join('')}</div>`
      : `<div class="card pad center">${empty('🧭', 'Agregá materias para ver sugerencias', 'Los sugeridos se basan en tus materias activas.')}</div>`}`;

  el.querySelector('[data-ac="new"]').onclick = addResource;
  el.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => {
    if (!confirm('¿Quitar este recurso?')) return;
    try { await api('/api/resources/' + b.dataset.del, { method: 'DELETE' }); toast('Recurso quitado', 'ok'); load(); }
    catch (e) { toast(e.message, 'err'); }
  });
}

function mineCard(r, n) {
  return `
  <div class="card">
    <div class="between">
      <div class="row"><span class="tsubj">${KIND_ICO[r.kind] || '🔗'}</span>
        <div><b>${esc(r.title)}</b>${r.subject_id ? '' : ''}</div></div>
    </div>
    ${r.note ? `<p class="muted" style="margin:8px 0">${esc(r.note)}</p>` : ''}
    <div class="row" style="margin-top:10px">
      <span class="chip">${KIND_LABEL[r.kind] || r.kind}</span>
      ${r.source === 'ia' ? '<span class="chip t-ia">Sugerido por IA</span>' : ''}
      <span style="flex:1"></span>
      ${r.url ? `<a class="btn tiny soft" href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">Abrir ↗</a>` : ''}
      <button class="iconbtn danger" data-del="${r.id}" title="Quitar">🗑</button>
    </div>
  </div>`;
}
function sugCard(c) {
  return `
  <div class="card">
    <div class="between"><div class="row"><span class="tsubj">${KIND_ICO[c.kind] || '🎓'}</span>
      <div><b>${esc(c.title)}</b><p class="sub">${esc(c.org)}</p></div></div>
      <span class="chip ${c.free ? 't-dominado' : ''}">${c.free ? 'Gratis' : 'Pago'}</span></div>
    <div class="chips" style="margin:10px 0">${(c.topics || []).map(t => `<span class="chip">${esc(t)}</span>`).join('')}</div>
    <a class="btn tiny primary" href="${esc(c.url)}" target="_blank" rel="noopener noreferrer">Ver recurso ↗</a>
  </div>`;
}