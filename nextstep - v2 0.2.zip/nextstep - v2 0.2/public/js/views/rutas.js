import { api, esc, fmtDate } from '../api.js';
import { toast, bar, empty } from '../ui.js';
import { createPath } from '../modals.js';
import { store } from '../store.js';

const KIND_ICO = { explicacion: '📖', practica: '✏️', evaluacion: '📝', proyecto: '🛠' };
const KIND_LABEL = { explicacion: 'Explicación', practica: 'Práctica', evaluacion: 'Evaluación', proyecto: 'Proyecto' };

let el;
let params = {};

export default {
  title: 'Rutas de aprendizaje',
  async show(root, p) {
    el = root; params = p || {};
    if (params.id) await showDetail();
    else await showList();
  },
};

async function showList() {
  el.innerHTML = '<div class="stack"><div class="card"><div class="skeleton" style="height:120px"></div></div></div>';
  let paths;
  try { paths = await api('/api/paths'); }
  catch (e) { el.innerHTML = empty('🗺️', 'No pude cargar tus rutas.', e.message); return; }
  el.innerHTML = `
    <div class="between mb8 wrap">
      <h1 class="h1">Rutas de aprendizaje</h1>
      <button class="btn primary" data-ac="new">＋ Nueva ruta</button>
    </div>
    <p class="sub mb16">Una secuencia con módulos y actividades para llegar de un punto a otro sin saltearte pasos.</p>
    ${paths.length ? `<div class="grid cols2">${paths.map(pathCard).join('')}</div>` : `
      <div class="card pad center">${empty('🗺️', 'Todavía no tenés rutas', 'Se crean solas cuando agregás una materia.\nTambién podés crear una desde acá.')}
      <button class="btn primary" data-ac="new">Crear mi primera ruta</button></div>`}`;
  el.querySelectorAll('[data-ac="new"]').forEach(b => b.onclick = () => createPath());
  el.querySelectorAll('[data-path]').forEach(a => a.addEventListener('click', e => {
    if (e.target.closest('[data-ac],select,button,a,input')) return;
    location.hash = '#/rutas/' + a.dataset.path;
  }));
  el.querySelectorAll('[data-ac="del"]').forEach(b => b.onclick = async () => {
    const p = Number(b.dataset.del);
    if (!confirm('¿Borrar esta ruta?')) return;
    try { await api('/api/paths/' + p, { method: 'DELETE' }); toast('Ruta borrada', 'ok'); showList(); }
    catch (e) { toast(e.message, 'err'); }
  });
  el.querySelectorAll('[data-ac="status"]').forEach(s => s.onchange = async () => {
    try { await api('/api/paths/' + s.dataset.status, { method: 'PATCH', body: { status: s.value } }); showList(); }
    catch (e) { toast(e.message, 'err'); }
  });
}

function pathCard(p) {
  return `
  <a class="card hover listrow" data-path="${p.id}" style="align-items:stretch;flex-direction:column">
    <div class="between">
      <div><b class="h2">${esc(p.title)}</b>
        <div class="row" style="margin-top:4px">
          <span class="chip ${p.source === 'ia' ? 't-ia' : ''}">${p.source === 'ia' ? '✨ Diseñada con IA' : 'Plantilla estándar'}</span>
          <span class="chip">${p.status === 'activa' ? 'Activa' : p.status === 'pausada' ? 'Pausada' : 'Finalizada'}</span>
        </div>
      </div>
      <b class="pct">${p.progress}%</b>
    </div>
    ${p.goal ? `<p class="muted" style="margin:8px 0">${esc(p.goal)}</p>` : ''}
    ${bar(p.progress, 'grad')}
    <div class="chips" style="margin-top:10px">${(p.modules || []).map(m => `<span class="chip ${m.state}">${m.done}/${m.count}</span>`).join('')}</div>
    <div class="row" style="margin-top:12px;border-top:1px solid var(--line);padding-top:10px">
      <select class="select tiny" data-ac="status" data-status="${p.id}">
        <option value="activa" ${p.status === 'activa' ? 'selected' : ''}>Activa</option>
        <option value="pausada" ${p.status === 'pausada' ? 'selected' : ''}>Pausada</option>
        <option value="finalizada" ${p.status === 'finalizada' ? 'selected' : ''}>Finalizada</option>
      </select>
      <span style="flex:1"></span>
      <button class="iconbtn danger" data-ac="del" data-del="${p.id}" title="Borrar ruta">🗑</button>
    </div>
  </a>`;
}

async function showDetail() {
  el.innerHTML = '<div class="card"><div class="skeleton" style="height:140px"></div></div>';
  let p;
  try { p = await api('/api/paths/' + params.id); }
  catch (e) { el.innerHTML = empty('🗺️', 'No encontré esa ruta.', e.message); return; }
  el.innerHTML = `
    <div class="between mb8 wrap">
      <div>
        <a href="#/rutas" class="sub">← Todas las rutas</a>
        <h1 class="h1">${esc(p.title)}</h1>
        <div class="row" style="margin-top:4px">
          <span class="chip ${p.source === 'ia' ? 't-ia' : ''}">${p.source === 'ia' ? '✨ Diseñada con IA' : 'Plantilla estándar'}</span>
          <span class="chip">${esc(p.status || 'Activa')}</span>
        </div>
      </div>
      <b class="pct h2">${p.progress}%</b>
    </div>
    ${p.goal ? `<p class="muted mb8">🎯 ${esc(p.goal)}</p>` : ''}
    <div class="card mb16">${bar(p.progress, 'grad')}<p class="sub" style="margin-top:6px">${p.progress === 100 ? '¡Ruta completada! 🎉' : `${p.modules.filter(m => m.state === 'completado').length}/${p.modules.length} módulos completados`}</p></div>
    <div class="stack">
      ${(p.modules || []).map((m, i) => moduleCard(p, m, i + 1)).join('')}
    </div>`;
  wireDetail(p);
}

function moduleCard(p, m, n) {
  return `
  <div class="card">
    <div class="between">
      <div class="row"><span class="mnum">${n}</span><div>
        <b class="h2">${esc(m.title)}</b>
        ${m.objective ? `<p class="muted">${esc(m.objective)}</p>` : ''}
      </div></div>
      ${m.state === 'completado' ? '<span class="tag dominado">Completado ✓</span>' : m.state === 'en_curso' ? '<span class="tag en_curso">En curso</span>' : '<span class="tag pendiente">Pendiente</span>'}
    </div>
    <div class="stack" style="margin-top:12px;background:var(--surface2);padding:12px;border-radius:12px">
      ${(m.activities || []).map(a => activityRow(p, m, a)).join('')}
    </div>
  </div>`;
}

function activityRow(p, m, a) {
  const done = a.state === 'completado';
  return `
  <div class="between" style="gap:10px">
    <div class="row" style="align-items:flex-start;flex:1;min-width:0">
      <span style="font-size:1.1rem">${KIND_ICO[a.kind] || '📘'}</span>
      <div style="min-width:0">
        <b style="display:block">${esc(a.title)}</b>
        <small class="muted">${KIND_LABEL[a.kind] || a.kind}${done ? ' · hecha el ' + fmtDate(a.completed_at) : ''}</small>
        ${a.content && !done ? `<p class="sub" style="margin-top:6px;white-space:pre-wrap">${esc(a.content)}</p>` : ''}
      </div>
    </div>
    ${done ? '<span class="tag dominado">✓</span>' : `<button class="btn tiny primary" data-ac="done" data-aid="${a.id}" data-pid="${p.id}">Marcar completada</button>`}
  </div>`;
}

function wireDetail(p) {
  el.querySelectorAll('[data-ac="done"]').forEach(b => b.onclick = async () => {
    const aid = Number(b.dataset.aid);
    b.disabled = true; b.textContent = 'Guardando…';
    try {
      const r = await api('/api/paths/activities/' + aid + '/complete', { method: 'POST' });
      toast('Actividad completada +25 XP', 'ok');
      if (r.module_just_done) toast('¡Módulo terminado! +40 XP 🎉', 'ok');
      store.me && await api('/api/auth/me').then(m => { store.me = m; window.dispatchEvent(new CustomEvent('profile-updated', { detail: m })); }).catch(() => {});
      showDetail();
    } catch (e) { b.disabled = false; b.textContent = 'Marcar completada'; toast(e.message, 'err'); }
  });
}