// Cliente HTTP de NEXTSTEP: envuelve fetch, maneja errores y redirige a login si la sesión expira.
export async function api(path, { method = 'GET', body, raw = false, signal } = {}) {
  const opts = { method, headers: {}, signal };
  if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  let res;
  try {
    res = await fetch(path, opts);
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    throw new ApiError('No se pudo conectar con el servidor.', 0);
  }
  if (res.status === 401 && !path.startsWith('/api/auth/')) {
    window.dispatchEvent(new Event('unauthorized'));
  }
  if (raw) return res;
  let data = null;
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) {
    try { data = await res.json(); } catch { /* cuerpo vacío */ }
  }
  if (!res.ok) {
    throw new ApiError(data?.error || `Error ${res.status}`, res.status, data);
  }
  return data;
}

export class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.status = status;
    this.data = data;
  }
}

// Lee un stream SSE de /api/chat: onText(t) por cada trozo, onEvent(o) por cada evento crudo,
// y devuelve meta (conversación + proveedor de IA que respondió).
export async function streamChat(body, onText, signal, onEvent) {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal,
  });
  if (!res.ok) {
    let msg = 'No se pudo usar la IA ahora.';
    try { msg = (await res.json()).error || msg; } catch { /* sin cuerpo */ }
    throw new ApiError(msg, res.status);
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  let full = '';
  let conversationId = null;
  let provider = null, providerLabel = null, model = null;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n\n')) >= 0) {
      const chunk = buf.slice(0, i);
      buf = buf.slice(i + 2);
      if (!chunk.startsWith('data: ')) continue;
      let o;
      try { o = JSON.parse(chunk.slice(6)); } catch { continue; }
      if (onEvent) onEvent(o);
      if (o.error) throw new ApiError(o.error);
      if (o.provider) { provider = o.provider; providerLabel = o.provider_label; model = o.model; }
      if (o.t) { full += o.t; onText(full); }
      if (o.done) {
        conversationId = o.conversation_id || null;
        if (o.provider) { provider = o.provider; providerLabel = o.provider_label; }
        onText(full, true);
      }
    }
  }
  return { full, conversationId, provider, providerLabel, model };
}

export function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
export function escAttr(s) { return esc(s); }

export function fmtDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const today = new Date();
  const sameDay = d.toDateString() === today.toDateString();
  if (sameDay) return d.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });
  if (d.getFullYear() === today.getFullYear()) return d.toLocaleDateString('es-AR', { day: 'numeric', month: 'short' });
  return d.toLocaleDateString('es-AR');
}