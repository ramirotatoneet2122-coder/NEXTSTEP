// Modales compartidos entre vistas (crear evaluación, crear ruta, agregar recurso).
import { api } from './api.js';
import { openModal, closeModal, toast } from './ui.js';

export const RANKS = ['Iniciante', 'Básico', 'Intermedio', 'Avanzado', 'Experto'];

export function chrome(title, bodyHtml, okLabel = 'Guardar', { hidden = false } = {}) {
  return openModal(
    `<div class="modal-head"><h3>${title}</h3><button class="mclose" type="button" data-mc>✕</button></div>
     <div class="modal-body">${bodyHtml}</div>
     <div class="modal-foot"><button class="btn ghost" type="button" data-mc>Cancelar</button>
     <button class="btn primary" type="button" data-ok${hidden ? ' hidden' : ''}>${okLabel}</button></div>`,
    { onMount: b => { b.querySelectorAll('[data-mc]').forEach(x => x.onclick = closeModal); } }
  );
}

export async function loadSubjects() {
  return api('/api/subjects').catch(() => []);
}
export function subjectOptions(subjects, selected = 0, required = false) {
  const opts = subjects.map(s => `<option value="${s.id}" ${Number(selected) === s.id ? 'selected' : ''}>${esc(s.emoji)} ${esc(s.name)}</option>`).join('');
  return required
    ? `<select class="select" data-sel="subject" required><option value="">Elegí la materia…</option>${opts}</select>`
    : `<select class="select" data-sel="subject"><option value="">Sin materia específica</option>${opts}</select>`;
}
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

/* ---------- Evaluación ---------- */
export async function createEval(subjectId) {
  const subjects = await loadSubjects();
  const box = chrome('Nueva evaluación', `
    <div class="field"><span class="flabel">Materia (requerida)</span>${subjectOptions(subjects, subjectId, true)}</div>
    <div class="field"><span class="flabel">Tipo</span>
      <select class="select" data-sel="kind">
        <option value="seguimiento">De seguimiento (medimos tu nivel actual)</option>
        <option value="inicial">Diagnóstica inicial</option>
      </select></div>
    <p class="sub">Son ~5 preguntas verificadas a mano. Al terminar te damos un puntaje y qué temas reforzar.</p>`, 'Comenzar');
  box.querySelector('[data-ok]').onclick = async () => {
    const sid = Number(box.querySelector('[data-sel="subject"]').value);
    if (!sid) return toast('Elegí una materia.', 'err');
    const kind = box.querySelector('[data-sel="kind"]').value;
    try {
      const ev = await api('/api/evaluations', { method: 'POST', body: { subject_id: sid, kind } });
      closeModal();
      location.hash = '#/evaluaciones/' + ev.id;
    } catch (e) { box.querySelector('[data-ok]').disabled = false; toast(e.message, 'err'); }
  };
}

/* ---------- Ruta ---------- */
export async function createPath(subjectId, subjectName) {
  const subjects = await loadSubjects();
  const box = chrome('Nueva ruta de aprendizaje', `
    <div class="field"><span class="flabel">Materia</span>${subjectOptions(subjects, subjectId, false)}</div>
    <div class="field"><span class="flabel">O nombre (si no está en tus materias)</span>
      <input class="input" data-f="name" placeholder="Ej.: Inglés conversacional" value="${subjectName ? esc(subjectName) : ''}"></div>
    <div class="field"><span class="flabel">Objetivo (opcional)</span>
      <input class="input" data-f="goal" placeholder="Ej.: entender la herencia en Java"></div>
    <div class="picker-row">
      <div class="field"><span class="flabel">Punto de partida</span>
        <select class="select" data-f="level"><option value="">Sin especificar</option>${RANKS.map((r, i) => `<option>${r}</option>`).join('')}</select></div>
      <div class="field"><span class="flabel">Duración (semanas)</span>
        <input class="input" type="number" min="1" max="16" data-f="weeks" placeholder="6"></div>
    </div>
    <label class="chk mt"><input type="checkbox" data-f="fromai"> <span>Que el profesor diseñe la ruta con IA (si está disponible)</span></label>`, 'Crear ruta');
  box.querySelector('[data-ok]').onclick = async () => {
    const sid = Number(box.querySelector('[data-sel="subject"]').value) || null;
    const name = box.querySelector('[data-f="name"]').value.trim();
    const goal = box.querySelector('[data-f="goal"]').value.trim();
    const level = box.querySelector('[data-f="level"]').value;
    const weeks = Number(box.querySelector('[data-f="weeks"]').value) || 0;
    const fromai = box.querySelector('[data-f="fromai"]').checked;
    if (!sid && !name) return toast('Elegí una materia o escribí un nombre.', 'err');
    try {
      const p = await api('/api/paths', { method: 'POST', body: { subject_id: sid, name, goal, level, weeks, from_ai: fromai } });
      closeModal(); location.hash = '#/rutas/' + p.id;
    } catch (e) { toast(e.message, 'err'); }
  };
}

/* ---------- Recurso ---------- */
export async function addResource() {
  const subjects = await loadSubjects();
  const box = chrome('Agregar recurso', `
    <div class="field"><span class="flabel">Título *</span><input class="input" data-f="title"></div>
    <div class="field"><span class="flabel">URL</span><input class="input" data-f="url" placeholder="https://…"></div>
    <div class="picker-row">
      <div class="field"><span class="flabel">Tipo</span>
        <select class="select" data-f="kind">
          <option value="curso">Curso</option><option value="documentacion">Documentación</option>
          <option value="tutorial">Tutorial</option><option value="video">Video</option>
          <option value="libro">Libro</option><option value="otro">Otro</option></select></div>
      <div class="field"><span class="flabel">Materia</span>${subjectOptions(subjects, 0, false)}</div>
    </div>
    <div class="field"><span class="flabel">Nota</span><textarea class="textarea" data-f="note" rows="2"></textarea></div>`, 'Guardar');
  box.querySelector('[data-ok]').onclick = async () => {
    const title = box.querySelector('[data-f="title"]').value.trim();
    const url = box.querySelector('[data-f="url"]').value.trim();
    const kind = box.querySelector('[data-f="kind"]').value;
    const note = box.querySelector('[data-f="note"]').value.trim();
    const subjectId = Number(box.querySelector('[data-sel="subject"]').value) || null;
    if (!title) return toast('Poné el título.', 'err');
    try {
      await api('/api/resources', { method: 'POST', body: { title, url, kind, note, subject_id: subjectId } });
      closeModal();
      window.dispatchEvent(new CustomEvent('resources-changed'));
      toast('Recurso guardado', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  };
}

export { esc };