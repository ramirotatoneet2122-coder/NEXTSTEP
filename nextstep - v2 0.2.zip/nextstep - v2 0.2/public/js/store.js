// Estado global del cliente (no es la fuente de verdad: los datos viven en el backend).
export const store = {
  me: null,          // { user, profile }
  meta: { greeting: '', startQuick: [], allowedUrls: [], subjects: [] },
  ia: { ready: false, active: null, providers: [] },  // estado del router de IA (Claude/ChatGPT/Gemini)
  iaReady: false,    // si el servidor tiene al menos una IA configurada
  currentRoute: '#/',
};

export async function loadMeta() {
  try {
    const m = await fetch('/api/meta').then(r => r.json());
    store.meta = { ...store.meta, ...m };
    if (m.ia) { store.ia = m.ia; store.iaReady = Boolean(m.ia.ready); }
  } catch { /* valores por defecto */ }
  try {
    const h = await fetch('/api/health').then(r => r.json());
    store.iaReady = Boolean(h.ia);
    if (Array.isArray(h.providers)) store.ia = { ...store.ia, ready: Boolean(h.ia), active: h.active, providers: h.providers };
  } catch { /* desconectado */ }
}

export async function loadMe() {
  const r = await fetch('/api/auth/me');
  if (r.ok) {
    store.me = await r.json();
    return store.me;
  }
  store.me = null;
  return null;
}