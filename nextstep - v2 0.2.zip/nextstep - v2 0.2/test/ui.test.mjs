import { test } from 'node:test';
import assert from 'node:assert/strict';
import { fmt, readTags, stripTags, setAllowedUrls } from '../public/js/ui.js';

test('stripTags quita etiquetas de control completas', () => {
  assert.equal(stripTags('Hola <opciones>a|b</opciones> <perfil>{"a":1}</perfil>').trim(), 'Hola');
  assert.equal(stripTags('x <resumen>corto</resumen>').trim(), 'x');
});

test('stripTags no corta texto común', () => {
  const out = stripTags('Mirá este <b>código</b>');
  assert.ok(out.includes('<b>código</b>'));
});

test('fmt escapa HTML y vuelve links permitidos', () => {
  setAllowedUrls(['https://www.freecodecamp.org']);
  const html = fmt('Mirá https://www.freecodecamp.org/learn\n\n**Negrita**');
  assert.ok(html.includes('<a href="https://www.freecodecamp.org/learn" target="_blank"'));
  assert.ok(html.includes('<b>Negrita</b>'));
});

test('fmt no linkea URLs ajenas ni inyecta HTML', () => {
  const html = fmt('https://evil.example <img src=x onerror=alert(1)>');
  assert.ok(!html.includes('<a href="https://evil.example'));
  assert.ok(!html.includes('<img'));
});

test('fmt admite bloques de código', () => {
  const html = fmt('Fijate:\n```js\nconst a = 1;\n```');
  assert.ok(html.includes('<pre><code>const a = 1;'));
});

test('readTags extrae opciones', () => {
  const out = readTags('Capa 2? <opciones>física|enlace no sé|capa 3|me ayudás a pensarlo</opciones>');
  assert.deepEqual(out, ['física', 'enlace no sé', 'capa 3', 'me ayudás a pensarlo']);
});

test('readTags sin etiqueta devuelve vacío', () => {
  assert.deepEqual(readTags('Sin sugerencias'), []);
});