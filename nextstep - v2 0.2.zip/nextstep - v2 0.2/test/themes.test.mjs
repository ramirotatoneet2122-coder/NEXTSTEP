import { test } from 'node:test';
import assert from 'node:assert/strict';
import { THEMES, THEME_LIST, mix, lum, contrastRatio, accentInk } from '../public/js/themes.js';

test('mix interpola colores', () => {
  assert.equal(mix('#000000', '#ffffff', 0.5), '#808080');
  assert.equal(mix('#ff0000', '#0000ff', 0), '#ff0000');
  assert.equal(mix('#ff0000', '#0000ff', 1), '#0000ff');
});

test('contraste negro/blanco cumple WCAG', () => {
  assert.ok(contrastRatio('#000000', '#ffffff') >= 21);
  assert.equal(contrastRatio('#000000', '#000000'), 1);
});

test('accentInk depende de la luminancia', () => {
  assert.equal(accentInk('#ffffff'), '#0B0B0D');
  assert.equal(accentInk('#0000ff'), '#FFFFFF');
});

test('todas las paletas tienen los tokens de color', () => {
  assert.ok(THEME_LIST.length >= 8);
  for (const t of THEME_LIST) {
    assert.ok(THEMES[t], 'tema ' + t);
    for (const mode of ['dark', 'light']) {
      const pal = THEMES[t].palettes[mode];
      assert.ok(pal, `${t}/${mode}`);
      for (const k of ['bg', 'surface', 'ink', 'muted', 'line', 'accent', 'accent2', 'good', 'warn', 'danger']) {
        assert.match(pal[k], /^#[0-9a-fA-F]{6}$/, `${t}/${mode} falta color ${k}`);
      }
    }
  }
});

test('highlight de cada tema tiene dos colores', () => {
  for (const t of THEME_LIST) {
    assert.ok(Array.isArray(THEMES[t].highlight) && THEMES[t].highlight.length === 2, t);
  }
});