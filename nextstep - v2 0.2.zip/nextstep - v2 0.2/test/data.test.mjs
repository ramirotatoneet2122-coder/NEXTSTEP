import { test } from 'node:test';
import assert from 'node:assert/strict';
import { RANKS, rankOf, TOPICS, COURSES, TEMPLATES, SUBJECTS, findSubject } from '../src/data.js';

test('RANKS y rankOf mapean porcentajes', () => {
  assert.equal(RANKS.length, 5);
  assert.equal(rankOf(0), 0);
  assert.equal(rankOf(25), 1);
  assert.equal(rankOf(50), 2);
  assert.equal(rankOf(75), 3);
  assert.equal(rankOf(90), 4);
});

test('preguntas del banco bien formadas', () => {
  let n = 0;
  for (const k of Object.keys(TOPICS)) {
    assert.ok(TOPICS[k].name, k + ' tiene nombre');
    assert.ok(Array.isArray(TOPICS[k].qs) && TOPICS[k].qs.length > 0, k + ' tiene preguntas');
    for (const q of TOPICS[k].qs) {
      n++;
      assert.ok(q.q && q.q.length > 5, k + ': enunciado');
      assert.ok(Array.isArray(q.o) && q.o.length >= 3, k + ': opciones');
      assert.ok(Number.isInteger(q.a) && q.a >= 0 && q.a < q.o.length, k + ': índice correcto válido');
      assert.ok(q.s, k + ': subtema');
      assert.ok(q.d >= 1 && q.d <= 3, k + ': dificultad');
      assert.ok(q.e && q.e.length > 5, k + ': explicación');
    }
  }
  assert.ok(n >= 12, 'el banco tiene contenido verificado');
});

test('cursos con URL https y datos mínimos', () => {
  assert.ok(COURSES.length > 0);
  for (const c of COURSES) {
    assert.ok(c.title && c.org && c.kind, 'curso ' + (c.title || '?'));
    assert.match(c.url, /^https:\/\//);
    assert.ok(Array.isArray(c.topics) && c.topics.length > 0);
  }
});

test('plantillas de rutas coherentes', () => {
  assert.ok(Object.keys(TEMPLATES).length > 0);
  for (const [key, t] of Object.entries(TEMPLATES)) {
    assert.ok(t.title, key + ': título');
    assert.ok(Array.isArray(t.match) && t.match.length > 0, key + ': match');
    assert.ok(Array.isArray(t.modules) && t.modules.length >= 2, key + ': módulos');
    for (const m of t.modules) {
      assert.ok(m.title && m.objective, key + ': módulo con título/objetivo');
      assert.ok(Array.isArray(m.adds) && m.adds.length > 0, key + ': agregados');
    }
  }
});

test('catálogo de materias de secundaria completo', () => {
  assert.ok(SUBJECTS.length >= 15, 'tiene la secundaria cubierta');
  for (const s of SUBJECTS) {
    assert.ok(s.key && s.name && s.emoji, s.name + ': clave/nombre/emoji');
    assert.ok(Array.isArray(s.topics) && s.topics.length >= 4, s.name + ': temas típicos');
  }
});

test('findSubject encuentra por nombre con/sin tildes y por clave', () => {
  assert.equal(findSubject('Matemática')?.key, 'matematica');
  assert.equal(findSubject('matematica')?.key, 'matematica');
  assert.equal(findSubject('INGLES')?.key, 'ingles');
  assert.equal(findSubject('inglés')?.name, 'Inglés');
  assert.equal(findSubject('lengua y literatura')?.key, 'lengua');
  assert.equal(findSubject('noexiste') , null);
});