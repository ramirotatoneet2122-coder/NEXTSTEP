@echo off
setlocal
cd /d "%~dp0"
title NEXTSTEP - Inicio

echo ==========================================
echo             NEXTSTEP
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: No se encontro Node.js.
  echo Instala Node.js 22.5 o superior desde https://nodejs.org/
  echo Despues vuelve a ejecutar este archivo.
  pause
  exit /b 1
)

node -e "const [a,b]=process.versions.node.split('.').map(Number); process.exit(a > 22 || (a === 22 && b >= 5) ? 0 : 1)"
if errorlevel 1 (
  echo ERROR: NEXTSTEP necesita Node.js 22.5 o superior.
  echo Tu version es:
  node -v
  pause
  exit /b 1
)

if not exist "node_modules\express\package.json" (
  echo Instalando dependencias. Necesitas conexion a Internet la primera vez...
  call npm install
  if errorlevel 1 (
    echo.
    echo ERROR: No se pudieron instalar las dependencias.
    pause
    exit /b 1
  )
)

echo Abriendo NEXTSTEP en el navegador...
start "" cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:3000"
echo.
echo No cierres esta ventana mientras uses NEXTSTEP.
echo Para detener el servidor, cierra esta ventana.
echo.
call npm start
pause
