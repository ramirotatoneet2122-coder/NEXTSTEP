// NEXTSTEP — base de datos SQLite (módulo nativo de Node 22+, sin dependencias extra)
import { DatabaseSync } from 'node:sqlite';
import fs from 'fs';
import path from 'path';

const SCHEMA = `
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id          TEXT PRIMARY KEY,
  created_at  INTEGER NOT NULL,
  last_seen   INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS accounts (
  id             TEXT PRIMARY KEY,
  username       TEXT NOT NULL UNIQUE COLLATE NOCASE,
  display_name   TEXT NOT NULL,
  password_hash  TEXT NOT NULL,
  created_at     INTEGER NOT NULL,
  last_login     INTEGER
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash  TEXT PRIMARY KEY,
  account_id  TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  created_at  INTEGER NOT NULL,
  expires_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_account ON sessions(account_id);

CREATE TABLE IF NOT EXISTS profiles (
  user_id                  TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  name                     TEXT,
  level_title              TEXT,
  level_number             INTEGER,
  current_xp               INTEGER,
  next_level_xp            INTEGER,
  streak_days              INTEGER,
  total_minutes_studied    INTEGER,
  completed_exercises      INTEGER,
  initial_assessment_done  INTEGER,
  preferences              TEXT NOT NULL DEFAULT '{}',
  extra                    TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS settings (
  user_id             TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  palette             TEXT,
  is_dark_mode        INTEGER,
  use_system_dark     INTEGER,
  custom_primary_hex  TEXT,
  custom_accent_hex   TEXT,
  study_mode          TEXT,
  active_subject_id   TEXT,
  custom_api_key      TEXT,
  extra               TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS subjects (
  user_id          TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id               TEXT NOT NULL,
  position         INTEGER NOT NULL,
  name             TEXT,
  category         TEXT,
  mastery_percent  INTEGER,
  data             TEXT NOT NULL,
  PRIMARY KEY (user_id, id)
);

CREATE TABLE IF NOT EXISTS routes (
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id          TEXT NOT NULL,
  position    INTEGER NOT NULL,
  subject_id  TEXT,
  title       TEXT,
  data        TEXT NOT NULL,
  PRIMARY KEY (user_id, id)
);

CREATE TABLE IF NOT EXISTS route_modules (
  user_id       TEXT NOT NULL,
  route_id      TEXT NOT NULL,
  id            TEXT NOT NULL,
  position      INTEGER NOT NULL,
  title         TEXT,
  is_completed  INTEGER,
  is_current    INTEGER,
  is_locked     INTEGER,
  data          TEXT NOT NULL,
  PRIMARY KEY (user_id, route_id, id),
  FOREIGN KEY (user_id, route_id) REFERENCES routes(user_id, id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS exercises (
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id          TEXT NOT NULL,
  position    INTEGER NOT NULL,
  subject_id  TEXT,
  difficulty  TEXT,
  data        TEXT NOT NULL,
  PRIMARY KEY (user_id, id)
);

CREATE TABLE IF NOT EXISTS evaluations (
  user_id        TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id             TEXT NOT NULL,
  position       INTEGER NOT NULL,
  subject_id     TEXT,
  title          TEXT,
  completed      INTEGER,
  score_percent  INTEGER,
  data           TEXT NOT NULL,
  PRIMARY KEY (user_id, id)
);

CREATE TABLE IF NOT EXISTS goals (
  user_id           TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id                TEXT NOT NULL,
  position          INTEGER NOT NULL,
  title             TEXT,
  priority          TEXT,
  progress_percent  INTEGER,
  data              TEXT NOT NULL,
  PRIMARY KEY (user_id, id)
);

CREATE TABLE IF NOT EXISTS goal_tasks (
  user_id       TEXT NOT NULL,
  goal_id       TEXT NOT NULL,
  id            TEXT NOT NULL,
  position      INTEGER NOT NULL,
  is_completed  INTEGER,
  data          TEXT NOT NULL,
  PRIMARY KEY (user_id, goal_id, id),
  FOREIGN KEY (user_id, goal_id) REFERENCES goals(user_id, id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS achievements (
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id           TEXT NOT NULL,
  position     INTEGER NOT NULL,
  is_unlocked  INTEGER,
  data         TEXT NOT NULL,
  PRIMARY KEY (user_id, id)
);

CREATE TABLE IF NOT EXISTS chat_messages (
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id         TEXT NOT NULL,
  position   INTEGER NOT NULL,
  sender     TEXT,
  timestamp  INTEGER,
  data       TEXT NOT NULL,
  PRIMARY KEY (user_id, id)
);

CREATE TABLE IF NOT EXISTS resources (
  user_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id        TEXT NOT NULL,
  position  INTEGER NOT NULL,
  title     TEXT,
  category  TEXT,
  data      TEXT NOT NULL,
  PRIMARY KEY (user_id, id)
);

CREATE INDEX IF NOT EXISTS idx_users_last_seen ON users(last_seen);
CREATE INDEX IF NOT EXISTS idx_chat_user_ts ON chat_messages(user_id, timestamp);
`;

const b = (v) => (v ? 1 : 0);
const j = (v) => JSON.stringify(v ?? null);
const KNOWN_TOP = new Set([
  'userProfile', 'themeConfig', 'studyMode', 'activeSubjectId', 'customApiKey',
  'subjects', 'routes', 'exercises', 'evaluations', 'goals', 'achievements',
  'chatHistory', 'resources',
]);
const KNOWN_PROFILE = new Set([
  'name', 'levelTitle', 'levelNumber', 'currentXp', 'nextLevelXp', 'streakDays',
  'totalMinutesStudied', 'completedExercisesCount', 'initialAssessmentDone', 'preferences',
]);

export function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec(SCHEMA);
  return db;
}

export function createStore(db) {
  const q = (sql) => db.prepare(sql);

  const stmts = {
    hasUser: q('SELECT 1 FROM users WHERE id = ?'),
    upsertUser: q(`INSERT INTO users (id, created_at, last_seen) VALUES (?, ?, ?)
                   ON CONFLICT(id) DO UPDATE SET last_seen = excluded.last_seen`),
    upsertProfile: q(`INSERT OR REPLACE INTO profiles
      (user_id, name, level_title, level_number, current_xp, next_level_xp, streak_days,
       total_minutes_studied, completed_exercises, initial_assessment_done, preferences, extra)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`),
    upsertSettings: q(`INSERT OR REPLACE INTO settings
      (user_id, palette, is_dark_mode, use_system_dark, custom_primary_hex, custom_accent_hex,
       study_mode, active_subject_id, custom_api_key, extra)
      VALUES (?,?,?,?,?,?,?,?,?,?)`),
    getProfile: q('SELECT * FROM profiles WHERE user_id = ?'),
    getSettings: q('SELECT * FROM settings WHERE user_id = ?'),
    delUser: q('DELETE FROM users WHERE id = ?'),
    purge: q('DELETE FROM users WHERE last_seen < ?'),
    countUsers: q('SELECT COUNT(*) AS n FROM users'),
  };

  // Colecciones simples: tabla, columnas tipadas extra, y cómo sacarlas del objeto
  const flat = {
    subjects: {
      table: 'subjects',
      cols: ['name', 'category', 'mastery_percent'],
      pick: (o) => [o.name, o.category, o.masteryPercent],
    },
    exercises: {
      table: 'exercises',
      cols: ['subject_id', 'difficulty'],
      pick: (o) => [o.subjectId, o.difficulty],
    },
    evaluations: {
      table: 'evaluations',
      cols: ['subject_id', 'title', 'completed', 'score_percent'],
      pick: (o) => [o.subjectId, o.title, b(o.completed), o.scorePercent ?? null],
    },
    achievements: {
      table: 'achievements',
      cols: ['is_unlocked'],
      pick: (o) => [b(o.isUnlocked)],
    },
    chatHistory: {
      table: 'chat_messages',
      cols: ['sender', 'timestamp'],
      pick: (o) => [o.sender, o.timestamp ?? null],
    },
    resources: {
      table: 'resources',
      cols: ['title', 'category'],
      pick: (o) => [o.title, o.category],
    },
  };

  const insertFlat = {};
  const selectFlat = {};
  const deleteFlat = {};
  for (const [key, c] of Object.entries(flat)) {
    const cols = ['user_id', 'id', 'position', ...c.cols, 'data'];
    insertFlat[key] = q(`INSERT INTO ${c.table} (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`);
    selectFlat[key] = q(`SELECT data FROM ${c.table} WHERE user_id = ? ORDER BY position`);
    deleteFlat[key] = q(`DELETE FROM ${c.table} WHERE user_id = ?`);
  }

  const insRoute = q('INSERT INTO routes (user_id, id, position, subject_id, title, data) VALUES (?,?,?,?,?,?)');
  const insModule = q(`INSERT INTO route_modules
    (user_id, route_id, id, position, title, is_completed, is_current, is_locked, data) VALUES (?,?,?,?,?,?,?,?,?)`);
  const selRoutes = q('SELECT id, data FROM routes WHERE user_id = ? ORDER BY position');
  const selModules = q('SELECT data FROM route_modules WHERE user_id = ? AND route_id = ? ORDER BY position');
  const delRoutes = q('DELETE FROM routes WHERE user_id = ?');

  const insGoal = q('INSERT INTO goals (user_id, id, position, title, priority, progress_percent, data) VALUES (?,?,?,?,?,?,?)');
  const insTask = q('INSERT INTO goal_tasks (user_id, goal_id, id, position, is_completed, data) VALUES (?,?,?,?,?,?)');
  const selGoals = q('SELECT id, data FROM goals WHERE user_id = ? ORDER BY position');
  const selTasks = q('SELECT data FROM goal_tasks WHERE user_id = ? AND goal_id = ? ORDER BY position');
  const delGoals = q('DELETE FROM goals WHERE user_id = ?');

  function transaction(fn) {
    db.exec('BEGIN');
    try {
      fn();
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  }

  function hasUser(uid) {
    return !!stmts.hasUser.get(uid);
  }

  function save(uid, s) {
    const now = Date.now();
    transaction(() => {
      stmts.upsertUser.run(uid, now, now);

      const p = s.userProfile || {};
      const pExtra = {};
      for (const [k, v] of Object.entries(p)) if (!KNOWN_PROFILE.has(k)) pExtra[k] = v;
      stmts.upsertProfile.run(
        uid, p.name ?? null, p.levelTitle ?? null, p.levelNumber ?? 0, p.currentXp ?? 0,
        p.nextLevelXp ?? 0, p.streakDays ?? 0, p.totalMinutesStudied ?? 0,
        p.completedExercisesCount ?? 0, b(p.initialAssessmentDone), j(p.preferences || {}), j(pExtra),
      );

      const t = s.themeConfig || {};
      const sExtra = {};
      for (const [k, v] of Object.entries(s)) if (!KNOWN_TOP.has(k)) sExtra[k] = v;
      stmts.upsertSettings.run(
        uid, t.palette ?? null, b(t.isDarkMode), b(t.useSystemDark),
        t.customPrimaryHex ?? null, t.customAccentHex ?? null,
        s.studyMode ?? null, s.activeSubjectId ?? null, s.customApiKey ?? null, j(sExtra),
      );

      for (const [key, c] of Object.entries(flat)) {
        deleteFlat[key].run(uid);
        (s[key] || []).forEach((o, i) => {
          insertFlat[key].run(uid, String(o.id), i, ...c.pick(o), j(o));
        });
      }

      delRoutes.run(uid); // borra módulos en cascada
      (s.routes || []).forEach((r, i) => {
        const { modules = [], ...route } = r;
        insRoute.run(uid, String(r.id), i, r.subjectId ?? null, r.title ?? null, j(route));
        modules.forEach((m, k) => {
          insModule.run(uid, String(r.id), String(m.id), k, m.title ?? null,
            b(m.isCompleted), b(m.isCurrent), b(m.isLocked), j(m));
        });
      });

      delGoals.run(uid); // borra tareas en cascada
      (s.goals || []).forEach((g, i) => {
        const { tasks = [], ...goal } = g;
        insGoal.run(uid, String(g.id), i, g.title ?? null, g.priority ?? null,
          g.progressPercent ?? 0, j(goal));
        tasks.forEach((tk, k) => {
          insTask.run(uid, String(g.id), String(tk.id), k, b(tk.isCompleted), j(tk));
        });
      });
    });
  }

  function load(uid) {
    stmts.upsertUser.run(uid, Date.now(), Date.now());
    const p = stmts.getProfile.get(uid);
    const st = stmts.getSettings.get(uid);
    if (!p || !st) return null;

    const state = {
      userProfile: {
        name: p.name,
        levelTitle: p.level_title,
        levelNumber: p.level_number,
        currentXp: p.current_xp,
        nextLevelXp: p.next_level_xp,
        streakDays: p.streak_days,
        totalMinutesStudied: p.total_minutes_studied,
        completedExercisesCount: p.completed_exercises,
        initialAssessmentDone: !!p.initial_assessment_done,
        preferences: JSON.parse(p.preferences),
        ...JSON.parse(p.extra),
      },
      themeConfig: {
        palette: st.palette,
        isDarkMode: !!st.is_dark_mode,
        useSystemDark: !!st.use_system_dark,
        customPrimaryHex: st.custom_primary_hex,
        customAccentHex: st.custom_accent_hex,
      },
      studyMode: st.study_mode,
      activeSubjectId: st.active_subject_id,
      ...JSON.parse(st.extra),
    };
    if (st.custom_api_key) state.customApiKey = st.custom_api_key;

    for (const key of Object.keys(flat)) {
      state[key] = selectFlat[key].all(uid).map((r) => JSON.parse(r.data));
    }
    state.routes = selRoutes.all(uid).map((r) => ({
      ...JSON.parse(r.data),
      modules: selModules.all(uid, r.id).map((m) => JSON.parse(m.data)),
    }));
    state.goals = selGoals.all(uid).map((g) => ({
      ...JSON.parse(g.data),
      tasks: selTasks.all(uid, g.id).map((t) => JSON.parse(t.data)),
    }));
    return state;
  }

  return {
    hasUser,
    save,
    load,
    deleteUser: (uid) => stmts.delUser.run(uid),
    purgeInactive: (olderThanMs) => stmts.purge.run(Date.now() - olderThanMs).changes,
    userCount: () => stmts.countUsers.get().n,
  };
}
