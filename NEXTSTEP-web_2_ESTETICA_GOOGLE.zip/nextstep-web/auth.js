// NEXTSTEP — cuentas de usuario: registro, inicio de sesión y sesiones.
// Las contraseñas NUNCA se guardan: solo un hash scrypt con sal aleatoria por usuario.
import crypto from 'crypto';

const SESSION_MS = 30 * 24 * 60 * 60 * 1000;
const USERNAME_RE = /^[A-Za-z0-9_.-]{3,30}$/;
const DISPLAY_RE = /^[\p{L}\p{N} _.'-]{1,40}$/u; // sin < > & " para evitar inyección en la interfaz

const scrypt = (password, salt) =>
  new Promise((resolve, reject) =>
    crypto.scrypt(password, salt, 64, { N: 16384, r: 8, p: 1 }, (err, key) => (err ? reject(err) : resolve(key))));

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt);
  return `scrypt$${salt.toString('hex')}$${key.toString('hex')}`;
}

async function verifyPassword(password, stored) {
  const [alg, saltHex, keyHex] = String(stored).split('$');
  if (alg !== 'scrypt' || !saltHex || !keyHex) return false;
  const expected = Buffer.from(keyHex, 'hex');
  const actual = await scrypt(password, Buffer.from(saltHex, 'hex'));
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
// Hash de relleno para que "usuario inexistente" tarde lo mismo que "contraseña incorrecta"
const DUMMY_HASH = `scrypt$${'00'.repeat(16)}$${'00'.repeat(64)}`;

export class AuthError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export function createAuth(db) {
  const q = (sql) => db.prepare(sql);
  const st = {
    byName: q('SELECT * FROM accounts WHERE username = ?'),
    byId: q('SELECT id, username, display_name FROM accounts WHERE id = ?'),
    insert: q('INSERT INTO accounts (id, username, display_name, password_hash, created_at, last_login) VALUES (?,?,?,?,?,?)'),
    touch: q('UPDATE accounts SET last_login = ? WHERE id = ?'),
    setPass: q('UPDATE accounts SET password_hash = ? WHERE id = ?'),
    newSession: q('INSERT INTO sessions (token_hash, account_id, created_at, expires_at) VALUES (?,?,?,?)'),
    session: q(`SELECT a.id, a.username, a.display_name FROM sessions s
                JOIN accounts a ON a.id = s.account_id
                WHERE s.token_hash = ? AND s.expires_at > ?`),
    delSession: q('DELETE FROM sessions WHERE token_hash = ?'),
    delOthers: q('DELETE FROM sessions WHERE account_id = ? AND token_hash != ?'),
    purge: q('DELETE FROM sessions WHERE expires_at < ?'),
    count: q('SELECT COUNT(*) AS n FROM accounts'),
  };
  st.purge.run(Date.now());

  const publicUser = (a) => ({ id: a.id, username: a.username, displayName: a.display_name });

  function createSession(accountId) {
    const token = crypto.randomBytes(32).toString('hex');
    const now = Date.now();
    st.newSession.run(sha256(token), accountId, now, now + SESSION_MS);
    return { token, maxAge: SESSION_MS };
  }

  function validateCredentials(username, password) {
    if (typeof username !== 'string' || !USERNAME_RE.test(username)) {
      throw new AuthError(400, 'El usuario debe tener 3 a 30 caracteres: letras, números, punto, guion o guion bajo.');
    }
    if (typeof password !== 'string' || password.length < 8 || password.length > 128) {
      throw new AuthError(400, 'La contraseña debe tener entre 8 y 128 caracteres.');
    }
  }

  return {
    async register({ username, password, displayName }) {
      validateCredentials(username, password);
      const name = (typeof displayName === 'string' && displayName.trim()) || username;
      if (!DISPLAY_RE.test(name)) {
        throw new AuthError(400, 'El nombre solo puede tener letras, números, espacios y . _ - \'');
      }
      if (st.byName.get(username)) throw new AuthError(409, 'Ese usuario ya existe. Elegí otro.');
      const id = crypto.randomUUID();
      const now = Date.now();
      try {
        st.insert.run(id, username, name.trim(), await hashPassword(password), now, now);
      } catch (e) {
        if (String(e.message).includes('UNIQUE')) throw new AuthError(409, 'Ese usuario ya existe. Elegí otro.');
        throw e;
      }
      return { user: publicUser({ id, username, display_name: name.trim() }), session: createSession(id) };
    },

    async login({ username, password }) {
      const acc = typeof username === 'string' ? st.byName.get(username) : null;
      const ok = await verifyPassword(String(password ?? ''), acc ? acc.password_hash : DUMMY_HASH);
      if (!acc || !ok) throw new AuthError(401, 'Usuario o contraseña incorrectos.');
      st.touch.run(Date.now(), acc.id);
      return { user: publicUser(acc), session: createSession(acc.id) };
    },

    async changePassword(accountId, currentToken, { currentPassword, newPassword }) {
      const acc = db.prepare('SELECT * FROM accounts WHERE id = ?').get(accountId);
      if (!(await verifyPassword(String(currentPassword ?? ''), acc.password_hash))) {
        throw new AuthError(401, 'La contraseña actual no es correcta.');
      }
      validateCredentials(acc.username, newPassword);
      st.setPass.run(await hashPassword(newPassword), accountId);
      st.delOthers.run(accountId, sha256(currentToken)); // cierra las demás sesiones
    },

    findSession(token) {
      if (!token || !/^[0-9a-f]{64}$/.test(token)) return null;
      const a = st.session.get(sha256(token), Date.now());
      return a ? publicUser(a) : null;
    },
    logout(token) {
      if (token) st.delSession.run(sha256(token));
    },
    getAccount: (id) => st.byId.get(id),
    count: () => st.count.get().n,
  };
}
