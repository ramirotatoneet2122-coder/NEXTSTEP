# NEXTSTEP — versión web (PC y celular)

Una sola página web que funciona en computadora y celular. Tiene cuentas de usuario (usuario + contraseña),
base de datos SQLite y el Profesor IA con Gemini. No hay .exe ni .apk: se entra desde el navegador.

## 1) Poner la clave de Gemini (una sola vez, en el servidor)
Abrí el archivo **`.env`** y reemplazá `PEGA_AQUI_TU_CLAVE` por tu clave (sacala gratis en https://aistudio.google.com/apikey):
```
GEMINI_API_KEY=AIzaSy...tu_clave...
```
- La clave queda **solo en el servidor**. Los usuarios no la ven ni la tienen que cargar.
- Todos los usuarios gastan tu cuota de Gemini: por eso hay un tope de **150 mensajes de IA por usuario por día**
  (`CHAT_DAILY_LIMIT` en `.env`) y 20 por minuto.
- Si algún día la clave se filtra, borrala en AI Studio, creá otra y cambiala en `.env`.

## 2) Subirla al servidor
Necesita un servidor que pueda correr **Node.js 22.13 o más nuevo** (o Docker). No sirve un hosting compartido que solo ofrece PHP/HTML.

### Opción A — Node directo (VPS / servidor propio)
```bash
# copiar esta carpeta al servidor, por ejemplo a /var/www/nextstep
cd /var/www/nextstep
npm install --omit=dev
npm start                      # prueba: http://IP-DEL-SERVIDOR:3000
```
Para que quede siempre encendido y con HTTPS, mirá `deploy/`:
- `deploy/nextstep.service` → servicio systemd (arranca solo y se reinicia si falla).
- `deploy/nginx.conf.example` → nginx delante de la app; el certificado HTTPS gratis se saca con `certbot`.

### Opción B — Docker
```bash
docker build -t nextstep-web .
docker run -d --restart always -p 3000:3000 -v nextstep-data:/data --env-file .env nextstep-web
```
(`-v nextstep-data:/data` es lo que hace que la base de datos no se borre al actualizar.)

> **Usá HTTPS siempre**: la gente va a escribir contraseñas. Sin HTTPS la cookie de sesión no es segura.

## 3) Usarla
- **PC**: abrir la dirección del sitio.
- **Celular**: abrir la dirección → menú del navegador → **"Agregar a pantalla de inicio" / "Instalar app"**.
  Queda con ícono propio y abre a pantalla completa, como una app.
- Al entrar por primera vez: *Crear cuenta*. La misma cuenta sirve en la PC y en el celular, y el progreso se sincroniza solo.

## Datos y seguridad
- Base de datos: `data/nextstep.db` (o donde digas en `NEXTSTEP_DB`). **Hacé copia de seguridad de ese archivo.**
- Las contraseñas se guardan solo como hash scrypt con sal; nadie (ni vos) puede leerlas.
- Máximo 10 intentos de login fallidos cada 15 min por usuario+IP; 20 registros por hora por IP.
- Todavía no hay "olvidé mi contraseña" por mail: si alguien la pierde hay que resetearla a mano en la base.

## Actualizar
Reemplazá los archivos (menos `.env` y `data/`) y reiniciá: `sudo systemctl restart nextstep` (o recrear el contenedor).
