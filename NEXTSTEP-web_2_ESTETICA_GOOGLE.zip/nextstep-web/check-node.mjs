// Verifica la versión de Node antes de arrancar (la base SQLite viene incluida desde Node 22.13).
const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 13)) {
  console.error(`\n❌ NEXTSTEP necesita Node.js 22.13 o más nuevo y este servidor tiene ${process.versions.node}.\n   Actualizá Node (https://nodejs.org) o usá Docker (ver README).\n`);
  process.exit(1);
}
