// Estado inicial de un usuario nuevo (materias, rutas, ejercicios, etc.)
export function getDefaultState() {
  return {
    userProfile: {
      name: "Estudiante",
      levelTitle: "Aprendiz Curioso",
      levelNumber: 3,
      currentXp: 420,
      nextLevelXp: 600,
      streakDays: 5,
      totalMinutesStudied: 185,
      completedExercisesCount: 18,
      initialAssessmentDone: false,
      preferences: {
        explanationDepth: "Equilibrada",
        languageStyle: "Claro y accesible",
        contentApproach: "Práctico con ejemplos",
        pacing: "Paso a paso",
        hintStyle: "Pistas progresivas",
        tutorTone: "Cercano y motivador",
        studyGoal: "Aprender habilidades clave y proyectos"
      }
    },
    themeConfig: {
      palette: "FOCUS_BLUE",
      isDarkMode: true,
      useSystemDark: false,
      customPrimaryHex: "#2563EB",
      customAccentHex: "#06B6D4"
    },
    studyMode: "PRACTICE",
    activeSubjectId: "subj_python",
    subjects: [
      {
        id: "subj_python",
        name: "Programación con Python",
        category: "Tecnología",
        iconEmoji: "🐍",
        estimatedLevel: "Intermedio",
        masteryPercent: 65,
        topicsMastered: ["Variables y tipos", "Condicionales", "Bucles for y while", "Funciones básicas"],
        topicsInProgress: ["Programación orientada a objetos", "Manejo de excepciones"],
        topicsPending: ["Decoradores", "Generadores y concurrencia", "APIs REST con FastAPI"],
        topicsToReinforce: ["Métodos especiales (__init__, __str__)", "Herencia múltiple"],
        description: "Desde fundamentos algorítmicos hasta desarrollo de software y manipulación de datos."
      },
      {
        id: "subj_math",
        name: "Álgebra y Matemáticas",
        category: "Ciencias Exactas",
        iconEmoji: "📐",
        estimatedLevel: "Intermedio",
        masteryPercent: 52,
        topicsMastered: ["Ecuaciones de 1er grado", "Factorización", "Funciones lineales"],
        topicsInProgress: ["Sistemas de ecuaciones", "Matrices y determinantes"],
        topicsPending: ["Espacios vectoriales", "Transformaciones lineales", "Cálculo diferencial"],
        topicsToReinforce: ["Operaciones con matrices inversas"],
        description: "Estructuras algebraicas, matrices y resolución analítica de problemas complejos."
      },
      {
        id: "subj_ai",
        name: "Inteligencia Artificial y ML",
        category: "Tecnología",
        iconEmoji: "🤖",
        estimatedLevel: "Principiante",
        masteryPercent: 38,
        topicsMastered: ["Concepto de IA vs ML", "Tipos de aprendizaje: Supervisado y No Supervisado"],
        topicsInProgress: ["Regresión lineal", "Métricas de evaluación (F1, Precisión)"],
        topicsPending: ["Redes neuronales", "Transformers y LLMs", "Fine-tuning"],
        topicsToReinforce: ["Overfitting y regularización L1/L2"],
        description: "Modelos predictivos, redes neuronales e integración práctica de modelos de lenguaje."
      },
      {
        id: "subj_history",
        name: "Historia Universal",
        category: "Humanidades",
        iconEmoji: "🏛️",
        estimatedLevel: "Avanzado",
        masteryPercent: 80,
        topicsMastered: ["Revolución Industrial", "Primera Guerra Mundial", "Guerra Fría"],
        topicsInProgress: ["Procesos de descolonización"],
        topicsPending: ["Geopolítica contemporánea"],
        topicsToReinforce: ["Impacto económico de la posguerra"],
        description: "Análisis crítico de procesos históricos, causas y consecuencias globales."
      },
      {
        id: "subj_english",
        name: "Inglés Técnico para IT",
        category: "Idiomas",
        iconEmoji: "🌐",
        estimatedLevel: "Intermedio",
        masteryPercent: 70,
        topicsMastered: ["Vocabulario de desarrollo", "Lectura de documentación", "Git PRs"],
        topicsInProgress: ["Explicación de arquitectura técnica"],
        topicsPending: ["Entrevistas técnicas en inglés"],
        topicsToReinforce: ["Phrasal verbs en resolución de bugs"],
        description: "Comunicación fluida en equipos internacionales, documentación y entrevistas."
      }
    ],
    routes: [
      {
        id: "route_python_master",
        subjectId: "subj_python",
        title: "Ruta: Desarrollador Backend en Python",
        description: "Recorrido integral desde la sintaxis central hasta arquitectura orientada a objetos y APIs.",
        targetLevel: "Intermedio - Avanzado",
        modules: [
          {
            id: "mod_py_1",
            orderNumber: 1,
            title: "1. Fundamentos y Flujo de Control",
            description: "Variables, colecciones dinámicas y estructuras condicionales.",
            isCompleted: true,
            isCurrent: false,
            isLocked: false,
            keyConcepts: ["Tipado dinámico", "List comprehensions", "Estructuras de control"],
            contentSummary: "Python destaca por su sintaxis legible. Las listas y diccionarios son las estructuras clave para manipular datos en memoria con alta expresividad.",
            xpReward: 50
          },
          {
            id: "mod_py_2",
            orderNumber: 2,
            title: "2. Funciones y Modularidad",
            description: "Parámetros *args y **kwargs, funciones de orden superior, ámbito y módulos.",
            isCompleted: true,
            isCurrent: false,
            isLocked: false,
            keyConcepts: ["Scope LEGB", "Funciones lambda", "Decoradores básicos"],
            contentSummary: "Las funciones en Python son objetos de primera clase. Pueden pasarse como argumentos y retornar otras funciones para crear abstracciones poderosas.",
            xpReward: 50
          },
          {
            id: "mod_py_3",
            orderNumber: 3,
            title: "3. Programación Orientada a Objetos",
            description: "Clases, constructores __init__, encapsulamiento, herencia, polimorfismo y métodos mágicos.",
            isCompleted: false,
            isCurrent: true,
            isLocked: false,
            keyConcepts: ["Clases e instancias", "Encapsulamiento", "Métodos mágicos"],
            contentSummary: "La POO permite modelar el dominio del problema mediante clases que agrupan estado (atributos) y comportamiento (métodos).",
            xpReward: 60
          },
          {
            id: "mod_py_4",
            orderNumber: 4,
            title: "4. Manejo de Errores y Archivos",
            description: "Bloques try/except/finally, creación de excepciones personalizadas y context managers.",
            isCompleted: false,
            isCurrent: false,
            isLocked: false,
            keyConcepts: ["Bloque try-except", "Context managers", "Persistencia JSON"],
            contentSummary: "El manejo robusto de excepciones evita caídas catastróficas y permite una degradación elegante ante fallos de I/O.",
            xpReward: 60
          },
          {
            id: "mod_py_5",
            orderNumber: 5,
            title: "5. Proyecto Integrador: API y Persistencia",
            description: "Construcción de un servicio RESTful con validaciones, endpoints y persistencia estructurada.",
            isCompleted: false,
            isCurrent: false,
            isLocked: true,
            keyConcepts: ["Rutas HTTP", "Serialización de datos", "Buenas prácticas REST"],
            contentSummary: "Integración de todos los módulos anteriores en un servicio funcional con arquitectura limpia.",
            xpReward: 100
          }
        ]
      }
    ],
    exercises: [
      {
        id: "ex_py_1",
        subjectId: "subj_python",
        subjectName: "Programación con Python",
        topic: "Programación Orientada a Objetos",
        difficulty: "MEDIA",
        question: "¿Cuál es el propósito del parámetro 'self' en los métodos de una clase en Python?",
        codeSnippet: "class Estudiante:\n    def __init__(self, nombre):\n        self.nombre = nombre",
        options: [
          "Es una palabra reservada que crea un nuevo hilo de ejecución.",
          "Representa la instancia específica del objeto que está ejecutando el método.",
          "Es un decorador obligatorio para métodos estáticos.",
          "Sirve para importar módulos del sistema automáticamente."
        ],
        correctOptionIndex: 1,
        hintLevel1: "Piensa en cómo sabe un objeto a qué atributos propios debe acceder cuando se llama al método.",
        hintLevel2: "Cuando haces alumno.saludar(), Python pasa internamente 'alumno' como primer argumento.",
        explanation: "'self' es una convención que referencia la instancia actual del objeto. Permite asignar y leer variables de instancia como self.nombre.",
        xpReward: 35
      },
      {
        id: "ex_py_2",
        subjectId: "subj_python",
        subjectName: "Programación con Python",
        topic: "List Comprehensions",
        difficulty: "FACIL",
        question: "¿Qué devolverá la siguiente comprensión de lista en Python?",
        codeSnippet: "numeros = [1, 2, 3, 4, 5]\nresultado = [n * 2 for n in numeros if n % 2 != 0]",
        options: [
          "[2, 4, 6, 8, 10]",
          "[2, 6, 10]",
          "[4, 8]",
          "[1, 3, 5]"
        ],
        correctOptionIndex: 1,
        hintLevel1: "Fíjate en la condición 'if n % 2 != 0'. ¿Qué números selecciona?",
        hintLevel2: "Filtra los impares (1, 3, 5) y luego aplica n * 2 a cada uno.",
        explanation: "La condición 'n % 2 != 0' filtra los números impares: 1, 3 y 5. Luego la expresión 'n * 2' los duplica: [2, 6, 10].",
        xpReward: 25
      },
      {
        id: "ex_math_1",
        subjectId: "subj_math",
        subjectName: "Álgebra y Matemáticas",
        topic: "Matrices",
        difficulty: "MEDIA",
        question: "Si la matriz A tiene dimensiones (3 x 2) y la matriz B tiene dimensiones (2 x 4), ¿cuáles son las dimensiones de la matriz producto A * B?",
        options: [
          "No se pueden multiplicar",
          "Dimensión (2 x 2)",
          "Dimensión (3 x 4)",
          "Dimensión (4 x 3)"
        ],
        correctOptionIndex: 2,
        hintLevel1: "Recuerda la regla de las columnas de la primera y las filas de la segunda.",
        hintLevel2: "Para (m x k) * (k x n), las columnas internas 'k' coinciden (2=2), y el resultado toma las externas (m x n).",
        explanation: "Dado que el número de columnas de A (2) es igual al número de filas de B (2), la multiplicación es válida y el resultado tiene dimensiones (3 x 4).",
        xpReward: 30
      }
    ],
    evaluations: [
      {
        id: "eval_diag_general",
        subjectId: "subj_python",
        subjectName: "Programación con Python",
        title: "Evaluación Diagnóstica: Python y Lógica de Código",
        durationMinutes: 12,
        completed: false,
        scorePercent: 0,
        demonstratedLevel: "Por evaluar",
        questions: [
          {
            id: "q1",
            topic: "Estructuras de Control",
            question: "¿Qué imprime el siguiente código? for i in range(1, 4): print(i, end=' ')",
            options: ["1 2 3 4", "1 2 3", "0 1 2 3", "2 3 4"],
            correctIndex: 1,
            explanation: "range(inicio, fin) es inclusivo en el inicio y exclusivo en el límite superior, por lo que genera 1, 2 y 3."
          },
          {
            id: "q2",
            topic: "Tipos de Datos",
            question: "¿Cuál de las siguientes colecciones en Python es inmutable?",
            options: ["Lista (list)", "Diccionario (dict)", "Tupla (tuple)", "Conjunto (set)"],
            correctIndex: 2,
            explanation: "Las tuplas son inmutables una vez creadas; no permiten modificar elementos in-situ."
          },
          {
            id: "q3",
            topic: "Funciones",
            question: "¿Qué sucede si una función en Python no incluye una sentencia 'return' explícita?",
            options: ["Lanza un error de sintaxis", "Retorna el valor 0", "Retorna 'None'", "Retorna una cadena vacía"],
            correctIndex: 2,
            explanation: "En Python, cualquier función que finaliza sin 'return' devuelve implícitamente None."
          }
        ]
      }
    ],
    goals: [
      {
        id: "goal_python_api",
        title: "Aprender a construir una API REST en Python",
        description: "Dominar endpoints, validaciones y conexión a bases de datos.",
        deadline: "En 3 semanas",
        priority: "ALTA",
        progressPercent: 66,
        tasks: [
          { id: "gt_1", title: "Completar módulo de POO y métodos especiales", isCompleted: true },
          { id: "gt_2", title: "Aprender manejo de excepciones y context managers", isCompleted: true },
          { id: "gt_3", title: "Implementar 3 endpoints CRUD con validaciones", isCompleted: false }
        ]
      }
    ],
    achievements: [
      { id: "first_step", title: "Primer Paso", description: "Comenzaste tu trayectoria en NEXTSTEP.", iconEmoji: "🚀", isUnlocked: true, unlockedAt: "Al inicio", xpReward: 100 },
      { id: "level_up", title: "Constancia en Ascenso", description: "Alcanzaste un nuevo nivel general de aprendizaje.", iconEmoji: "⭐", isUnlocked: true, unlockedAt: "Nivel 3", xpReward: 150 },
      { id: "route_progress", title: "Explorador de Rutas", description: "Completaste módulos de tu ruta personalizada.", iconEmoji: "🗺️", isUnlocked: true, unlockedAt: "Ruta Python", xpReward: 100 },
      { id: "practice_hero", title: "Mente Resiliente", description: "Completaste más de 10 ejercicios interactivos.", iconEmoji: "💡", isUnlocked: true, unlockedAt: "Esta semana", xpReward: 200 },
      { id: "quiz_ace", title: "Evaluador Riguroso", description: "Finalizaste una evaluación completa demostrando tu nivel.", iconEmoji: "🏆", isUnlocked: false, xpReward: 250 }
    ],
    chatHistory: [
      {
        id: "msg_1",
        sender: "tutor",
        content: "¡Bienvenido a NEXTSTEP! Soy tu profesor particular con inteligencia artificial. Conozco tus preferencias y estoy listo para acompañarte en tu ruta de aprendizaje. ¿En qué tema o desafío te gustaría avanzar hoy?",
        timestamp: Date.now()
      }
    ],
    resources: [
      { id: "res_1", title: "Documentación Oficial de Python 3", category: "Documentación", description: "Referencia completa del lenguaje, librería estándar y tutorial oficial estructurado.", difficulty: "Todos los niveles", urlPlaceholder: "docs.python.org/es/3/", iconEmoji: "📖" },
      { id: "res_2", title: "3Blue1Brown: Esencia del Álgebra Lineal", category: "Visual & Conceptual", description: "Serie visual magistral para comprender transformaciones, determinantes y vectores.", difficulty: "Intermedio", urlPlaceholder: "3blue1brown.com/topics/linear-algebra", iconEmoji: "🎥" },
      { id: "res_3", title: "Guía de Prompt Engineering y LLMs", category: "Inteligencia Artificial", description: "Principios modernos para diseñar instrucciones de sistema y Few-Shot.", difficulty: "Principiante a Avanzado", urlPlaceholder: "ai.google.dev/docs", iconEmoji: "🧠" }
    ]
  };
}
