import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath, pathToFileURL } from 'url';
import { openDb, createStore } from './db.js';
import { createAuth, AuthError } from './auth.js';
import { getDefaultState } from './defaults.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, '.env') });  // la clave de Gemini se lee de web/.env

/**
 * Crea la app Express de NEXTSTEP (web, PC y servidor comparten este código).
 *  - dbFile: ruta del archivo SQLite (usuarios, contraseñas con hash y todo el progreso)
 *  - Todas las rutas /api/* (salvo /api/auth/* y /api/health) exigen iniciar sesión.
 */
export function createApp({
  dbFile = process.env.NEXTSTEP_DB || path.join(__dirname, 'data', 'nextstep.db'),
  geminiKey = process.env.GEMINI_API_KEY,
} = {}) {
  geminiKey = (geminiKey || '').trim().replace(/^['"]|['"]$/g, '');
  if (!geminiKey || geminiKey.startsWith('PEGA_AQUI')) geminiKey = '';
  const app = express();
  const db = openDb(dbFile);
  const store = createStore(db);
  const auth = createAuth(db);

  app.set('trust proxy', 1);
  app.use(cors());
  app.use(express.json({ limit: '1mb' }));
  app.use(express.static(path.join(__dirname, 'public')));

  // --- Sesiones / cuentas ---
  function parseCookies(header = '') {
    return Object.fromEntries(header.split(';').map((c) => c.trim().split('=')).filter((p) => p[0]));
  }
  const sessionToken = (req) => parseCookies(req.headers.cookie).nextstep_session;
  function setSessionCookie(req, res, session) {
    res.cookie('nextstep_session', session.token, {
      httpOnly: true, sameSite: 'lax', secure: req.secure, maxAge: session.maxAge, path: '/',
    });
  }

  // Frena la fuerza bruta: 10 intentos fallidos cada 15 min por usuario+IP, y 20 registros por hora por IP
  const failures = new Map();
  const registrations = new Map();
  function tooMany(map, key, max, windowMs) {
    const now = Date.now();
    const arr = (map.get(key) || []).filter((t) => now - t < windowMs);
    map.set(key, arr);
    return arr.length >= max;
  }
  const note = (map, key) => map.set(key, [...(map.get(key) || []), Date.now()]);

  function authError(res, e) {
    if (e instanceof AuthError) return res.status(e.status).json({ error: e.message });
    console.error('Error de autenticación:', e);
    return res.status(500).json({ error: 'Error interno al procesar la cuenta.' });
  }

  app.get('/api/auth/me', (req, res) => {
    const user = auth.findSession(sessionToken(req));
    res.json({ user: user || null, firstAccount: auth.count() === 0 });
  });

  app.post('/api/auth/register', async (req, res) => {
    const ipKey = req.ip;
    if (tooMany(registrations, ipKey, 20, 60 * 60 * 1000)) {
      return res.status(429).json({ error: 'Demasiados registros desde esta conexión. Probá más tarde.' });
    }
    try {
      const { user, session } = await auth.register(req.body || {});
      note(registrations, ipKey);
      setSessionCookie(req, res, session);
      res.status(201).json({ user });
    } catch (e) { authError(res, e); }
  });

  app.post('/api/auth/login', async (req, res) => {
    const key = `${req.ip}|${String(req.body?.username || '').toLowerCase()}`;
    if (tooMany(failures, key, 10, 15 * 60 * 1000)) {
      return res.status(429).json({ error: 'Demasiados intentos fallidos. Esperá 15 minutos.' });
    }
    try {
      const { user, session } = await auth.login(req.body || {});
      failures.delete(key);
      setSessionCookie(req, res, session);
      res.json({ user });
    } catch (e) {
      if (e instanceof AuthError && e.status === 401) note(failures, key);
      authError(res, e);
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    auth.logout(sessionToken(req));
    res.clearCookie('nextstep_session', { path: '/' });
    res.json({ ok: true });
  });

  app.post('/api/auth/password', async (req, res) => {
    const token = sessionToken(req);
    const user = auth.findSession(token);
    if (!user) return res.status(401).json({ error: 'Iniciá sesión para continuar.', auth: true });
    try {
      await auth.changePassword(user.id, token, req.body || {});
      res.json({ ok: true });
    } catch (e) { authError(res, e); }
  });

  // Todo lo demás de /api requiere sesión
  app.use('/api', (req, res, next) => {
    if (req.path === '/health') return next();
    const user = auth.findSession(sessionToken(req));
    if (!user) return res.status(401).json({ error: 'Iniciá sesión para continuar.', auth: true });
    req.uid = user.id;
    req.account = user;
    next();
  });

  // --- Límite simple para el chat con IA (evita abusos de la clave del servidor) ---
  const hits = new Map();
  const daily = new Map();   // mensajes por cuenta y por día (protege tu cuota de Gemini)
  const DAILY_MAX = Number(process.env.CHAT_DAILY_LIMIT) || 150;
  function chatLimiter(req, res, next) {
    const now = Date.now();
    const day = new Date().toISOString().slice(0, 10) + req.uid;
    if ((daily.get(day) || 0) >= DAILY_MAX) {
      return res.status(429).json({ error: `Llegaste al límite de ${DAILY_MAX} mensajes de hoy. Volvé mañana.` });
    }
    const arr = (hits.get(req.uid) || []).filter((t) => now - t < 60_000);
    if (arr.length >= 20) {
      return res.status(429).json({ error: 'Demasiados mensajes seguidos. Esperá un minuto.' });
    }
    arr.push(now);
    hits.set(req.uid, arr);
    daily.set(day, (daily.get(day) || 0) + 1);
    if (daily.size > 5000) daily.clear();
    next();
  }

  // --- Persistencia (SQLite) ---
  function saveState(uid, state) {
    store.save(uid, state);
  }
  function loadState(uid) {
    const existing = store.load(uid);
    if (existing) return existing;
    // Primera vez de esta cuenta: estado inicial con su nombre
    const initial = getDefaultState();
    const acc = auth.getAccount(uid);
    if (acc) initial.userProfile.name = acc.display_name;
    saveState(uid, initial);
    return store.load(uid);
  }

  app.get('/api/state', (req, res) => {
    const state = loadState(req.uid);
    res.json(state);
  });

  app.post('/api/settings', (req, res) => {
    const state = loadState(req.uid);
    const { themeConfig, studyMode, activeSubjectId, preferences, customApiKey } = req.body;
    if (themeConfig) state.themeConfig = { ...state.themeConfig, ...themeConfig };
    if (studyMode) state.studyMode = studyMode;
    if (activeSubjectId) state.activeSubjectId = activeSubjectId;
    if (preferences) state.userProfile.preferences = { ...state.userProfile.preferences, ...preferences };
    if (customApiKey !== undefined) state.customApiKey = customApiKey;
    saveState(req.uid, state);
    res.json({ success: true, state });
  });

  app.post('/api/action', (req, res) => {
    const state = loadState(req.uid);
    const { action, payload } = req.body;

    if (action === 'ADD_XP') {
      const amount = payload.amount || 20;
      state.userProfile.currentXp += amount;
      if (state.userProfile.currentXp >= state.userProfile.nextLevelXp) {
        state.userProfile.levelNumber += 1;
        state.userProfile.nextLevelXp = Math.floor(state.userProfile.nextLevelXp * 1.5);
      }
    } else if (action === 'ADD_STUDY_TIME') {
      state.userProfile.totalMinutesStudied += (payload.minutes || 1);
    } else if (action === 'COMPLETE_MODULE') {
      const { moduleId } = payload;
      for (const route of state.routes) {
        const idx = route.modules.findIndex(m => m.id === moduleId);
        if (idx !== -1) {
          route.modules[idx].isCompleted = true;
          route.modules[idx].isCurrent = false;
          if (idx + 1 < route.modules.length) {
            route.modules[idx + 1].isCurrent = true;
            route.modules[idx + 1].isLocked = false;
          }
        }
      }
      state.userProfile.currentXp += 60;
    } else if (action === 'TOGGLE_GOAL_TASK') {
      const { goalId, taskId } = payload;
      const goal = state.goals.find(g => g.id === goalId);
      if (goal) {
        const task = goal.tasks.find(t => t.id === taskId);
        if (task) {
          task.isCompleted = !task.isCompleted;
          const comp = goal.tasks.filter(t => t.isCompleted).length;
          goal.progressPercent = Math.round((comp / goal.tasks.length) * 100);
          state.userProfile.currentXp += 25;
        }
      }
    } else if (action === 'ADD_GOAL') {
      const g = payload.goal || {};
      const clip = (x, max, fb) => (typeof x === 'string' && x.trim() ? x.trim().slice(0, max) : fb);
      const now = Date.now();
      const tasks = (Array.isArray(g.tasks) ? g.tasks : []).slice(0, 15)
        .map((t, i) => ({ id: `gt_${now}_${i}`, title: clip(t && t.title, 120, 'Tarea'), isCompleted: false }));
      if (state.goals.length < 50) {
        state.goals.push({
          id: 'goal_' + now, title: clip(g.title, 100, 'Nuevo objetivo'), description: clip(g.description, 300, ''),
          deadline: clip(g.deadline, 40, 'Sin plazo'),
          priority: ['ALTA', 'MEDIA', 'BAJA'].includes(g.priority) ? g.priority : 'MEDIA',
          progressPercent: 0, tasks,
        });
      }
    } else if (action === 'COMPLETE_EXERCISE') {
      // La corrección se hace en el servidor con la respuesta guardada del ejercicio
      const ex = state.exercises.find(e => e.id === payload.exerciseId);
      if (ex) {
        const p = state.userProfile;
        p.completedExercisesCount += 1;
        if (Number(payload.selectedIndex) === ex.correctOptionIndex) {
          p.currentXp += ex.xpReward;
          if (p.currentXp >= p.nextLevelXp) {
            p.levelNumber += 1;
            p.nextLevelXp = Math.floor(p.nextLevelXp * 1.5);
          }
        }
      }
    } else if (action === 'ADD_SUBJECT') {
      const clip = (v, max, fb) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : fb);
      if (state.subjects.length < 50) {
        state.subjects.push({
          id: 'subj_' + Date.now(),
          name: clip(payload.name, 60, 'Nueva materia'),
          category: clip(payload.category, 40, 'General'),
          iconEmoji: '📘',
          estimatedLevel: 'Principiante',
          masteryPercent: 10,
          topicsMastered: [],
          topicsInProgress: [],
          topicsPending: [],
          topicsToReinforce: [],
          description: clip(payload.description, 300, 'Materia personalizada'),
        });
      }
    } else if (action === 'CLEAR_CHAT') {
      state.chatHistory = [{
        id: 'msg_' + Date.now(),
        sender: 'tutor',
        content: 'Conversación reiniciada. ¿Qué tema quieres explorar hoy?',
        timestamp: Date.now(),
      }];
    } else if (action === 'COMPLETE_ONBOARDING' && payload.skipped) {
      state.userProfile.initialAssessmentDone = true;   // omitir: sin cambios de perfil ni XP
    } else if (action === 'COMPLETE_ONBOARDING') {
      const p = state.userProfile;
      const clean = (v, fallback) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, 120) : fallback);
      p.preferences = {
        ...p.preferences,
        studyGoal: clean(payload.goal, p.preferences.studyGoal),
        explanationDepth: clean(payload.depth, p.preferences.explanationDepth),
        tutorTone: clean(payload.tone, p.preferences.tutorTone),
      };
      if (!p.initialAssessmentDone) {
        p.currentXp += 100;
        if (p.currentXp >= p.nextLevelXp) {
          p.levelNumber += 1;
          p.nextLevelXp = Math.floor(p.nextLevelXp * 1.5);
        }
      }
      p.initialAssessmentDone = true;
    } else if (action === 'COMPLETE_EVALUATION') {
      const { evalId, scorePercent, level, strengths, weaknesses } = payload;
      const ev = state.evaluations.find(e => e.id === evalId);
      if (ev) {
        ev.completed = true;
        ev.scorePercent = scorePercent;
        ev.demonstratedLevel = level;
        ev.strengths = strengths;
        ev.weaknessesToReinforce = weaknesses;
        state.userProfile.currentXp += 120;
      }
    }

    saveState(req.uid, state);
    res.json({ success: true, state });
  });

  app.post('/api/reset', (req, res) => {
    const defaultState = getDefaultState();
    defaultState.userProfile.name = req.account.displayName;
    saveState(req.uid, defaultState);
    res.json({ success: true, state: defaultState });
  });

  // Gemini Chat Endpoint
  app.post('/api/chat', chatLimiter, async (req, res) => {
    const state = loadState(req.uid);
    const { message, pedagogicalAction } = req.body;
    const apiKey = req.body.customApiKey || state.customApiKey || geminiKey;

    if (!apiKey || apiKey === 'tu_clave_gemini_aqui') {
      return res.status(400).json({
        error: "Clave de Gemini API no configurada. Ingresa tu clave en Configuración o en el archivo .env."
      });
    }

    const activeSubj = state.subjects.find(s => s.id === state.activeSubjectId) || state.subjects[0];
    const profile = state.userProfile;
    const pref = profile.preferences;

    const systemInstruction = `
  Eres NEXTSTEP, profesor particular virtual con inteligencia artificial para el alumno ${profile.name}.
  PRINCIPIOS PEDAGÓGICOS:
  1. No eres un chatbot genérico. Eres un educador empático, metódico y activo.
  2. Comprueba la comprensión haciendo preguntas al final de cada concepto.
  3. Si el alumno pide pistas o practica: entrega pistas graduales socráticas, jamás la respuesta completa de golpe.
  4. Explica por qué ocurren los errores y guía hacia la solución.
  5. Adáptate a las peticiones del usuario inmediatamente.

  PERFIL:
  - Alumno: ${profile.name} (Nivel ${profile.levelNumber}, ${profile.currentXp} XP)
  - Materia activa: ${activeSubj.name} (${activeSubj.category}), Dominio actual: ${activeSubj.masteryPercent}%
  - Preferencias: Explicación ${pref.explanationDepth}, Lenguaje ${pref.languageStyle}, Enfoque ${pref.contentApproach}, Tono ${pref.tutorTone}.
  - Modo de estudio: ${state.studyMode}.
  ${pedagogicalAction ? `INSTRUCCIÓN PEDAGÓGICA SOLICITADA: ${pedagogicalAction}` : ''}
  `;

    try {
      const recent = state.chatHistory.slice(-8);
      const contents = [];

      for (const m of recent) {
        contents.push({
          role: m.sender === 'user' ? 'user' : 'model',
          parts: [{ text: m.content }]
        });
      }

      const fullUserText = pedagogicalAction ? `[${pedagogicalAction}]: ${message}` : message;
      contents.push({
        role: 'user',
        parts: [{ text: fullUserText }]
      });

      const geminiPayload = {
        systemInstruction: {
          parts: [{ text: systemInstruction }]
        },
        contents: contents,
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 1500
        }
      };

      // Call Google Gemini API (gemini-2.5-flash)
      const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent`;
      const response = await fetch(geminiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
        body: JSON.stringify(geminiPayload)
      });

      if (!response.ok) {
        const errBody = await response.text();
        return res.status(response.status).json({
          error: `Error de Gemini API (${response.status}): ${errBody}`
        });
      }

      const json = await response.json();
      const candidateText = json.candidates?.[0]?.content?.parts?.[0]?.text;

      if (!candidateText) {
        return res.status(500).json({ error: "La IA no retornó contenido legible." });
      }

      // Save message to state
      state.chatHistory.push({
        id: "msg_" + Date.now(),
        sender: "user",
        content: fullUserText,
        pedagogicalAction: pedagogicalAction || null,
        timestamp: Date.now()
      });

      state.chatHistory.push({
        id: "msg_" + (Date.now() + 1),
        sender: "tutor",
        content: candidateText,
        timestamp: Date.now() + 1
      });

      state.userProfile.currentXp += 15;
      saveState(req.uid, state);

      res.json({ reply: candidateText, state });
    } catch (err) {
      console.error("Gemini fetch error:", err);
      res.status(500).json({ error: "Fallo de conexión con Google Gemini: " + err.message });
    }
  });

  app.get('/api/health', (req, res) => res.json({ ok: true, accounts: auth.count(), geminiConfigured: !!geminiKey }));

  app.close = () => db.close();
  return app;
}

/** Arranca el servidor. port = 0 elige un puerto libre (lo usa la app de PC). */
export function startServer({ port = process.env.PORT || 3000, host, ...opts } = {}) {
  const app = createApp(opts);
  return new Promise((resolve, reject) => {
    const server = app.listen(port, host, () => {
      const actual = server.address().port;
      resolve({ app, server, port: actual });
    });
    server.on('error', reject);
  });
}

// Ejecución directa: `node server.js`
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  startServer().then(({ port }) => {
    console.log('=========================================');
    console.log('🚀 NEXTSTEP Web Platform ejecutándose en:');
    console.log(`👉 http://localhost:${port}`);
    console.log('=========================================');
  });
}
