// Service worker mínimo: hace que el navegador ofrezca 'Instalar app'. No guarda nada: la app siempre usa el servidor.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
