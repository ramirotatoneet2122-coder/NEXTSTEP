// NEXTSTEP — pantalla de inicio de sesión / registro y botón "Cerrar sesión".
const nsAuth = (() => {
  const STYLE = `
  #ns-auth{position:fixed;inset:0;z-index:100000;display:flex;align-items:center;justify-content:center;padding:16px;
    background:radial-gradient(1200px 600px at 20% -10%,rgba(59,130,246,.22),transparent),radial-gradient(900px 500px at 90% 110%,rgba(139,92,246,.18),transparent),var(--bg-main,#0B0F19);
    font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--text-primary,#F1F5F9);overflow:auto}
  #ns-auth .card{width:100%;max-width:410px;background:var(--bg-card,#111827);border:1px solid var(--border,#334155);border-radius:20px;padding:28px;box-shadow:0 24px 70px rgba(0,0,0,.5)}
  #ns-auth .brand{display:flex;align-items:center;gap:12px;margin-bottom:6px}
  #ns-auth .logo{width:42px;height:42px;border-radius:50%;background:var(--primary,#3B82F6);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1.2rem;color:#fff}
  #ns-auth .brand b{font-size:1.5rem;letter-spacing:.5px}
  #ns-auth .sub{color:var(--text-secondary,#94A3B8);font-size:.92rem;margin:0 0 18px}
  #ns-auth .tabs{display:flex;background:var(--bg-input,#0F172A);border-radius:12px;padding:4px;margin-bottom:18px}
  #ns-auth .tabs button{flex:1;padding:9px;border:0;border-radius:9px;background:transparent;color:var(--text-secondary,#94A3B8);font-weight:600;font-size:.95rem;cursor:pointer;font-family:inherit}
  #ns-auth .tabs button.on{background:var(--primary,#3B82F6);color:#fff}
  #ns-auth label{display:block;font-size:.82rem;font-weight:600;margin:0 0 5px;color:var(--text-secondary,#94A3B8)}
  #ns-auth .field{margin-bottom:13px}
  #ns-auth input{width:100%;box-sizing:border-box;padding:12px 14px;border-radius:10px;border:1px solid var(--border,#334155);background:var(--bg-input,#0F172A);color:inherit;font-size:1rem;font-family:inherit;outline:none}
  #ns-auth input:focus{border-color:var(--primary,#3B82F6)}
  #ns-auth .pw{position:relative}#ns-auth .pw button{position:absolute;right:6px;top:50%;transform:translateY(-50%);background:none;border:0;color:var(--text-secondary,#94A3B8);cursor:pointer;font-size:1.05rem;padding:6px}
  #ns-auth .err{color:#F87171;font-size:.88rem;min-height:1.25em;margin:2px 0 10px}
  #ns-auth .go{width:100%;padding:13px;border:0;border-radius:11px;background:var(--primary,#3B82F6);color:#fff;font-weight:700;font-size:1rem;cursor:pointer;font-family:inherit}
  #ns-auth .go:disabled{opacity:.6;cursor:wait}
  #ns-auth .hint{font-size:.8rem;color:var(--text-secondary,#94A3B8);margin-top:12px;text-align:center;line-height:1.4}`;

  const post = (path, body) => fetch(path, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}),
  });

  let currentUser = null;
  function addAccountBar(user) { currentUser = user; }   // la tarjeta de cuenta se dibuja en Configuración
  async function logout() { await post('/api/auth/logout'); location.reload(); }

  // Si la sesión vence con la app abierta, vuelve a la pantalla de login
  function watchExpiredSessions() {
    const base = window.fetch;
    window.fetch = async (...args) => {
      const res = await base(...args);
      const url = typeof args[0] === 'string' ? args[0] : '';
      if (res.status === 401 && url.startsWith('/api/') && !url.startsWith('/api/auth/')) location.reload();
      return res;
    };
  }

  function showForm(firstAccount, onDone) {
    const st = document.createElement('style'); st.textContent = STYLE; document.head.appendChild(st);
    const o = document.createElement('div'); o.id = 'ns-auth';
    o.innerHTML = `<div class="card">
      <div class="brand"><div class="logo">N</div><b>NEXTSTEP</b></div>
      <p class="sub" id="ns-sub"></p>
      <div class="tabs"><button type="button" data-m="login">Iniciar sesión</button><button type="button" data-m="register">Crear cuenta</button></div>
      <form id="ns-form" autocomplete="on" novalidate>
        <div class="field"><label for="ns-user">Usuario</label><input id="ns-user" name="username" autocomplete="username" autocapitalize="none" spellcheck="false"></div>
        <div class="field" id="ns-name-f"><label for="ns-name">Tu nombre (cómo te saluda el tutor)</label><input id="ns-name" name="displayName" autocomplete="nickname"></div>
        <div class="field"><label for="ns-pass">Contraseña</label><div class="pw"><input id="ns-pass" name="password" type="password"><button type="button" id="ns-eye" aria-label="Mostrar contraseña">👁</button></div></div>
        <div class="field" id="ns-pass2-f"><label for="ns-pass2">Repetir contraseña</label><input id="ns-pass2" type="password" autocomplete="new-password"></div>
        <div class="err" id="ns-err" role="alert"></div>
        <button class="go" id="ns-go" type="submit"></button>
      </form>
      <p class="hint" id="ns-hint"></p></div>`;
    document.body.appendChild(o);
    const $ = (id) => o.querySelector('#' + id);
    let mode = firstAccount ? 'register' : 'login';

    function render() {
      o.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.m === mode));
      const reg = mode === 'register';
      $('ns-name-f').style.display = reg ? '' : 'none';
      $('ns-pass2-f').style.display = reg ? '' : 'none';
      $('ns-pass').autocomplete = reg ? 'new-password' : 'current-password';
      $('ns-go').textContent = reg ? 'Crear mi cuenta' : 'Entrar';
      $('ns-sub').textContent = reg ? 'Creá tu cuenta para guardar tu progreso.' : 'Entrá con tu usuario y contraseña.';
      $('ns-hint').textContent = reg ? 'Usuario: 3 a 30 caracteres (letras, números, . _ -). Contraseña: mínimo 8.' : '';
      $('ns-err').textContent = '';
    }
    o.querySelectorAll('.tabs button').forEach(b => b.onclick = () => { mode = b.dataset.m; render(); });
    $('ns-eye').onclick = () => {
      const t = $('ns-pass').type === 'password' ? 'text' : 'password';
      $('ns-pass').type = t; $('ns-pass2').type = t;
    };

    $('ns-form').onsubmit = async (e) => {
      e.preventDefault();
      const err = $('ns-err'), go = $('ns-go');
      const username = $('ns-user').value.trim(), password = $('ns-pass').value;
      if (!username || !password) { err.textContent = 'Completá usuario y contraseña.'; return; }
      if (mode === 'register' && password !== $('ns-pass2').value) { err.textContent = 'Las contraseñas no coinciden.'; return; }
      go.disabled = true; err.textContent = '';
      try {
        const body = { username, password };
        if (mode === 'register') body.displayName = $('ns-name').value.trim();
        const res = await post('/api/auth/' + mode, body);
        const data = await res.json().catch(() => ({}));
        if (!res.ok) { err.textContent = data.error || 'No se pudo completar. Probá de nuevo.'; go.disabled = false; return; }
        o.remove();
        onDone(data.user);
      } catch (_) {
        err.textContent = 'No hay conexión con el servidor.'; go.disabled = false;
      }
    };
    render();
    $('ns-user').focus();
  }

  async function ensureLoggedIn() {
    watchExpiredSessions();
    let me = { user: null, firstAccount: false };
    try { me = await (await fetch('/api/auth/me')).json(); } catch (_) { /* servidor caído: se muestra el login igual */ }
    if (me.user) { addAccountBar(me.user); return true; }
    return new Promise((resolve) => showForm(me.firstAccount, (user) => { addAccountBar(user); resolve(true); }));
  }

  return { ensureLoggedIn, logout, get user() { return currentUser; } };
})();
window.nsAuth = nsAuth;
