// Pide la clave de Gemini la primera vez (en AI Studio la inyectaba la plataforma; fuera de ahí hay que cargarla una vez).
(function () {
  const STYLE = `
  #ns-key-overlay{position:fixed;inset:0;background:rgba(3,7,18,.78);display:flex;align-items:center;justify-content:center;z-index:99999;padding:16px;font-family:'Plus Jakarta Sans',system-ui,sans-serif}
  #ns-key-box{background:var(--bg-card,#111827);color:var(--text-primary,#F1F5F9);border:1px solid var(--border,#334155);border-radius:18px;padding:26px;max-width:460px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,.5)}
  #ns-key-box h2{margin:0 0 8px;font-size:1.3rem}
  #ns-key-box p{margin:0 0 14px;line-height:1.5;color:var(--text-secondary,#94A3B8);font-size:.95rem}
  #ns-key-box a{color:var(--primary,#3B82F6)}
  #ns-key-box input{width:100%;box-sizing:border-box;padding:12px 14px;border-radius:10px;border:1px solid var(--border,#334155);background:var(--bg-input,#0F172A);color:inherit;font-size:1rem;margin-bottom:6px}
  #ns-key-err{color:#F87171;font-size:.85rem;min-height:1.2em;margin-bottom:8px}
  #ns-key-box .row{display:flex;gap:10px;justify-content:flex-end}
  #ns-key-box button{padding:11px 18px;border-radius:10px;border:1px solid var(--border,#334155);background:transparent;color:inherit;font-weight:600;cursor:pointer;font-size:.95rem}
  #ns-key-box button.ns-primary{background:var(--primary,#3B82F6);border-color:transparent;color:#fff}`;

  async function needsKey() {
    if (typeof app === 'undefined' || !app.state) return false;
    if (app.state.customApiKey) return false;
    try {
      const h = await (await fetch('/api/health')).json();
      return !h.geminiConfigured;
    } catch (_) { return true; }
  }

  function show() {
    if (document.getElementById('ns-key-overlay')) return;
    const st = document.createElement('style'); st.textContent = STYLE; document.head.appendChild(st);
    const o = document.createElement('div'); o.id = 'ns-key-overlay';
    o.innerHTML = `<div id="ns-key-box">
      <h2>🔑 Conectá el Profesor IA</h2>
      <p>Para que el tutor responda necesitás tu clave de Google Gemini. Es gratis y se pide una sola vez:
      <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">conseguir mi clave en AI Studio</a>
      (botón "Create API key"), copiala y pegala acá.</p>
      <input id="ns-key-input" type="password" placeholder="AIza..." autocomplete="off">
      <div id="ns-key-err"></div>
      <div class="row"><button id="ns-key-later">Más tarde</button><button class="ns-primary" id="ns-key-save">Guardar clave</button></div>
    </div>`;
    document.body.appendChild(o);
    const input = o.querySelector('#ns-key-input'), err = o.querySelector('#ns-key-err');
    o.querySelector('#ns-key-later').onclick = () => { sessionStorage.setItem('ns-key-later', '1'); o.remove(); };
    const save = async () => {
      const key = input.value.trim();
      if (key.length < 20) { err.textContent = 'Esa clave parece incompleta. Copiala entera desde AI Studio.'; return; }
      await app.updateRemoteSettings({ customApiKey: key });
      o.remove();
    };
    o.querySelector('#ns-key-save').onclick = save;
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') save(); });
    input.focus();
  }

  let tries = 0;
  const t = setInterval(async () => {
    if (++tries > 40) return clearInterval(t);
    if (typeof app === 'undefined' || !app.state) return;
    clearInterval(t);
    if (sessionStorage.getItem('ns-key-later')) return;
    if (await needsKey()) show();
  }, 150);
})();
