'use strict';
/* NEXTSTEP — interfaz web (réplica de la app original de AI Studio).
   Todas las pantallas se dibujan acá; el estado vive en el servidor (/api/*). */

const ICONS = {
  home: 'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z',
  chat: 'M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z',
  map: 'M20.5 3l-.16.03L15 5.1 9 3 3.36 4.9c-.21.07-.36.25-.36.48V20.5c0 .28.22.5.5.5l.16-.03L9 18.9l6 2.1 5.64-1.9c.21-.07.36-.25.36-.48V3.5c0-.28-.22-.5-.5-.5zM15 19l-6-2.11V5l6 2.11V19z',
  bulb: 'M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7z',
  apps: 'M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z',
  send: 'M2.01 21L23 12 2.01 3 2 10l15 2-15 2z',
  trash: 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
  play: 'M8 5v14l11-7z',
  pause: 'M6 19h4V5H6v14zm8-14v14h4V5h-4z',
  refresh: 'M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z',
  sun: 'M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1zm0 18v2c0 .55.45 1 1 1s1-.45 1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1zM5.99 4.58a.996.996 0 00-1.41 0 .996.996 0 000 1.41l1.06 1.06c.39.39 1.03.39 1.41 0s.39-1.03 0-1.41L5.99 4.58zm12.37 12.37a.996.996 0 00-1.41 0 .996.996 0 000 1.41l1.06 1.06c.39.39 1.03.39 1.41 0a.996.996 0 000-1.41l-1.06-1.06zm1.06-10.96a.996.996 0 000-1.41.996.996 0 00-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06zM7.05 18.36a.996.996 0 000-1.41.996.996 0 00-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06z',
  moon: 'M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9 9-4.03 9-9c0-.46-.04-.92-.1-1.36-.98 1.37-2.58 2.26-4.4 2.26-2.98 0-5.4-2.42-5.4-5.4 0-1.81.89-3.42 2.26-4.4-.44-.06-.9-.1-1.36-.1z',
  check: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z',
  book: 'M21 5c-1.11-.35-2.33-.5-3.5-.5-1.95 0-4.05.4-5.5 1.5-1.45-1.1-3.55-1.5-5.5-1.5S2.45 4.9 1 6v14.65c0 .25.25.5.5.5.1 0 .15-.05.25-.05C3.1 20.45 5.05 20 6.5 20c1.95 0 4.05.4 5.5 1.5 1.35-.85 3.8-1.5 5.5-1.5 1.65 0 3.35.3 4.75 1.05.1.05.15.05.25.05.25 0 .5-.25.5-.5V6c-.6-.45-1.25-.75-2-1zm0 13.5c-1.1-.35-2.3-.5-3.5-.5-1.7 0-4.15.65-5.5 1.5V8c1.35-.85 3.8-1.5 5.5-1.5 1.2 0 2.4.15 3.5.5v11.5z',
  arrow: 'M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z',
  timer: 'M15 1H9v2h6V1zm-4 13h2V8h-2v6zm8.03-6.61l1.42-1.42c-.43-.51-.9-.99-1.41-1.41l-1.42 1.42C16.07 4.74 14.12 4 12 4c-4.97 0-9 4.03-9 9s4.02 9 9 9 9-4.03 9-9c0-2.12-.74-4.07-1.97-5.61zM12 20c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z',
  school: 'M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82zM12 3L1 9l11 6 9-4.91V17h2V9L12 3z',
  plus: 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
  lock: 'M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zM9 8V6c0-1.66 1.34-3 3-3s3 1.34 3 3v2H9z',
};
const ic = (n) => `<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="${ICONS[n] || ''}"/></svg>`;
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = (id) => document.getElementById(id);
const trunc = (s, n) => (String(s).length > n ? String(s).slice(0, n) : String(s));

const MODES = {
  CONCENTRATION: ['⏱️', 'Concentración', 'Concentración (Pomodoro)'],
  READING: ['📖', 'Lectura', 'Lectura profunda'],
  PRACTICE: ['💡', 'Práctica', 'Práctica activa'],
  EVALUATION: ['📝', 'Examen', 'Modo Examen'],
  REVIEW: ['🔄', 'Repaso', 'Repaso de errores'],
  PLANNING: ['📅', 'Planificación', 'Planificación'],
};
const PALETTES = [
  ['FOCUS_BLUE', 'Azul Enfoque', ['#66aeff', '#38bdf8', '#818cf8']],
  ['FOREST_GREEN', 'Verde Bosque', ['#34d399', '#10b981', '#a3e635']],
  ['LAVENDER_CALM', 'Lavanda Calma', ['#a78bfa', '#c084fc', '#f472b6']],
  ['WARM_STUDY', 'Estudio Cálido', ['#fbbf24', '#fb923c', '#f87171']],
  ['OCEAN_TEAL', 'Océano Turquesa', ['#2dd4bf', '#38bdf8', '#22d3ee']],
  ['ROSE_PASTEL', 'Rosa Pastel', ['#fb7185', '#f472b6', '#a78bfa']],
  ['HIGH_CONTRAST', 'Alto Contraste', ['#fde047', '#38bdf8', '#4ade80']],
  ['DARK_FOCUS', 'Enfoque Oscuro', ['#38bdf8', '#818cf8', '#34d399']],
  ['LIGHT_MINIMAL', 'Minimalista', ['#e4e4e7', '#a1a1aa', '#d4d4d8']],
  ['CUSTOM', 'Personalizado', ['#d0bcff', '#ccc2dc', '#efb8c8']],
];
const NAV_MAIN = [['dashboard', 'Inicio', 'home'], ['tutor', 'Tutor IA', 'chat'], ['routes', 'Rutas', 'map'], ['practice', 'Práctica', 'bulb']];
const SECTIONS = [
  ['dashboard', 'Inicio', 'Resumen de tu día'], ['tutor', 'Tutor IA', 'Chat con tu profesor'],
  ['learning', 'Mi Aprendizaje', 'Materias y dominio'], ['routes', 'Rutas de Estudio', 'Módulos paso a paso'],
  ['practice', 'Práctica y Retos', 'Ejercicios con pistas'], ['evaluations', 'Evaluaciones', 'Mide tu nivel'],
  ['goals', 'Mis Objetivos', 'Metas y tareas'], ['progress', 'Mi Progreso', 'Nivel, XP y logros'],
  ['resources', 'Recursos', 'Material recomendado'], ['settings', 'Configuración', 'Tema, tutor y cuenta'],
];
const PREF_OPTIONS = {
  explanationDepth: ['Breve', 'Equilibrada', 'Detallada'],
  languageStyle: ['Claro y accesible', 'Técnico', 'Formal', 'Casual'],
  contentApproach: ['Práctico con ejemplos', 'Teórico', 'Mixto'],
  pacing: ['Paso a paso', 'Rápido', 'A mi ritmo'],
  hintStyle: ['Pistas progresivas', 'Respuesta directa', 'Solo guía'],
  tutorTone: ['Cercano y motivador', 'Neutro', 'Exigente'],
};
const PREF_LABELS = {
  explanationDepth: 'Profundidad de explicación', languageStyle: 'Estilo de lenguaje', contentApproach: 'Enfoque del contenido',
  pacing: 'Ritmo', hintStyle: 'Estilo de pistas', tutorTone: 'Tono del tutor',
};
const QUICK = [
  ['💡 Explícamelo más simple', 'Explícamelo de forma más simple', 'EXPLICAR_SIMPLE'],
  ['🔍 Dame un ejemplo real', 'Dame un ejemplo real y práctico', 'EJEMPLO_REAL'],
  ['📝 Ponme un ejercicio', 'Ponme un ejercicio para practicar', 'PEDIR_EJERCICIO'],
  ['🧩 Dame una pista', 'Dame una pista sin darme la respuesta', 'PISTA_GRADUAL'],
  ['📚 Hazme un resumen', 'Hazme un resumen de lo importante', 'RESUMEN'],
];
const ONBOARD_GOALS = [
  'Aprender a programar y crear proyectos', 'Aprobar exámenes y reforzar asignaturas',
  'Preparar una certificación técnica', 'Aprender a mi propio ritmo con curiosidad',
];
const ONBOARD_DEPTH = [['Breve', 'Breve y al grano'], ['Equilibrada', 'Equilibrada'], ['Detallada', 'Detallada y con ejemplos']];

function markdown(src) {
  const blocks = [];
  let t = esc(src).replace(/```(\w*)\n?([\s\S]*?)```/g, (_, _l, code) => { blocks.push(`<pre><code>${code.replace(/\n$/, '')}</code></pre>`); return `\u0000${blocks.length - 1}\u0000`; });
  t = t.replace(/`([^`\n]+)`/g, '<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>').replace(/(^|[\s(])\*([^*\n]+)\*/g, '$1<i>$2</i>');
  const out = [];
  let list = null;
  const closeList = () => { if (list) { out.push(`</${list}>`); list = null; } };
  for (const line of t.split('\n')) {
    const ul = line.match(/^\s*[-*•]\s+(.*)/), ol = line.match(/^\s*\d+[.)]\s+(.*)/), h = line.match(/^#{1,4}\s+(.*)/);
    if (ul || ol) {
      const kind = ul ? 'ul' : 'ol';
      if (list !== kind) { closeList(); out.push(`<${kind}>`); list = kind; }
      out.push(`<li>${(ul || ol)[1]}</li>`);
    } else {
      closeList();
      if (h) out.push(`<p><b>${h[1]}</b></p>`);
      else if (line.trim()) out.push(`<p>${line}</p>`);
    }
  }
  closeList();
  return out.join('').replace(/\u0000(\d+)\u0000/g, (_, i) => blocks[i]).replace(/<p>(<pre>[\s\S]*?<\/pre>)<\/p>/g, '$1');
}

const app = {
  state: null,
  view: 'dashboard',
  pomo: { secs: 25 * 60, running: false, timer: null },
  ex: { i: 0, sel: null, hint: 0, checked: false, correct: false },
  ev: null,
  ob: null,
  chatPending: false,

  /* ---------- arranque ---------- */
  async init() {
    try {
      this.state = await this.api('/api/state');
    } catch (e) {
      document.body.innerHTML = `<div style="padding:30px;font-family:sans-serif">No se pudo cargar NEXTSTEP: ${esc(e.message)}</div>`;
      return;
    }
    this.applyTheme();
    this.buildNav();
    this.bindStatic();
    const start = location.hash.slice(1);
    this.go(SECTIONS.some((s) => s[0] === start) ? start : 'dashboard', true);
    if (!this.state.userProfile.initialAssessmentDone) this.openOnboarding();
  },

  async api(path, body) {
    const res = await fetch(path, body === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    let data = {};
    try { data = await res.json(); } catch (_) { /* respuesta vacía */ }
    if (!res.ok) throw new Error(data.error || `Error ${res.status}`);
    return data;
  },

  /* usada también por key-setup.js */
  async updateRemoteSettings(patch) {
    const r = await this.api('/api/settings', patch);
    this.state = r.state;
    this.applyTheme();
    this.renderTop();
    return r;
  },

  async act(action, payload = {}, { render = true } = {}) {
    const r = await this.api('/api/action', { action, payload });
    this.state = r.state;
    this.renderTop();
    if (render) this.renderView();
    return r.state;
  },

  /* ---------- tema ---------- */
  isDark() {
    const t = this.state.themeConfig;
    return t.useSystemDark ? matchMedia('(prefers-color-scheme: dark)').matches : !!t.isDarkMode;
  },
  applyTheme() {
    const t = this.state.themeConfig, b = document.body, dark = this.isDark();
    b.dataset.theme = t.palette || 'FOCUS_BLUE';
    b.dataset.mode = dark ? 'dark' : 'light';
    ['--primary', '--on-primary', '--secondary'].forEach((v) => b.style.removeProperty(v));
    if (t.palette === 'CUSTOM') {
      const hex = /^#[0-9a-fA-F]{6}$/;
      if (hex.test(t.customPrimaryHex || '')) { b.style.setProperty('--primary', t.customPrimaryHex); b.style.setProperty('--on-primary', '#ffffff'); }
      if (hex.test(t.customAccentHex || '')) b.style.setProperty('--secondary', t.customAccentHex);
    }
    const bg = getComputedStyle(b).getPropertyValue('--surface').trim();
    document.querySelector('meta[name=theme-color]')?.setAttribute('content', bg || '#0B1B3A');
  },

  /* ---------- navegación ---------- */
  buildNav() {
    const item = (id, label, icon) => `<button class="nav-item" data-act="nav" data-id="${id}" data-nav="${id}"><span class="nav-pill">${ic(icon)}</span><span>${label}</span></button>`;
    const html = NAV_MAIN.map((n) => item(n[0], n[1], n[2])).join('') + item('more', 'Más', 'apps');
    $('bottom-nav').innerHTML = html;
    $('rail').innerHTML = html;
    $('send-icon-holder')?.remove();
    $('chat-send-btn').innerHTML = ic('send');
    $('clear-chat-btn').innerHTML = ic('trash');
  },
  go(id, replace) {
    if (id === 'more') return this.openMore();
    this.view = id;
    document.querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + id));
    const main = NAV_MAIN.some((n) => n[0] === id) ? id : 'more';
    document.querySelectorAll('[data-nav]').forEach((b) => b.classList.toggle('active', b.dataset.nav === main));
    if (replace) history.replaceState(null, '', '#' + id); else history.replaceState(null, '', '#' + id);
    this.closeMore();
    this.renderView();
    const v = $('view-' + id);
    if (v && id !== 'tutor') v.scrollTop = 0;
  },
  openMore() {
    $('sheet-grid').innerHTML = SECTIONS.map(([id, name, desc]) =>
      `<button class="sheet-item ${this.view === id ? 'sel' : ''}" data-act="nav" data-id="${id}"><b>${esc(name)}</b><span>${esc(desc)}</span></button>`).join('');
    $('sheet-more').classList.add('open');
  },
  closeMore() { $('sheet-more').classList.remove('open'); },

  renderTop() {
    const s = this.state, m = MODES[s.studyMode] || MODES.PRACTICE;
    $('mode-icon').textContent = m[0];
    $('mode-text').textContent = m[1];
    $('streak-count').textContent = s.userProfile.streakDays;
    $('theme-toggle').innerHTML = ic(this.isDark() ? 'sun' : 'moon');
  },

  renderView() {
    this.renderTop();
    const fn = { dashboard: 'vDashboard', tutor: 'vTutor', learning: 'vLearning', routes: 'vRoutes', practice: 'vPractice', evaluations: 'vEvaluations', goals: 'vGoals', progress: 'vProgress', resources: 'vResources', settings: 'vSettings' }[this.view];
    if (this.view === 'tutor') return this.vTutor();
    const el = $('view-' + this.view);
    if (el && fn) el.innerHTML = `<div class="page">${this[fn]()}</div>`;
  },

  /* ---------- eventos fijos (barra superior, chat) ---------- */
  bindStatic() {
    const isField = (el) => el.tagName === 'SELECT' || (el.tagName === 'INPUT');
    document.addEventListener('click', (e) => {
      const el = e.target.closest('[data-act]');
      if (el && !isField(el) && this.H[el.dataset.act]) this.H[el.dataset.act].call(this, el.dataset, el);
    });
    document.addEventListener('change', (e) => {
      const el = e.target.closest('[data-act]');
      if (el && isField(el) && this.H[el.dataset.act]) this.H[el.dataset.act].call(this, el.dataset, el);
    });
    $('theme-toggle').onclick = () => this.H.theme.call(this);
    $('mode-pill-btn').onclick = () => this.openModeDialog();
    $('clear-chat-btn').onclick = () => this.confirm('¿Reiniciar la conversación?', 'Se borrará el historial del chat con el profesor.', 'Reiniciar', () => this.act('CLEAR_CHAT'));
    $('sheet-more').addEventListener('click', (e) => { if (e.target === $('sheet-more')) this.closeMore(); });
    $('dialog-root').addEventListener('click', (e) => { if (e.target === $('dialog-root') && !this.ob) this.closeDialog(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { this.closeMore(); if (!this.ob) this.closeDialog(); } });
    const input = $('chat-input');
    input.addEventListener('input', () => { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 120) + 'px'; });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); $('chat-form').requestSubmit(); } });
    $('chat-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const text = input.value.trim();
      if (!text) return;
      input.value = ''; input.style.height = 'auto';
      this.sendChat(text, null);
    });
    matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', () => { if (this.state.themeConfig.useSystemDark) { this.applyTheme(); this.renderTop(); } });
  },

  toast(msg) {
    const t = $('toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(this._tt); this._tt = setTimeout(() => t.classList.remove('show'), 2600);
  },
  dialog(html) { $('dialog-box').innerHTML = html; $('dialog-root').classList.add('open'); },
  closeDialog() { $('dialog-root').classList.remove('open'); },
  confirm(title, text, okLabel, onOk) {
    this._ok = onOk;
    this.dialog(`<h2>${esc(title)}</h2><p class="muted">${esc(text)}</p>
      <div class="actions"><button class="btn btn-text" data-act="closeDialog">Cancelar</button><button class="btn btn-filled" data-act="confirmOk">${esc(okLabel)}</button></div>`);
  },

  /* ---------- Inicio ---------- */
  vDashboard() {
    const s = this.state, p = s.userProfile;
    const pct = Math.min(100, Math.round((p.currentXp / p.nextLevelXp) * 100));
    let route = null, mod = null;
    for (const r of s.routes) { const m = r.modules.find((x) => x.isCurrent); if (m) { route = r; mod = m; break; } }
    const subj = s.subjects.slice(0, 3).map((x) => `
      <div class="subject-row"><span class="emoji-lg">${esc(x.iconEmoji)}</span>
        <div class="grow"><div class="title-sm">${esc(x.name)}</div><div class="caption muted">${esc(x.estimatedLevel)} • ${x.topicsMastered.length} temas dominados</div></div>
        <span class="pill pill-primary">${x.masteryPercent}% Maestría</span></div>`).join('');
    const goals = s.goals.slice(0, 2).map((g) => `
      <div class="stack" style="gap:6px"><div class="row between"><div class="title-sm grow">${esc(g.title)}</div><span class="caption label-primary">${esc(g.deadline)}</span></div>
      <div class="progress sm"><i style="width:${g.progressPercent}%"></i></div><div class="caption muted">${g.progressPercent}% completado</div></div>`).join('');
    return `
      <div class="page-head"><div><h1 class="title-lg">¡Hola, ${esc(p.name)}! 👋</h1>
        <p class="muted" style="margin-top:6px">Profesor particular IA listo para tu sesión de hoy.</p></div>
        <span class="level-chip">Nivel ${p.levelNumber}</span></div>
      <div class="pomodoro"><div class="row"><span style="color:var(--primary)">${ic('timer')}</span>
        <span class="time grow" id="pomo-label">Foco Pomodoro: ${this.pomoText()}</span>
        <button class="btn btn-tonal btn-sm" id="pomo-toggle" data-act="pomoToggle">${ic(this.pomo.running ? 'pause' : 'play')}${this.pomo.running ? 'Pausar' : 'Iniciar'}</button>
        <button class="icon-btn" data-act="pomoReset" aria-label="Reiniciar">${ic('refresh')}</button></div>
        <div class="progress sm"><i id="pomo-bar" style="width:${Math.round((1 - this.pomo.secs / 1500) * 100)}%"></i></div></div>
      <div class="card primary stack" style="gap:12px"><div class="row"><div class="grow"><div class="title-md">${esc(p.levelTitle)}</div>
        <div style="margin-top:4px;opacity:.9">Nivel ${p.levelNumber} • Racha de ${p.streakDays} días seguidos 🔥</div></div><span class="lv-circle">Lv.${p.levelNumber}</span></div>
        <div class="progress"><i style="width:${pct}%"></i></div>
        <div class="row between caption"><span>${p.currentXp} XP acumulados</span><span>Meta: ${p.nextLevelXp} XP</span></div></div>
      <div class="grid-3">
        <div class="stat"><div class="top"><span>Tiempo Estudio</span></div><div class="val">${p.totalMinutesStudied} min</div><div class="sub">Registrado real</div></div>
        <div class="stat"><div class="top"><span>Ejercicios</span><span class="ico">${ic('check')}</span></div><div class="val">${p.completedExercisesCount}</div><div class="sub">Resueltos y corregidos</div></div>
        <div class="stat"><div class="top"><span>Materias</span><span class="ico">${ic('book')}</span></div><div class="val">${s.subjects.length}</div><div class="sub">En aprendizaje</div></div></div>
      <div class="card outlined stack"><div class="row between"><span class="label-primary">🎯 Próximo Paso Recomendado</span><span style="color:var(--primary)">${ic('arrow')}</span></div>
        ${mod ? `<h3 class="title-md">${esc(mod.title)}</h3><p class="muted">${esc(mod.description)}</p>
          <button class="btn btn-filled btn-block" data-act="nav" data-id="routes">${ic('play')}Continuar Recorrido</button>`
        : `<h3 class="title-md">¡Completaste tus rutas actuales! 🎉</h3><p class="muted">Agregá una nueva materia o pedile al profesor un desafío.</p>
          <button class="btn btn-filled btn-block" data-act="nav" data-id="learning">Ver mis materias</button>`}</div>
      <div class="card secondary"><div class="row"><div class="grow"><div class="title-sm">💬 Consultar al Profesor IA</div>
        <p style="margin-top:4px;opacity:.9">Haz preguntas libres, pide pistas graduales o solicita ejercicios con corrección.</p></div>
        <button class="btn btn-text" style="color:inherit" data-act="nav" data-id="tutor">Abrir Chat</button></div></div>
      <div class="grid-2">
        <div class="card outlined stack"><div class="row between"><h3 class="title-md">Materias en Curso</h3><button class="btn btn-text btn-sm" data-act="nav" data-id="learning">Ver todas</button></div>${subj || '<div class="empty">Sin materias</div>'}</div>
        <div class="card outlined stack"><div class="row between"><h3 class="title-md">Objetivos Activos</h3><button class="btn btn-text btn-sm" data-act="nav" data-id="goals">Gestionar</button></div>${goals || '<div class="empty">Sin objetivos</div>'}</div></div>`;
  },

  pomoText() { const s = this.pomo.secs; return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); },
  pomoTick() {
    const P = this.pomo;
    if (P.secs > 0) {
      P.secs--;
      if (P.secs % 60 === 0) this.act('ADD_STUDY_TIME', { minutes: 1 }, { render: false }).catch(() => {});
    } else {
      clearInterval(P.timer); P.running = false; P.secs = 1500;
      this.act('ADD_XP', { amount: 20 }, { render: false }).catch(() => {});
      this.toast('¡Pomodoro completado! +20 XP 🎉');
      if (this.view === 'dashboard') this.renderView();
      return;
    }
    const l = $('pomo-label'); if (l) l.textContent = 'Foco Pomodoro: ' + this.pomoText();
    const b = $('pomo-bar'); if (b) b.style.width = Math.round((1 - P.secs / 1500) * 100) + '%';
  },

  /* ---------- Tutor IA ---------- */
  vTutor() {
    const s = this.state, subj = s.subjects.find((x) => x.id === s.activeSubjectId) || s.subjects[0];
    const m = MODES[s.studyMode] || MODES.PRACTICE;
    $('chat-subject-indicator').textContent = `Modo: ${m[1]} • ${subj ? subj.name : 'General'}`;
    $('chat-subject-chips').innerHTML = s.subjects.map((x) =>
      `<button class="chip ${subj && x.id === subj.id ? 'selected' : ''}" data-act="pickSubject" data-id="${esc(x.id)}">${esc(x.iconEmoji)} ${esc(x.name)}</button>`).join('');
    $('chat-quick-chips').innerHTML = QUICK.map((q, i) => `<button class="chip" data-act="quick" data-i="${i}">${esc(q[0])}</button>`).join('');
    const box = $('chat-messages-container');
    box.innerHTML = s.chatHistory.map((x) => {
      const kind = x.sender === 'user' ? 'user' : x.sender === 'system' ? 'system' : 'tutor';
      return `<div class="msg ${kind}">${kind === 'tutor' ? '<div class="who">🤖 Profesor NEXTSTEP</div>' : ''}
        <div class="bubble">${x.pedagogicalAction ? `<div class="caption label-primary" style="margin-bottom:4px;color:inherit;opacity:.85">${esc(x.pedagogicalAction)}</div>` : ''}${kind === 'user' ? esc(x.content).replace(/\n/g, '<br>') : markdown(x.content)}</div></div>`;
    }).join('') + (this.chatPending ? '<div class="msg tutor pending"><div class="who">🤖 Profesor NEXTSTEP</div><div class="bubble">Pensando…</div></div>' : '');
    box.scrollTop = box.scrollHeight;
    $('chat-send-btn').disabled = this.chatPending;
  },
  async sendChat(message, action) {
    if (this.chatPending) return;
    this.state.chatHistory.push({ id: 'tmp_' + Date.now(), sender: 'user', content: action ? `[${action}]: ${message}` : message, timestamp: Date.now() });
    this.chatPending = true; this.vTutor();
    try {
      const r = await this.api('/api/chat', { message, pedagogicalAction: action });
      this.state = r.state;
    } catch (e) {
      this.state.chatHistory.push({ id: 'err_' + Date.now(), sender: 'system', content: '⚠️ ' + e.message, timestamp: Date.now() });
    }
    this.chatPending = false;
    this.renderTop();
    if (this.view === 'tutor') this.vTutor();
  },

  /* ---------- Mi Aprendizaje ---------- */
  vLearning() {
    const cards = this.state.subjects.map((x) => {
      const pills = (arr, cls) => arr.map((t) => `<span class="pill ${cls}">${esc(t)}</span>`).join('');
      return `<div class="card outlined stack"><div class="subject-row"><span class="emoji-lg">${esc(x.iconEmoji)}</span>
        <div class="grow"><div class="title-md">${esc(x.name)}</div><div class="caption muted">${esc(x.category)} • ${esc(x.estimatedLevel)}</div></div>
        <span class="pill pill-primary">${x.masteryPercent}%</span></div>
        <div class="progress"><i style="width:${x.masteryPercent}%"></i></div>
        ${x.description ? `<p class="muted">${esc(x.description)}</p>` : ''}
        <div class="tags">${pills(x.topicsMastered, 'pill-green')}${pills(x.topicsInProgress, 'pill-primary')}${pills(x.topicsToReinforce, 'pill-amber')}${pills(x.topicsPending, 'pill-red')}</div>
        <div class="row"><button class="btn btn-filled btn-sm" data-act="studySubject" data-id="${esc(x.id)}">Estudiar con IA</button></div></div>`;
    }).join('');
    return `<div class="page-head"><div><h1 class="title-lg">Mi Aprendizaje</h1><p class="muted" style="margin-top:6px">Tus materias, temas dominados y por reforzar.</p></div>
      <button class="btn btn-tonal btn-sm" data-act="newSubject">${ic('plus')}Nueva</button></div>
      <div class="row caption muted" style="flex-wrap:wrap;gap:12px"><span><span class="pill pill-green">Dominado</span></span><span class="pill pill-primary">En progreso</span><span class="pill pill-amber">Reforzar</span><span class="pill pill-red">Pendiente</span></div>
      <div class="grid-cards">${cards}</div>`;
  },

  /* ---------- Rutas ---------- */
  vRoutes() {
    const html = this.state.routes.map((r) => {
      const done = r.modules.filter((m) => m.isCompleted).length;
      const mods = r.modules.map((m) => `
        <div class="module ${m.isCompleted ? 'done' : m.isCurrent ? 'current' : m.isLocked ? 'locked' : ''}">
          <span class="num">${m.isCompleted ? '✓' : m.isLocked ? ic('lock') : m.orderNumber}</span>
          <div class="grow stack" style="gap:6px"><div class="title-sm">${esc(m.title)}</div><p class="muted">${esc(m.description)}</p>
            <div class="tags">${(m.keyConcepts || []).map((c) => `<span class="pill pill-primary">${esc(c)}</span>`).join('')}</div>
            ${m.contentSummary && m.isCurrent ? `<p>${esc(m.contentSummary)}</p>` : ''}
            ${m.isCurrent ? `<div class="row" style="flex-wrap:wrap"><button class="btn btn-filled btn-sm" data-act="completeModule" data-id="${esc(m.id)}">Marcar completado (+60 XP)</button>
              <button class="btn btn-outlined btn-sm" data-act="askModule" data-id="${esc(m.id)}">Estudiar con IA</button></div>` : ''}</div></div>`).join('');
      return `<div class="card primary stack"><div class="title-md">${esc(r.title)}</div><p>${esc(r.description)}</p>
        <div class="row between caption"><span>${done} de ${r.modules.length} módulos</span><span class="pill pill-primary" style="background:rgba(255,255,255,.14)">${esc(r.targetLevel)}</span></div>
        <div class="progress"><i style="width:${Math.round((done / r.modules.length) * 100)}%"></i></div></div><div class="stack">${mods}</div>`;
    }).join('');
    return `<div><h1 class="title-lg">Rutas de Estudio</h1><p class="muted" style="margin-top:6px">Avanzá módulo por módulo; el profesor te acompaña en cada uno.</p></div>${html || '<div class="empty">Todavía no hay rutas.</div>'}`;
  },

  /* ---------- Práctica ---------- */
  vPractice() {
    const list = this.state.exercises;
    if (!list.length) return '<div class="empty">No hay ejercicios todavía.</div>';
    const E = this.ex, i = Math.min(E.i, list.length - 1), x = list[i];
    const tabs = list.map((e, k) => `<button class="chip ${k === i ? 'selected' : ''}" style="max-width:190px;overflow:hidden;text-overflow:ellipsis" data-act="exPick" data-i="${k}">Reto ${k + 1}: ${esc(trunc(e.topic, 20))}</button>`).join('');
    const opts = x.options.map((o, k) => {
      let cls = '';
      if (E.checked) cls = k === x.correctOptionIndex ? 'ok' : k === E.sel ? 'bad' : '';
      else if (k === E.sel) cls = 'sel';
      return `<button class="option ${cls}" ${E.checked ? 'disabled' : ''} data-act="exSelect" data-i="${k}"><span class="radio"></span><span>${esc(o)}</span></button>`;
    }).join('');
    const hint = E.hint >= 1 ? `<div class="hint">💡 ${esc(E.hint >= 2 ? x.hintLevel2 : x.hintLevel1)}</div>` : '';
    const fb = E.checked ? `<div class="feedback ${E.correct ? 'ok' : 'bad'}"><b>${E.correct ? `¡Correcto! +${x.xpReward} XP 🎉` : 'Todavía no 💪'}</b><br>${esc(x.explanation || '')}</div>` : '';
    return `<div class="page-head"><h1 class="title-lg">Ejercicios y Práctica</h1><span class="level-chip">Ejercicio ${i + 1} de ${list.length}</span></div>
      <p class="muted">Entrenamiento adaptativo con pistas graduales y corrección pedagógica.</p>
      <div class="chips">${tabs}</div>
      <div class="card outlined stack" style="gap:14px"><div class="row between"><span class="pill pill-primary" style="background:var(--primary-container)">${esc(x.subjectName)}</span>
        <span class="row" style="gap:6px"><span class="pill pill-amber">${esc(x.difficulty)}</span><span class="pill pill-green">+${x.xpReward} XP</span></span></div>
        <div class="exercise-q">${esc(x.question)}</div>${x.codeSnippet ? `<pre class="code">${esc(x.codeSnippet)}</pre>` : ''}
        <div class="stack">${opts}</div>${E.checked ? '' : hint}${fb}
        <div class="row" style="flex-wrap:wrap">${E.checked
          ? `<button class="btn btn-filled" data-act="exNext">${i < list.length - 1 ? 'Siguiente reto' : 'Volver al primero'}</button><button class="btn btn-outlined" data-act="askEx">Preguntar a la IA</button>`
          : `<button class="btn btn-filled" data-act="exCheck" ${E.sel === null ? 'disabled' : ''}>Comprobar</button><button class="btn btn-outlined" data-act="exHint" ${E.hint >= 2 ? 'disabled' : ''}>Pista</button>`}</div></div>`;
  },

  /* ---------- Evaluaciones ---------- */
  vEvaluations() {
    if (this.ev) return this.vEvalTaking();
    const cards = this.state.evaluations.map((e) => `<div class="card outlined stack"><div class="row between"><div class="title-md grow">${esc(e.title)}</div>
        ${e.completed ? `<span class="pill pill-green">${e.scorePercent}%</span>` : '<span class="pill pill-amber">Pendiente</span>'}</div>
      <div class="tags"><span class="pill pill-primary">${esc(e.subjectName)}</span><span class="pill pill-primary">${e.durationMinutes} min</span><span class="pill pill-primary">${e.questions.length} preguntas</span></div>
      ${e.completed ? `<p>Nivel demostrado: <b>${esc(e.demonstratedLevel)}</b></p>
        ${(e.strengths || []).length ? `<div class="caption muted">Fortalezas</div><div class="tags">${e.strengths.map((t) => `<span class="pill pill-green">${esc(t)}</span>`).join('')}</div>` : ''}
        ${(e.weaknessesToReinforce || []).length ? `<div class="caption muted">A reforzar</div><div class="tags">${e.weaknessesToReinforce.map((t) => `<span class="pill pill-amber">${esc(t)}</span>`).join('')}</div>` : ''}`
        : `<button class="btn btn-filled" data-act="evStart" data-id="${esc(e.id)}">Comenzar evaluación</button>`}</div>`).join('');
    return `<div><h1 class="title-lg">Evaluaciones</h1><p class="muted" style="margin-top:6px">Medí tu nivel real y descubrí qué reforzar. Ganás +120 XP al completar una.</p></div><div class="grid-cards">${cards || '<div class="empty">No hay evaluaciones.</div>'}</div>`;
  },
  vEvalTaking() {
    const V = this.ev, e = this.state.evaluations.find((x) => x.id === V.id), q = e.questions[V.i];
    const opts = q.options.map((o, k) => `<button class="option ${V.sel === k ? 'sel' : ''}" data-act="evSelect" data-i="${k}"><span class="radio"></span><span>${esc(o)}</span></button>`).join('');
    return `<div class="page-head"><h1 class="title-lg">${esc(e.title)}</h1><span class="level-chip">${V.i + 1} / ${e.questions.length}</span></div>
      <div class="progress"><i style="width:${Math.round((V.i / e.questions.length) * 100)}%"></i></div>
      <div class="card outlined stack"><span class="pill pill-primary" style="align-self:flex-start">${esc(q.topic)}</span><div class="exercise-q">${esc(q.question)}</div><div class="stack">${opts}</div>
        <div class="row"><button class="btn btn-text" data-act="evCancel">Salir</button><span class="grow"></span>
        <button class="btn btn-filled" data-act="evNext" ${V.sel === null ? 'disabled' : ''}>${V.i < e.questions.length - 1 ? 'Siguiente' : 'Finalizar'}</button></div></div>`;
  },

  /* ---------- Objetivos ---------- */
  vGoals() {
    const pr = { ALTA: 'pill-red', MEDIA: 'pill-amber', BAJA: 'pill-green' };
    const cards = this.state.goals.map((g) => `<div class="card outlined stack"><div class="row between"><div class="title-md grow">${esc(g.title)}</div><span class="pill ${pr[g.priority] || 'pill-primary'}">${esc(g.priority)}</span></div>
      <p class="muted">${esc(g.description)}</p><div class="row between caption"><span class="label-primary">${esc(g.deadline)}</span><span>${g.progressPercent}%</span></div>
      <div class="progress"><i style="width:${g.progressPercent}%"></i></div>
      <div>${g.tasks.map((t) => `<label class="check-row ${t.isCompleted ? 'done' : ''}"><input type="checkbox" ${t.isCompleted ? 'checked' : ''} data-act="toggleTask" data-g="${esc(g.id)}" data-t="${esc(t.id)}"><span>${esc(t.title)}</span></label>`).join('')}</div></div>`).join('');
    return `<div class="page-head"><div><h1 class="title-lg">Mis Objetivos</h1><p class="muted" style="margin-top:6px">Cada tarea completada suma +25 XP.</p></div>
      <button class="btn btn-tonal btn-sm" data-act="newGoal">${ic('plus')}Nuevo</button></div><div class="grid-cards">${cards || '<div class="empty">Todavía no tenés objetivos.</div>'}</div>`;
  },

  /* ---------- Progreso ---------- */
  vProgress() {
    const s = this.state, p = s.userProfile, pct = Math.min(100, Math.round((p.currentXp / p.nextLevelXp) * 100));
    const ach = s.achievements.map((a) => `<div class="card outlined achievement ${a.isUnlocked ? '' : 'locked'}"><span class="emoji-lg">${esc(a.iconEmoji)}</span>
      <div class="grow"><div class="title-sm">${esc(a.title)}</div><div class="caption muted">${esc(a.description)}</div></div>
      <span class="pill ${a.isUnlocked ? 'pill-green' : 'pill-primary'}">${a.isUnlocked ? '+' + a.xpReward + ' XP' : '🔒'}</span></div>`).join('');
    const mastery = s.subjects.map((x) => `<div class="stack" style="gap:6px"><div class="row between"><span>${esc(x.iconEmoji)} ${esc(x.name)}</span><b>${x.masteryPercent}%</b></div><div class="progress sm"><i style="width:${x.masteryPercent}%"></i></div></div>`).join('');
    return `<div><h1 class="title-lg">Mi Progreso</h1></div>
      <div class="card primary stack" style="gap:12px"><div class="row"><div class="grow"><div class="title-md">${esc(p.levelTitle)}</div><div style="opacity:.9">Nivel ${p.levelNumber}</div></div><span class="lv-circle">Lv.${p.levelNumber}</span></div>
        <div class="progress"><i style="width:${pct}%"></i></div><div class="row between caption"><span>${p.currentXp} XP</span><span>Meta: ${p.nextLevelXp} XP</span></div></div>
      <div class="grid-3"><div class="stat"><div class="top">Tiempo</div><div class="val">${p.totalMinutesStudied}</div><div class="sub">minutos</div></div>
        <div class="stat"><div class="top">Ejercicios</div><div class="val">${p.completedExercisesCount}</div><div class="sub">resueltos</div></div>
        <div class="stat"><div class="top">Racha</div><div class="val">${p.streakDays}</div><div class="sub">días 🔥</div></div></div>
      <div class="card outlined stack"><h3 class="title-md">Dominio por materia</h3>${mastery}</div>
      <h3 class="title-md">Logros</h3><div class="grid-cards">${ach}</div>`;
  },

  /* ---------- Recursos ---------- */
  vResources() {
    const cards = this.state.resources.map((r) => `<div class="card outlined stack"><div class="subject-row"><span class="emoji-lg">${esc(r.iconEmoji)}</span>
      <div class="grow"><div class="title-sm">${esc(r.title)}</div><div class="caption muted">${esc(r.category)} • ${esc(r.difficulty)}</div></div></div>
      <p class="muted">${esc(r.description)}</p><span class="pill pill-primary" style="align-self:flex-start">${esc(r.urlPlaceholder)}</span></div>`).join('');
    return `<div><h1 class="title-lg">Recursos</h1><p class="muted" style="margin-top:6px">Material recomendado por tu profesor IA.</p></div><div class="grid-cards">${cards}</div>`;
  },

  /* ---------- Configuración ---------- */
  vSettings() {
    const s = this.state, t = s.themeConfig, u = window.nsAuth?.user;
    const pal = PALETTES.map(([id, name, sw]) => `<button class="palette ${t.palette === id ? 'selected' : ''}" data-act="palette" data-id="${id}"><span>${esc(name)}</span><span class="swatches">${sw.map((c) => `<i style="background:${c}"></i>`).join('')}</span></button>`).join('');
    const prefs = Object.keys(PREF_OPTIONS).map((k) => `<div class="field"><label for="pref-${k}">${PREF_LABELS[k]}</label><select class="select" id="pref-${k}" data-act="pref" data-k="${k}">
      ${PREF_OPTIONS[k].map((o) => `<option ${s.userProfile.preferences[k] === o ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select></div>`).join('');
    return `<div><h1 class="title-lg">Configuración</h1></div>
      ${u ? `<div class="card outlined row"><div class="avatar">👤</div><div class="grow"><div class="title-sm">${esc(u.displayName)}</div><div class="caption muted">Usuario: ${esc(u.username)}</div></div>
        <button class="btn btn-outlined btn-sm" data-act="logout">Cerrar sesión</button></div>` : ''}
      <div class="card outlined stack"><h3 class="title-md">Apariencia</h3>
        <div class="row between"><span>Modo oscuro</span><button class="btn btn-tonal btn-sm" data-act="theme">${this.isDark() ? 'Activado' : 'Desactivado'}</button></div>
        <div class="row between"><span>Seguir el tema del sistema</span><button class="btn btn-tonal btn-sm" data-act="sysTheme">${t.useSystemDark ? 'Sí' : 'No'}</button></div>
        <div class="grid-cards" style="grid-template-columns:repeat(auto-fill,minmax(210px,1fr))">${pal}</div>
        ${t.palette === 'CUSTOM' ? `<div class="form-grid"><div class="field"><label>Color principal</label><input type="color" class="input" style="height:46px;padding:4px" value="${esc(t.customPrimaryHex || '#2563eb')}" data-act="customColor" data-k="customPrimaryHex"></div>
          <div class="field"><label>Color secundario</label><input type="color" class="input" style="height:46px;padding:4px" value="${esc(t.customAccentHex || '#06b6d4')}" data-act="customColor" data-k="customAccentHex"></div></div>` : ''}</div>
      <div class="card outlined stack"><h3 class="title-md">Tu profesor</h3><div class="field"><label>Modo de estudio</label><select class="select" data-act="studyModeSel">
        ${Object.entries(MODES).map(([k, v]) => `<option value="${k}" ${s.studyMode === k ? 'selected' : ''}>${v[0]} ${v[2]}</option>`).join('')}</select></div>
        <div class="form-grid">${prefs}</div></div>
      <div class="card outlined stack"><h3 class="title-md">Clave de Gemini (opcional)</h3>
        <p class="muted">Si el servidor ya tiene una clave configurada no necesitás cargar nada. Podés usar la tuya propia si querés.</p>
        <div class="row"><input class="input grow" id="api-key-input" type="password" placeholder="AIza..." autocomplete="off" value="${esc(s.customApiKey || '')}"><button class="btn btn-filled btn-sm" data-act="saveKey">Guardar</button></div></div>
      <div class="card error stack"><h3 class="title-md">Zona peligrosa</h3><p>Borra todo tu progreso y vuelve al estado inicial.</p>
        <button class="btn btn-danger btn-sm" style="align-self:flex-start" data-act="resetAll">Reiniciar mi progreso</button></div>`;
  },

  /* ---------- diálogos ---------- */
  openModeDialog() {
    this.dialog(`<h2>Modo de estudio</h2><div class="stack">${Object.entries(MODES).map(([k, v]) =>
      `<button class="option ${this.state.studyMode === k ? 'sel' : ''}" data-act="setMode" data-id="${k}"><span class="radio"></span><span>${v[0]} ${v[2]}</span></button>`).join('')}</div>
      <div class="actions"><span></span><button class="btn btn-text" data-act="closeDialog">Cerrar</button></div>`);
  },
  openOnboarding() {
    this.ob = this.ob || { step: 1, goal: null, depth: 'Equilibrada' };
    const O = this.ob, one = O.step === 1;
    const opts = one
      ? ONBOARD_GOALS.map((g) => `<button class="option ${O.goal === g ? 'sel' : ''}" data-act="obGoal" data-v="${esc(g)}"><span>${esc(g)}</span></button>`).join('')
      : ONBOARD_DEPTH.map(([v, l]) => `<button class="option ${O.depth === v ? 'sel' : ''}" data-act="obDepth" data-v="${esc(v)}"><span>${esc(l)}</span></button>`).join('');
    this.dialog(`<div class="head">${ic('school')}<h2>Bienvenido a NEXTSTEP</h2></div>
      <p class="muted caption" style="font-size:13px">Tu profesor particular con IA que aprende contigo. Personalicemos tu punto de partida (Paso ${O.step} de 2):</p>
      <div class="title-sm">${one ? '¿Cuál es tu objetivo principal?' : '¿Cómo preferís las explicaciones?'}</div><div class="stack">${opts}</div>
      <div class="actions"><button class="btn btn-text" data-act="obSkip">Omitir por ahora</button>
        <button class="btn btn-tonal" style="background:var(--primary);color:var(--on-primary)" data-act="obNext">${one ? 'Siguiente' : 'Empezar'}</button></div>`);
  },

  /* ---------- acciones (data-act) ---------- */
  H: {
    nav(d) { this.go(d.id); },
    closeDialog() { this.closeDialog(); },
    confirmOk() { this.closeDialog(); const f = this._ok; this._ok = null; if (f) f(); },
    theme() {
      const t = this.state.themeConfig;
      this.updateRemoteSettings({ themeConfig: { isDarkMode: !this.isDark(), useSystemDark: false } }).then(() => this.renderView());
    },
    sysTheme() { this.updateRemoteSettings({ themeConfig: { useSystemDark: !this.state.themeConfig.useSystemDark } }).then(() => this.renderView()); },
    palette(d) { this.updateRemoteSettings({ themeConfig: { palette: d.id } }).then(() => this.renderView()); },
    customColor(d, el) { this.updateRemoteSettings({ themeConfig: { [d.k]: el.value } }); },
    setMode(d) { this.closeDialog(); this.updateRemoteSettings({ studyMode: d.id }).then(() => this.renderView()); },
    studyModeSel(d, el) { this.updateRemoteSettings({ studyMode: el.value }); },
    pref(d, el) { this.updateRemoteSettings({ preferences: { [d.k]: el.value } }); },
    async saveKey() {
      const v = $('api-key-input').value.trim();
      await this.updateRemoteSettings({ customApiKey: v });
      this.toast(v ? 'Clave guardada ✓' : 'Clave eliminada');
    },
    logout() { window.nsAuth.logout(); },
    resetAll() {
      this.confirm('¿Reiniciar tu progreso?', 'Se borrarán tu avance, ejercicios y chat. Tu cuenta se mantiene.', 'Reiniciar', async () => {
        const r = await this.api('/api/reset', {}); this.state = r.state; this.applyTheme(); this.ex = { i: 0, sel: null, hint: 0, checked: false, correct: false }; this.renderView(); this.toast('Progreso reiniciado');
      });
    },
    pomoToggle() {
      const P = this.pomo;
      if (P.running) { clearInterval(P.timer); P.running = false; } else { P.running = true; P.timer = setInterval(() => this.pomoTick(), 1000); }
      this.renderView();
    },
    pomoReset() { clearInterval(this.pomo.timer); this.pomo.running = false; this.pomo.secs = 1500; this.renderView(); },
    pickSubject(d) { this.updateRemoteSettings({ activeSubjectId: d.id }).then(() => this.vTutor()); },
    quick(d) { const q = QUICK[d.i]; this.sendChat(q[1], q[2]); },
    studySubject(d) { this.updateRemoteSettings({ activeSubjectId: d.id }).then(() => this.go('tutor')); },
    async completeModule(d) { await this.act('COMPLETE_MODULE', { moduleId: d.id }); this.toast('¡Módulo completado! +60 XP 🎉'); },
    askModule(d) {
      const m = this.state.routes.flatMap((r) => r.modules).find((x) => x.id === d.id);
      this.go('tutor'); if (m) this.sendChat(`Explícame el módulo "${m.title}" paso a paso`, 'EXPLICAR_MODULO');
    },
    exPick(d) { this.ex = { i: +d.i, sel: null, hint: 0, checked: false, correct: false }; this.renderView(); },
    exSelect(d) { this.ex.sel = +d.i; this.renderView(); },
    exHint() { this.ex.hint = Math.min(2, this.ex.hint + 1); this.renderView(); },
    async exCheck() {
      const x = this.state.exercises[this.ex.i];
      this.ex.checked = true; this.ex.correct = this.ex.sel === x.correctOptionIndex;
      await this.act('COMPLETE_EXERCISE', { exerciseId: x.id, selectedIndex: this.ex.sel });
    },
    exNext() { const n = this.state.exercises.length; this.ex = { i: (this.ex.i + 1) % n, sel: null, hint: 0, checked: false, correct: false }; this.renderView(); },
    askEx() { const x = this.state.exercises[this.ex.i]; this.go('tutor'); this.sendChat(`Explícame con más detalle este ejercicio: "${x.question}"`, 'EXPLICAR_SIMPLE'); },
    evStart(d) { this.ev = { id: d.id, i: 0, sel: null, answers: [] }; this.renderView(); },
    evSelect(d) { this.ev.sel = +d.i; this.renderView(); },
    evCancel() { this.ev = null; this.renderView(); },
    async evNext() {
      const V = this.ev, e = this.state.evaluations.find((x) => x.id === V.id);
      V.answers.push(V.sel); V.sel = null;
      if (V.i < e.questions.length - 1) { V.i++; return this.renderView(); }
      const ok = e.questions.filter((q, k) => V.answers[k] === q.correctIndex);
      const bad = e.questions.filter((q, k) => V.answers[k] !== q.correctIndex);
      const score = Math.round((ok.length / e.questions.length) * 100);
      const level = score >= 80 ? 'Avanzado' : score >= 50 ? 'Intermedio' : 'Principiante';
      const uniq = (a) => [...new Set(a.map((q) => q.topic))];
      this.ev = null;
      await this.act('COMPLETE_EVALUATION', { evalId: e.id, scorePercent: score, level, strengths: uniq(ok), weaknesses: uniq(bad) });
      this.toast(`Evaluación completada: ${score}% • +120 XP`);
    },
    toggleTask(d) { this.act('TOGGLE_GOAL_TASK', { goalId: d.g, taskId: d.t }); },
    newSubject() {
      this.dialog(`<h2>Nueva materia</h2><div class="field"><label>Nombre</label><input class="input" id="ns-subj-name" maxlength="60" placeholder="Ej: Historia Argentina"></div>
        <div class="field"><label>Categoría</label><input class="input" id="ns-subj-cat" maxlength="40" placeholder="Ej: Humanidades"></div>
        <div class="field"><label>Descripción (opcional)</label><input class="input" id="ns-subj-desc" maxlength="300"></div>
        <div class="actions"><button class="btn btn-text" data-act="closeDialog">Cancelar</button><button class="btn btn-filled" data-act="saveSubject">Agregar</button></div>`);
    },
    async saveSubject() {
      const name = $('ns-subj-name').value.trim();
      if (!name) return this.toast('Poné un nombre para la materia');
      await this.act('ADD_SUBJECT', { name, category: $('ns-subj-cat').value.trim(), description: $('ns-subj-desc').value.trim() });
      this.closeDialog(); this.toast('Materia agregada ✓');
    },
    newGoal() {
      this.dialog(`<h2>Nuevo objetivo</h2><div class="field"><label>Objetivo</label><input class="input" id="ns-goal-title" maxlength="100" placeholder="Ej: Rendir Álgebra"></div>
        <div class="field"><label>Plazo</label><input class="input" id="ns-goal-deadline" maxlength="40" placeholder="Ej: En 2 semanas"></div>
        <div class="field"><label>Prioridad</label><select class="select" id="ns-goal-prio"><option>ALTA</option><option selected>MEDIA</option><option>BAJA</option></select></div>
        <div class="field"><label>Tareas (una por línea)</label><textarea class="input" id="ns-goal-tasks" rows="4" maxlength="600"></textarea></div>
        <div class="actions"><button class="btn btn-text" data-act="closeDialog">Cancelar</button><button class="btn btn-filled" data-act="saveGoal">Agregar</button></div>`);
    },
    async saveGoal() {
      const title = $('ns-goal-title').value.trim();
      if (!title) return this.toast('Poné un título para el objetivo');
      const now = Date.now();
      const tasks = $('ns-goal-tasks').value.split('\n').map((t) => t.trim()).filter(Boolean).slice(0, 15).map((t, i) => ({ id: `gt_${now}_${i}`, title: t, isCompleted: false }));
      await this.act('ADD_GOAL', { goal: { title, deadline: $('ns-goal-deadline').value.trim() || 'Sin plazo', priority: $('ns-goal-prio').value, tasks } });
      this.closeDialog(); this.toast('Objetivo agregado ✓');
    },
    obGoal(d) { this.ob.goal = d.v; this.openOnboarding(); },
    obDepth(d) { this.ob.depth = d.v; this.openOnboarding(); },
    obNext() {
      if (this.ob.step === 1) { this.ob.step = 2; return this.openOnboarding(); }
      this.finishOnboarding({ goal: this.ob.goal, depth: this.ob.depth });
    },
    obSkip() { this.finishOnboarding({ skipped: true }); },
  },

  async finishOnboarding(payload) {
    this.ob = null; this.closeDialog();
    await this.act('COMPLETE_ONBOARDING', payload);
    this.toast(payload.skipped ? 'Podés personalizar todo en Configuración' : '¡Listo! Tu profesor ya conoce tu objetivo 🎯');
  },
};

window.app = app;
document.addEventListener('DOMContentLoaded', async () => {
  if (await nsAuth.ensureLoggedIn()) app.init();
});
