// NEXTSTEP — plataforma educativa con profesor IA.
// Backend: Express 5 + SQLite (node:sqlite, integrado en Node.js 22.5+).
import dotenv from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import rateLimit from 'express-rate-limit';
import { initDb } from './src/db.js';
import { GREETING, START_QUICK, ALLOWED_URLS, MODES as PROMPT_MODES } from './src/prompt.js';
import { providerInfo, missingConfigMessage } from './src/llm.js';
import { authRouter } from './src/routes/auth.js';
import { contentRouter } from './src/routes/content.js';
import { richRouter } from './src/routes/rich.js';
import { productivityRouter } from './src/routes/productivity.js';
import { progressRouter } from './src/routes/progress.js';
import { chatRouter } from './src/routes/chat.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// El .env siempre se busca junto al proyecto, sin importar desde dónde se ejecute.
dotenv.config({ path: path.join(__dirname, '.env') });
const PORT = Number(process.env.PORT) || 3000;

initDb();

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '200kb' }));

const limiter = rateLimit({
  windowMs: 60_000,
  limit: Number(process.env.RATE_LIMIT_PER_MIN) || 40,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Hiciste muchas consultas seguidas. Esperá un minuto y probá de nuevo.' },
});

// ---- Público ----
app.get('/api/health', (_req, res) => {
  const { provider, model, ready } = providerInfo();
  res.json({ ok: true, provider, model, ia: ready });
});

app.get('/api/meta', (_req, res) => {
  res.json({
    greeting: GREETING,
    startQuick: START_QUICK,
    allowedUrls: ALLOWED_URLS,
    modes: Object.keys(PROMPT_MODES),
    requiresSetup: !providerInfo().ready,
    setupMessage: missingConfigMessage(),
  });
});

// ---- Rutas autenticadas ----
app.use('/api/auth', limiter, authRouter);
app.use('/api', contentRouter);      // materias, temas, conversaciones
app.use('/api', richRouter);         // rutas, módulos, actividades, evaluaciones
app.use('/api', productivityRouter); // objetivos, tareas, recursos, sesiones
app.use('/api', progressRouter);     // dashboard, estadísticas
app.use('/api', limiter, chatRouter); // chat SSE

// ---- Estáticos y SPA ----
app.use(express.static(path.join(__dirname, 'public'), { maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0 }));
app.use((req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Manejo de errores amigable (nunca filtra datos sensibles).
app.use((err, req, res, _next) => {
  const status = typeof err?.status === 'number' && err.status >= 400 && err.status < 500 ? err.status : 500;
  console.error('[error]', status, req.method, req.originalUrl, '\n', err?.stack ?? err);
  if (res.headersSent) return;
  res.status(status).json({ error: status === 500 ? 'Algo salió mal en el servidor. Probá de nuevo.' : err.message });
});

app.listen(PORT, () => {
  console.log(`NEXTSTEP andando en http://localhost:${PORT}`);
  const info = providerInfo();
  console.log(`IA: ${info.provider}${info.model ? ' / ' + info.model : ''}`);
  if (!info.ready) console.warn('Atención: ' + missingConfigMessage() + ' Copiá .env.example a .env y completalo.');
});