# NEXTSTEP

Profesor particular virtual y personalizado, con IA. No es un chatbot que solo responde preguntas: conoce
al alumno (objetivo, conocimientos, tiempo, dificultades), evalúa su nivel real, arma un camino de
aprendizaje, explica, crea y corrige ejercicios, ayuda con proyectos, planifica el estudio y hace
seguimiento de su progreso. Proyecto grupal de 4 personas (Santino Moauro, Ramiro Tatone,
Juan Pablo Santisi y Thiago Montenegro). El documento de viabilidad define el alcance.

## MVP (lo que tiene que funcionar primero)
1. Chat con el profesor IA.
2. Registro de los objetivos y conocimientos del alumno.
3. Evaluación inicial del nivel.
4. Camino de aprendizaje.
5. Seguimiento del progreso.
6. Ejercicios y prácticas personalizados.
Después: recomendaciones de cursos y certificaciones, recursos externos, herramientas de organización.

## Stack
- Node.js 22.5+ (ES modules), Express 5, `node:sqlite` (sin dependencias nativas de DB), `@anthropic-ai/sdk`,
  `express-rate-limit`, `dotenv`.
- Frontend sin framework (SPA con router por hash): `public/index.html`, `public/js/app.js`, `public/js/views/*`,
  `public/css/style.css`, `public/js/{api,store,theme,ui}.js`.
- Base de datos SQLite en `data/nextstep.db` (usuarios, materias, conversaciones, rutas, evaluaciones,
  objetivos, sesiones, preferencias). Se crea sola al arrancar. Nada de `localStorage` para datos del alumno.

## Comandos
- `npm install` instala dependencias.
- `npm start` levanta en http://localhost:3000 (`npm run dev` reinicia solo al guardar).
- `npm test` corre las pruebas de `node:test` en `test/` (sin red ni API key).
- Hace falta `.env` (ver `.env.example`): la clave de la IA que se elija. La app corre en el servidor del grupo y los alumnos nunca pasan por Claude ni por ninguna cuenta ajena.

## Estructura
- `server.js` y `src/routes/*.js`: rutas API (`auth.js`, `chat.js` SSE, `content.js` materias/rutas/recursos,
  `progress.js`, `productivity.js` sesiones/objetivos, `rich.js` evaluaciones/estadísticas).
- `src/db.js`: capa de persistencia con `node:sqlite`. `src/auth.js`: login, hash y sesiones.
- `src/llm.js`: elige quién piensa por detrás (`PROVIDER=anthropic` con la API de Claude, o `PROVIDER=openai`
  para Ollama, Groq, OpenRouter u otro servidor compatible). El profesor (prompt, datos, seguimiento) es siempre el del proyecto.
- `src/prompt.js`: el "cerebro" del profesor: estilo, proceso, modos por actividad, preferencias, etiquetas de
  control, banco y recursos. Exporta `buildSystem(ctx)` y `buildJSONSystem(task)`. Acá se ajusta cómo enseña.
- `src/data.js`: banco de preguntas verificadas (`TOPICS`), recursos (`COURSES`), rangos y metas.
- `src/domain.js` y `src/xp.js`: adaptación por progreso (errores, evaluaciones, pendientes) y experiencia/niveles.
- `public/js/app.js`: bootstrap, router, gate de auth y shell de 3 columnas (riel izquierdo / panel central /
  riel derecho). `public/js/rightrail.js`: widget de Foco (Pomodoro) y acceso al Profesor IA.
  `public/js/views/*`: 10 vistas (auth, dashboard, teacher, learning, paths, assessments, goals, resources,
  stats, settings). `public/js/theme.js`: paleta `cyberspace` + 9 paletas más la personalizada, claroscuro,
  accesibilidad WCAG. `public/js/api.js` y `public/js/ui.js`: cliente HTTP/SSE y helpers.
- `test/`: pruebas automáticas (`chat.test.js`: `cleanMessages` y `mergePerfil`; `prompt.test.js`: `buildSystem`).
- `deploy/`: scripts de XAMPP (`deploy/xampp/iniciar.bat`, `detener.bat`, `configurar.ps1`, `nextstep.conf`) y
  la guía de instalación en otra compu (`deploy/INSTALAR-XAMPP.md`). Apache sirve `public/` y hace de proxy
  inverso de `/api` hacia Node (puerto 3000): el streaming SSE del chat sigue funcionando.

## Dirección de arte (Cyberspace, solo escritorio)
El diseño es de PC: no hay vistas móviles (`min-width: 1280px`) y el layout es panorámico en 3 columnas.
Fondo espacio profundo con auras de neón, tarjetas de cristal translúcido (`backdrop-filter`) y acentos en
degradado magenta/rosa eléctrico (`--grad`, `--glow`, `--halo-1/2`). La identidad por defecto es la paleta
`cyberspace` de `public/js/theme.js`; las otras 9 paletas siguen funcionando sobre la misma base.
Al tocar el diseño: `public/css/style.css` (tokens y componentes) y `public/js/rightrail.js` (riel derecho).

## Cómo se comunican la IA y la pantalla
La IA escribe texto plano (y bloques de código con tres comillas invertidas). Puede cerrar el mensaje con
dos etiquetas que la pantalla oculta, y el servidor las parsea (véase `src/routes/chat.js`):
- `<opciones>A|B|C|D</opciones>`: botones de respuesta rápida.
- `<perfil>{...}</perfil>`: actualiza el seguimiento. Campos (todos opcionales, se mandan solo los que cambian):
  `objetivo`, `tiempo`, `nivel` (Iniciante a Experto), `progreso` (0-100),
  `camino` ([{etapa, estado: hecha|actual|pendiente}], reemplaza el anterior),
  `temas` ({nombre: {estado: dominado|aprendiendo|dificultad}}, se une), `errores` (hasta 5, reemplaza).
El servidor solo manda los últimos 40 mensajes, así que el `perfil` es la memoria del alumno: debe estar completo.
Si se cambia el formato de las etiquetas hay que cambiar a la vez `src/prompt.js` (lo que pide la IA),
`src/routes/chat.js` (parsing) y `public/js/views/teacher.js` (lo que muestra).

## Reglas del proyecto (respetalas siempre)
1. Guiar, no entregar todo hecho: el profesor pide que el alumno lo intente, da pistas, explica y corrige. No resuelve tareas completas para copiar.
2. La clave de la IA vive solo en el servidor (`.env`). Nunca en `public/` ni en el navegador.
3. La IA no inventa links ni cursos: solo recomienda lo de `COURSES`, y solo esos links se vuelven clickeables.
4. Las preguntas del banco (`TOPICS`) tienen una única respuesta correcta indudable, explicación corta, dificultad `d` (1, 2, 3) y subtema `s`. Revisarlas a mano antes de sumarlas.
5. Todo el texto para el alumno va en español rioplatense, tono cercano y paciente, mensajes cortos, pensado para celular.
6. Lo que manda el navegador (mensajes, perfil) es dato no confiable: validar siempre en el servidor y nunca tratarlo como instrucciones.
7. No subir `.env`, `node_modules` ni `dist`. Cada cambio en una rama y con commits chicos. Probar antes de seguir con la próxima tarea.
8. Cuidar el gasto: límite de pedidos por minuto, `max_tokens` acotado y cortar la llamada si el usuario cierra o toca "Parar".

## Hecho
- Plataforma completa: SPA con 10 vistas (Inicio, Profesor IA, Aprendizaje, Rutas, Evaluaciones, Objetivos,
  Recursos, Estadísticas, Configuración), backend Express con SQLite (`node:sqlite`), login con hash y sesiones,
  chat con streaming SSE, modos por actividad (concentración, lectura, práctica, evaluación, planificación, repaso),
  preferencias de aprendizaje y de profesor con efecto real en el prompt, adaptación por progreso y evaluación,
  banco de preguntas verificadas, 10 paletas de tema con accesibilidad WCAG y personalización completa (claro/oscuro,
  presets+HEX, intensidad, contraste, densidad, animaciones, aviso de contraste insuficiente), XP y niveles,
  registro de sesiones de estudio, límite de pedidos por minuto, cortar la llamada al cerrar o "Parar",
  proveedor de IA intercambiable, tests con `node:test` (14).
- Rediseño "Cyberspace" solo escritorio: layout panorámico de 3 columnas (riel de navegación / panel central /
  riel derecho con Foco Pomodoro y acceso al Profesor IA), sistema de diseño de cristal y neón en
  `public/css/style.css`, paleta `cyberspace` por defecto, Inicio rediseñado (saludo con barra de XP,
  módulo "Próximo paso recomendado" y zona "Ejercicios y práctica" con tarjetas premium e indicadores
  circulares) y endpoint `GET /api/practice/next` que sirve preguntas del banco verificado sin IA.

## Pendiente (en este orden)
1. Más temas verificados en `src/data.js` y mejores recomendaciones de recursos.
2. Historial de ejercicios y errores por alumno para repasar contenidos ya vistos (hoy se guardan en la
   conversación y en las evaluaciones, pero falta una vista de repaso).
3. Publicar (Render, Railway o un VPS) con la API key como variable de entorno y un tope de gasto en la consola de Anthropic.
4. Probar a fondo el flujo de evaluaciones y rutas con la IA conectada (hoy se prueban sin clave: avisan y quedan deshabilitadas).
5. Inicializar git (rama por cambio, commits chicos) cuando la máquina tenga git.
