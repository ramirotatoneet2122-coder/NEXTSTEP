// Banco de preguntas y lista de cursos de NEXTSTEP.
// Las preguntas están verificadas a mano: la IA usa ESTE banco para el test.
// Los links de COURSES son los únicos que la IA puede recomendar.

const RANKS = ['Iniciante', 'Básico', 'Intermedio', 'Avanzado', 'Experto'];
const RANK_MIN = [0, 25, 50, 75, 90];
const rankOf = p => { let r = 0; RANK_MIN.forEach((m, i) => { if (p >= m) r = i; }); return r; };
const GOALS = { examen: 'Rendir un examen', trabajo: 'Conseguir trabajo', cv: 'Mejorar mi CV', proyecto: 'Hacer un proyecto' };

const TOPICS = {
  html: { name: 'HTML', qs: [
    { d: 1, s: 'Etiquetas básicas', q: '¿Qué etiqueta se usa para crear un enlace?', o: ['<link>', '<a>', '<href>', '<url>'], a: 1, e: 'La etiqueta <a> con href crea enlaces.' },
    { d: 1, s: 'Estructura de la página', q: '¿Dónde va el contenido visible de la página?', o: ['<head>', '<meta>', '<html>', '<body>'], a: 3, e: '<body> contiene lo que se ve; <head> guarda metadatos.' },
    { d: 2, s: 'Accesibilidad', q: '¿Qué atributo da el texto alternativo de una imagen?', o: ['alt', 'src', 'title', 'name'], a: 0, e: 'alt describe la imagen para lectores de pantalla.' },
    { d: 2, s: 'Listas', q: '¿Qué etiqueta crea una lista numerada?', o: ['<ul>', '<li>', '<dl>', '<ol>'], a: 3, e: '<ol> es la lista ordenada; <ul> es de viñetas.' },
    { d: 3, s: 'HTML semántico', q: '¿Cuál de estas es una etiqueta semántica?', o: ['<div>', '<span>', '<article>', '<b>'], a: 2, e: '<article> da significado; <div> y <span> son genéricas.' },
    { d: 3, s: 'Formularios', q: '¿Qué atributo hace obligatorio un campo de formulario?', o: ['required', 'mandatory', 'validate', 'needed'], a: 0, e: 'required impide enviar el formulario con el campo vacío.' }
  ] },
  js: { name: 'JavaScript', qs: [
    { d: 1, s: 'Variables', q: '¿Cuál declara una constante?', o: ['var x', 'let x', 'const x', 'static x'], a: 2, e: 'const declara un valor que no se reasigna.' },
    { d: 1, s: 'Consola', q: '¿Cómo se muestra un mensaje en la consola?', o: ['print("hola")', 'console.log("hola")', 'echo "hola"', 'log.console("hola")'], a: 1, e: 'console.log() escribe en la consola.' },
    { d: 2, s: 'Comparaciones', q: '¿Qué devuelve 5 === "5"?', o: ['true', 'false', 'undefined', 'Error'], a: 1, e: '=== compara valor y tipo.' },
    { d: 2, s: 'Arrays', q: '¿Qué método agrega un elemento al final de un array?', o: ['shift', 'add', 'push', 'append'], a: 2, e: 'push agrega al final; shift saca el primero.' },
    { d: 3, s: 'Funciones flecha', q: '¿Qué imprime? const f = x => x * 2; console.log(f(4))', o: ['4', '8', 'x*2', 'undefined'], a: 1, e: 'Duplica el argumento: 8.' },
    { d: 3, s: 'Asincronía', q: '¿Para qué sirve await?', o: ['Repetir una función', 'Esperar el resultado de una promesa', 'Declarar una variable', 'Cortar un bucle'], a: 1, e: 'await pausa la función async hasta que la promesa se resuelve.' }
  ] },
  java: { name: 'Java', qs: [
    { d: 1, s: 'Tipos de datos', q: '¿Qué tipo guarda texto?', o: ['char', 'text', 'String', 'Str'], a: 2, e: 'String guarda cadenas; char, un solo carácter.' },
    { d: 1, s: 'Objetos', q: '¿Qué palabra clave crea un objeto nuevo?', o: ['new', 'make', 'create', 'object'], a: 0, e: 'new llama al constructor.' },
    { d: 2, s: 'Método main', q: '¿Cómo se declara el método principal?', o: ['void start()', 'public static void main(String[] args)', 'main()', 'static int run()'], a: 1, e: 'La JVM busca public static void main(String[] args).' },
    { d: 2, s: 'Bucles', q: '¿Cuál es una estructura de repetición?', o: ['if', 'switch', 'return', 'for'], a: 3, e: 'for repite un bloque; if y switch son condicionales.' },
    { d: 3, s: 'Herencia', q: '¿Qué palabra clave permite heredar de otra clase?', o: ['implements', 'extends', 'inherits', 'super'], a: 1, e: 'extends hereda de una clase; implements es para interfaces.' },
    { d: 3, s: 'Encapsulamiento', q: '¿Qué modificador impide acceder a un atributo desde otra clase?', o: ['public', 'private', 'static', 'final'], a: 1, e: 'private limita el acceso a la propia clase.' }
  ] },
  python: { name: 'Python', qs: [
    { d: 1, s: 'Funciones', q: '¿Qué palabra clave define una función en Python?', o: ['function', 'def', 'fun', 'lambda'], a: 1, e: 'def define funciones; lambda crea funciones anónimas cortas.' },
    { d: 1, s: 'Salida', q: '¿Qué muestra print("2" + "3")?', o: ['5', '23', '"5"', 'Error'], a: 1, e: 'El + concatena textos: muestra 23.' },
    { d: 2, s: 'Listas', q: '¿Qué método agrega un elemento al final de una lista?', o: ['push', 'add', 'append', 'concat'], a: 2, e: 'append agrega al final; push no existe en Python.' },
    { d: 2, s: 'Condicionales', q: '¿Para qué sirve elif?', o: ['Repetir un bloque', 'Evaluar otra condición si la anterior fue falsa', 'Romper el bucle', 'Definir una variable'], a: 1, e: 'elif encadena condiciones luego de un if.' },
    { d: 3, s: 'Bucles', q: '¿Cuántas iteraciones hace for i in range(3)?', o: ['2', '3', '4', 'Error'], a: 1, e: 'range(3) genera 0, 1 y 2: tres iteraciones.' },
    { d: 3, s: 'Diccionarios', q: 'Con d = {"edad": 15}, ¿cómo se accede al valor de "edad"?', o: ['d.edad', 'd[0]', 'd["edad"]', 'edad(d)'], a: 2, e: 'Los diccionarios usan claves: d["edad"].' }
  ] },
  sql: { name: 'Bases de datos (SQL)', qs: [
    { d: 1, s: 'Consultas básicas', q: '¿Qué sentencia lee datos de una tabla?', o: ['GET', 'SELECT', 'READ', 'FETCH'], a: 1, e: 'SELECT consulta datos.' },
    { d: 1, s: 'Filtros', q: '¿Qué cláusula filtra filas?', o: ['WHERE', 'ORDER BY', 'GROUP BY', 'LIMIT'], a: 0, e: 'WHERE deja las filas que cumplen la condición.' },
    { d: 2, s: 'Claves', q: '¿Qué identifica de forma única cada fila de una tabla?', o: ['Clave foránea', 'Índice', 'Clave primaria', 'Vista'], a: 2, e: 'La clave primaria es única y no nula.' },
    { d: 2, s: 'Ordenar resultados', q: '¿Qué cláusula ordena los resultados?', o: ['SORT', 'ORDER BY', 'ARRANGE', 'GROUP BY'], a: 1, e: 'ORDER BY ordena por columnas.' },
    { d: 3, s: 'JOIN', q: '¿Qué hace un INNER JOIN?', o: ['Trae todas las filas de ambas tablas', 'Trae solo las filas con coincidencia en ambas tablas', 'Borra filas duplicadas', 'Une dos bases de datos'], a: 1, e: 'Devuelve solo las filas con par en las dos tablas.' },
    { d: 3, s: 'Funciones de agregación', q: '¿Qué función cuenta filas?', o: ['SUM()', 'COUNT()', 'TOTAL()', 'LEN()'], a: 1, e: 'COUNT() cuenta filas; SUM() suma valores.' }
  ] },
  redes: { name: 'Redes', qs: [
    { d: 1, s: 'Direcciones IP', q: '¿Qué identifica una dirección IP?', o: ['Un usuario', 'Un programa', 'Un dispositivo en una red', 'Un sitio web'], a: 2, e: 'La IP identifica un dispositivo en una red.' },
    { d: 1, s: 'Protocolos web', q: '¿Qué protocolo cifra la comunicación web?', o: ['HTTP', 'FTP', 'HTTPS', 'SMTP'], a: 2, e: 'HTTPS es HTTP con cifrado TLS.' },
    { d: 2, s: 'Dispositivos de red', q: '¿Qué dispositivo enruta paquetes entre redes distintas?', o: ['Switch', 'Router', 'Hub', 'Repetidor'], a: 1, e: 'El router conecta redes; el switch conecta equipos de una misma red.' },
    { d: 2, s: 'DNS', q: '¿Para qué sirve el DNS?', o: ['Cifrar archivos', 'Traducir nombres de dominio a direcciones IP', 'Acelerar el Wi-Fi', 'Bloquear virus'], a: 1, e: 'Convierte nombres de dominio en direcciones IP.' },
    { d: 3, s: 'Puertos', q: '¿Cuál es el puerto por defecto de HTTPS?', o: ['80', '21', '443', '25'], a: 2, e: 'HTTPS usa el 443; HTTP, el 80.' },
    { d: 3, s: 'Subredes', q: '¿Cuántas direcciones útiles para dispositivos tiene una red /24?', o: ['256', '254', '255', '128'], a: 1, e: '256 menos la de red y la de broadcast: 254.' }
  ] },
  mate: { name: 'Matemática', qs: [
    { d: 1, s: 'Porcentajes', q: '¿Cuánto es el 15% de 200?', o: ['20', '30', '15', '45'], a: 1, e: '200 × 0,15 = 30.' },
    { d: 1, s: 'Orden de operaciones', q: '¿Cuánto es 3 + 4 × 2?', o: ['14', '11', '10', '9'], a: 1, e: 'Primero 4 × 2 = 8; luego 3 + 8 = 11.' },
    { d: 2, s: 'Ecuaciones', q: 'Resolvé: 2x + 6 = 14', o: ['x = 3', 'x = 10', 'x = 4', 'x = 8'], a: 2, e: '2x = 8, entonces x = 4.' },
    { d: 2, s: 'Geometría', q: '¿Cuál es el área de un círculo de radio 3?', o: ['6π', '3π', '12π', '9π'], a: 3, e: 'π × r² = 9π.' },
    { d: 3, s: 'Funciones', q: 'Si f(x) = 2x² − 3, ¿cuánto vale f(3)?', o: ['15', '9', '12', '18'], a: 0, e: '2 × 9 − 3 = 15.' },
    { d: 3, s: 'Sistemas de ecuaciones', q: 'Si x + y = 10 y x − y = 2, ¿cuánto vale x?', o: ['4', '6', '8', '2'], a: 1, e: 'Sumando: 2x = 12, entonces x = 6.' }
  ] },
  geografia: { name: 'Geografía', qs: [
    { d: 1, s: 'Capitales', q: '¿Cuál es la capital de la Argentina?', o: ['Córdoba', 'Buenos Aires', 'Rosario', 'La Plata'], a: 1, e: 'Buenos Aires es la capital nacional.' },
    { d: 1, s: 'Continentes', q: '¿En qué continente está Egipto?', o: ['Asia', 'América', 'África', 'Europa'], a: 2, e: 'Egipto está en el noreste de África.' },
    { d: 2, s: 'Líneas imaginarias', q: '¿Qué línea divide la Tierra en hemisferios norte y sur?', o: ['El meridiano de Greenwich', 'El Ecuador', 'El trópico de Cáncer', 'El círculo polar'], a: 1, e: 'El Ecuador, paralelo 0°, divide ambos hemisferios.' },
    { d: 2, s: 'Océanos', q: '¿Qué océano baña la costa este de la Argentina?', o: ['Pacífico', 'Atlántico', 'Índico', 'Antártico'], a: 1, e: 'El océano Atlántico está al este del país.' },
    { d: 3, s: 'Relieves', q: '¿Cuál es la cordillera más larga del planeta?', o: ['El Himalaya', 'Los Andes', 'Los Alpes', 'Las Rocosas'], a: 1, e: 'Los Andes recorren más de 7000 km por Sudamérica.' },
    { d: 3, s: 'Población', q: '¿Qué país tiene actualmente la mayor población del mundo?', o: ['China', 'India', 'Estados Unidos', 'Brasil'], a: 1, e: 'India superó a China en población hacia 2023.' }
  ] },
  historia: { name: 'Historia', qs: [
    { d: 1, s: 'Fechas clave', q: '¿En qué año comenzó la Revolución de Mayo?', o: ['1800', '1810', '1820', '1825'], a: 1, e: 'Fue el 25 de mayo de 1810 en Buenos Aires.' },
    { d: 1, s: 'Siglos', q: '¿En qué siglo tuvo lugar la Revolución Francesa?', o: ['XVII', 'XVIII', 'XIX', 'XX'], a: 1, e: 'Comenzó en 1789, durante el siglo XVIII.' },
    { d: 1, s: 'Guerra mundial', q: '¿En qué año terminó la Segunda Guerra Mundial?', o: ['1939', '1945', '1918', '1950'], a: 1, e: 'Terminó en 1945 con la rendición de Alemania y Japón.' },
    { d: 2, s: 'Independencia', q: '¿Dónde y cuándo se declaró la independencia argentina?', o: ['1810 en Buenos Aires', '1816 en San Miguel de Tucumán', '1820 en Rosario', '1813 en Córdoba'], a: 1, e: 'El 9 de julio de 1816, en el Congreso de Tucumán.' },
    { d: 2, s: 'América precolonial', q: '¿Qué imperio tenía su centro en el valle de México?', o: ['El inca', 'El azteca', 'El maya del sur', 'El mapuche'], a: 1, e: 'El Imperio azteca dominó el centro de México.' },
    { d: 3, s: 'Exploración', q: 'La primera vuelta al mundo fue completada por la expedición de:', o: ['Cristóbal Colón', 'Magallanes y Elcano', 'Vasco da Gama', 'Hernán Cortés'], a: 1, e: 'Partió con Magallanes y la terminó Elcano en 1522.' },
    { d: 3, s: 'Siglo XX', q: '¿Qué fue la Guerra Fría?', o: ['Una guerra entre países europeos', 'Un conflicto ideológico y político protagonizado por EE. UU. y la URSS', 'Una batalla naval en el Atlántico', 'Un tratado comercial'], a: 1, e: 'Fue la confrontación entre los bloques capitalista y soviético.' }
  ] },
  ciencia: { name: 'Ciencias naturales', qs: [
    { d: 1, s: 'Sistema solar', q: '¿Cuál es el planeta más cercano al Sol?', o: ['Venus', 'Mercurio', 'Marte', 'Tierra'], a: 1, e: 'Mercurio es el primero en distancia al Sol.' },
    { d: 1, s: 'Fotosíntesis', q: '¿Qué gas usan las plantas para hacer la fotosíntesis?', o: ['Oxígeno', 'Nitrógeno', 'Dióxido de carbono', 'Hidrógeno'], a: 2, e: 'En la fotosíntesis se toma CO₂ y se libera oxígeno.' },
    { d: 2, s: 'Estructura de la vida', q: '¿Cuál es la unidad básica de los seres vivos?', o: ['El átomo', 'La célula', 'El tejido', 'El órgano'], a: 1, e: 'Todos los organismos están formados por células.' },
    { d: 2, s: 'Biología molecular', q: '¿Cómo se llaman las unidades que forman el ADN?', o: ['Aminoácidos', 'Nucleótidos', 'Glucosas', 'Lípidos'], a: 1, e: 'El ADN es una cadena de nucleótidos.' },
    { d: 3, s: 'Física', q: '¿Qué magnitud mide un amperímetro?', o: ['El voltaje', 'La corriente eléctrica', 'La resistencia', 'La potencia'], a: 1, e: 'El amperímetro mide amperios, es decir, corriente.' },
    { d: 3, s: 'Energía celular', q: '¿Qué proceso celular obtiene energía a partir de la glucosa?', o: ['Fotosíntesis', 'Respiración celular', 'Ósmosis', 'Fermentación láctica'], a: 1, e: 'En la respiración celular se libera la energía de la glucosa.' },
    { d: 3, s: 'Científicos', q: 'La teoría de la relatividad fue desarrollada por:', o: ['Isaac Newton', 'Albert Einstein', 'Niels Bohr', 'James Clerk Maxwell'], a: 1, e: 'Einstein la publicó a comienzos del siglo XX.' }
  ] },
  lengua: { name: 'Lengua', qs: [
    { d: 1, s: 'Tildes', q: '¿Cuál de estas palabras está bien escrita?', o: ['Cancion', 'Cancíon', 'Canción', 'Cáncion'], a: 2, e: 'Aguda terminada en n: lleva tilde.' },
    { d: 1, s: 'Clases de palabras', q: '¿Cuál de estas palabras es un verbo?', o: ['Mesa', 'Correr', 'Rápido', 'Azul'], a: 1, e: 'Correr expresa una acción.' },
    { d: 2, s: 'Hay, ahí y ay', q: 'Completá: "___ muchos libros en la mesa."', o: ['Ahí', 'Hay', 'Ay', 'Ahy'], a: 1, e: '"Hay" (de haber) indica existencia; "ahí" indica lugar.' },
    { d: 2, s: 'Sujeto y predicado', q: 'En "Los chicos juegan en la plaza", ¿cuál es el sujeto?', o: ['juegan', 'en la plaza', 'Los chicos', 'la plaza'], a: 2, e: 'Es quien realiza la acción: "Los chicos".' },
    { d: 3, s: 'Conectores', q: '¿Qué conector expresa oposición?', o: ['Además', 'Sin embargo', 'Por lo tanto', 'Es decir'], a: 1, e: '"Sin embargo" contrasta ideas.' },
    { d: 3, s: 'Tipos de texto', q: 'Un texto que busca convencer con argumentos es:', o: ['Narrativo', 'Instructivo', 'Argumentativo', 'Descriptivo'], a: 2, e: 'El argumentativo defiende una postura con razones.' }
  ] },
  ingles: { name: 'Inglés', qs: [
    { d: 1, s: 'Vocabulario', q: '¿Qué significa "knowledge"?', o: ['Rodilla', 'Conocimiento', 'Cuchillo', 'Noticia'], a: 1, e: 'Knowledge es conocimiento.' },
    { d: 1, s: 'Verbo to be', q: 'Completá: She ___ a student.', o: ['am', 'are', 'is', 'be'], a: 2, e: 'Con she, he, it: "is".' },
    { d: 2, s: 'Pasado simple', q: '¿Cuál es el pasado de "go"?', o: ['goed', 'went', 'gone', 'going'], a: 1, e: 'go, went, gone.' },
    { d: 2, s: 'Preposiciones', q: 'Completá: "I\'ll see you ___ Monday."', o: ['in', 'at', 'by', 'on'], a: 3, e: 'Con días se usa "on".' },
    { d: 3, s: 'Present perfect', q: '¿Cuál oración es correcta?', o: ['I have lived here since 2020', 'I live here since 2020', 'I am living here since 2020', 'I lived here since 2020'], a: 0, e: 'Algo que empezó en el pasado y sigue: present perfect con since.' },
    { d: 3, s: 'Condicionales', q: 'Completá: "If I ___ more time, I would study more."', o: ['have', 'had', 'will have', 'would have'], a: 1, e: 'Segundo condicional: pasado simple en el "if".' }
  ] }
};

const EFF_H = [15, 60, 200];
const FCC = 'https://www.freecodecamp.org/espanol/learn/';
const COURSES = [
  { topics: ['html'], title: 'Diseño web responsivo', org: 'freeCodeCamp', url: FCC, kind: 'Certificado', cert: 1, free: 1, effort: 2, min: 0, goals: ['trabajo', 'cv'] },
  { topics: ['html', 'js'], title: 'Aprender desarrollo web', org: 'MDN Web Docs', url: 'https://developer.mozilla.org/es/docs/Learn', kind: 'Curso', cert: 0, free: 1, effort: 1, min: 0, goals: ['examen', 'proyecto'] },
  { topics: ['html', 'js'], title: 'Desafíos de frontend', org: 'Frontend Mentor', url: 'https://www.frontendmentor.io/', kind: 'Proyecto', cert: 0, free: 1, effort: 1, min: 1, goals: ['proyecto', 'cv'] },
  { topics: ['js'], title: 'Algoritmos y estructuras de datos con JavaScript', org: 'freeCodeCamp', url: FCC, kind: 'Certificado', cert: 1, free: 1, effort: 2, min: 1, goals: ['trabajo', 'cv'] },
  { topics: ['js', 'html'], title: 'Ruta completa de desarrollo web', org: 'The Odin Project', url: 'https://www.theodinproject.com/', kind: 'Proyecto', cert: 0, free: 1, effort: 2, min: 2, goals: ['trabajo', 'proyecto', 'cv'] },
  { topics: ['python'], title: 'Científico de datos con Python', org: 'freeCodeCamp', url: FCC, kind: 'Certificado', cert: 1, free: 1, effort: 2, min: 1, goals: ['trabajo', 'proyecto', 'cv'] },
  { topics: ['java', 'js'], title: 'Ejercicios de práctica con mentores', org: 'Exercism', url: 'https://exercism.org/', kind: 'Práctica', cert: 0, free: 1, effort: 1, min: 1, goals: ['examen', 'trabajo'] },
  { topics: ['java'], title: 'Learn Java', org: 'Codecademy', url: 'https://www.codecademy.com/learn/learn-java', kind: 'Curso', cert: 2, free: 0, effort: 1, min: 0, goals: ['examen', 'cv'] },
  { topics: ['java'], title: 'Certificaciones de Java', org: 'Oracle', url: 'https://education.oracle.com/', kind: 'Certificado', cert: 2, free: 0, effort: 2, min: 3, goals: ['trabajo', 'cv', 'examen'] },
  { topics: ['sql'], title: 'Bases de datos relacionales', org: 'freeCodeCamp', url: FCC, kind: 'Certificado', cert: 1, free: 1, effort: 2, min: 1, goals: ['trabajo', 'cv'] },
  { topics: ['sql'], title: 'Lecciones interactivas de SQL', org: 'SQLBolt', url: 'https://sqlbolt.com/', kind: 'Curso', cert: 0, free: 1, effort: 0, min: 0, goals: ['examen', 'proyecto'] },
  { topics: ['redes'], title: 'Cursos de redes con insignia', org: 'Cisco Networking Academy', url: 'https://www.netacad.com/', kind: 'Certificado', cert: 1, free: 1, effort: 1, min: 0, goals: ['trabajo', 'cv', 'examen'] },
  { topics: ['redes'], title: 'Google IT Support', org: 'Coursera', url: 'https://www.coursera.org/professional-certificates/google-it-support', kind: 'Certificado', cert: 2, free: 0, effort: 2, min: 1, goals: ['trabajo', 'cv'] },
  { topics: ['mate'], title: 'Matemática', org: 'Khan Academy', url: 'https://es.khanacademy.org/math', kind: 'Curso', cert: 0, free: 1, effort: 1, min: 0, goals: ['examen'] },
  { topics: ['lengua', 'mate', 'ciencia', 'geografia', 'historia'], title: 'Recursos para el secundario', org: 'Educ.ar', url: 'https://www.educ.ar/', kind: 'Curso', cert: 0, free: 1, effort: 0, min: 0, goals: ['examen'] },
  { topics: ['ingles'], title: 'LearnEnglish', org: 'British Council', url: 'https://learnenglish.britishcouncil.org/', kind: 'Curso', cert: 0, free: 1, effort: 1, min: 0, goals: ['examen', 'cv'] },
  { topics: ['ingles'], title: 'Exámenes de inglés', org: 'Cambridge English', url: 'https://www.cambridgeenglish.org/', kind: 'Certificado', cert: 2, free: 0, effort: 2, min: 2, goals: ['trabajo', 'cv', 'examen'] },
  { topics: ['html', 'js', 'python', 'java', 'sql'], title: 'Subí tus proyectos a GitHub', org: 'GitHub', url: 'https://github.com/', kind: 'Proyecto', cert: 0, free: 1, effort: 0, min: 1, goals: ['cv', 'trabajo', 'proyecto'] }
];

// ---- Armado de evaluaciones desde el banco verificado ----
// Permite evaluar sin depender de la IA para los temas con preguntas verificadas.
const seedRand = n => () => {
  n |= 0; n = (n + 0x6D2B79F5) | 0;
  let t = Math.imul(n ^ (n >>> 15), 1 | n);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

export function bankQuiz(topicKey, count = 5, difficulty = 2, seed = 1) {
  const t = TOPICS[topicKey];
  if (!t) return null;
  const rnd = seedRand(seed);
  const harder = Math.max(1, difficulty);
  const pool = t.qs.filter(q => q.d <= harder + 1);
  const chosen = [...pool].sort(() => rnd() - 0.5).slice(0, count);
  return chosen.map((q, i) => ({
    id: `bank-${topicKey}-${i}`,
    q: q.q,
    options: q.o,
    correct: q.a,
    explanation: q.e,
    topic: t.name,
    sub: q.s,
    d: q.d,
  }));
}

export function quizScore(items) {
  const ok = items.filter(i => i.answer === i.correct).length;
  return { score: ok, total: items.length, pct: items.length ? Math.round((ok / items.length) * 100) : 0 };
}

export { RANKS, RANK_MIN, rankOf, GOALS, TOPICS, EFF_H, COURSES };