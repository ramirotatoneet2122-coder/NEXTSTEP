// Capa de persistencia de NEXTSTEP.
// Usa node:sqlite (incluido en Node.js desde 22.5) para no depender de módulos nativos.
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = process.env.DB_FILE || path.join(DATA_DIR, 'nextstep.db');

fs.mkdirSync(DATA_DIR, { recursive: true });

export const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

// ---- Helpers genéricos ----
export const q = (sql, ...params) => db.prepare(sql).get(...params);
export const qa = (sql, ...params) => db.prepare(sql).all(...params);
export const run = (sql, ...params) => db.prepare(sql).run(...params);

function tx(fn) {
  db.exec('BEGIN');
  try {
    const r = fn();
    db.exec('COMMIT');
    return r;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
}

const now = () => new Date().toISOString();

// Convierte fila con columnas JSON en objetos.
// En SQLite guardamos JSON como TEXT y lo parseamos al leer.
function vals(obj) {
  const out = {};
  for (const [k, v] of Object.entries(obj || {})) out[k] = v ?? null;
  return out;
}
export const rowToJson = row => {
  if (!row) return null;
  const out = { ...row };
  for (const k of Object.keys(out)) {
    if (typeof out[k] === 'string' && /^\[|^\{/.test(out[k].trimStart())) {
      try { out[k] = JSON.parse(out[k]); } catch { /* queda como texto */ }
    }
  }
  return out;
};

export { tx, now, vals };

// ---- Esquema ----
export function initDb() {
  db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    pass_hash TEXT NOT NULL,
    display_name TEXT NOT NULL DEFAULT '',
    language TEXT NOT NULL DEFAULT 'es',
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS auth_tokens (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
  );

  -- Preferencias de la persona: apariencia, aprendizaje y forma de enseñar del profesor.
  CREATE TABLE IF NOT EXISTS preferences (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    theme_json TEXT NOT NULL DEFAULT '{}',
    learning_json TEXT NOT NULL DEFAULT '{}',
    teacher_json TEXT NOT NULL DEFAULT '{}',
    ui_json TEXT NOT NULL DEFAULT '{}',
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    goal TEXT NOT NULL DEFAULT '',
    level TEXT NOT NULL DEFAULT 'Iniciante',
    level_score INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'active', -- active | paused | finished
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pendiente', -- dominado | aprendiendo | dificultad | pendiente
    level INTEGER NOT NULL DEFAULT 0,
    confidence INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    title TEXT NOT NULL DEFAULT 'Nueva conversación',
    mode TEXT NOT NULL DEFAULT 'normal',
    perfil_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role TEXT NOT NULL, -- user | assistant
    content TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS paths (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    summary TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pendiente', -- pendiente | en_curso | completado
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS modules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    path_id INTEGER NOT NULL REFERENCES paths(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    objective TEXT NOT NULL DEFAULT '',
    position INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'pendiente', -- pendiente | en_curso | completado
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS activities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    module_id INTEGER NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'practica', -- explicacion | recurso | practica | evaluacion
    status TEXT NOT NULL DEFAULT 'pendiente',
    score REAL,
    created_at TEXT NOT NULL,
    completed_at TEXT
  );

  CREATE TABLE IF NOT EXISTS assessments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    kind TEXT NOT NULL DEFAULT 'inicial', -- inicial | seguimiento | tema
    title TEXT NOT NULL,
    score REAL,
    total INTEGER NOT NULL DEFAULT 0,
    detail_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    finished_at TEXT
  );

  CREATE TABLE IF NOT EXISTS assessment_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    assessment_id INTEGER NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    prompt TEXT NOT NULL,
    options_json TEXT NOT NULL DEFAULT '[]',
    correct INTEGER NOT NULL DEFAULT -1,
    explanation TEXT NOT NULL DEFAULT '',
    topic TEXT NOT NULL DEFAULT '',
    difficulty INTEGER NOT NULL DEFAULT 1,
    answer INTEGER NOT NULL DEFAULT -1
  );

  CREATE TABLE IF NOT EXISTS goals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    deadline TEXT,
    status TEXT NOT NULL DEFAULT 'activo', -- activo | hecho | abandonado
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    goal_id INTEGER NOT NULL REFERENCES goals(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0,
    position INTEGER NOT NULL DEFAULT 0,
    due TEXT,
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS resources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    url TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL DEFAULT 'curso', -- curso | documentacion | tutorial | video | proyecto | otro
    notes TEXT NOT NULL DEFAULT '',
    verified INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS study_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    minutes INTEGER NOT NULL DEFAULT 0,
    kind TEXT NOT NULL DEFAULT 'estudio',
    started_at TEXT NOT NULL,
    ended_at TEXT
  );

  CREATE TABLE IF NOT EXISTS xp_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    amount INTEGER NOT NULL,
    reason TEXT NOT NULL,
    subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS achievements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code TEXT NOT NULL,
    title TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(user_id, code)
  );
  `);
}

// ---- Utilidades de dominio ----
export function getUser(id) {
  return rowToJson(q('SELECT * FROM users WHERE id = ?', id));
}

export function getUserByUsername(username) {
  return rowToJson(q('SELECT * FROM users WHERE username = ? COLLATE NOCASE', username));
}

export function createUser({ username, passHash, displayName, language = 'es' }) {
  const id = run('INSERT INTO users (username, pass_hash, display_name, language, created_at) VALUES (?,?,?,?,?)',
    username, passHash, displayName, language, now()).lastInsertRowid;
  // Preferencias predeterminadas razonables.
  run('INSERT INTO preferences (user_id, updated_at) VALUES (?,?)', id, now());
  return getUser(id);
}

// Preferencias del usuario (apariencia / aprendizaje / profesor / ui)
export function getPreferences(userId) {
  const p = rowToJson(q('SELECT theme_json, learning_json, teacher_json, ui_json FROM preferences WHERE user_id = ?', userId));
  const parse = (s, def) => { try { return JSON.parse(s || 'null') ?? def; } catch { return def; } };
  return {
    theme: parse(p?.theme_json, {}),
    learning: parse(p?.learning_json, {}),
    teacher: parse(p?.teacher_json, {}),
    ui: parse(p?.ui_json, {}),
  };
}

export function setPreference(userId, field, value) {
  const col = field + '_json';
  const cols = { theme_json: 1, learning_json: 1, teacher_json: 1, ui_json: 1 };
  if (!cols[col]) throw new Error('Campo de preferencia inválido');
  run(`UPDATE preferences SET ${col} = ?, updated_at = ? WHERE user_id = ?`, JSON.stringify(value), now(), userId);
  return getPreferences(userId);
}

// Experiencia total y nivel.
export function totalXp(userId) {
  return q('SELECT COALESCE(SUM(amount),0) AS xp FROM xp_events WHERE user_id = ?', userId).xp;
}

// (la racha real se calcula en src/xp.js -> computeStreak)