// Capa que separa a NEXTSTEP del proveedor de IA. Cambiando variables en .env se elige quién "piensa"
// por detrás; el profesor (prompt, datos y seguimiento) es siempre el del proyecto.
//
//   PROVIDER=anthropic    -> API de Claude (necesita ANTHROPIC_API_KEY)
//   PROVIDER=openai       -> cualquier servidor compatible con la API de OpenAI:
//                            Ollama (corre en tu compu), Groq, OpenRouter, etc.
//                            (necesita OPENAI_BASE_URL, MODEL y, según el servicio, OPENAI_API_KEY)
import Anthropic from '@anthropic-ai/sdk';

const PROVIDER = (process.env.PROVIDER || 'anthropic').toLowerCase();
export const MODEL = process.env.MODEL || (PROVIDER === 'anthropic' ? 'claude-sonnet-5-5' : '');
const MAX_TOKENS = Number(process.env.MAX_TOKENS) || 2000;
const AI_TIMEOUT_MS = Number(process.env.AI_TIMEOUT_MS) || 90_000;

export function providerInfo() {
  const ready = PROVIDER === 'anthropic'
    ? Boolean(process.env.ANTHROPIC_API_KEY)
    : Boolean(process.env.OPENAI_BASE_URL && MODEL);
  const base = PROVIDER === 'anthropic' ? 'https://api.anthropic.com' : (process.env.OPENAI_BASE_URL || '');
  return { provider: PROVIDER, model: MODEL || null, ready, base };
}

export function missingConfigMessage() {
  return PROVIDER === 'anthropic'
    ? 'Falta la ANTHROPIC_API_KEY en el archivo .env del servidor.'
    : 'Falta OPENAI_BASE_URL o MODEL en el archivo .env del servidor.';
}

export function aiConfigured() { return providerInfo().ready; }

let anthropic = null;
function getAnthropic() { anthropic ??= new Anthropic(); return anthropic; }

function withSignal(signal, abortTimeout) {
  if (signal) return signal;
  const ctl = new AbortController();
  abortTimeout.t = setTimeout(() => ctl.abort(), AI_TIMEOUT_MS);
  abortTimeout.clear = () => clearTimeout(abortTimeout.t);
  return ctl.signal;
}

// ---- Streaming (para el chat) ----
async function viaAnthropicStream({ system, messages, signal, onText }) {
  const client = getAnthropic();
  const stream = client.messages.stream({ model: MODEL, max_tokens: MAX_TOKENS, system, messages }, { signal });
  stream.on('text', onText);
  await stream.finalMessage();
}

async function viaOpenAIStream({ system, messages, signal, onText }) {
  const base = process.env.OPENAI_BASE_URL.replace(/\/$/, '');
  const headers = { 'Content-Type': 'application/json' };
  if (process.env.OPENAI_API_KEY) headers.Authorization = `Bearer ${process.env.OPENAI_API_KEY}`;
  const r = await fetch(`${base}/chat/completions`, {
    method: 'POST',
    headers,
    signal,
    body: JSON.stringify({
      model: MODEL,
      stream: true,
      max_tokens: MAX_TOKENS,
      messages: [{ role: 'system', content: system }, ...messages],
    }),
  });
  if (!r.ok) {
    const err = new Error(`El servidor de IA respondió ${r.status}`);
    err.status = r.status;
    throw err;
  }
  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) return;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line.startsWith('data:')) continue;
      const data = line.slice(5).trim();
      if (data === '[DONE]') return;
      try {
        const t = JSON.parse(data).choices?.[0]?.delta?.content;
        if (t) onText(t);
      } catch { /* línea sin texto: se ignora */ }
    }
  }
}

export function streamChat(opts) {
  return PROVIDER === 'anthropic' ? viaAnthropicStream(opts) : viaOpenAIStream(opts);
}

// ---- Completar texto completo (sin streaming) ----
async function completeAnthropic({ system, messages, signal }) {
  const client = getAnthropic();
  const r = await client.messages.create({ model: MODEL, max_tokens: MAX_TOKENS, system, messages }, { signal });
  return r.content.filter(b => b.type === 'text').map(b => b.text).join('');
}

async function completeOpenAI({ system, messages, signal }) {
  const base = process.env.OPENAI_BASE_URL.replace(/\/$/, '');
  const headers = { 'Content-Type': 'application/json' };
  if (process.env.OPENAI_API_KEY) headers.Authorization = `Bearer ${process.env.OPENAI_API_KEY}`;
  const r = await fetch(`${base}/chat/completions`, {
    method: 'POST',
    headers,
    signal,
    body: JSON.stringify({
      model: MODEL,
      stream: false,
      max_tokens: MAX_TOKENS,
      messages: [{ role: 'system', content: system }, ...messages],
    }),
  });
  if (!r.ok) {
    const err = new Error(`El servidor de IA respondió ${r.status}`);
    err.status = r.status;
    throw err;
  }
  const j = await r.json();
  return j.choices?.[0]?.message?.content ?? '';
}

// Devuelve texto completo.
export async function complete({ system, messages, signal }) {
  if (!aiConfigured()) {
    const err = new Error('AI_NOT_CONFIGURED');
    throw err;
  }
  return PROVIDER === 'anthropic' ? completeAnthropic({ system, messages, signal }) : completeOpenAI({ system, messages, signal });
}

// Pide a la IA un JSON válido y lo devuelve ya parseado (con reintento una vez).
export async function completeJSON({ system, messages, signal }) {
  const txt = await complete({ system, messages, signal });
  return extractJSON(txt);
}

export function extractJSON(txt) {
  const s = String(txt ?? '');
  const t = s.trim().replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '');
  try { return JSON.parse(t); } catch { /* sigue */ }
  const start = t.indexOf('{');
  const arr = t.indexOf('[');
  let from = -1;
  if (start === -1 && arr === -1) return null;
  if (start === -1) from = arr;
  else if (arr === -1) from = start;
  else from = Math.min(start, arr);
  const open = t[from], close = open === '{' ? '}' : ']';
  let depth = 0, inStr = false, esc = false;
  for (let i = from; i < t.length; i++) {
    const c = t[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') inStr = true;
    else if (c === open) depth++;
    else if (c === close) {
      depth--;
      if (depth === 0) {
        try { return JSON.parse(t.slice(from, i + 1)); } catch { return null; }
      }
    }
  }
  return null;
}