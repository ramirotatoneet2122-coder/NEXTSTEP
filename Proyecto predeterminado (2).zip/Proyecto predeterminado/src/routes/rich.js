// Rutas de aprendizaje, módulos, actividades y evaluaciones.
import { Router } from 'express';
import { run, q, qa, rowToJson, now, tx } from '../db.js';
import { requireAuth } from '../auth.js';
import { grantXp } from '../xp.js';
import { getSubject, loadSubjectSummary, matchBankKey } from '../domain.js';
import { bankQuiz } from '../data.js';
import { aiConfigured, completeJSON } from '../llm.js';
import { buildJSONSystem } from '../prompt.js';

export const richRouter = Router();
richRouter.use(requireAuth);

const KIND_ACTIVITY = ['explicacion', 'recurso', 'practica', 'evaluacion'];
const ACT_STATUS = ['pendiente', 'completada'];

// ---------- Rutas ----------
function pathSummary(row) {
  const modules = qa('SELECT * FROM modules WHERE path_id = ? ORDER BY position', row.id);
  const done = modules.filter(m => m.status === 'completado').length;
  const inCourse = modules.find(m => m.status === 'en_curso') || modules[0];
  return {
    id: row.id,
    title: row.title,
    summary: row.summary,
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    subjectId: row.subject_id,
    modules: modules.length,
    modulesDone: done,
    progress: modules.length ? Math.round(done / modules.length * 100) : 0,
    nextModule: inCourse ? { id: inCourse.id, title: inCourse.title, status: inCourse.status } : null,
  };
}

richRouter.get('/paths', (req, res) => {
  const rows = qa('SELECT * FROM paths WHERE user_id = ? ORDER BY created_at DESC', req.userId);
  res.json({ paths: rows.map(pathSummary) });
});

richRouter.post('/paths', (req, res) => {
  const subject = req.body?.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
  const title = String(req.body?.title || '').trim().slice(0, 100);
  if (!title) return res.status(400).json({ error: 'Ingresá un título para la ruta.' });
  const summary = String(req.body?.summary || '').trim().slice(0, 300);
  const id = run('INSERT INTO paths (user_id, subject_id, title, summary, created_at, updated_at) VALUES (?,?,?,?,?,?)',
    req.userId, subject ? subject.id : null, title, summary, now(), now()).lastInsertRowid;

  const modules = Array.isArray(req.body?.modules) ? req.body.modules.slice(0, 12) : [];
  modules.forEach((m, i) => {
    const mTitle = String(m.title || '').trim().slice(0, 90);
    if (!mTitle) return;
    const objectivo = String(m.objective || '').trim().slice(0, 280);
    const mid = run('INSERT INTO modules (path_id, user_id, title, objective, position, created_at) VALUES (?,?,?,?,?,?)',
      id, req.userId, mTitle, objectivo, i, now()).lastInsertRowid;
    const acts = Array.isArray(m.activities) ? m.activities.slice(0, 5) : [{ title: 'Explicación inicial', kind: 'explicacion' }, { title: 'Práctica y ejercicios', kind: 'practica' }];
    acts.forEach(a => {
      const aTitle = String(a.title || '').trim().slice(0, 90) || 'Actividad';
      const kind = KIND_ACTIVITY.includes(a.kind) ? a.kind : 'practica';
      run('INSERT INTO activities (module_id, user_id, title, kind, created_at) VALUES (?,?,?,?,?)',
        mid, req.userId, aTitle, kind, now());
    });
  });
  grantXp(req.userId, 20, 'Creaste una ruta de aprendizaje');
  res.status(201).json({ path: pathSummary(q('SELECT * FROM paths WHERE id = ?', id)) });
});

// Genera una ruta de aprendizaje personalizada con IA.
richRouter.post('/paths/generate', async (req, res) => {
  const subject = req.body?.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
  if (!subject) return res.status(400).json({ error: 'Elegí la materia para la ruta.' });
  const timePerWeek = Math.max(1, Math.min(40, Number(req.body?.hoursPerWeek) || 5));
  const targetLevel = ['Iniciante', 'Básico', 'Intermedio', 'Avanzado', 'Experto'].includes(req.body?.target)
    ? req.body.target : 'Intermedio';

  if (!aiConfigured()) {
    return res.status(503).json({ error: 'Para generar rutas con IA, configurá el proveedor de IA en el servidor (ver README). Mientras tanto podés crear la ruta a mano.' });
  }

  const task = `Generá una ruta personalizada de aprendizaje para un alumno que quiere aprender "${subject.name}".
Nivel actual: ${subject.level}. Objetivo: ${subject.goal || 'no especificado'}. Nivel objetivo: ${targetLevel}.
Tiempo disponible: ${timePerWeek} horas por semana. Devolvé EXCLUSIVAMENTE un JSON con esta forma:
{"title": "título corto", "summary": "resumen de 1 frase", "modules": [{"title": "nombre del módulo", "objective": "objetivo de aprendizaje del módulo"}]}
Entre 4 y 7 módulos, ordenados del fundamento al avance. Sin inventar links, cursos ni marcas.`;
  try {
    const out = await completeJSON({ system: buildJSONSystem(task), messages: [{ role: 'user', content: 'Generá la ruta.' }] });
    const modules = Array.isArray(out?.modules) ? out.modules.slice(0, 8) : [];
    if (!modules.length) return res.status(502).json({ error: 'La IA no devolvió una ruta válida. Probá de nuevo.' });
    const title = String(out.title || `Ruta de ${subject.name}`).slice(0, 100);
    const summary = String(out.summary || '').slice(0, 300);
    const id = run('INSERT INTO paths (user_id, subject_id, title, summary, created_at, updated_at) VALUES (?,?,?,?,?,?)',
      req.userId, subject.id, title, summary, now(), now()).lastInsertRowid;
    modules.forEach((m, i) => {
      const mTitle = String(m.title || `Módulo ${i + 1}`).trim().slice(0, 90);
      const objectivo = String(m.objective || '').trim().slice(0, 280);
      const mid = run('INSERT INTO modules (path_id, user_id, title, objective, position, created_at) VALUES (?,?,?,?,?,?)',
        id, req.userId, mTitle, objectivo, i, now()).lastInsertRowid;
      const defaultActs = [
        { title: `Explicación: ${mTitle}`, kind: 'explicacion' },
        { title: `Práctica: ${mTitle}`, kind: 'practica' },
        { title: `Evaluación del módulo`, kind: 'evaluacion' },
      ];
      defaultActs.forEach(a => run('INSERT INTO activities (module_id, user_id, title, kind, created_at) VALUES (?,?,?,?,?)',
        mid, req.userId, a.title, a.kind, now()));
    });
    grantXp(req.userId, 20, 'Generaste una ruta con IA');
    res.status(201).json({ path: pathSummary(q('SELECT * FROM paths WHERE id = ?', id)) });
  } catch (e) {
    console.error('[gen path]', e?.message ?? e);
    res.status(502).json({ error: 'No se pudo generar la ruta. Probá de nuevo en un momento.' });
  }
});

richRouter.get('/paths/:id', (req, res) => {
  const p = q('SELECT * FROM paths WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!p) return res.status(404).json({ error: 'No existe esa ruta.' });
  const modules = qa('SELECT * FROM modules WHERE path_id = ? ORDER BY position', p.id).map(rowToJson).map(m => ({
    ...m,
    activities: qa('SELECT * FROM activities WHERE module_id = ? ORDER BY id', m.id).map(rowToJson),
  }));
  const subject = p.subject_id ? loadSubjectSummary(getSubject(req.userId, p.subject_id)) : null;
  res.json({ path: pathSummary(p), modules, subject });
});

richRouter.put('/paths/:id', (req, res) => {
  const p = q('SELECT * FROM paths WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!p) return res.status(404).json({ error: 'No existe esa ruta.' });
  const status = ['pendiente', 'en_curso', 'completado'].includes(req.body?.status) ? req.body.status : p.status;
  const title = req.body?.title !== undefined ? String(req.body.title).trim().slice(0, 100) : p.title;
  run('UPDATE paths SET status = ?, title = ?, updated_at = ? WHERE id = ?', status, title, now(), p.id);
  res.json({ path: pathSummary(q('SELECT * FROM paths WHERE id = ?', p.id)) });
});

richRouter.delete('/paths/:id', (req, res) => {
  const p = q('SELECT * FROM paths WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!p) return res.status(404).json({ error: 'No existe esa ruta.' });
  run('DELETE FROM paths WHERE id = ?', p.id);
  res.json({ ok: true });
});

// ---------- Módulos ----------
richRouter.put('/modules/:id', (req, res) => {
  const m = q('SELECT * FROM modules WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!m) return res.status(404).json({ error: 'No existe ese módulo.' });
  const status = ['pendiente', 'en_curso', 'completado'].includes(req.body?.status) ? req.body.status : m.status;
  run('UPDATE modules SET status = ?, created_at = created_at WHERE id = ?', status, m.id);
  const prev = m.status;
  let gained = 0;
  if (status === 'completado' && prev !== 'completado') gained = grantXp(req.userId, 25, 'Completaste un módulo').gained;
  // Si todos los módulos están completados, la ruta pasa a completado.
  const p = q('SELECT * FROM paths WHERE id = ?', m.path_id);
  const others = qa('SELECT status FROM modules WHERE path_id = ?', m.path_id);
  if (others.length && others.every(o => o.status === 'completado')) {
    run('UPDATE paths SET status = ?, updated_at = ? WHERE id = ?', 'completado', now(), m.path_id);
  }
  res.json({ ok: true, gained });
});

// ---------- Actividades ----------
richRouter.post('/modules/:id/activities', (req, res) => {
  const m = q('SELECT * FROM modules WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!m) return res.status(404).json({ error: 'No existe ese módulo.' });
  const title = String(req.body?.title || '').trim().slice(0, 90);
  if (!title) return res.status(400).json({ error: 'Ingresá un título para la actividad.' });
  const kind = KIND_ACTIVITY.includes(req.body?.kind) ? req.body.kind : 'practica';
  const id = run('INSERT INTO activities (module_id, user_id, title, kind, created_at) VALUES (?,?,?,?,?)',
    m.id, req.userId, title, kind, now()).lastInsertRowid;
  res.status(201).json({ activity: rowToJson(q('SELECT * FROM activities WHERE id = ?', id)) });
});

richRouter.put('/activities/:id', (req, res) => {
  const a = q('SELECT * FROM activities WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!a) return res.status(404).json({ error: 'No existe esa actividad.' });
  const status = ACT_STATUS.includes(req.body?.status) ? req.body.status : a.status;
  const score = req.body?.score !== undefined && !isNaN(Number(req.body.score))
    ? Math.max(0, Math.min(100, Math.round(Number(req.body.score)))) : a.score;
  run('UPDATE activities SET status = ?, score = ?, completed_at = ? WHERE id = ?',
    status, score, status === 'completada' ? now() : a.completed_at, a.id);
  let gained = 0;
  if (status === 'completada' && a.status !== 'completada') {
    gained = grantXp(req.userId, 40, 'Completaste una actividad').gained;
  }
  res.json({ ok: true, gained });
});

richRouter.delete('/activities/:id', (req, res) => {
  const a = q('SELECT * FROM activities WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!a) return res.status(404).json({ error: 'No existe esa actividad.' });
  run('DELETE FROM activities WHERE id = ?', a.id);
  res.json({ ok: true });
});

// ---------- Evaluaciones ----------
function sanitizeItem(i) {
  let options = [];
  try { options = JSON.parse(i.options_json || '[]'); } catch { options = []; }
  return { id: i.id, prompt: i.prompt, options, explanation: i.explanation, topic: i.topic, difficulty: i.difficulty };
}

// La búsqueda de la materia del banco verificado vive en domain.js (matchBankKey).

function storeItems(assessmentId, userId, subjectId, items) {
  items.forEach(it => {
    run('INSERT INTO assessment_items (assessment_id, user_id, subject_id, prompt, options_json, correct, explanation, topic, difficulty, answer) VALUES (?,?,?,?,?,?,?,?,?,?)',
      assessmentId, userId, subjectId,
      String(it.q || it.prompt || '').slice(0, 500),
      JSON.stringify(Array.isArray(it.options) ? it.options.map(o => String(o).slice(0, 200)) : []),
      Number(it.correct) || 0,
      String(it.explanation || '').slice(0, 400),
      String(it.topic || '').slice(0, 80),
      Number(it.d || it.difficulty || 1),
      -1);
  });
}

richRouter.post('/assessments/generate', async (req, res) => {
  const subject = req.body?.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
  const kind = ['inicial', 'seguimiento', 'tema'].includes(req.body?.kind) ? req.body.kind : 'inicial';
  const count = Math.max(3, Math.min(10, Number(req.body?.count) || 5));
  if (!subject) return res.status(400).json({ error: 'Elegí la materia a evaluar.' });

  const key = matchBankKey(subject.name);
  let items = null;
  let title = `Evaluación ${kind === 'inicial' ? 'inicial' : kind === 'tema' ? 'de tema' : 'de seguimiento'} de ${subject.name}`;
  let used = 'banco';

  if (key) {
    items = bankQuiz(key, count, 2, subject.id);
  } else if (aiConfigured()) {
    used = 'ia';
    try {
      const task = `Generá una evaluación de nivel ${kind} para la materia "${subject.name}". Objetivo: ${subject.goal || 'no especificado'}. Devolvé un JSON con la forma:
{"title": "título corto", "items": [{"q": "pregunta", "options": ["opA","opB","opC","opD"], "correct": 0, "explanation": "explicación breve de la respuesta correcta", "topic": "tema corto", "d": 1}]}
Requisitos: entre ${count} y ${Math.min(count, 8)} preguntas; una única respuesta correcta indudable; dificultades mezcladas; en español.`;
      const out = await completeJSON({ system: buildJSONSystem(task), messages: [{ role: 'user', content: 'Generá la evaluación ahora.' }] });
      if (out && Array.isArray(out.items) && out.items.length) {
        title = String(out.title || title).slice(0, 100);
        items = out.items.slice(0, 10);
      }
    } catch (e) {
      used = 'ia-error';
    }
  }

  if (!items && !aiConfigured()) {
    return res.status(503).json({ error: 'Para evaluar esta materia la IA tiene que estar configurada en el servidor. Para las materias del banco verificado (HTML, JavaScript, Python, Java, SQL, Redes, Matemática, Geografía, Historia, Ciencias, Lengua e Inglés) se evalúa automáticamente sin clave.' });
  }
  if (!items) {
    return res.status(502).json({ error: 'No se pudo generar la evaluación ahora. Probá de nuevo en un momento.' });
  }

  const id = run('INSERT INTO assessments (user_id, subject_id, kind, title, score, total, created_at) VALUES (?,?,?,?,NULL,?,?)',
    req.userId, subject.id, kind, title, items.length, now()).lastInsertRowid;
  storeItems(id, req.userId, subject.id, items);

  const stored = qa('SELECT * FROM assessment_items WHERE assessment_id = ? ORDER BY id', id);
  const detail = stored.map(sanitizeItem);
  run('UPDATE assessments SET detail_json = ? WHERE id = ?', JSON.stringify(detail), id);
  res.status(201).json({ assessment: rowToJson(q('SELECT * FROM assessments WHERE id = ?', id)), items: detail });
});

richRouter.get('/assessments', (req, res) => {
  const rows = qa('SELECT a.*, s.name AS subject_name FROM assessments a LEFT JOIN subjects s ON s.id = a.subject_id WHERE a.user_id = ? ORDER BY a.created_at DESC', req.userId);
  res.json({ assessments: rows.map(rowToJson) });
});

richRouter.get('/assessments/:id', (req, res) => {
  const a = q('SELECT * FROM assessments WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!a) return res.status(404).json({ error: 'No existe esa evaluación.' });
  const items = qa('SELECT * FROM assessment_items WHERE assessment_id = ? ORDER BY id', a.id);
  const answered = items.every(i => i.answer >= 0);
  const subject = a.subject_id ? loadSubjectSummary(getSubject(req.userId, a.subject_id)) : null;
  res.json({
    assessment: rowToJson(a),
    items: items.map(i => answered ? { ...sanitizeItem(i), correct: i.correct, answer: i.answer } : sanitizeItem(i)),
    subject,
    answered,
  });
});

richRouter.post('/assessments/:id/submit', (req, res) => {
  const a = q('SELECT * FROM assessments WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!a) return res.status(404).json({ error: 'No existe esa evaluación.' });
  if (a.finished_at) return res.status(400).json({ error: 'Esta evaluación ya fue respondida.' });
  const answers = req.body?.answers;
  if (!Array.isArray(answers)) return res.status(400).json({ error: 'Faltan las respuestas.' });

  const items = qa('SELECT * FROM assessment_items WHERE assessment_id = ? ORDER BY id', a.id);
  const results = items.map((it, idx) => {
    const ans = answers[idx];
    const valid = Number.isInteger(ans) && ans >= 0 && ans < JSON.parse(it.options_json || '[]').length ? ans : -1;
    run('UPDATE assessment_items SET answer = ? WHERE id = ?', valid, it.id);
    return { id: it.id, prompt: it.prompt, options: JSON.parse(it.options_json || '[]'), correct: it.correct, answer: valid, explanation: it.explanation, topic: it.topic, ok: valid === it.correct };
  });
  const okCount = results.filter(r => r.ok).length;
  const total = items.length || 1;
  const pct = Math.round(okCount / total * 100);
  run('UPDATE assessments SET score = ?, total = ?, finished_at = ? WHERE id = ?', okCount, total, now(), a.id);

  // Adaptación pedagógica: ajustar temas según resultados.
  if (a.subject_id) {
    const cache = {};
    results.forEach(r => {
      const label = r.topic.toLowerCase().trim();
      let t = cache[label];
      if (!t) {
        t = q('SELECT * FROM topics WHERE subject_id = ? AND lower(name) = lower(?)', a.subject_id, label.trim());
        if (!t) t = q('SELECT * FROM topics WHERE subject_id = ? AND instr(lower(name), lower(?)) > 0', a.subject_id, label.slice(0, 8));
        cache[label] = t;
      }
      if (!t) return;
      if (r.ok) {
        const conf = Math.min(3, (t.confidence || 0) + 1);
        const status = conf >= 2 ? 'dominado' : 'aprendiendo';
        run('UPDATE topics SET confidence = ?, status = ?, updated_at = ? WHERE id = ?', conf, status, now(), t.id);
      } else {
        run('UPDATE topics SET status = ?, updated_at = ? WHERE id = ?', t.status === 'dominado' ? 'aprendiendo' : 'dificultad', now(), t.id);
      }
    });
  }

  const xp = grantXp(req.userId, Math.round(okCount / total * 50), 'Completaste una evaluación', a.subject_id || null);
  res.json({ ok: true, score: okCount, total, pct, results, gained: xp.gained, unlocked: xp.unlocked });
});