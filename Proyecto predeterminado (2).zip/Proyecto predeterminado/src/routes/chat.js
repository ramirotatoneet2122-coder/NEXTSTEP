// Chat con el profesor IA (SSE). Guarda los mensajes en la base de datos y arma el contexto
// con preferencias, modo de actividad, materia y datos adaptativos del alumno.
import { Router } from 'express';
import { run, q, qa, now } from '../db.js';
import { requireAuth } from '../auth.js';
import { buildSystem } from '../prompt.js';
import { streamChat, providerInfo, missingConfigMessage } from '../llm.js';
import { MODES, adaptiveContext, getSubject } from '../domain.js';
import { getPreferences } from '../db.js';

export const chatRouter = Router();

const MAX_MESSAGES = 40;

// Limpia los mensajes que vienen de la base (que ya son de confianza del backend, pero igual se sanitizan).
export function cleanMessages(raw) {
  const m = raw
    .filter(x => x && (x.role === 'user' || x.role === 'assistant') && typeof x.content === 'string' && x.content.trim())
    .map(x => ({ role: x.role, content: x.content.slice(0, 6000) }))
    .slice(-MAX_MESSAGES);
  while (m.length && m[0].role !== 'user') m.shift();
  const out = [];
  for (const x of m) {
    const last = out[out.length - 1];
    if (last && last.role === x.role) last.content += '\n\n' + x.content;
    else out.push({ ...x });
  }
  if (!out.length || out[out.length - 1].role !== 'user') return null;
  return out;
}

function stripTags(t) {
  let s = t.replace(/<opciones>[\s\S]*?<\/opciones>/g, '').replace(/<perfil>[\s\S]*?<\/perfil>/g, '');
  const i = s.search(/<(opciones|perfil)/);
  if (i >= 0) s = s.slice(0, i);
  const m = s.match(/<[a-z]{0,8}$/);
  if (m && ('<opciones'.startsWith(m[0]) || '<perfil'.startsWith(m[0]))) s = s.slice(0, m.index);
  return s;
}

function readOptions(t) {
  const op = t.match(/<opciones>([\s\S]*?)<\/opciones>/);
  return op ? op[1].split('|').map(s => s.trim()).filter(Boolean).slice(0, 4).map(s => s.slice(0, 40)) : [];
}

function readPerfil(t) {
  const pf = t.match(/<perfil>([\s\S]*?)<\/perfil>/);
  if (!pf) return null;
  try {
    const o = JSON.parse(pf[1]);
    return o && typeof o === 'object' ? o : null;
  } catch {
    return null;
  }
}

// Une el perfil guardado con la actualización que manda la IA (solo cambia lo que viene nuevo).
export function mergePerfil(base, update) {
  if (!update || typeof update !== 'object') return { ...(base || {}) };
  return { ...(base || {}), ...update };
}

function friendlyError(e) {
  if (e?.message === 'AI_NOT_CONFIGURED') return missingConfigMessage();
  const s = e?.status;
  if (s === 401 || s === 403) return 'La clave del servicio de IA no es válida.';
  if (s === 429) return 'La IA tiene muchas consultas ahora. Probá de nuevo en un rato.';
  if (s === 529 || s === 503) return 'La IA está saturada. Probá de nuevo en un momento.';
  return 'No se pudo usar la IA ahora.';
}

chatRouter.post('/chat', requireAuth, async (req, res) => {
  if (!providerInfo().ready) return res.status(503).json({ error: missingConfigMessage() });

  const uid = req.userId;
  const conversationId = Number(req.body?.conversationId);
  const content = String(req.body?.content || '').trim().slice(0, 6000);
  if (!Number.isInteger(conversationId)) return res.status(400).json({ error: 'Falta la conversación.' });
  if (!content) return res.status(400).json({ error: 'Escribí un mensaje para el profesor.' });

  const conv = q('SELECT * FROM conversations WHERE id = ? AND user_id = ?', conversationId, uid);
  if (!conv) return res.status(404).json({ error: 'No existe esa conversación.' });

  // Guardar el mensaje del alumno.
  const userMsgId = run('INSERT INTO messages (conversation_id, role, content, created_at) VALUES (?,?,?,?)',
    conversationId, 'user', content, now()).lastInsertRowid;

  // Si es el primer mensaje, el título sale del propio mensaje.
  const totalU = q('SELECT COUNT(*) AS c FROM messages WHERE conversation_id = ? AND role = ?', conversationId, 'user').c;
  if (totalU === 1 && conv.title === 'Nueva conversación') {
    run('UPDATE conversations SET title = ? WHERE id = ?', content.slice(0, 42) + (content.length > 42 ? '…' : ''), conversationId);
  }

  // Contexto: preferencias, modo, materia, datos adaptativos y perfil de la conversación.
  let perfil = {};
  try { perfil = JSON.parse(conv.perfil_json || '{}') || {}; } catch { perfil = {}; }
  const prefs = getPreferences(uid);
  const subject = conv.subject_id ? getSubject(uid, conv.subject_id) : null;
  const adaptive = adaptiveContext(uid, conv.subject_id || null);
  const mode = MODES.includes(conv.mode) ? conv.mode : 'normal';

  const system = buildSystem({
    perfil,
    prefs: { learning: prefs.learning, teacher: prefs.teacher },
    mode,
    adaptive,
    subjectName: subject ? `${subject.name}${subject.goal ? ' — objetivo: ' + subject.goal : ''}` : '',
  });

  const raw = qa('SELECT role, content FROM messages WHERE conversation_id = ? ORDER BY id', conversationId);
  const messages = cleanMessages(raw.map(r => ({ role: r.role, content: r.content })));
  if (!messages) return res.status(400).json({ error: 'No pudimos armar la conversación.' });

  res.set({
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
  });
  res.flushHeaders();
  const send = o => res.write(`data: ${JSON.stringify(o)}\n\n`);

  const abort = new AbortController();
  let finished = false;
  res.on('close', () => { if (!finished) abort.abort(); });

  try {
    let text = '';
    await streamChat({
      system,
      messages,
      signal: abort.signal,
      onText: t => {
        text += t;
        send({ t });
      },
    });
    const clean = stripTags(text).trim();
    if (!clean.length) throw new Error('La IA no devolvió nada.');

    run('INSERT INTO messages (conversation_id, role, content, created_at) VALUES (?,?,?,?)',
      conversationId, 'assistant', clean.slice(0, 12000), now());
    run('UPDATE conversations SET updated_at = ? WHERE id = ?', now(), conversationId);

    // <opciones> y <perfil> se guardan en la conversación para que la pantalla los muestre/oculte.
    const quick = readOptions(text);
    const pf = readPerfil(text);
    let merged = perfil;
    if (pf) {
      merged = mergePerfil(perfil, pf);
      run('UPDATE conversations SET perfil_json = ? WHERE id = ?', JSON.stringify(merged), conversationId);
    }
    send({ done: true, quick, perfil: merged });
  } catch (e) {
    const cancelled = e?.name === 'AbortError' || e?.name === 'APIUserAbortError';
    if (!cancelled) {
      console.error('[chat]', e?.status ?? '', e?.message ?? e);
      if (!res.writableEnded && !res.destroyed) send({ error: friendlyError(e) });
    }
  } finally {
    finished = true;
    res.end();
  }
});