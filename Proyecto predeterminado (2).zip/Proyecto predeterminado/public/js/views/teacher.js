/* NEXTSTEP — Mi profesor IA: chat con streaming (SSE), modos por actividad y
   lista de conversaciones. Las respuestas de la IA son reales (nunca simuladas):
   si no hay clave configurada se muestra el aviso y el chat queda deshabilitado. */
import { api, streamChat, ApiError } from '../api.js';
import * as store from '../store.js';
import { el, svgIc, esc, chatHTML, fmtRel, toast } from '../ui.js';
import { getMeta, setupNotice } from '../app.js';

const MODE_LABELS = {
  normal: 'Conversación', concentracion: 'Concentración', lectura: 'Lectura',
  practica: 'Práctica', evaluacion: 'Evaluación', planificacion: 'Planificación', repaso: 'Repaso',
};
const KIND_ICON = { normal: 'chat', concentracion: 'star', lectura: 'book', practica: 'pencil', evaluacion: 'quiz', planificacion: 'calendar', repaso: 'clock' };

export function teacherView(params) {
  const meta = getMeta();
  const setup = meta && meta.requiresSetup;
  const root = el('div');
  if (setup) root.append(setupNotice());

  const wrap = el('div', { class: 'chat-wrap' + (setup ? ' with-notice' : '') });

  /* ---- Panel lateral ---- */
  const side = el('div', { class: 'chat-side' });
  const subjectSel = el('select', { class: 'input' }, el('option', { value: '' }, 'Sin materia'));
  const modeSel = el('select', { class: 'input' });
  for (const m of (meta.modes || ['normal', 'concentracion', 'lectura', 'practica', 'evaluacion', 'planificacion', 'repaso'])) {
    modeSel.append(el('option', { value: m }, MODE_LABELS[m] || m));
  }
  const newBtn = el('button', {
    class: 'btn block', disabled: !!setup,
    onclick: () => createConversation(),
  }, svgIc('plus', 18), 'Nueva charla');

  const convList = el('div', { class: 'conv-list' });

  api('/subjects').then(r => {
    for (const su of r.subjects) subjectSel.append(el('option', { value: su.id }, su.name));
  }).catch(() => {});

  /* ---- Panel principal ---- */
  const main = el('div', { class: 'chat-main' });
  const head = el('div', { class: 'chat-head' });
  const headTitle = el('div', { class: 't' }, 'Nueva conversación');
  const headMode = el('select', { class: 'input', style: 'max-width:170px' });
  const headSubject = el('select', { class: 'input', style: 'max-width:180px' }, el('option', { value: '' }, 'Sin materia'));
  headMode.append(el('option', { value: 'normal' }, 'Conversación'));
  head.append(headTitle, headSubject, headMode);

  const body = el('div', { class: 'chat-body' });
  const quickBar = el('div', { class: 'chat-quick' });
  const inBar = el('div', { class: 'chat-in' });
  const input = el('textarea', {
    rows: 1, placeholder: setup ? 'La IA no está configurada aún' : 'Escribile a tu profesor… (Enter para enviar)',
    disabled: setup,
    onkeydown: e => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
      if (e.key === 'Enter') input.style.height = 'auto';
    },
    oninput: autoGrow,
  });
  const sendBtn = el('button', { class: 'btn', disabled: setup, 'aria-label': 'Enviar', html: svgIc('send', 18) });
  sendBtn.addEventListener('click', send);
  const stopBtn = el('button', { class: 'btn danger hidden', html: svgIc('stop', 18) });
  inBar.append(input, sendBtn, stopBtn);
  main.append(head, body, quickBar, inBar);

  // Mensaje que llega desde el riel derecho ("Profesor IA"): queda escrito para que el alumno lo envíe.
  const pending = sessionStorage.getItem('ns_pending_msg');
  if (pending) {
    sessionStorage.removeItem('ns_pending_msg');
    input.value = pending;
    autoGrow();
    input.focus();
  }
  wrap.append(side, main);
  root.append(wrap);

  /* ---- Estado ---- */
  let current = null;            // conversación abierta
  let aborter = null;

  side.append(el('div', { class: 'flex', style: 'padding:0 2px' },
    el('div', { class: 'field grow' }, el('label', { text: 'Materia' }), subjectSel),
    el('div', { class: 'field grow' }, el('label', { text: 'Modo' }), modeSel)),
    newBtn,
    el('div', { class: 'muted small', style: 'padding:0 4px' }, 'Tus charlas'),
    convList);

  /* ---- Acciones ---- */
  function autoGrow() { input.style.height = 'auto'; input.style.height = Math.min(130, input.scrollHeight) + 'px'; }

  async function createConversation() {
    try {
      const r = await api('/conversations', {
        method: 'POST',
        body: { subject_id: subjectSel.value ? Number(subjectSel.value) : null, mode: modeSel.value, title: 'Nueva conversación' },
      });
      localStorage.setItem('ns_teacher_conv', String(r.conversation.id));
      openConversation(r.conversation.id, true);
    } catch (e) { toast((e && e.message) || 'No se pudo crear la charla.', 'err'); }
  }

  async function openConversation(id, isNew = false) {
    try {
      const d = await api(`/conversations/${id}`);
      current = d.conversation;
      localStorage.setItem('ns_teacher_conv', String(id));
      headTitle.textContent = d.conversation.title === 'Nueva conversación' ? 'Nueva conversación' : d.conversation.title;
      headTitle.title = d.conversation.title;

      // Selector de modo del encabezado (guarda el cambio en el servidor).
      headMode.innerHTML = '';
      for (const m of (meta.modes || Object.keys(MODE_LABELS))) {
        headMode.append(el('option', { value: m, ...(m === d.conversation.mode ? { selected: '' } : {}) }, MODE_LABELS[m] || m));
      }
      headMode.onchange = () => {
        api(`/conversations/${id}`, { method: 'PUT', body: { mode: headMode.value } })
          .then(r => { current = r.conversation; applyActivityMode(headMode.value); })
          .catch(() => toast('No se pudo cambiar el modo.', 'err'));
      };

      // Materia del encabezado
      headSubject.innerHTML = '';
      headSubject.append(el('option', { value: '' }, 'Sin materia'));
      const subs = store.cacheKey('subjects') || [];
      for (const su of subs) headSubject.append(el('option', { value: su.id, ...(su.id === d.conversation.subject_id ? { selected: '' } : {}) }, su.name));
      headSubject.onchange = () => {
        api(`/conversations/${id}`, { method: 'PUT', body: { subject_id: headSubject.value ? Number(headSubject.value) : null } }).catch(() => toast('No se pudo actualizar.', 'err'));
      };
      if (!store.cacheKey('subjects')) {
        api('/subjects').then(r => { store.setCache('subjects', r.subjects); headSubject.innerHTML = ''; headSubject.append(el('option', { value: '' }, 'Sin materia')); for (const su of r.subjects) headSubject.append(el('option', { value: su.id, ...(su.id === d.conversation.subject_id ? { selected: '' } : {}) }, su.name)); }).catch(() => {});
      }

      body.innerHTML = '';
      quickBar.innerHTML = '';
      if (!d.messages || !d.messages.length) {
        body.append(greetingBubble(meta));
      } else {
        for (const m of d.messages) body.append(messageBubble(m.role, m.content, m.role === 'assistant'));
      }
      applyActivityMode(d.conversation.mode);
      body.scrollTop = body.scrollHeight;
      refreshConvList();
      input.focus();
      if (isNew) window.history.replaceState(null, '', `#/teacher/${id}`);
    } catch (e) { toast((e && e.message) || 'No se pudo abrir la charla.', 'err'); }
  }

  function applyActivityMode(mode) {
    const v = document.getElementById('view');
    if (v) v.dataset.activity = mode || '';
  }

  function greetingBubble(meta) {
    const m = el('div', { class: 'msg ai' });
    const b = el('div', { class: 'bub' });
    b.textContent = meta && meta.greeting ? meta.greeting : '¡Hola! Soy NEXTSTEP, tu profesor particular. Contame qué querés aprender.';
    m.append(b);
    if (meta && meta.startQuick && meta.startQuick.length) {
      for (const q of meta.startQuick) quickBar.append(chip(q, () => input.value = q));
    }
    return m;
  }

  function messageBubble(role, content, isAi = false) {
    const m = el('div', { class: `msg ${isAi ? 'ai' : 'user'}` });
    const b = el('div', { class: 'bub' });
    if (isAi) {
      b.innerHTML = chatHTML(content, (getMeta() || {}).allowedUrls);
    } else {
      b.textContent = content;
    }
    m.append(b);
    return m;
  }

  function chip(text, onclick) {
    return el('button', { class: 'chip', onclick }, text);
  }

  function addQuickOptions(list) {
    quickBar.innerHTML = '';
    if (!Array.isArray(list) || !list.length) return;
    for (const o of list) {
      if (o.startsWith('#')) {
        const mode = o.slice(1);
        if (MODE_LABELS[mode]) { /* modo referenciado por la IA */ continue; }
      }
      quickBar.append(chip(o, () => { input.value = o; input.focus(); }));
    }
  }

  async function send() {
    const text = input.value.trim();
    if (!text || !current || setup) return;
    if (aborter) return; // ya está enviando

    body.append(messageBubble('user', text));
    input.value = '';
    autoGrow();
    sendBtn.classList.add('hidden');
    stopBtn.classList.remove('hidden');
    quickBar.innerHTML = '';

    const aiMsg = el('div', { class: 'msg ai' });
    const bubble = el('div', { class: 'bub' });
    const typing = el('span', { class: 'muted' }, 'Escribiendo…');
    bubble.append(typing);
    aiMsg.append(bubble);
    body.append(aiMsg);
    body.scrollTop = body.scrollHeight;

    aborter = new AbortController();
    const started = Date.now();
    try {
      const out = await streamChat({
        conversationId: current.id,
        content: text,
        signal: aborter.signal,
        onChunk: t => {
          if (typing) typing.remove();
          bubble.innerHTML = chatHTML(bubble._acc ? bubble._acc + t : t, (getMeta() || {}).allowedUrls);
          bubble._acc = bubble._acc ? bubble._acc + t : t;
          body.scrollTop = body.scrollHeight;
        },
      });
      const elapsed = Date.now() - started;
      if (!out.text) {
        if (elapsed < 2500) await new Promise(r => setTimeout(r, 2500 - elapsed));
        bubble.textContent = 'No recibí respuesta. Probá de nuevo.';
      } else {
        if (typing) typing.remove();
        bubble.innerHTML = chatHTML(out.text, (getMeta() || {}).allowedUrls);
        addQuickOptions(out.quick);
      }
    } catch (e) {
      if (typing) typing.remove();
      if (e && e.name === 'AbortError') {
        bubble.textContent = 'Paraste la respuesta.';
      } else {
        const msg = (e && e.message) || 'No se pudo usar la IA ahora.';
        if (e instanceof ApiError && e.status === 503) {
          bubble.innerHTML = '';
          bubble.append(setupNotice());
        } else {
          bubble.textContent = msg + ' Quedó guardado lo que escribiste: podés volver a pedirle que responda.';
        }
      }
    } finally {
      aborter = null;
      sendBtn.classList.remove('hidden');
      stopBtn.classList.add('hidden');
      body.scrollTop = body.scrollHeight;
      await store.loadMe().catch(() => {});
      refreshConvList();
    }
  }

  stopBtn.addEventListener('click', () => { if (aborter) aborter.abort(); });

  async function refreshConvList() {
    try {
      const r = await api('/conversations');
      convList.innerHTML = '';
      for (const c of r.conversations) {
        const item = el('div', { class: `conv-item${current && c.id === current.id ? ' on' : ''}`, onclick: () => openConversation(c.id) });
        item.append(el('div', { class: 't' }, c.title));
        item.append(el('div', { class: 'm' }, `${fmtRel(c.updated_at)} · ${MODE_LABELS[c.mode] || 'Conversación'}${c.last_msg ? ' · ' + c.last_msg.slice(0, 40) : ''}`));
        convList.append(item);
      }
      if (!r.conversations.length) {
        convList.append(el('div', { class: 'muted small', style: 'padding:8px 4px;line-height:1.5' }, 'Todavía no tenés charlas. Arrancá una nueva y contale qué querés aprender.'));
      }
    } catch { /* silencioso */ }
  }

  // Abrir una conversación específica (o la última guardada).
  const seed = async () => {
    await refreshConvList();
    if (params[0]) { openConversation(Number(params[0])); return; }
    const last = Number(localStorage.getItem('ns_teacher_conv')) || null;
    if (last) {
      const r = await api('/conversations').catch(() => null);
      if (r && r.conversations.some(c => c.id === last)) { openConversation(last); return; }
    }
    // Nueva charla si no hay actividad previa.
    if (!setup) createConversation();
  };
  seed();

  return root;
}