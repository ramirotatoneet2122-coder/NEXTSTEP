# Instalar NEXTSTEP con XAMPP (en cualquier PC)

Guía paso a paso para levantar la plataforma en otra computadora, usando **XAMPP (Apache)** como servidor web
y **Node.js** para la API. Todo queda en un clic: doble clic en `iniciar.bat`.

## Cómo funciona

```
Navegador ──► Apache (XAMPP, puerto 8080) ──┬─► sirve el frontend (public/) desde disco
                                             └─► /api/*  ──proxy inverso──► Node/Express (puerto 3000)
                                                                             └─ SQLite (data/nextstep.db)
```

- **Apache** sirve la interfaz (archivos estáticos de `public/`) y hace de *proxy inverso* hacia la API.
- **Node.js** corre el backend (Express + SQLite). El chat con streaming (SSE) sigue funcionando a través del proxy.
- El `.env` (con la clave de la IA) **nunca** se publica: queda fuera del web root, que es `public/`.

## Requisitos

| Qué | Versión | Para qué |
|---|---|---|
| XAMPP | 8.x (Apache 2.4) | Servir el frontend y hacer de proxy |
| Node.js | 22.5 o más (LTS) | API y base de datos (usa `node:sqlite`) |
| Navegador | Chrome/Edge/Firefox recientes | La app es de escritorio (mínimo 1280 px de ancho) |

## Instalación paso a paso

### 1. Instalar XAMPP
1. Descargá XAMPP de <https://www.apachefriends.org/es/index.html> e instalalo (deja Apache y MySQL ticked; MySQL no hace falta).
2. Abrí **XAMPP Control Panel** una vez y verificá que Apache arranca. Si el puerto 80 está ocupado, no pasa nada: el instalador de NEXTSTEP busca otro puerto solo.

### 2. Instalar Node.js
1. Descargá el **LTS** de <https://nodejs.org> (22.5 o más) e instalalo con los valores por defecto.
2. Verificá en una consola nueva: `node -v` → tiene que mostrar `v22.5.0` o mayor.

### 3. Copiar el proyecto
1. Copiá la carpeta del proyecto (la que tiene `server.js`, `public/`, `src/`) donde quieras, por ejemplo `C:\nextstep`.
   Ojo: **evitá** carpetas con caracteres raros; los espacios están bien (`C:\Program Files\...` funciona).
2. Abrí una consola en esa carpeta y corré:
   ```bat
   npm install
   ```
   (descarga las dependencias; es la única vez que hace falta internet).

### 4. Configurar la clave de la IA
1. Copiá `.env.example` como `.env` (en la misma carpeta).
2. Abrí `.env` y poné tu clave:
   ```ini
   PROVIDER=anthropic
   ANTHROPIC_API_KEY=sk-ant-...
   ```
3. Guardá. Si no ponés la clave, la app **igual abre** y avisa en pantalla que la IA no está conectada
   (el resto — materias, rutas, objetivos, estadísticas — funciona sin IA).

### 5. Levantar el servidor
1. Abrí la carpeta `deploy\xampp`.
2. **Doble clic en `iniciar.bat`**.
   - Configura Apache solo la primera vez (activa `mod_proxy`, agrega el VirtualHost y el puerto).
   - Levanta Apache y la API de Node, espera a que la API responda y abre el navegador.
3. Listo: entrá en **http://localhost:8080**

### 6. Detener el servidor
- Doble clic en `detener.bat` (frena Apache y la API de Node).

### 7. Dejar Apache siempre listo (opcional)
En **XAMPP Control Panel** → *Service* → Apache → *Install* (lo instala como servicio de Windows y arranca solo
con la PC). El `iniciar.bat` igual hay que correrlo, porque la API de Node la levanta ese script.

## Si algo no funciona

| Síntoma | Causa probable | Solución |
|---|---|---|
| "No se encontró Apache" | XAMPP no está en `C:\xampp` | Editá la variable `XAMPP` de `iniciar.bat` |
| La API no responde | El puerto 3000 está ocupado | Cambiá `API_PORT` en `iniciar.bat` (por ejemplo 3010) |
| "Configuración de Apache inválida" | Error en `httpd.conf` | `configurar.ps1` deja una copia en `C:\xampp\apache\conf\httpd.conf.nextstep.bak`; copiala de vuelta |
| 503 al entrar | La API de Node no arrancó | Mirá `deploy\xampp\api-err.log` (el script lo genera) |
| El chat no hace streaming | Proxy sin buffer | Verificá que en `httpd.conf` estén activos `mod_proxy` y `mod_proxy_http` (el instalador lo hace) |
| Puerto 80 ocupado | Otro programa lo usa | NEXTSTEP no usa el 80: entra por el 8080 |
| `npm install` falla | Sin internet o Node viejo | Verificá `node -v` y la conexión |

## Instalar a mano (si preferís no usar el script)

1. En `C:\xampp\apache\conf\httpd.conf`:
   - descomentá `LoadModule proxy_http_module modules/mod_proxy_http.so`
   - agregá `Listen 8080` (al lado de `Listen 80`)
   - al final del archivo: `Include conf/extra/nextstep.conf`
2. Copiá `deploy\xampp\nextstep.conf` a `C:\xampp\apache\conf\extra\nextstep.conf` y reemplazá
   `__PROJECT_DIR__` por la ruta de tu proyecto (con `/` en vez de `\`), `__PORT__` por `8080` y `__API_PORT__` por `3000`.
3. Validá: `C:\xampp\apache\bin\httpd.exe -t` → tiene que decir `Syntax OK`.
4. Arrancá Apache y, en otra consola, la API: `node server.js`.
5. Entrá a http://localhost:8080

## Datos y copias de seguridad

- La base de datos está en `data/nextstep.db` (SQLite). Copiala para respaldar todo lo que hay cargado.
- Para dejar la PC como de fábrica: borrá `data/` y `.env` (se recrean al arrancar).
- Los logs del servidor: `deploy\xampp\api-out.log` y `api-err.log`.

## Para desarrollar (sin Apache)

El backend se puede levantar solo, como siempre:

```bat
npm start
```

→ http://localhost:3000 (el frontend lo sirve el propio Express).
Usá este modo cuando estés programando: el proxy de Apache solo hace falta para la versión "final" delaluz de la app.
