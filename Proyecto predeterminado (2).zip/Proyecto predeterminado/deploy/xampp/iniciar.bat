@echo off
rem ==========================================================================
rem  NEXTSTEP - iniciar con XAMPP (Apache + Node)
rem  Levanta Apache (sirve el frontend y hace de proxy a la API) y la API de Node.
rem  Uso: doble clic en este archivo.
rem
rem  Variables que se pueden cambiar aca: XAMPP, WEB_PORT, API_PORT
rem  Ojo: no usar el nombre PORT (la app lee la variable PORT para su puerto).
rem  Para pruebas sin consola:  set NS_NO_PAUSE=1   set NS_NO_BROWSER=1
rem ==========================================================================
setlocal enabledelayedexpansion
chcp 65001 >nul

set "HERE=%~dp0"
set "PROJECT=%HERE%..\.."
for %%I in ("%PROJECT%") do set "PROJECT=%%~fI"
set "XAMPP=C:\xampp"
set "HTTPD=%XAMPP%\apache\bin\httpd.exe"
set "HTTPD_CONF=%XAMPP%\apache\conf\httpd.conf"
set "WEB_PORT=8080"
set "API_PORT=3000"
set "PIDFILE=%HERE%nextstep.pid"
set "APILOG_OUT=%HERE%api-out.log"
set "APILOG_ERR=%HERE%api-err.log"

echo.
echo  ==============================================
echo   NEXTSTEP - servidor XAMPP + Node
echo  ==============================================
echo.

if not exist "%HTTPD%" (
  echo  [X] No encontre Apache en %HTTPD%
  echo      Instala XAMPP o edita la variable XAMPP de este archivo.
  if not defined NS_NO_PAUSE pause
  exit /b 1
)

rem ---- 1. Detener cualquier Apache anterior (para poder medir los puertos) ----
taskkill /IM httpd.exe /F >nul 2>&1
ping -n 2 127.0.0.1 >nul

rem ---- 2. Configurar Apache: idempotente, se puede volver a ejecutar ----
powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%configurar.ps1" -ProjectDir "%PROJECT%" -XamppDir "%XAMPP%" -Port %WEB_PORT% -ApiPort %API_PORT%
if errorlevel 2 (
  echo.
  echo  [X] La configuracion de Apache quedo invalida. Revisa el mensaje de arriba.
  if not defined NS_NO_PAUSE pause
  exit /b 2
)

rem ---- 3. Levantar Apache ----
start "" "%HTTPD%" -f "%HTTPD_CONF%"
ping -n 3 127.0.0.1 >nul
echo  [OK] Apache levantado.

rem ---- 4. Ubicar Node.js ----
set "NODEEXE="
for /f "delims=" %%n in ('where node 2^>nul') do if not defined NODEEXE set "NODEEXE=%%n"
if not defined NODEEXE if exist "%ProgramFiles%\nodejs\node.exe" set "NODEEXE=%ProgramFiles%\nodejs\node.exe"
if not defined NODEEXE (
  echo  [X] No encontre Node.js. Instalalo desde https://nodejs.org - version 22.5 o mas.
  if not defined NS_NO_PAUSE pause
  exit /b 3
)

if not exist "%PROJECT%\node_modules" (
  echo  [i] Instalando dependencias con npm install...
  pushd "%PROJECT%"
  call npm.cmd install
  popd
)

rem ---- 5. Levantar la API de Node (con log propio para poder depurar) ----
if exist "%PIDFILE%" (
  for /f %%p in ('type "%PIDFILE%"') do taskkill /PID %%p /F >nul 2>&1
  del "%PIDFILE%" >nul 2>&1
)

echo  [i] Levantando la API de Node...
rem Rutas con comillas simples: CMD no las toca. El script se pasa relativo
rem (sin espacios) y el directorio de trabajo se fija en el proyecto.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Start-Process -FilePath '%NODEEXE%' -ArgumentList 'server.js' -WorkingDirectory '%PROJECT%' -WindowStyle Minimized -RedirectStandardOutput '%APILOG_OUT%' -RedirectStandardError '%APILOG_ERR%' -PassThru; Set-Content -Path '%PIDFILE%' -Value $p.Id"

set "NODE_PID="
if exist "%PIDFILE%" set /p NODE_PID=<"%PIDFILE%"
if not defined NODE_PID (
  echo  [X] No se pudo levantar Node.
  if not defined NS_NO_PAUSE pause
  exit /b 4
)

rem ---- 6. Esperar a que la API responda ----
set "API_OK="
for /l %%i in (1,1,20) do (
  if not defined API_OK (
    powershell -NoProfile -Command "try { Invoke-WebRequest -Uri 'http://127.0.0.1:%API_PORT%/api/health' -UseBasicParsing -TimeoutSec 2 | Out-Null; exit 0 } catch { exit 1 }" >nul 2>&1
    if not errorlevel 1 set "API_OK=1"
    if not defined API_OK ping -n 2 127.0.0.1 >nul
  )
)
if not defined API_OK (
  echo  [X] La API no respondio en el puerto %API_PORT%. Log:
  type "%APILOG_ERR%"
  if not defined NS_NO_PAUSE pause
  exit /b 5
)
echo  [OK] API de Node - PID %NODE_PID% - puerto %API_PORT%.

rem ---- 7. Abrir el navegador ----
if not defined NS_NO_BROWSER start "" "http://localhost:%WEB_PORT%"
echo.
echo  ==============================================
echo   Listo: http://localhost:%WEB_PORT%
echo   Para detener todo: detener.bat
echo  ==============================================
echo.
exit /b 0
