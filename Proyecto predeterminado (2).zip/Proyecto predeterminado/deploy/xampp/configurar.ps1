# ==========================================================================
# NEXTSTEP - configurador de XAMPP (Apache)
# Instala el VirtualHost de NEXTSTEP en Apache, activa mod_proxy, resuelve
# puertos ocupados y valida la configuracion. Es idempotente.
#
#   powershell -ExecutionPolicy Bypass -File configurar.ps1 [-ProjectDir <ruta>] [-XamppDir C:\xampp] [-Port 8080] [-ApiPort 3000]
#
# Nota: el archivo es ASCII puro a proposito (PowerShell 5.1 lo lee como ANSI).
# ==========================================================================
param(
  [string]$ProjectDir = '',
  [string]$XamppDir   = 'C:\xampp',
  [int]$Port          = 8080,
  [int]$ApiPort       = 3000
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not $ProjectDir) { $ProjectDir = (Resolve-Path (Join-Path $here '..\..')).Path }
$ProjectDir = (Resolve-Path $ProjectDir).Path

$confDir   = Join-Path $XamppDir 'apache\conf'
$httpd     = Join-Path $XamppDir 'apache\bin\httpd.exe'
$httpdConf = Join-Path $confDir 'httpd.conf'
$vhostDst  = Join-Path $confDir 'extra\nextstep.conf'
$vhostSrc  = Join-Path $here 'nextstep.conf'

function Say($msg, $color = 'Gray') { Write-Host $msg -ForegroundColor $color }

# Devuelve $true si el puerto esta libre para escuchar.
function Test-PortFree([int]$p) {
  $l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, $p)
  try { $l.Start(); return $true } catch { return $false } finally { try { $l.Stop() } catch {} }
}

if (-not (Test-Path $httpd)) {
  Say "XAMPP no encontrado en $XamppDir" 'Red'
  Say "Instala XAMPP o pasa -XamppDir con la ruta correcta." 'Yellow'
  exit 1
}
if (-not (Test-Path (Join-Path $ProjectDir 'public'))) {
  Say "La carpeta $ProjectDir no parece el proyecto NEXTSTEP (falta public/)." 'Red'
  exit 1
}

Say "Proyecto : $ProjectDir" 'Cyan'
Say "XAMPP    : $XamppDir" 'Cyan'

# ---- 1. Copia de seguridad de httpd.conf (solo la primera vez) ----
$backup = Join-Path $confDir 'httpd.conf.nextstep.bak'
if (-not (Test-Path $backup)) {
  Copy-Item $httpdConf $backup
  Say "Copia de seguridad: $backup" 'DarkGray'
}

$conf = Get-Content $httpdConf -Raw

# ---- 2. Activar mod_proxy_http (necesario para proxear a http://) ----
if ($conf -match '(?m)^#(LoadModule\s+proxy_http_module\s+.*)$') {
  $conf = [regex]::Replace($conf, '(?m)^#(LoadModule\s+proxy_http_module\s+.*)$', '$1')
  Say "mod_proxy_http activado" 'Green'
}
if ($conf -notmatch '(?m)^LoadModule\s+proxy_module\s') {
  $conf = [regex]::Replace($conf, '(?m)^#(LoadModule\s+proxy_module\s+.*)$', '$1')
  Say "mod_proxy activado" 'Green'
}

# ---- 3. Puertos: el de NEXTSTEP y el del sitio principal de Apache ----
$nextPort = $Port
while (-not (Test-PortFree $nextPort) -and $nextPort -lt ($Port + 20)) { $nextPort++ }
if ($nextPort -ne $Port) {
  Say "El puerto $Port esta ocupado: NEXTSTEP usara el $nextPort." 'Yellow'
}

# Apache escucha en 80 por defecto: si algo lo ocupa, Apache se cae entero.
if (-not (Test-PortFree 80)) {
  $mainPort = 8081
  while (-not (Test-PortFree $mainPort) -and $mainPort -lt 8099) { $mainPort++ }
  $conf = [regex]::Replace($conf, '(?m)^Listen\s+80\s*$', "Listen $mainPort")
  Say "El puerto 80 esta ocupado: el sitio principal de XAMPP pasa al $mainPort." 'Yellow'
}

# ---- 4. Include del vhost de NEXTSTEP + puerto en Listen ----
# Apache exige que todo puerto usado por un VirtualHost este en la lista "Listen".
if ($conf -notmatch "(?m)^Listen\s+$nextPort\s*$") {
  $conf = [regex]::Replace($conf, '(?m)^(Listen\s+80\s*)$', "`$1`r`nListen $nextPort")
  Say "Listen $nextPort agregado a httpd.conf" 'Green'
}

$includeLine = 'Include conf/extra/nextstep.conf'
if ($conf -notmatch [regex]::Escape($includeLine)) {
  $conf = $conf.TrimEnd() + "`r`n`r`n# NEXTSTEP (agregado por deploy/xampp/configurar.ps1)`r`n$includeLine`r`n"
  Say "Include agregado a httpd.conf" 'Green'
}

Set-Content -Path $httpdConf -Value $conf -Encoding ASCII

# ---- 5. Escribir el VirtualHost con las rutas reales ----
$vhost = Get-Content $vhostSrc -Raw
$vhost = $vhost.Replace('__PROJECT_DIR__', $ProjectDir.Replace('\', '/'))
$vhost = $vhost.Replace('__PORT__', [string]$nextPort)
$vhost = $vhost.Replace('__API_PORT__', [string]$ApiPort)
Set-Content -Path $vhostDst -Value $vhost -Encoding ASCII
Say "VirtualHost escrito: $vhostDst" 'Green'

# ---- 6. Validar la configuracion de Apache ----
# httpd -t escribe "Syntax OK" en stderr: se baja el nivel de error para no cortarlo.
$ErrorActionPreference = 'Continue'
$check = (& $httpd -f (Join-Path $confDir 'httpd.conf') -t 2>&1 | Out-String)
$code = $LASTEXITCODE
$ErrorActionPreference = 'Stop'
if ($code -ne 0) {
  Say 'LA CONFIGURACION DE APACHE TIENE ERRORES:' 'Red'
  Write-Host $check -ForegroundColor Red
  Say "Para volver atras: Copy-Item `"$backup`" `"$httpdConf`"" 'Yellow'
  exit 2
}
Say 'Configuracion de Apache valida.' 'Green'

# ---- 7. Comprobar que el puerto de la API de Node este libre ----
if (-not (Test-PortFree $ApiPort)) {
  Say "El puerto $ApiPort esta ocupado: la API de Node no va a poder arrancar." 'Yellow'
  Say "Cerrá el otro proceso o usá otro puerto con -ApiPort." 'Yellow'
}

Say ''
Say "  Apache  : http://localhost:$nextPort   (API Node en el puerto $ApiPort)" 'Cyan'
Say ''
exit 0
