@echo off
rem ==========================================================================
rem  NEXTSTEP - detener el servidor (Apache + API de Node)
rem ==========================================================================
setlocal
chcp 65001 >nul
set "HERE=%~dp0"
set "PIDFILE=%HERE%nextstep.pid"

if exist "%PIDFILE%" (
  for /f %%p in ('type "%PIDFILE%"') do (
    taskkill /PID %%p /F >nul 2>&1 && echo  [OK] API de Node detenida ^(PID %%p^).
  )
  del "%PIDFILE%" >nul 2>&1
) else (
  echo  [i] No hay PID guardado; busco instancias de server.js...
  powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"name='node.exe'\" | Where-Object { $_.CommandLine -like '*server.js*' } | ForEach-Object { Stop-Process -Id $_.Id -Force; Write-Host ('  [OK] node detenido (PID ' + $_.Id + ')') }"
)

taskkill /IM httpd.exe /F >nul 2>&1 && echo  [OK] Apache detenido.
echo.
echo  Servidor detenido.
ping -n 3 127.0.0.1 >nul
exit /b 0
