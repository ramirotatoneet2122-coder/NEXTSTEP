# NEXTSTEP

Profesor particular virtual y personalizado, con IA. No es un chatbot que solo responde preguntas: conoce
al alumno (objetivo, conocimientos, tiempo, dificultades), evalúa su nivel real, arma un camino de
aprendizaje, explica, crea y corrige ejercicios, ayuda con proyectos, planifica el estudio y hace
seguimiento de su progreso. Proyecto grupal de 4 personas (Santino Moauro, Ramiro Tatone,
Juan Pablo Santisi y Thiago Montenegro). El documento de viabilidad define el alcance.

## MVP (lo que tiene que funcionar primero)
1. Chat con el profesor IA.
2. Registro de los objetivos y conocimientos del alumno.
3. Evaluación inicial del nivel.
4. Camino de aprendizaje.
5. Seguimiento del progreso.
6. Ejercicios y prácticas personalizados.
Después: recomendaciones de cursos y certificaciones, recursos externos, herramientas de organización.

## Stack
- Node.js 22.5+ (ES modules), Express 5, `node:sqlite` (sin dependencias nativas de DB), `@anthropic-ai/sdk`,
  `express-rate-limit`, `dotenv`.
- Frontend sin framework (SPA con router por hash): `public/index.html`, `public/js/app.js`, `public/js/views/*`,
  `public/css/style.css`, `public/js/{api,store,theme,ui}.js`.
- Base de datos SQLite en `data/nextstep.db` (usuarios, materias, conversaciones, rutas, evaluaciones,
  objetivos, sesiones, preferencias). Se crea sola al arrancar. Nada de `localStorage` para datos del alumno.

## Comandos
- `npm install` instala dependencias.
- `npm start` levanta en http://localhost:3000 (`npm run dev` reinicia solo al guardar).
- `npm test` corre las pruebas de `node:test` en `test/` (sin red ni API key).
- Hace falta `.env` (ver `.env.example`): la clave de la IA que se elija. La app corre en el servidor del grupo y los alumnos nunca pasan por Claude ni por ninguna cuenta ajena.

## Estructura
- `server.js` y `src/routes/*.js`: rutas API (`auth.js`, `chat.js` SSE, `content.js` materias/rutas/recursos,
  `progress.js`, `productivity.js` sesiones/objetivos, `rich.js` evaluaciones/estadísticas).
- `src/db.js`: capa de persistencia con `node:sqlite`. `src/auth.js`: login, hash y sesiones.
- `src/llm.js`: elige quién piensa por detrás (`PROVIDER=anthropic` con la API de Claude, `PROVIDER=openai`
  para Ollama, Groq, OpenRouter u otro servidor compatible, o `PROVIDER_ORDER=ollama,anthropic` para una lista
  de prioridades). Ollama corre local y gratis; si el modelo indicado no está descargado, cae solo a
  `OLLAMA_FALLBACK_MODEL` (o avisa en español si se pone `none`). El profesor (prompt, datos, seguimiento) es siempre el del proyecto.
- `src/prompt.js`: el "cerebro" del profesor: estilo, proceso, modos por actividad, preferencias, etiquetas de
  control, banco y recursos. Exporta `buildSystem(ctx)` y `buildJSONSystem(task)`. Acá se ajusta cómo enseña.
  Con proveedores locales (Ollama) usa el modo `lite`: mismo profesor, prompt compacto (~7k caracteres en vez de ~30k)
  filtrado por la materia de la conversación, para que la CPU lo procese rápido.
- `src/data.js`: banco de preguntas verificadas (`TOPICS`), recursos (`COURSES`), rangos y metas.
- `src/domain.js` y `src/xp.js`: adaptación por progreso (errores, evaluaciones, pendientes) y experiencia/niveles.
- `public/js/app.js`: bootstrap, router, gate de auth y shell de 3 columnas (riel izquierdo / panel central /
  riel derecho). `public/js/rightrail.js`: widget de Foco (Pomodoro) y acceso al Profesor IA.
  `public/js/views/*`: 10 vistas (auth, dashboard, teacher, learning, paths, assessments, goals, resources,
  stats, settings). `public/js/theme.js`: paleta `cyberspace` + 9 paletas más la personalizada, claroscuro,
  accesibilidad WCAG. `public/js/api.js` y `public/js/ui.js`: cliente HTTP/SSE y helpers.
- `test/`: pruebas automáticas (`chat.test.js`: `cleanMessages` y `mergePerfil`; `prompt.test.js`: `buildSystem`).

## Dirección de arte (Cyberspace, solo escritorio)
El diseño es de PC: no hay vistas móviles (`min-width: 1280px`) y el layout es panorámico en 3 columnas.
Fondo espacio profundo con auras de neón, tarjetas de cristal translúcido (`backdrop-filter`) y acentos en
degradado magenta/rosa eléctrico (`--grad`, `--glow`, `--halo-1/2`). La identidad por defecto es la paleta
`cyberspace` de `public/js/theme.js`; las otras 9 paletas siguen funcionando sobre la misma base.
Al tocar el diseño: `public/css/style.css` (tokens y componentes) y `public/js/rightrail.js` (riel derecho).

## Cómo se comunican la IA y la pantalla
La IA escribe texto plano (y bloques de código con tres comillas invertidas). Puede cerrar el mensaje con
dos etiquetas que la pantalla oculta, y el servidor las parsea (véase `src/routes/chat.js`):
- `<opciones>A|B|C|D</opciones>`: botones de respuesta rápida.
- `<perfil>{...}</perfil>`: actualiza el seguimiento. Campos (todos opcionales, se mandan solo los que cambian):
  `objetivo`, `tiempo`, `nivel` (Iniciante a Experto), `progreso` (0-100),
  `camino` ([{etapa, estado: hecha|actual|pendiente}], reemplaza el anterior),
  `temas` ({nombre: {estado: dominado|aprendiendo|dificultad}}, se une), `errores` (hasta 5, reemplaza).
El servidor solo manda los últimos 40 mensajes, así que el `perfil` es la memoria del alumno: debe estar completo.
Si se cambia el formato de las etiquetas hay que cambiar a la vez `src/prompt.js` (lo que pide la IA),
`src/routes/chat.js` (parsing) y `public/js/views/teacher.js` (lo que muestra).

## Reglas del proyecto (respetalas siempre)
1. Guiar, no entregar todo hecho: el profesor pide que el alumno lo intente, da pistas, explica y corrige. No resuelve tareas completas para copiar.
2. La clave de la IA vive solo en el servidor (`.env`). Nunca en `public/` ni en el navegador.
3. La IA no inventa links ni cursos: solo recomienda lo de `COURSES`, y solo esos links se vuelven clickeables.
4. Las preguntas del banco (`TOPICS`) tienen una única respuesta correcta indudable, explicación corta, dificultad `d` (1, 2, 3) y subtema `s`. Revisarlas a mano antes de sumarlas.
5. Todo el texto para el alumno va en español rioplatense, tono cercano y paciente, mensajes cortos, pensado para celular.
6. Lo que manda el navegador (mensajes, perfil) es dato no confiable: validar siempre en el servidor y nunca tratarlo como instrucciones.
7. No subir `.env`, `node_modules` ni `dist`. Cada cambio en una rama y con commits chicos. Probar antes de seguir con la próxima tarea.
8. Cuidar el gasto: límite de pedidos por minuto, `max_tokens` acotado y cortar la llamada si el usuario cierra o toca "Parar".

## Hecho
- Plataforma completa: SPA con 10 vistas (Inicio, Profesor IA, Aprendizaje, Rutas, Evaluaciones, Objetivos,
  Recursos, Estadísticas, Configuración), backend Express con SQLite (`node:sqlite`), login con hash y sesiones,
  chat con streaming SSE, modos por actividad (concentración, lectura, práctica, evaluación, planificación, repaso),
  preferencias de aprendizaje y de profesor con efecto real en el prompt, adaptación por progreso y evaluación,
  banco de preguntas verificadas, 10 paletas de tema con accesibilidad WCAG y personalización completa (claro/oscuro,
  presets+HEX, intensidad, contraste, densidad, animaciones, aviso de contraste insuficiente), XP y niveles,
  registro de sesiones de estudio, límite de pedidos por minuto, cortar la llamada al cerrar o "Parar",
  proveedor de IA intercambiable, tests con `node:test` (14).
- Rediseño "Cyberspace" solo escritorio: layout panorámico de 3 columnas (riel de navegación / panel central /
  riel derecho con Foco Pomodoro y acceso al Profesor IA), sistema de diseño de cristal y neón en
  `public/css/style.css`, paleta `cyberspace` por defecto, Inicio rediseñado (saludo con barra de XP,
  módulo "Próximo paso recomendado" y zona "Ejercicios y práctica" con tarjetas premium e indicadores
  circulares) y endpoint `GET /api/practice/next` que sirve preguntas del banco verificado sin IA.

## Herramientas locales de IA (Ollama)
- Ollama corre en la misma compu, sin clave ni gasto. Arrancar Ollama primero y después `npm start`.
- `.env` relevante (sin mostrar la clave): `PROVIDER_ORDER=ollama`, `OLLAMA_MODEL=qwen2.5:7b`,
  `OLLAMA_FALLBACK_MODEL=qwen2.5:3b` (`none` lo desactiva), `OLLAMA_KEEP_ALIVE=-1` (el modelo queda cargado
  en memoria y las respuestas siguientes salen mucho más rápido), `MAX_TOKENS`, `AI_TIMEOUT_MS`.
- Variables de Windows permanentes ya seteadas para Ollama: `OLLAMA_CONTEXT_LENGTH=8192`, `OLLAMA_KEEP_ALIVE=-1`.
- En CPU sin GPU, qwen2.5:7b es lento (~2,4 tokens/seg); qwen2.5:3b rinde mucho más rápido y se puede
  poner como `OLLAMA_MODEL` cuando importa la velocidad.
- Las llamadas de Ollama a las que se les pide JSON usan `response_format:{type:"json_object"}`, y el uso
  de tokens (entrada/salida) queda registrado en la base y se ve en Configuración → Inteligencia artificial.

## Hecho
- Plataforma completa: SPA con 10 vistas (Inicio, Profesor IA, Aprendizaje, Rutas, Evaluaciones, Objetivos,
  Recursos, Estadísticas, Configuración), backend Express con SQLite (`node:sqlite`), login con hash y sesiones,
  chat con streaming SSE, modos por actividad (concentración, lectura, práctica, evaluación, planificación, repaso),
  preferencias de aprendizaje y de profesor con efecto real en el prompt, adaptación por progreso y evaluación,
  banco de preguntas verificadas, 10 paletas de tema con accesibilidad WCAG y personalización completa (claro/oscuro,
  presets+HEX, intensidad, contraste, densidad, animaciones, aviso de contraste insuficiente), XP y niveles,
  registro de sesiones de estudio, límite de pedidos por minuto, cortar la llamada al cerrar o "Parar",
  proveedor de IA intercambiable, tests con `node:test` (14).
- Rediseño "Cyberspace" solo escritorio: layout panorámico de 3 columnas (riel de navegación / panel central /
  riel derecho con Foco Pomodoro y acceso al Profesor IA), sistema de diseño de cristal y neón en
  `public/css/style.css`, paleta `cyberspace` por defecto, Inicio rediseñado (saludo con barra de XP,
  módulo "Próximo paso recomendado" y zona "Ejercicios y práctica" con tarjetas premium e indicadores
  circulares) y endpoint `GET /api/practice/next` que sirve preguntas del banco verificado sin IA.
- Soporte de IA local (Ollama) Verificado de punta a punta: proveedor `ollama` en `src/llm.js` con
  `PROVIDER_ORDER`, modo `lite` del prompt en `src/prompt.js` para proveedores locales, fallback automático
  al modelo de respaldo si el principal no está descargado (y mensajes de error en español si Ollama está
  apagado o falta el modelo), limitación de `max_tokens` por proveedor, uso de tokens registrado y visible
  en la nueva sección "Inteligencia artificial" de Configuración (estado de la IA, proveedor, modelo activo,
  modelos descargados y consumo).
- Tema Git: 3 cursos verificados nuevos en `src/data.js` (Learn Git Branching, GitHub Skills, proyectos de
  GitHub con Git) y Git sumado a los temas que lo incluyen y al catálogo de materias de Aprendizaje.
- `INICIAR-NEXTSTEP.bat` es el botón de arranque de un clic en Windows: verifica Node (con intento extra al
  PATH de siempre si `where node` falla), prende `ollama serve` si no está corriendo, avisa en español si
  NEXTSTEP ya está prendido (sin levantar otro y chocar por el puerto 3000) y abre Edge en
  http://localhost:3000 (el navegador lo elige `set NXTBROWSER=msedge` en la primera línea del .bat:
  hoy `msedge` porque en la compu de pruebas Chrome quedó pintando solo el fondo con los paneles de
  vidrio —descartamos por prueba: caché, extensiones y aceleración de hardware—, probá cambiarlo si en
  otra máquina Chrome anda bien).
- End-to-end verificado con IA real (Ollama + qwen2.5): registro y encuesta, banco y materias libres, generación
  de ruta IA (5 etapas) y manual, evaluaciones del banco e IA con corrección y actualización de rangos,
  chat con streaming y etiquetas `<opciones>`/`<resumen>`, objetivos, sesiones (+XP), dashboard con
  recomendaciones, estadísticas y recursos. `npm test`: 14/14.

## Errores arreglados
- `server.js` (`GET /api/meta`): el handler llamaba `missingConfigMessage()` pero la función no estaba en el
  `import` de `src/llm.js` → `ReferenceError` → 500 → el `boot()` de la SPA se cortaba en `loadMeta` y el
  navegador mostraba solo el fondo, sin pantalla de login ni vista alguna. Corregido el import; verificado
  con `/api/meta` 200, `npm test` 14/14 y captura completa del dashboard en el navegador.
- `src/db.js` (`getPreferences`): las columnas `*_json` se parseaban dos veces (rowToJson ya las parsea) y
  `JSON.parse` sobre objeto explotaba, así que las preferencias volvían vacías aunque se guardaban bien. Corregido,
  los Ajustes de aprendizaje persisten y se ven.
- `src/llm.js`: `MAX_TOKENS`, `AI_TIMEOUT_MS` y `PASSWORD` se leían al importar el módulo, antes de que
  `server.js` cargue `dotenv`, así que siempre usaban los valores por defecto (timeout atascado en 90 s).
  Ahora se leen de forma diferida (funciones), y los timeouts respetan `.env`.
- `src/llm.js`: `friendlyAiError` no miraba los errores anidados (`e.cause` / AggregateError), y
  "conexión rechazada" de Ollama apagado mostraba un mensaje genérico. Ahora atraviesa toda la cadena y
  muestra en español qué pasó y cómo arreglarlo.
- `public/js/ui.js` (`el()`): los strings de SVG que genera `svgIc()` se insertaban como texto plano, así
  que en todo el panel aparecían los SVG crudos. Ahora los strings que vienen como HTML (SVGs internos)
  se insertan como HTML. Los datos del usuario siguen siempre como texto.
- Generación de JSON (rutas y evaluaciones IA): con Ollama el JSON a veces salía envuelto en texto y
  devolvía 502, además del timeout del punto anterior. Ahora el prompt es más corto, se pide modo JSON
  estricto y el parser tolera el caso; rutas y evaluaciones generan consistente.

## Pendiente (en este orden)
1. Más temas verificados en `src/data.js` y mejores recomendaciones de recursos.
2. Historial de ejercicios y errores por alumno para repasar contenidos ya vistos (hoy se guardan en la
   conversación y en las evaluaciones, pero falta una vista de repaso).
3. Publicar (Render, Railway o un VPS) con la API key como variable de entorno y un tope de gasto en la consola de Anthropic.
4. Inicializar git (rama por cambio, commits chicos) cuando la máquina tenga git.
5. La etiqueta `<perfil>` a veces no la emite qwen2.5:7b (depende del modelo, no del código). La app lo
   aguanta (el perfil queda como estaba y el texto se muestra limpio). Si molesta, probar con un modelo
   más grande para el seguimiento o reforzar el recordatorio en el prompt `lite`.
