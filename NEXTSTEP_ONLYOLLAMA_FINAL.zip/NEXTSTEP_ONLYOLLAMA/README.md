# NEXTSTEP

Profesor particular virtual con IA: te conoce, evalúa tu nivel real, te arma un camino de aprendizaje,
te explica, te hace practicar, corrige tus errores y lleva el seguimiento de tu progreso.

## Diseño (Cyberspace · solo escritorio)

La interfaz está diseñada **exclusivamente para PC**: layout panorámico de 3 columnas, sin vistas móviles
(`min-width: 1280px`). Dirección de arte "Cyberspace": fondo espacio profundo con auras de neón, tarjetas
translúcidas con `backdrop-filter` y acentos en degradado magenta/rosa eléctrico.

| Zona | Contenido |
|---|---|
| Riel izquierdo (258 px) | Logo, secciones principales (Inicio, Tutor IA, Rutas, Práctica) y panel desplegable "Más" (Mi aprendizaje, Objetivos, Recursos, Estadísticas, Configuración) |
| Panel central | Vista de la sección; en Inicio: saludo con barra de XP, módulo "Próximo paso recomendado" y zona "Ejercicios y práctica" |
| Riel derecho (340 px) | Widget "Foco" (Pomodoro con presets, registra la sesión y da XP), acceso directo al "Profesor IA" y anillo de progreso del nivel |

Piezas del diseño:

- `public/css/style.css`: sistema de diseño completo (tokens, cristal, neón, retícula espacial, componentes).
- `public/js/rightrail.js`: riel derecho (temporizador de foco + panel del profesor IA).
- `public/js/theme.js`: paleta `cyberspace` (identidad por defecto) + las 9 paletas anteriores y la personalizada.
- `public/js/views/dashboard.js`: inicio rediseñado con POO y ejercicios con tarjetas premium e indicadores circulares.
- `GET /api/practice/next`: sirve una pregunta del banco verificado para la zona de práctica (no necesita IA).

Tipografía: Space Grotesk (títulos), Inter (interfaz) y JetBrains Mono (código).

## Arrancar

**Forma sencilla en Windows:** hacé doble clic en `INICIAR-NEXTSTEP.bat`. Se abrirá `http://localhost:3000`. No abras `public/index.html` directamente: la aplicación necesita el servidor para que funcionen el menú, la sesión, las vistas y la API.

Forma manual:

1. Necesitás Node.js 22.5 o más nuevo (usa `node:sqlite`, integrado).
2. En esta carpeta: `npm install`
3. Copiá `.env.example` como `.env` y pegá tu clave de la API de Anthropic en `ANTHROPIC_API_KEY`
   (se crea en https://console.anthropic.com). Sin clave, el chat avisa y queda deshabilitado.
4. `npm start` y abrí http://localhost:3000

Probá `http://localhost:3000/api/health`: si dice `"ia":true`, la clave está cargada.

La base de datos (usuarios, materias, conversaciones, rutas, evaluaciones, objetivos, sesiones y
preferencias) se crea sola en `data/nextstep.db` la primera vez que arranca.

## Elegir qué IA usa por detrás

La app es del grupo: corre en tu servidor, con tu prompt, tus datos y tu seguimiento de alumnos. Los alumnos
nunca entran a Claude ni a ninguna cuenta ajena. Lo único que se elige es qué modelo responde, en `.env`:

| Opción | Cuándo conviene |
|---|---|
| `PROVIDER=anthropic` (API de Claude) | Mejor calidad para enseñar y seguir el formato del seguimiento. Cuesta por uso. |
| `PROVIDER=openai` con Ollama | Corre en tu propia compu, sin cuenta ni costo, y los datos no salen de tu máquina. Los modelos chicos enseñan peor y a veces fallan en el formato del seguimiento. |
| `PROVIDER=openai` con Groq u OpenRouter | En la nube, a veces con plan gratis y límites. Hay que probar la calidad en español. |

Cambiar de opción no requiere tocar el código. Con cualquier modelo, probalo con una charla de alumno antes de
confiar en él: tiene que guiar sin dar todo hecho y actualizar bien el seguimiento.

## Cómo está armado

- `server.js` + `src/routes/*.js`: API REST (auth, chat SSE, materias, rutas, evaluaciones, objetivos,
  recursos, sesiones, estadísticas, preferencias). La clave de IA vive solo acá (`.env`).
- `src/db.js`: capa de persistencia con `node:sqlite` (sin dependencias nativas).
- `src/prompt.js`: el "cerebro" del profesor (estilo, proceso, modos, preferencias, etiquetas). Acá se ajusta
  cómo enseña. Exporta `buildSystem` y `buildJSONSystem`, que usan los tests.
- `src/data.js`: banco de preguntas verificadas (`TOPICS`, una única respuesta correcta) y recursos (`COURSES`).
- `src/llm.js`: elige el proveedor (`PROVIDER=anthropic` u OpenAI-compatible).
- `src/domain.js` + `src/xp.js`: lógica de adaptación por progreso y de experiencia/niveles.
- `public/`: SPA sin framework (router por hash, 10 vistas, diseño Cyberspace de escritorio en 3 columnas,
  10 paletas con accesibilidad WCAG, chat con streaming, widget de foco Pomodoro). Sin `localStorage`:
  todo vive en el servidor.
- `test/`: pruebas automáticas con `node:test` (`npm test`). Sin red ni API key.

## Trabajar con OpenCode

1. Instalá OpenCode siguiendo https://opencode.ai y abrilo dentro de esta carpeta con el comando `opencode`.
2. Conectá el proveedor Anthropic (con tu clave de API o tu cuenta, según te ofrezca OpenCode).
3. Pasale el contexto con `/init` o dejá que lea `AGENTS.md` de la raíz: ahí está la idea, el MVP, el stack,
   la estructura y las reglas del proyecto.
4. Pedile una tarea por vez y probá cada cambio antes de la siguiente. Prompts para empezar:

- "Leé AGENTS.md y explicame cómo está armado el proyecto en 10 líneas."
- "Escribí más preguntas verificadas para `src/data.js` siguiendo el formato del banco."
- "Agregá un test para `buildJSONSystem` en `test/prompt.test.js`."
- "Revisá la accesibilidad de la paleta X en `public/js/theme.js` contra WCAG."

## Reparto sugerido para 4 personas

| Persona | Tarea |
|---|---|
| 1 | Frontend: SPA, vistas, tema y personalización |
| 2 | Backend y base de datos: API, sesiones, seguimiento |
| 3 | IA: prompt en `src/prompt.js`, pruebas de conversaciones |
| 4 | Contenido y calidad: preguntas y recursos en `src/data.js`, tests y documentación |

## Costos y seguridad

- Con una API en la nube, cada mensaje consume créditos: poné un tope de gasto mensual en la consola del servicio. Los mensajes de los alumnos pasan por ese servicio, así que conviene avisarles en la app.
- Las claves van solo en `.env` (ya está en `.gitignore`). Si se filtra, generá una nueva.
- El servidor limita los pedidos por minuto y corta la llamada si cerrás la pestaña.
- Lo que manda el navegador (mensajes, perfil) es dato no confiable: se valida en el servidor y nunca se
  trata como instrucciones.
- Los links de `src/data.js` conviene revisarlos cada tanto: pueden cambiar los precios o las condiciones.