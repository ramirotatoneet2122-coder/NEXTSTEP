@echo off
setlocal
cd /d "%~dp0"
title NEXTSTEP - Inicio
set "NXTBROWSER=msedge"

echo ==========================================
echo             NEXTSTEP
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  if exist "C:\Program Files\nodejs\node.exe" (
    set "PATH=C:\Program Files\nodejs;%PATH%"
  ) else (
    echo ERROR: No se encontro Node.js.
    echo Instala Node.js 22.5 o superior desde https://nodejs.org/
    echo Despues vuelve a ejecutar este archivo.
    pause
    exit /b 1
  )
)

node -e "const [a,b]=process.versions.node.split('.').map(Number); process.exit(a > 22 || (a === 22 && b >= 5) ? 0 : 1)"
if errorlevel 1 (
  echo ERROR: NEXTSTEP necesita Node.js 22.5 o superior.
  echo Tu version es:
  node -v
  pause
  exit /b 1
)

if not exist "node_modules\express\package.json" (
  echo Instalando dependencias. Necesitas conexion a Internet la primera vez...
  call npm install
  if errorlevel 1 (
    echo.
    echo ERROR: No se pudieron instalar las dependencias.
    pause
    exit /b 1
  )
)

echo Verificando si el puerto 3000 ya esta ocupado...
netstat -ano | findstr :3000 | findstr LISTENING >nul 2>nul
if not errorlevel 1 (
  echo Se detecto un servidor anterior en el puerto 3000.
  echo Voy a actualizarlo si pertenece a NEXTSTEP ^(Node ejecutando server.js^).
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ids = Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique; if (-not $ids) { exit 0 }; foreach ($id in $ids) { $p = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $id); if ($p.Name -ne 'node.exe' -or $p.CommandLine -notmatch 'server\.js') { Write-Host 'El puerto 3000 pertenece a otro programa. No lo cerre.'; exit 2 }; Stop-Process -Id $id -Force }; exit 0"
  if errorlevel 1 (
    echo.
    echo No pude reemplazar el proceso en el puerto 3000 porque no parece ser NEXTSTEP.
    echo Cierra la aplicacion que usa ese puerto y vuelve a ejecutar este archivo.
    pause
    exit /b 1
  )
  timeout /t 2 /nobreak >nul
)

echo Verificando Ollama (el cerebro de la IA)...
set OLLAMA_EXE=%LOCALAPPDATA%\Programs\Ollama\ollama.exe
curl.exe -s -o nul --max-time 2 http://localhost:11434/api/version
if errorlevel 1 (
  if exist "%OLLAMA_EXE%" (
    echo Ollama no esta corriendo. Prendiendolo...
    start "Ollama" /min "%OLLAMA_EXE%" serve
    echo Esperando que Ollama arranque...
    timeout /t 6 /nobreak >nul
  ) else (
    echo AVISO: Ollama no esta instalado. La app funciona pero la IA estara apagada.
    echo Instalalo desde https://ollama.com
  )
)

echo Abriendo NEXTSTEP en el navegador...
start "" cmd /c "timeout /t 5 /nobreak >nul & start %NXTBROWSER% http://localhost:3000 2>nul"
echo.
echo No cierres esta ventana mientras uses NEXTSTEP.
echo Para detener el servidor, cierra esta ventana.
echo.
call npm start
pause
