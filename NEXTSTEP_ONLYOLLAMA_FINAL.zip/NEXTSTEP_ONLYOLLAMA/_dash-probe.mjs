const base = 'http://localhost:3000/api';
// login con la cuenta creada por el usuario en la pantalla
const r = await fetch(`${base}/auth/login`, {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ username: 'juanqa1', password: 'prueba1234' }),
});
const j = await r.json();
const tok = j.token;
console.log('login:', r.status);
const padre = { Authorization: 'Bearer ' + tok };
const calls = [
  ['/dashboard', 'GET', null],
  ['/subjects', 'GET', null],
  ['/practice/next', 'GET', null],
  ['/practice/next?subject=practicas-libres&difficulty=1', 'GET', null],
  ['/stats', 'GET', null],
  ['/goals', 'GET', null],
  ['/resources', 'GET', null],
  ['/sessions', 'GET', null],
  ['/ai/status', 'GET', null],
];
for (const [path, method, body] of calls) {
  const res = await fetch(base + path, { method, headers: padre, body: body ? JSON.stringify(body) : undefined });
  const txt = (await res.text()).slice(0, 120);
  console.log(res.status, path.padEnd(60), txt);
}
