// Tests de buildSystem y buildJSONSystem (src/prompt.js), el "cerebro" del profesor.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildSystem, buildJSONSystem, GREETING, MODES } from '../src/prompt.js';

test('buildSystem con perfil plano (compatibilidad) no tira y guarda el perfil como dato', () => {
  const out = buildSystem({ objetivo: 'Aprender JavaScript' });
  assert.match(out, /Sos NEXTSTEP/);
  assert.match(out, /Aprender JavaScript/);
  assert.match(out, /PERFIL GUARDADO POR LA APP/);
});

test('buildSystem con contexto incluye modo, materia, prefs y datos adaptativos', () => {
  const out = buildSystem({
    perfil: { objetivo: 'Preparar un parcial', nivel: 'Intermedio' },
    prefs: { learning: { detail: 'detallado', difficulty: 'facil' }, teacher: { tone: 'motivador' } },
    mode: 'practica',
    subjectName: 'Matemática — objetivo: parcial',
    adaptive: { difficultyTopics: ['Fracciones'], lastAssessment: { pct: 62 } },
  });
  assert.match(out, /Modo práctica/);
  assert.match(out, /Materia\/tema en contexto: Matemática/);
  assert.match(out, /Explicaciones detalladas y completas/);
  assert.match(out, /Ejercicios fáciles, que generen confianza/);
  assert.match(out, /Tono motivador/);
  assert.match(out, /Le cuestan: Fracciones/);
  assert.match(out, /sacó 62%/);
});

test('buildSystem usa modo normal y defaults si no vienen datos', () => {
  const out = buildSystem({});
  assert.match(out, /Conversación general de estudio/);
  assert.match(out, /español rioplatense/);
  assert.match(out, /BANCO DE PREGUNTAS VERIFICADAS/);
  assert.match(out, /LISTA DE RECURSOS VERIFICADOS/);
  assert.match(out, /ETIQUETAS DE CONTROL/);
});

test('buildSystem incluye las etiquetas <opciones> y <perfil> para la pantalla', () => {
  const out = buildSystem({});
  assert.match(out, /<opciones>/);
  assert.match(out, /<perfil>/);
  assert.match(out, new RegExp(GREETING.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').slice(0, 30)));
});

test('buildSystem muestra el modo pedido aunque sea extraño del esquema', () => {
  for (const key of Object.keys(MODES)) {
    const out = buildSystem({ perfil: {}, mode: key });
    assert.match(out, new RegExp(MODES[key].slice(0, 20).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  }
});

test('buildJSONSystem exige JSON sin texto alrededor y prohíbe inventar links', () => {
  const out = buildJSONSystem('Armá un camino de 5 etapas para JavaScript.');
  assert.match(out, /EXCLUSIVAMENTE JSON válido/);
  assert.match(out, /No inventes links, cursos, certificaciones ni nombres de organizaciones/);
  assert.match(out, /Armá un camino de 5 etapas para JavaScript\./);
});