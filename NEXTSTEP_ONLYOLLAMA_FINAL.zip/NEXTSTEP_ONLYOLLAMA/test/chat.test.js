// Tests de las funciones puras de src/routes/chat.js (cleanMessages y mergePerfil).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';

// chat.js abre la base al importar: usamos una DB temporal para no tocar la real.
process.env.DB_FILE = path.join(os.tmpdir(), `nextstep-test-${process.pid}.db`);

const { cleanMessages, mergePerfil } = await import('../src/routes/chat.js');

test('cleanMessages filtra entradas inválidas', () => {
  const out = cleanMessages([
    null,
    { role: 'system', content: 'x' },
    { role: 'user', content: '   ' },
    { role: 'user', content: 'hola' },
    { role: 'assistant', content: '¿en qué te ayudo?' },
    { role: 'user', content: 'dale' },
  ]);
  assert.deepEqual(out, [
    { role: 'user', content: 'hola' },
    { role: 'assistant', content: '¿en qué te ayudo?' },
    { role: 'user', content: 'dale' },
  ]);
});

test('cleanMessages une mensajes seguidos del mismo rol', () => {
  const out = cleanMessages([
    { role: 'user', content: 'primero' },
    { role: 'user', content: 'segundo' },
    { role: 'assistant', content: 'respuesta' },
    { role: 'user', content: 'siguiente' },
  ]);
  assert.deepEqual(out, [
    { role: 'user', content: 'primero\n\nsegundo' },
    { role: 'assistant', content: 'respuesta' },
    { role: 'user', content: 'siguiente' },
  ]);
});

test('cleanMessages descarta asistentes iniciales', () => {
  const out = cleanMessages([
    { role: 'assistant', content: 'soy el saludo' },
    { role: 'user', content: 'hola' },
  ]);
  assert.deepEqual(out, [{ role: 'user', content: 'hola' }]);
});

test('cleanMessages devuelve null si no queda un usuario al final', () => {
  assert.equal(cleanMessages([]), null);
  assert.equal(cleanMessages([{ role: 'assistant', content: 'solo yo' }]), null);
});

test('cleanMessages limita cantidad de mensajes y largo de cada uno', () => {
  const muchos = Array.from({ length: 51 }, (_, i) => ({ role: i % 2 ? 'assistant' : 'user', content: `m${i}` }));
  const out = cleanMessages(muchos);
  assert.ok(out.length <= 40, 'no puede pasar de 40 mensajes');

  const largo = cleanMessages([{ role: 'user', content: 'a'.repeat(9000) }]);
  assert.equal(largo[0].content.length, 6000);
});

test('mergePerfil une el perfil guardado con el cambio parcial de la IA', () => {
  const base = { objetivo: 'Aprender Python', nivel: 'Iniciante', errores: ['a'] };
  const out = mergePerfil(base, { nivel: 'Intermedio', progreso: 40 });
  assert.deepEqual(out, { objetivo: 'Aprender Python', nivel: 'Intermedio', errores: ['a'], progreso: 40 });
});

test('mergePerfil no muta el perfil base', () => {
  const base = { objetivo: 'X' };
  mergePerfil(base, { nivel: 'Y' });
  assert.deepEqual(base, { objetivo: 'X' });
});

test('mergePerfil tolera actualización vacía o no objeto', () => {
  const base = { objetivo: 'X' };
  assert.deepEqual(mergePerfil(base, null), { objetivo: 'X' });
  assert.deepEqual(mergePerfil(base, 'texto'), { objetivo: 'X' });
  assert.deepEqual(mergePerfil({}, { a: 1 }), { a: 1 });
});