// Autenticación, perfil, preferencias y gestión de datos personales.
import { Router } from 'express';
import { getUser, getUserByUsername, createUser, getPreferences, setPreference, q, qa, run } from '../db.js';
import { hashPassword, verifyPassword, createToken, deleteToken, requireAuth, validateCredentials, purgeUserData, purgeTokens } from '../auth.js';
import { userStats, levelInfo, ACHIEVEMENTS } from '../xp.js';
import { LEARNING_DEFAULTS, TEACHER_DEFAULTS } from '../prompt.js';

export const authRouter = Router();

authRouter.post('/register', validateCredentials, (req, res) => {
  const { username, password, displayName } = req.body;
  if (getUserByUsername(username)) {
    return res.status(409).json({ error: 'Ese nombre de usuario ya está en uso. Elegí otro.' });
  }
  const user = createUser({
    username,
    passHash: hashPassword(password),
    displayName: String(displayName || username).slice(0, 40),
  });
  const token = createToken(user.id);
  res.status(201).json({ token, user: publicUser(user) });
});

authRouter.post('/login', (req, res) => {
  const username = String(req.body?.username || '').trim();
  const password = String(req.body?.password || '');
  if (!username || !password) return res.status(400).json({ error: 'Ingresá tu usuario y contraseña.' });
  const user = getUserByUsername(username);
  if (!user || !verifyPassword(password, user.pass_hash)) {
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos.' });
  }
  const token = createToken(user.id);
  res.json({ token, user: publicUser(user) });
});

authRouter.post('/logout', (req, res) => {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (token) deleteToken(token);
  res.json({ ok: true });
});

function publicUser(u) {
  return { id: u.id, username: u.username, displayName: u.display_name, language: u.language, createdAt: u.created_at };
}

function prefsPayload(userId) {
  const prefs = getPreferences(userId);
  return {
    user: publicUser(getUser(userId)),
    preferences: prefs,
    defaults: { learning: LEARNING_DEFAULTS, teacher: TEACHER_DEFAULTS },
    stats: userStats(userId),
    level: levelInfo(userStats(userId).xp),
  };
}

authRouter.get('/me', requireAuth, (req, res) => {
  res.json(prefsPayload(req.userId));
});

authRouter.put('/prefs/:field', requireAuth, (req, res) => {
  const field = req.params.field;
  if (!['theme', 'learning', 'teacher', 'ui'].includes(field)) {
    return res.status(400).json({ error: 'Preferencia inválida.' });
  }
  const value = req.body?.value;
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return res.status(400).json({ error: 'La preferencia tiene que ser un objeto.' });
  }
  const prefs = setPreference(req.userId, field, JSON.parse(JSON.stringify(value)));
  res.json({ ok: true, preferences: prefs });
});

authRouter.put('/profile', requireAuth, (req, res) => {
  const { displayName, language } = req.body || {};
  const user = getUser(req.userId);
  const name = typeof displayName === 'string' && displayName.trim()
    ? displayName.trim().slice(0, 40) : user.display_name;
  const lang = ['es', 'en', 'pt'].includes(language) ? language : user.language;
  run('UPDATE users SET display_name = ?, language = ? WHERE id = ?', name, lang, req.userId);
  res.json({ ok: true, user: publicUser(getUser(req.userId)) });
});

// Exportar los datos del usuario (privacidad: el alumno puede ver qué guardamos).
authRouter.get('/data', requireAuth, (req, res) => {
  const uid = req.userId;
  const dump = {
    user: publicUser(getUser(uid)),
    preferences: getPreferences(uid),
    subjects: qa('SELECT * FROM subjects WHERE user_id = ?', uid),
    goals: qa('SELECT * FROM goals WHERE user_id = ?', uid),
    conversations: qa('SELECT * FROM conversations WHERE user_id = ?', uid),
    paths: qa('SELECT * FROM paths WHERE user_id = ?', uid),
    assessments: qa('SELECT * FROM assessments WHERE user_id = ?', uid),
    resources: qa('SELECT * FROM resources WHERE user_id = ?', uid),
    achievements: qa('SELECT * FROM achievements WHERE user_id = ?', uid),
    xpEvents: qa('SELECT * FROM xp_events WHERE user_id = ?', uid),
    studySessions: qa('SELECT * FROM study_sessions WHERE user_id = ?', uid),
  };
  res.json(dump);
});

// Eliminar la cuenta y todos los datos.
authRouter.delete('/account', requireAuth, (req, res) => {
  purgeTokens(req.userId);
  purgeUserData(req.userId);
  res.json({ ok: true });
});

// Logros conocidos (catálogo) y obtenidos.
authRouter.get('/achievements', requireAuth, (req, res) => {
  const earned = qa('SELECT code, title, created_at FROM achievements WHERE user_id = ? ORDER BY created_at', req.userId);
  const catalog = Object.entries(ACHIEVEMENTS).map(([code, v]) => ({
    code, title: v.title, desc: v.desc,
    earned: earned.some(e => e.code === code),
    earnedAt: earned.find(e => e.code === code)?.created_at ?? null,
  }));
  res.json({ catalog });
});