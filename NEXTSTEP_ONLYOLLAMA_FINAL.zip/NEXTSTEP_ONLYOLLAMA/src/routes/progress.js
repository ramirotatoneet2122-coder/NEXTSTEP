// Dashboard y estadísticas agregadas con datos reales persistidos.
import { Router } from 'express';
import { run, q, qa, now } from '../db.js';
import { requireAuth } from '../auth.js';
import { userStats, levelInfo, RANKS, rankOf } from '../xp.js';
import { listSubjects, constancyStats, weekdaySeries, adaptiveContext } from '../domain.js';

export const progressRouter = Router();
progressRouter.use(requireAuth);

function greetingFor(name) {
  const h = new Date().getHours();
  const saludo = h < 12 ? 'Buenos días' : h < 19 ? 'Buenas tardes' : 'Buenas noches';
  return `${saludo}, ${name || 'estudiante'}`;
}

// Recomendaciones calculadas en el servidor con datos reales (sin IA: reglas claras y explicables).
export function computeRecommendations(userId) {
  const recs = [];
  const last = q('SELECT a.*, s.name AS subject_name FROM assessments a LEFT JOIN subjects s ON s.id = a.subject_id WHERE a.user_id = ? AND a.finished_at IS NOT NULL ORDER BY a.finished_at DESC LIMIT 1', userId);
  if (last && last.total) {
    const pct = Math.round(last.score / last.total * 100);
    if (pct < 50) recs.push({
      kind: 'reforzar', target: `evaluacion-${last.subject_id ?? ''}`,
      text: `En tu última evaluación de ${last.subject_name || 'esa materia'} sacaste ${pct}%. Conviene reforzar lo que falló antes de avanzar.`,
      action: 'Hacer una práctica de refuerzo', route: 'teacher',
    });
    else if (pct >= 80) recs.push({
      kind: 'avanzar', target: `materia-${last.subject_id ?? ''}`,
      text: `Tu último resultado fue muy bueno (${pct}%). Es buen momento para avanzar al siguiente tema de tu ruta.`,
      action: 'Continuar la ruta', route: 'paths',
    });
  }
  const hard = qa("SELECT t.name, s.name AS subject_name, s.id AS subject_id FROM topics t JOIN subjects s ON s.id = t.subject_id WHERE t.user_id = ? AND t.status = 'dificultad' ORDER BY t.updated_at DESC LIMIT 3", userId);
  hard.forEach(h => recs.push({
    kind: 'repaso', target: `materia-${h.subject_id}`,
    text: `Tenés dificultad registrada en "${h.name}" de ${h.subject_name}. Una sesión de repaso con el profesor puede destrabarla.`,
    action: 'Repasar con el profesor', route: 'teacher',
  }));
  const nextAct = q(`SELECT a.id, a.title, m.title AS module_title, p.id AS path_id FROM activities a JOIN modules m ON m.id = a.module_id JOIN paths p ON p.id = m.path_id WHERE a.user_id = ? AND a.status = 'pendiente' ORDER BY m.position, a.id LIMIT 1`, userId);
  if (nextAct) recs.push({
    kind: 'siguiente', target: `ruta-${nextAct.path_id}`,
    text: `Tu próxima actividad pendiente es "${nextAct.title}" (${nextAct.module_title}).`,
    action: 'Ver la ruta', route: 'paths', ref: nextAct.path_id,
  });
  const goals = qa("SELECT * FROM goals WHERE user_id = ? AND status = 'activo' AND deadline IS NOT NULL ORDER BY deadline LIMIT 1", userId);
  if (goals.length) {
    const days = Math.ceil((new Date(goals[0].deadline + 'T23:59:59') - new Date()) / 864e5);
    if (days <= 7 && days >= 0) recs.push({
      kind: 'plazo', target: `objetivo-${goals[0].id}`,
      text: `Tu objetivo "${goals[0].title}" vence en ${days === 0 ? 'menos de un día' : days + ' día(s)'}. Una buena planificación te ayuda a priorizar.`,
      action: 'Planificar', route: 'goals', ref: goals[0].id,
    });
  }
  const stats = userStats(userId);
  if (stats.streak === 0) recs.push({
    kind: 'constancia', target: null,
    text: 'Hoy todavía no registraste una sesión. Quince minutos alcanzan para mantener la constancia.',
    action: 'Registrar una sesión', route: 'dashboard',
  });
  if (!stats.subjects) recs.push({
    kind: 'empezar', target: null,
    text: 'Todavía no tenés materias. Contame qué querés aprender y arrancamos.',
    action: 'Elegir una materia', route: 'learning',
  });
  return recs.slice(0, 5);
}

progressRouter.get('/dashboard', (req, res) => {
  const uid = req.userId;
  const user = q('SELECT * FROM users WHERE id = ?', uid);
  const stats = userStats(uid);
  const level = levelInfo(stats.xp);
  const constancy = constancyStats(uid);
  const series = weekdaySeries(constancy.daysStudied);
  const subjects = listSubjects(uid).filter(s => s.status === 'active' || s.status === 'paused').slice(0, 4);
  const goals = qa('SELECT * FROM goals WHERE user_id = ? AND status = ? ORDER BY created_at DESC LIMIT 4', uid, 'activo').map(g => ({
    ...g,
    tasksDone: q('SELECT COUNT(*) AS c FROM tasks WHERE goal_id = ? AND done = 1', g.id).c,
    tasksTotal: q('SELECT COUNT(*) AS c FROM tasks WHERE goal_id = ?', g.id).c,
  }));
  const lastConv = q('SELECT id, title, mode, updated_at FROM conversations WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1', uid);
  const lastPath = q('SELECT * FROM paths WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1', uid);
  const recs = computeRecommendations(uid);
  // IA-contexto adaptativo para el saludo personalizado (sin llamar a la IA).
  const activitiesDone = stats.activities;
  res.json({
    greeting: greetingFor(user?.display_name),
    level, stats, constancy, weekSeries: series,
    subjects, goals, lastConversation: lastConv, lastPath,
    recommendations: recs,
    achievementsCount: q('SELECT COUNT(*) AS c FROM achievements WHERE user_id = ?', uid).c,
    activitiesDone,
    topicsCount: q('SELECT COUNT(*) AS c FROM topics WHERE user_id = ?', uid).c,
  });
});

progressRouter.get('/stats', (req, res) => {
  const uid = req.userId;
  const stats = userStats(uid);
  const level = levelInfo(stats.xp);
  const constancy = constancyStats(uid);
  const series = weekdaySeries(constancy.daysStudied);

  const subjects = listSubjects(uid).map(s => ({
    id: s.id, name: s.name, level: s.level, score: s.score, status: s.status,
    topics: q('SELECT COUNT(*) AS c FROM topics WHERE subject_id = ?', s.id).c,
    dominados: q("SELECT COUNT(*) AS c FROM topics WHERE subject_id = ? AND status = 'dominado'", s.id).c,
  }));

  const evals = qa(`SELECT a.kind, a.title, a.score, a.total, a.created_at, s.name AS subject_name, a.subject_id
    FROM assessments a LEFT JOIN subjects s ON s.id = a.subject_id
    WHERE a.user_id = ? AND a.finished_at IS NOT NULL ORDER BY a.created_at`, uid);

  const sessions = qa(`SELECT s.minutes, s.started_at, su.name AS subject_name FROM study_sessions s
    LEFT JOIN subjects su ON su.id = s.subject_id WHERE s.user_id = ? ORDER BY s.started_at DESC LIMIT 40`, uid);

  const strengths = qa(`SELECT t.name, s.name AS subject_name FROM topics t JOIN subjects s ON s.id = t.subject_id WHERE t.user_id = ? AND t.status = 'dominado'`, uid);
  const weaknesses = qa(`SELECT t.name, s.name AS subject_name FROM topics t JOIN subjects s ON s.id = t.subject_id WHERE t.user_id = ? AND t.status = 'dificultad'`, uid);

  const goals = qa('SELECT title, status, created_at FROM goals WHERE user_id = ? ORDER BY created_at', uid);
  const goalsDone = goals.filter(g => g.status === 'hecho').length;

  // Evolución del nivel general (XP acumulado por fecha).
  const xpByDay = qa("SELECT substr(created_at,1,10) AS d, SUM(amount) AS day FROM xp_events WHERE user_id = ? GROUP BY d ORDER BY d", uid);
  let acc = 0;
  const xpEvolution = xpByDay.map(x => {
    acc += x.day;
    return { day: x.d, xp: acc, level: levelInfo(acc).level };
  });

  // Actividades completadas por tipo.
  const actsKind = qa("SELECT kind, COUNT(*) AS c FROM activities WHERE user_id = ? AND status = 'completada' GROUP BY kind", uid);

  res.json({
    level, stats, weekSeries: series, subjects,
    assessments: evals.map(rowToJsonSafe),
    sessions: sessions.map(rowToJsonSafe),
    strengths, weaknesses,
    goals: { count: goals.length, done: goalsDone },
    xpEvolution,
    activitiesByKind: actsKind,
    adaptive: adaptiveContext(uid),
  });
});

function rowToJsonSafe(r) { return { ...r }; }

progressRouter.get('/stats/level-evolution', (req, res) => {
  const uid = req.userId;
  const xpByDay = qa("SELECT substr(created_at,1,10) AS d, SUM(amount) AS day FROM xp_events WHERE user_id = ? GROUP BY d ORDER BY d", uid);
  let acc = 0;
  res.json({ evolution: xpByDay.map(x => { acc += x.day; return { day: x.d, xp: acc, level: levelInfo(acc).level }; }) });
});