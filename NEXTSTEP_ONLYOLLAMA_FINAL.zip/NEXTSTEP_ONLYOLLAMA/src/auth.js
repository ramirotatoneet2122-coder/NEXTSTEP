// Autenticación: contraseñas con scrypt de node:crypto, sesiones con token.
import crypto from 'node:crypto';
import { q, qa, run, now } from './db.js';

const TOKEN_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 días

export function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(pw, salt, 64);
  return 'scrypt$' + salt.toString('hex') + '$' + key.toString('hex');
}

export function verifyPassword(pw, stored) {
  try {
    const [, saltHex, keyHex] = String(stored).split('$');
    if (!saltHex || !keyHex) return false;
    const salt = Buffer.from(saltHex, 'hex');
    const key = Buffer.from(keyHex, 'hex');
    const candidate = crypto.scryptSync(pw, salt, 64);
    return key.length === candidate.length && crypto.timingSafeEqual(key, candidate);
  } catch {
    return false;
  }
}

export function createToken(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  run('INSERT INTO auth_tokens (token, user_id, created_at, expires_at) VALUES (?,?,?,?)',
    token, userId, now(), new Date(Date.now() + TOKEN_TTL_MS).toISOString());
  return token;
}

export function userIdForToken(token) {
  if (!token || typeof token !== 'string') return null;
  const r = q('SELECT user_id, expires_at FROM auth_tokens WHERE token = ?', token);
  if (!r) return null;
  if (new Date(r.expires_at).getTime() < Date.now()) return null;
  return r.user_id;
}

export function deleteToken(token) {
  try { run('DELETE FROM auth_tokens WHERE token = ?', token); } catch { /* sin efecto */ }
}

export function deleteExpiredTokens() {
  run('DELETE FROM auth_tokens WHERE expires_at < ?', now());
}

// Middleware Express: valida el token y carga el usuario en req.user.
export function requireAuth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  const userId = token ? userIdForToken(token) : null;
  if (!userId) return res.status(401).json({ error: 'Tu sesión venció o no iniciaste sesión.' });
  req.userId = userId;
  req.token = token;
  next();
}

// Límites de la cuenta (personajes normales, esto es un proyecto educativo).
export function validateCredentials(req, res, next) {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || username.trim().length < 3 || username.trim().length > 30) {
    return res.status(400).json({ error: 'El nombre de usuario tiene que tener entre 3 y 30 caracteres.' });
  }
  if (typeof password !== 'string' || password.length < 6 || password.length > 100) {
    return res.status(400).json({ error: 'La contraseña tiene que tener entre 6 y 100 caracteres.' });
  }
  if (!/^[A-Za-z0-9_.-]+$/.test(username.trim())) {
    return res.status(400).json({ error: 'El nombre de usuario solo puede tener letras, números, puntos, guiones y guión bajo.' });
  }
  req.body.username = username.trim();
  next();
}

// Borra progreso académico del usuario (permite "eliminar mis datos").
export function purgeUserData(userId) {
  run('DELETE FROM messages WHERE conversation_id IN (SELECT id FROM conversations WHERE user_id = ?)', userId);
  run('DELETE FROM conversations WHERE user_id = ?', userId);
  run('DELETE FROM assessments WHERE user_id = ?', userId);
  run('DELETE FROM activities WHERE user_id = ?', userId);
  run('DELETE FROM modules WHERE user_id = ?', userId);
  run('DELETE FROM paths WHERE user_id = ?', userId);
  run('DELETE FROM topics WHERE user_id = ?', userId);
  run('DELETE FROM tasks WHERE user_id = ?', userId);
  run('DELETE FROM goals WHERE user_id = ?', userId);
  run('DELETE FROM resources WHERE user_id = ?', userId);
  run('DELETE FROM study_sessions WHERE user_id = ?', userId);
  run('DELETE FROM xp_events WHERE user_id = ?', userId);
  run('DELETE FROM achievements WHERE user_id = ?', userId);
  run('DELETE FROM subjects WHERE user_id = ?', userId);
  run('DELETE FROM users WHERE id = ?', userId);
}

export function purgeTokens(userId) {
  run('DELETE FROM auth_tokens WHERE user_id = ?', userId);
}