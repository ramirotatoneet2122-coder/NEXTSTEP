// Lógica de dominio compartida entre rutas, chat y generación IA.
import { q, qa } from './db.js';
import { RANKS, rankOf } from './data.js';
import { computeStreak } from './xp.js';

export const MODES = ['normal', 'concentracion', 'lectura', 'practica', 'evaluacion', 'planificacion', 'repaso'];
export const TOPIC_STATUS = { dominado: 90, aprendiendo: 60, dificultad: 25, pendiente: 0 };

// Avance de una materia basado en temas + evaluaciones (nunca solo tiempo de estudio).
export function subjectScore(subjectId) {
  const topics = qa('SELECT status FROM topics WHERE subject_id = ?', subjectId);
  const topScore = topics.length
    ? Math.round(topics.reduce((acc, t) => acc + (TOPIC_STATUS[t.status] ?? 0), 0) / topics.length)
    : 5;
  const evals = qa('SELECT score, total FROM assessments WHERE subject_id = ? AND finished_at IS NOT NULL', subjectId);
  const evalPct = evals.length
    ? Math.round(evals.reduce((a, e) => a + (e.total ? e.score / e.total : 0), 0) / evals.length * 100)
    : null;
  let score;
  if (evalPct === null) score = Math.round(10 + 0.85 * topScore);
  else score = Math.round(0.55 * evalPct + 0.45 * topScore);
  return { score: Math.max(0, Math.min(100, score)), topics: topScore, evals: evalPct, countEvals: evals.length };
}

export function loadSubjectSummary(row) {
  const sc = subjectScore(row.id);
  const topics = typeof row.topics_count === 'number'
    ? row.topics_count : q('SELECT COUNT(*) AS c FROM topics WHERE subject_id = ?', row.id).c;
  const open = q('SELECT COUNT(*) AS c FROM topics WHERE subject_id = ?', row.id).c;
  return {
    id: row.id,
    name: row.name,
    goal: row.goal,
    level: RANKS[rankOf(sc.score)],
    score: sc.score,
    status: row.status,
    topicsCount: topics,
    openTopics: open - q('SELECT COUNT(*) AS c FROM topics WHERE subject_id = ? AND status = ?', row.id, 'pendiente').c,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function listSubjects(userId) {
  const rows = qa('SELECT * FROM subjects WHERE user_id = ? ORDER BY created_at DESC', userId);
  return rows.map(loadSubjectSummary);
}

export function getSubject(userId, id) {
  const row = q('SELECT * FROM subjects WHERE id = ? AND user_id = ?', id, userId);
  if (!row) return null;
  return row;
}

// Busca en el banco verificado la materia que coincide con un nombre libre del alumno.
export function matchBankKey(name) {
  const n = String(name || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const aliases = {
    html: ['html'],
    js: ['javascript', 'js', 'scripts'],
    java: ['java'],
    python: ['python', 'py'],
    sql: ['sql', 'base de datos', 'bases de datos', 'database'],
    redes: ['redes', 'network', 'networking'],
    mate: ['matematica', 'matematicas', 'algebra', 'aritmetica', 'mate'],
    geografia: ['geografia'],
    historia: ['historia'],
    ciencia: ['ciencia', 'ciencias', 'naturales', 'biologia', 'fisica', 'quimica'],
    lengua: ['lengua', 'castellano', 'espanol', 'litreratura'],
    ingles: ['ingles', 'english', 'idioma'],
    git: ['git', 'github', 'control de versiones'],
  };
  for (const key of Object.keys(aliases)) {
    if (aliases[key].some(a => a && n.includes(a))) return key;
  }
  return null;
}

// ---- Contexto adaptativo para la IA (F): dificultades, errores, evaluaciones, pendientes. ----
export function adaptiveContext(userId, subjectId = null) {
  const out = {};
  const filter = subjectId ? ' AND subject_id = ?' : '';
  const params = subjectId ? [userId, subjectId] : [userId];

  const diff = qa(`SELECT t.name FROM topics t WHERE t.user_id = ?${filter.replace('subject_id', 't.subject_id')} AND t.status = 'dificultad' ORDER BY t.updated_at DESC LIMIT 6`, ...params);
  out.difficultyTopics = diff.map(r => r.name);

  const pending = qa(`SELECT t.name FROM topics t WHERE t.user_id = ?${filter.replace('subject_id', 't.subject_id')} AND t.status = 'aprendiendo' ORDER BY t.updated_at DESC LIMIT 4`, ...params);
  out.pendingReviews = pending.map(r => r.name).concat(diff.map(r => r.name)).slice(0, 6);

  const strengths = qa(`SELECT t.name FROM topics t WHERE t.user_id = ?${filter.replace('subject_id', 't.subject_id')} AND t.status = 'dominado' ORDER BY t.updated_at DESC LIMIT 4`, ...params);
  out.strengths = strengths.map(r => r.name);

  const last = qa(`SELECT title, score, total FROM assessments WHERE user_id = ?${filter} AND finished_at IS NOT NULL ORDER BY finished_at DESC LIMIT 1`, ...params)[0];
  if (last) out.lastAssessment = { title: last.title, pct: last.total ? Math.round(last.score / last.total * 100) : 0 };

  // Errores recientes desde el perfil de la última conversación activa.
  const conv = q('SELECT perfil_json FROM conversations WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1', userId);
  if (conv && conv.perfil_json) {
    try {
      const p = JSON.parse(conv.perfil_json);
      if (Array.isArray(p.errores) && p.errores.length) out.recentErrors = p.errores.slice(0, 5);
      if (p.objetivo) out.goal = p.objetivo;
    } catch { /* perfil corrupto: se ignora */ }
  }
  return out;
}

// Racha y tiempo de estudio (indicadores de constancia, NO de conocimiento).
export function constancyStats(userId) {
  const minutesToday = q('SELECT COALESCE(SUM(minutes),0) AS c FROM study_sessions WHERE user_id = ? AND date(started_at) = date(?)',
    userId, new Date().toISOString()).c || 0;
  const weekStart = new Date(Date.now() - 6 * 864e5).toISOString().slice(0, 10);
  const minutesWeek = q('SELECT COALESCE(SUM(minutes),0) AS c FROM study_sessions WHERE user_id = ? AND date(started_at) >= ?',
    userId, weekStart).c || 0;
  const daysStudied = qa('SELECT substr(started_at,1,10) AS d, SUM(minutes) AS total FROM study_sessions WHERE user_id = ? AND date(started_at) >= ? GROUP BY d',
    userId, weekStart).map(r => ({ date: r.d, minutes: r.total }));
  return { minutesToday, minutesWeek, daysStudied, streak: computeStreak(userId) };
}

// Serie de 7 días (terminando hoy) con los minutos de estudio de cada día.
export function weekdaySeries(daysStudied) {
  const today = new Date();
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate() - i));
    const key = d.toISOString().slice(0, 10);
    const found = daysStudied.find(x => x.date === key);
    days.push({ key, label: ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'][d.getUTCDay()], minutes: found ? found.minutes : 0 });
  }
  return days;
}

export function modeLabel(mode) {
  const labels = {
    normal: 'Conversación', concentracion: 'Concentración', lectura: 'Lectura',
    practica: 'Práctica', evaluacion: 'Evaluación', planificacion: 'Planificación', repaso: 'Repaso',
  };
  return labels[mode] || 'Conversación';
}