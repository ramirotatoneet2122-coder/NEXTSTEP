// Capa que separa a NEXTSTEP del proveedor de IA. Cambiando variables en .env se elige quién "piensa"
// por detrás; el profesor (prompt, datos y seguimiento) es siempre el del proyecto.
//
//   PROVIDER_ORDER=ollama,openai,anthropic  -> se prueba en orden y usa el primero que esté listo.
//   PROVIDER=ollama    -> Ollama en tu compu (OLLAMA_HOST, OLLAMA_MODEL), sin costo ni cuenta.
//   PROVIDER=openai    -> cualquier servidor compatible con la API de OpenAI (Groq, OpenRouter, etc.).
//   PROVIDER=anthropic -> API de Claude (necesita ANTHROPIC_API_KEY).
import Anthropic from '@anthropic-ai/sdk';
import { recordAiUsage } from './db.js';

// OJO: dotenv se carga en server.js, PERO los imports de módulos se ejecutan antes
// que el cuerpo de server.js. Por eso el .env NO está cargado al evaluar este módulo:
// leer process.env acá daría siempre los valores por defecto. Las funciones leen
// el .env en el momento de la llamada.
const maxTokensOf = () => Number(process.env.MAX_TOKENS) || 2000;
const aiTimeoutMsOf = () => Number(process.env.AI_TIMEOUT_MS) || 90_000;

// Lista ordenada de proveedores a probar (PROVIDER_ORDER), o el único (PROVIDER).
export function providerOrder() {
  const raw = String(process.env.PROVIDER_ORDER || '').trim();
  if (raw) {
    const order = raw
      .split(',')
      .map(s => s.trim().toLowerCase())
      .filter(s => ['ollama', 'openai', 'anthropic'].includes(s));
    if (order.length) return order;
  }
  const p = (process.env.PROVIDER || '').toLowerCase();
  if (['ollama', 'openai', 'anthropic'].includes(p)) return [p];
  // Por defecto: priorizar Ollama (local). Si no hay OLLAMA_MODEL configurado,
  // igual probamos ollama primero y mostrará el mensaje claro en /api/meta
  if (process.env.OLLAMA_MODEL || process.env.OLLAMA_HOST) return ['ollama'];
  // Último recurso: priorizar ollama
  return ['ollama'];
}

// ---- Utilidades Ollama ----
export const ollamaHost = () => {
  let h = (process.env.OLLAMA_HOST || 'http://localhost:11434').replace(/\/$/, '');
  if (!/\/v1$/.test(h)) h += '/v1';
  return h;
};
export const ollamaModel = () =>
  process.env.OLLAMA_MODEL || process.env.MODEL || 'qwen2.5:7b';
const openaiModel = () => process.env.MODEL || '';
const anthropicModel = () => process.env.MODEL || 'claude-sonnet-5-5';

export function providerModel(p) {
  return p === 'ollama' ? ollamaModel() : p === 'openai' ? openaiModel() : anthropicModel();
}

// Modelo de repuesto para Ollama si el principal no está descargado (404).
// Ejemplo: OLLAMA_MODEL=qwen2.5:7b + OLLAMA_FALLBACK_MODEL=qwen2.5:3b.
// Con el valor "none" el repuesto queda desactivado.
export const ollamaFallbackModel = () => {
  const v = (process.env.OLLAMA_FALLBACK_MODEL || '').trim();
  if (!v || /^(none|off|0|no)$/i.test(v)) return '';
  return v;
};

// ¿Está listo un proveedor? (sincronico: solo mira variables de entorno).
export function providerReady(p) {
  if (p === 'anthropic') return Boolean(process.env.ANTHROPIC_API_KEY);
  if (p === 'ollama') return Boolean(ollamaModel());
  return Boolean(process.env.OPENAI_BASE_URL && openaiModel());
}

export function providerName(p) {
  return { ollama: 'Ollama (en tu compu)', openai: 'Servidor OpenAI-compatible', anthropic: 'API de Claude' }[p] || p;
}

// Devuelve el proveedor activo (el primero listo del orden) con su info.
export function providerInfo() {
  const order = providerOrder();
  const active = order.find(providerReady) || order[0] || 'anthropic';
  return {
    provider: active,
    order,
    model: providerModel(active) || null,
    ready: providerReady(active),
    base: active === 'anthropic' ? 'https://api.anthropic.com'
      : active === 'ollama' ? ollamaHost().replace(/\/v1$/, '')
      : (process.env.OPENAI_BASE_URL || ''),
  };
}

export function missingConfigMessage(p = providerInfo().provider) {
  if (p === 'anthropic') return 'Falta la ANTHROPIC_API_KEY en el archivo .env del servidor.';
  if (p === 'ollama') return 'Falta OLLAMA_MODEL en el archivo .env del servidor (por ejemplo OLLAMA_MODEL=qwen2.5:7b).';
  return 'Falta OPENAI_BASE_URL o MODEL en el archivo .env del servidor.';
}

export function aiConfigured() { return providerInfo().ready; }

// ¿El proveedor activo corre en esta compu (CPU/local)? Sirve para usar prompts compactos.
export function isLocalProvider() {
  const p = providerInfo().provider;
  if (p === 'ollama') return true;
  if (p === 'openai') return /localhost|127\.0\.0\.1/.test(process.env.OPENAI_BASE_URL || '');
  return false;
}

// Lista de modelos instalados en Ollama (para Configuración → IA).
export async function listOllamaModels() {
  const base = ollamaHost();
  const r = await fetch(`${base}/models`, { signal: AbortSignal.timeout(4000) });
  if (!r.ok) throw new Error(`Ollama respondió ${r.status}`);
  const j = await r.json();
  return (j.data || []).map(m => m.id).filter(Boolean);
}

const passwordOf = () => process.env.OPENAI_API_KEY || null;

// ---------------- Errores amigables (en español) ----------------
// Une todo el texto del error y sus causas anidadas (Node anida ECONNREFUSED en
// e.cause, que además puede ser un AggregateError con .errors).
function errorChainText(e) {
  const seen = new Set();
  const parts = [];
  let cur = e;
  while (cur && typeof cur === 'object' && !seen.has(cur)) {
    seen.add(cur);
    if (cur.code) parts.push(String(cur.code));
    if (typeof cur.message === 'string') parts.push(cur.message);
    if (typeof cur.body === 'string') parts.push(cur.body);
    if (Array.isArray(cur.errors)) for (const inner of cur.errors) parts.push(errorChainText(inner));
    cur = cur.cause;
  }
  return parts.join(' | ');
}

export function friendlyAiError(e, provider = providerInfo().provider) {
  if (e?.name === 'TimeoutError' || e?.name === 'AbortError') {
    return 'La IA tardó demasiado en responder. Probá de nuevo en un momento.';
  }
  const chain = errorChainText(e);
  if (e?.code === 'ECONNREFUSED' || /fetch failed|ECONNREFUSED|ENOTFOUND|EHOSTUNREACH/i.test(chain)) {
    if (provider === 'ollama') return 'No pudimos conectar con Ollama. Abrí la aplicación de Ollama en la compu del servidor (o corré "ollama serve") y probá de nuevo.';
    return 'No pudimos conectar con el servidor de IA. Probá de nuevo en un rato.';
  }
  const s = e?.status;
  const body = String(e?.body || e?.message || '');
  if (provider === 'ollama' && (s === 404 || /not found|no existe|no encontr/i.test(body))) {
    return `El modelo de Ollama no está descargado. En la compu del servidor corré: ollama pull ${providerModel('ollama')}`;
  }
  if (s === 401 || s === 403) return 'La clave del servicio de IA no es válida.';
  if (s === 429) return 'La IA tiene muchas consultas ahora. Probá de nuevo en un rato.';
  if (s === 500 || s === 502 || s === 503 || s === 529) return 'La IA está saturada o con un error temporal. Probá de nuevo en un momento.';
  return 'No se pudo usar la IA ahora.';
}

function withSignal(signal, abortTimeout) {
  if (signal) return signal;
  const ctl = new AbortController();
  abortTimeout.t = setTimeout(() => ctl.abort(), aiTimeoutMsOf());
  abortTimeout.clear = () => clearTimeout(abortTimeout.t);
  return ctl.signal;
}

// ---------------- Streaming (para el chat) ----------------
async function viaAnthropicStream({ system, messages, signal, onText, abortTimeout }) {
  const client = new Anthropic();
  const stream = client.messages.stream({ model: anthropicModel(), max_tokens: maxTokensOf(), system, messages }, { signal: withSignal(signal, abortTimeout) });
  stream.on('text', onText);
  const final = await stream.finalMessage();
  recordAiUsage('anthropic', anthropicModel(), final?.usage?.input_tokens || 0, final?.usage?.output_tokens || 0);
}

// Llama al servidor OpenAI-compatible (Ollama, Groq, etc.) en modo streaming.
async function viaOpenAIStream({ system, messages, signal, onText, abortTimeout, _model }, pn) {
  const base = pn === 'ollama' ? ollamaHost() : process.env.OPENAI_BASE_URL.replace(/\/$/, '');
  const model = _model || (pn === 'ollama' ? ollamaModel() : openaiModel());
  const headers = { 'Content-Type': 'application/json' };
  if (passwordOf()) headers.Authorization = `Bearer ${passwordOf()}`;
  const r = await fetch(`${base}/chat/completions`, {
    method: 'POST',
    headers,
    signal: withSignal(signal, abortTimeout),
    body: JSON.stringify({ model, stream: true, max_tokens: maxTokensOf(), stream_options: pn === 'ollama' ? { include_usage: true } : undefined, messages: [{ role: 'system', content: system }, ...messages] }),
  });
  if (!r.ok) {
    let body = '';
    try { body = (await r.json())?.error?.message || ''; } catch { /* sin cuerpo */ }
    // Si el modelo principal de Ollama no está descargado, probamos el de repuesto.
    if (pn === 'ollama' && r.status === 404 && !_model && ollamaFallbackModel() && ollamaFallbackModel() !== model) {
      return viaOpenAIStream({ system, messages, signal, onText, abortTimeout, _model: ollamaFallbackModel() }, pn);
    }
    const err = new Error(`El servidor de IA respondió ${r.status}`);
    err.status = r.status;
    err.body = body;
    throw err;
  }
  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let buf = '', usage = null;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line.startsWith('data:')) continue;
      const data = line.slice(5).trim();
      if (data === '[DONE]') continue;
      let j = null;
      try { j = JSON.parse(data); } catch { continue; }
      const t = j.choices?.[0]?.delta?.content;
      if (t) onText(t);
      if (j.usage) usage = j.usage;
    }
  }
  if (usage) recordAiUsage(pn, model, usage.prompt_tokens || 0, usage.completion_tokens || 0);
}

export function streamChat(opts) {
  const { provider } = providerInfo();
  const abortTimeout = {};
  const pass = { ...opts, abortTimeout };
  const run = provider === 'anthropic' ? viaAnthropicStream : viaOpenAIStream;
  const finish = () => abortTimeout.clear && abortTimeout.clear();
  return run(pass, provider).finally(finish);
}

// ---------------- Completar texto completo (sin streaming) ----------------
async function viaAnthropic({ system, messages, signal, abortTimeout }) {
  const client = new Anthropic();
  const r = await client.messages.create({ model: anthropicModel(), max_tokens: maxTokensOf(), system, messages }, { signal: withSignal(signal, abortTimeout) });
  recordAiUsage('anthropic', anthropicModel(), r?.usage?.input_tokens || 0, r?.usage?.output_tokens || 0);
  return r.content.filter(b => b.type === 'text').map(b => b.text).join('');
}

async function viaOpenAI({ system, messages, signal, abortTimeout, response_format, _model }, pn) {
  const base = pn === 'ollama' ? ollamaHost() : process.env.OPENAI_BASE_URL.replace(/\/$/, '');
  const model = _model || (pn === 'ollama' ? ollamaModel() : openaiModel());
  // En generaciones con IA local (CPU) limito el máximo de salida: 2000 tokens a
  // ~2,5 tokens por segundo pueden ser 13 minutos; con JSON estricto alcanza con menos.
  const localCaps = pn === 'ollama';

  const headers = { 'Content-Type': 'application/json' };
  if (passwordOf()) headers.Authorization = `Bearer ${passwordOf()}`;
  const r = await fetch(`${base}/chat/completions`, {
    method: 'POST',
    headers,
    signal: withSignal(signal, abortTimeout),
    body: JSON.stringify({ model, stream: false, max_tokens: localCaps ? Math.min(maxTokensOf(), 1024) : maxTokensOf(), response_format: response_format, messages: [{ role: 'system', content: system }, ...messages] }),
  });
  if (!r.ok) {
    let body = '';
    try { body = JSON.stringify((await r.json())) || ''; } catch { /* sin cuerpo */ }
    // Si el modelo principal de Ollama no está descargado, probamos el de repuesto.
    if (pn === 'ollama' && r.status === 404 && !_model && ollamaFallbackModel() && ollamaFallbackModel() !== model) {
      return viaOpenAI({ system, messages, signal, abortTimeout, response_format, _model: ollamaFallbackModel() }, pn);
    }
    const err = new Error(`El servidor de IA respondió ${r.status}`);
    err.status = r.status;
    err.body = body;
    throw err;
  }
  const j = await r.json();
  if (j.usage) recordAiUsage(pn, model, j.usage.prompt_tokens || 0, j.usage.completion_tokens || 0);
  return j.choices?.[0]?.message?.content ?? '';
}

// Devuelve texto completo del proveedor activo.
export async function complete({ system, messages, signal, jsonMode }) {
  if (!aiConfigured()) {
    const err = new Error('AI_NOT_CONFIGURED');
    throw err;
  }
  const { provider } = providerInfo();
  const abortTimeout = {};
  const run = provider === 'anthropic' ? viaAnthropic : viaOpenAI;
  try {
    // El modo JSON garantizado solo lo soporta Ollama (response_format);
    // en otras APIs se confía en el prompt + reintentos de completeJSON.
    const force = provider === 'ollama' && jsonMode ? { response_format: { type: 'json_object' } } : {};
    return await run({ system, messages, signal, abortTimeout, ...force }, provider);
  } finally {
    abortTimeout.clear && abortTimeout.clear();
  }
}

// Pide a la IA un JSON válido y lo devuelve ya parseado. Si el modelo (sobre todo
// uno local chico) contesta con texto de más o JSON cortado, reintenta hasta 2 veces.
export async function completeJSON({ system, messages, signal }) {
  if (!aiConfigured()) {
    const err = new Error('AI_NOT_CONFIGURED');
    throw err;
  }
  const convo = [...messages];
  let lastText = '';
  for (let intento = 0; intento < 3; intento++) {
    const txt = await complete({ system, messages: convo, signal, jsonMode: true });
    lastText = txt;
    const parsed = extractJSON(txt);
    if (parsed && typeof parsed === 'object') return parsed;
    // No fue JSON: pedir de nuevo con un recordatorio corto y explícito.
    convo.push({ role: 'assistant', content: String(txt).slice(0, 400) || '(respuesta inválida)' });
    convo.push({ role: 'user', content: 'Tu respuesta anterior no sirvió porque no era JSON puro. Respondé ahora SOLO el objeto JSON, empezando por { y terminando con }, sin explicaciones antes ni después.' });
  }
  // Último intento de rescate: si el JSON viene cortado, se arregla la cola en extractJSON.
  return extractJSON(lastText);
}

export function extractJSON(txt) {
  const s = String(txt ?? '');
  const t = s.trim().replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '');
  try { return JSON.parse(t); } catch { /* sigue */ }
  const start = t.indexOf('{');
  const arr = t.indexOf('[');
  let from = -1;
  if (start === -1 && arr === -1) return null;
  if (start === -1) from = arr;
  else if (arr === -1) from = start;
  else from = Math.min(start, arr);
  const open = t[from], close = open === '{' ? '}' : ']';
  let depth = 0, inStr = false, esc = false;
  for (let i = from; i < t.length; i++) {
    const c = t[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') inStr = true;
    else if (c === open) depth++;
    else if (c === close) {
      depth--;
      if (depth === 0) {
        try { return JSON.parse(t.slice(from, i + 1)); } catch { return null; }
      }
    }
  }
  // JSON cortado (el modelo se quedó sin tokens): cortar de a pedazos hasta que cierre.
  let cut = Math.min(t.length, 4000);
  while (cut > 100) {
    const tail = t.slice(from, cut).replace(/,\s*$/, '') + (open === '{' ? '}' : ']');
    try { const j = JSON.parse(tail); if (j && typeof j === 'object') return j; } catch { /* probar más corto */ }
    const lastComma = t.slice(from, cut).lastIndexOf(',');
    if (lastComma <= 0) break;
    cut = from + lastComma;
  }
  return null;
}

// ---------------- Cierre de sesión de streaming limpio ----------------
// Nota: streamChat limpia el timeout con finally; el chat usa su propio AbortSignal.
export const _llmTests = { providerReady, providerModel };
