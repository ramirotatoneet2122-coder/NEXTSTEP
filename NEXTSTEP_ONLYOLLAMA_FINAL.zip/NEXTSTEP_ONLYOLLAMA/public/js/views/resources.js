/* NEXTSTEP — Recursos: recomendados (solo desde el banco verificado) y guardados por el alumno. */
import { api } from '../api.js';
import * as store from '../store.js';
import { el, svgIc, emptyState, modal, toast, fmtDate } from '../ui.js';

const KIND_LABEL = { curso: 'Curso', documentacion: 'Documentación', tutorial: 'Tutorial', video: 'Video', proyecto: 'Proyecto', otro: 'Otro' };

export function resourcesView() {
  const root = el('div', { class: 'stack' });
  root.append(el('div', { class: 'skeleton', style: 'height:120px;border-radius:14px' }));
  load(root);
  return root;
}

async function load(root) {
  root.innerHTML = '';
  const head = el('div', { class: 'view-head flex wrap' });
  head.append(el('div', { class: 'grow' }, el('h1', { text: 'Recursos' }),
    el('p', { text: 'Las recomendaciones salen de una lista verificada por el proyecto: nunca son links inventados. También podés guardar los tuyos.' })));
  head.append(el('button', { class: 'btn ghost', onclick: openAdd }, svgIc('plus', 18), 'Guardar recurso'));
  root.append(head);

  try {
    const [rec, mine] = await Promise.all([api('/resources/recommended').catch(() => null), api('/resources').catch(() => null)]);
    if (rec && rec.recommendations && rec.recommendations.length) {
      const card = el('div', { class: 'card' });
      card.append(el('div', { class: 'card-title', style: 'margin-bottom:6px' }, svgIc('sparkles', 18), 'Recomendados para vos'));
      card.append(el('p', { class: 'sub', style: 'margin-bottom:12px' }, 'Basados en tus materias activas y objetivos. Los enlaces apuntan a la lista verificada del proyecto.'));
      for (const r of rec.recommendations) {
        card.append(el('div', { style: 'padding:12px 0;border-top:1px dashed var(--line)' },
          el('div', { class: 'flex' },
            el('div', { class: 'grow' },
              el('a', { href: r.url, target: '_blank', rel: 'noopener noreferrer', style: 'font-weight:700' }, r.title),
              el('p', { class: 'meta', text: `${r.org} · ${KIND_LABEL[r.kind] || r.kind}${r.free ? ' · gratis' : ''}` })),
            el('span', { class: 'tag' }, r.subjectName || (r.wouldHelp && r.wouldHelp[0]) || '') ),
          r.wouldHelp && r.wouldHelp.length ? el('p', { class: 'muted small', style: 'margin-top:6px' }, 'Te sirve para: ' + r.wouldHelp.join(', ')) : null,
          el('p', { class: 'muted small' }, `${r.effort ? 'Esfuerzo: ' + r.effort + ' · ' : ''}Rango sugerido: ${r.min || 'varía'}. Confirmá precio y condiciones en el sitio.`)));
      }
      root.append(card);
    }

    const mineCard = el('div', { class: 'card' });
    mineCard.append(el('div', { class: 'card-title', style: 'margin-bottom:8px' }, svgIc('book', 18), 'Mis recursos'));
    if (!mine || !mine.resources || !mine.resources.length) {
      mineCard.append(el('p', { class: 'muted small' }, 'Todavía no guardaste recursos propios.'));
    } else {
      for (const r of mine.resources) {
        mineCard.append(el('div', { class: 'li' },
          el('span', { class: 'ic', html: svgIc('link', 19) }),
          el('div', { class: 'grow' },
            r.url ? el('a', { href: r.url, target: '_blank', rel: 'noopener noreferrer' }, r.title) : el('p', { style: 'font-weight:600' }, r.title),
            el('p', { class: 'meta' }, `${KIND_LABEL[r.kind] || r.kind}${r.subject_name ? ' · ' + r.subject_name : ''} · ${fmtDate(r.created_at)}`),
            r.notes ? el('p', { class: 'muted small', text: r.notes }) : null),
          el('button', { class: 'icon-btn danger', title: 'Quitar', onclick: async () => {
            if (!confirm('¿Quitar este recurso?')) return;
            try { await api(`/resources/${r.id}`, { method: 'DELETE' }); load(root); } catch (e) { toast((e && e.message) || 'Error.', 'err'); }
          }, html: svgIc('trash', 17) })));
      }
    }
    root.append(mineCard);
  } catch (e) {
    root.append(emptyState((e && e.message) || 'No se pudieron cargar los recursos.', 'warn'));
  }
}

function openAdd() {
  const title = el('input', { class: 'input', placeholder: 'Título del recurso' });
  const url = el('input', { class: 'input', placeholder: 'URL (ej: developer.mozilla.org/…)' });
  const kind = el('select', { class: 'input' }, ...Object.keys(KIND_LABEL).map(k => el('option', { value: k }, KIND_LABEL[k])));
  const notes = el('textarea', { class: 'input', placeholder: 'Notas (opcional)' });
  const subjSel = el('select', { class: 'input' }, el('option', { value: '' }, 'Sin materia'));
  api('/subjects').then(r => { for (const su of r.subjects) subjSel.append(el('option', { value: su.id }, su.name)); }).catch(() => {});
  const wrap = el('div', { class: 'stack' },
    el('div', { class: 'field' }, el('label', { text: 'Título' }), title),
    el('div', { class: 'field' }, el('label', { text: 'URL' }), url),
    el('div', { class: 'field' }, el('label', { text: 'Tipo' }), kind),
    el('div', { class: 'field' }, el('label', { text: 'Materia (opcional)' }), subjSel),
    el('div', { class: 'field' }, el('label', { text: 'Notas' }), notes));
  let close = () => {};
  close = modal({
    title: 'Guardar recurso',
    body: wrap,
    footer: [
      el('button', { class: 'btn ghost', onclick: close }, 'Cancelar'),
      el('button', { class: 'btn', onclick: async (e) => {
        if (!title.value.trim()) return toast('Ingresá el título.', 'err');
        const b = e.target; b.disabled = true;
        try {
          await api('/resources', { method: 'POST', body: { title: title.value.trim(), url: url.value.trim(), kind: kind.value, notes: notes.value.trim(), subject_id: subjSel.value ? Number(subjSel.value) : null } });
          close();
          toast('Recurso guardado', 'ok');
          location.hash = '/resources';
        } catch (err) { toast((err && err.message) || 'No se pudo guardar.', 'err'); }
        finally { b.disabled = false; }
      } }, 'Guardar'),
    ],
  });
}