/* NEXTSTEP — vista de acceso: ingreso y registro. */
import * as store from '../store.js';
import { el } from '../ui.js';


export function authView({ tab = 'login', fieldError = '' } = {}) {
  let mode = tab;

  const card = el('div', { class: 'auth-card', role: 'main' });
  card.append(el('div', { class: 'brand' },
    el('svg', { viewBox: '0 0 32 32', fill: 'none', 'aria-hidden': 'true', style: 'width:34px;height:34px' },
      el('circle', { cx: 16, cy: 16, r: 14, stroke: 'var(--accent)', 'stroke-width': 2.5, fill: 'none' }),
      el('path', { d: 'M16 6l5 12-5-2-5 2 5-12z', fill: 'var(--accent)' }),
    ),
    el('span', { text: 'NEXTSTEP' }),
  ));
  card.append(el('p', { class: 'tagline', text: 'Tu profesor particular con IA. Aprendé a tu ritmo, con seguimiento real.' }));

  const tabs = el('div', { class: 'auth-tabs' });
  const mkTab = (id, label) => el('button', {
    class: mode === id ? 'on' : '',
    text: label,
    onclick: () => { mode = id; renderTabs(); formArea.innerHTML = ''; formArea.append(renderForm(mode)); },
  });
  const tabLogin = mkTab('login', 'Ingresar');
  const tabRegister = mkTab('register', 'Crear cuenta');
  tabs.append(tabLogin, tabRegister);
  card.append(tabs);

  function renderTabs() { tabLogin.classList.toggle('on', mode === 'login'); tabRegister.classList.toggle('on', mode === 'register'); }

  const formArea = el('div');
  card.append(formArea);

  const errorBox = el('div', { class: 'field', role: 'alert' });
  function setError(msg) {
    errorBox.innerHTML = '';
    if (!msg) { errorBox.hidden = true; return; }
    errorBox.hidden = false;
    errorBox.append(el('p', { class: 'muted small', style: 'color:var(--danger);font-weight:600' }, msg));
  }

  function renderForm(m) {
    setError(fieldError || '');
    const form = el('form', { novalidate: true, onsubmit: async e => {
      e.preventDefault();
      const btn = form.querySelector('button[type=submit]');
      btn.disabled = true;
      btn.textContent = 'Un momento…';
      try {
        try { localStorage.removeItem('ns_onboarded'); } catch { /* noop */ }
        if (m === 'login') {
          await store.login(username.value.trim(), password.value);
        } else {
          await store.register(username.value.trim(), password.value, displayName.value.trim());
        }
        // La API confirmó el login y el token ya quedó persistido. Recarga
        // la SPA en la ruta protegida para reconstruir el estado desde sesión.
        location.hash = '#/dashboard';
        location.reload();
      } catch (err) {
        setError((err && err.message) || 'No se pudo conectar. Probá de nuevo.');
      } finally {
        btn.disabled = false;
        btn.textContent = m === 'login' ? 'Entrar' : 'Crear cuenta';
      }
    } });

    const username = el('input', { class: 'input', autocomplete: 'username', placeholder: 'Nombre de usuario', required: true });
    const password = el('input', { class: 'input', type: 'password', autocomplete: m === 'login' ? 'current-password' : 'new-password', placeholder: 'Contraseña (mínimo 6 caracteres)', required: true });
    const displayName = el('input', { class: 'input', autocomplete: 'name', placeholder: 'Cómo querés que te diga (opcional)' });

    form.append(
      el('div', { class: 'field' }, el('label', { text: 'Usuario' }), username),
      el('div', { class: 'field' }, el('label', { text: 'Contraseña' }), password),
    );
    // No pasar null directo a .append: el append nativo del navegador lo convierte en texto "null".
    if (m === 'register') {
      form.append(
        el('div', { class: 'field' }, el('label', { text: 'Nombre visible' }), displayName,
          el('span', { class: 'hint', text: 'Lo usamos para saludarte. Lo podés cambiar después.' })),
      );
    }
    form.append(
      errorBox,
      el('button', { class: 'btn block', type: 'submit' }, m === 'login' ? 'Entrar' : 'Crear cuenta'),
      el('p', { class: 'muted small center', style: 'margin-top:14px;line-height:1.6' }, m === 'login'
        ? '¿No tenés cuenta? Tocá «Crear cuenta» arriba. Tus datos quedan guardados en el servidor del grupo, nunca en el navegador.'
        : 'Al registrarte creás tu propio seguimiento: materias, rutas, evaluaciones y progreso. Cada alumno ve solo lo suyo.'),
    );
    return form;
  }

  formArea.append(renderForm(mode));
  return card;
}