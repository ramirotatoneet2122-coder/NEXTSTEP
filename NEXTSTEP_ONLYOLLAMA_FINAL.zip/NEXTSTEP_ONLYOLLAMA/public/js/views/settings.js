/* NEXTSTEP — Configuración: tema visual (10 paletas + personalización), "Mi forma de
   aprender", modo del profesor y privacidad. Las preferencias se guardan por usuario
   (servidor) y se cachean en el navegador; las de aprendizaje inciden en el prompt de la IA. */
import { api } from '../api.js';
import * as store from '../store.js';
import { el, svgIc, modal, toast } from '../ui.js';
import {
  PALETTE_LIST, THEME_DEFAULTS, applyTheme, checkAccessibility,
  contrastRatio, miniPreview, effectiveMode,
} from '../theme.js';

const L_OPTS = {
  detail: { label: 'Qué tan completa es la explicación', options: [['breve', 'Breve y al grano'], ['detallado', 'Detallada y completa']] },
  language: { label: 'Lenguaje de las explicaciones', options: [['sencillo', 'Sencillo y cotidiano'], ['tecnico', 'Permitís terminología técnica']] },
  examples: { label: 'Ejemplos y aplicaciones', options: [['practico', 'Prácticos y reales'], ['teorico', 'Más conceptos y razonamiento']] },
  overview: { label: 'Cómo arrancás un tema nuevo', options: [['pasos', 'Paso a paso, de lo concreto a lo general'], ['vision', 'Con la visión general primero']] },
  difficulty: { label: 'Dificultad de los ejercicios', options: [['facil', 'Fáciles, que generen confianza'], ['intermedio', 'Intermedia'], ['avanzado', 'Exigentes y desafiantes']] },
  balance: { label: 'Equilibrio en cada sesión', options: [['practica', 'Más práctica'], ['explicacion', 'Más explicación']] },
  hints: { label: 'Cuando te equivocás', options: [['progresivas', 'Pistas de a poco'], ['directas', 'Corrección directa bien explicada']] },
  sessions: { label: 'Ritmo de las sesiones', options: [['cortas', 'Sesiones cortas y enfocadas'], ['prolongadas', 'Sesiones largas y profundas']] },
};
const L_FORMATS = [['preguntas', 'Preguntas y autoevaluación'], ['ejemplos', 'Ejemplos trabajados'], ['esquemas', 'Esquemas y mapas'], ['resumenes', 'Resúmenes'], ['problemas', 'Problemas prácticos']];
const T_OPTS = {
  explanationLevel: { label: 'Nivel de explicación', options: [['basica', 'Básico: desde lo esencial'], ['media', 'Intermedio'], ['avanzada', 'Avanzado: a fondo']] },
  pace: { label: 'Ritmo de avance', options: [['tranquilo', 'Tranquilo'], ['equilibrado', 'Equilibrado'], ['intensivo', 'Intensivo']] },
  teaching: { label: 'Cómo enseñar', options: [['ejemplos', 'Con más ejemplos'], ['teoria', 'Con más teoría'], ['ejercicios', 'Con más ejercicios'], ['equilibrada', 'Equilibrado']] },
  correction: { label: 'Corrección de errores', options: [['pistas', 'Pistas graduales primero'], ['completa', 'Explicar el error completo']] },
  autonomy: { label: 'Cuánta autonomía te da', options: [['guiado', 'Guiado paso a paso'], ['autonomia', 'Que resuelvas solo']] },
  goal: { label: 'Tu objetivo principal', options: [['comprender', 'Comprender a fondo'], ['aprobar', 'Aprobar un examen'], ['habilidad', 'Aprender una habilidad práctica'], ['proyecto', 'Completar un proyecto']] },
  tone: { label: 'Tono', options: [['neutral', 'Neutral'], ['cercano', 'Cercano'], ['motivador', 'Motivador']] },
  language: { label: 'Idioma', options: [['es', 'Español rioplatense'], ['en', 'Inglés'], ['pt', 'Portugués']] },
};

export function settingsView() {
  const root = el('div', { class: 'stack' });
  const s = store.get();
  const head = el('div', { class: 'view-head' });
  head.append(el('h1', { text: 'Configuración' }));
  head.append(el('p', { text: 'Todo se guarda en tu cuenta y se aplica solo en tus dispositivos.' }));
  root.append(head);
  root.append(aiSection());
  root.append(themeSection(s));
  root.append(learningSection(s));
  root.append(teacherSection(s));
  root.append(profileSection(s));
  root.append(el('div', { class: 'card', style: 'border-left:4px solid var(--warn)' },
    el('p', { style: 'font-weight:700;margin-bottom:6px' }, 'Restablecer configuración'),
    el('p', { class: 'muted small', style: 'margin-bottom:12px' }, 'Vuelve el tema y las preferencias de aprendizaje y de profesor a los valores iniciales. No borra tu progreso.'),
    el('button', { class: 'btn ghost', onclick: async () => {
      const d = store.get().defaults || {};
      await store.savePrefField('theme', JSON.parse(JSON.stringify(THEME_DEFAULTS)));
      await store.savePrefField('learning', JSON.parse(JSON.stringify(d.learning || {})));
      await store.savePrefField('teacher', JSON.parse(JSON.stringify(d.teacher || {})));
      toast('Configuración restablecida', 'ok');
    } }, 'Restablecer a valores iniciales')));
  return root;
}

/* ================= Inteligencia artificial (proveedor y uso de tokens) ================= */
function aiSection() {
  const sec = el('div', { class: 'settings-sec' });
  sec.append(el('h3', { text: 'Inteligencia artificial' }));
  sec.append(el('p', { class: 'sub' }, 'Qué modelo hace de profesor y cuántos tokens consumió. De esto se encarga el servidor: acá solo lo ves.'));

  const body = el('div', { class: 'stack', style: 'margin-top:10px' });
  body.append(el('div', { class: 'skeleton', style: 'height:70px;border-radius:10px' }));
  sec.append(body);

  api('/ai/status').then(st => {
    body.innerHTML = '';
    const lines = el('div', { class: 'stack' });

    // Proveedores configurados (lista), con el activo marcado.
    const list = el('div', { class: 'stack', style: 'gap:8px' });
    for (const p of st.providers || []) {
      const row = el('div', { class: 'flex', style: 'background:var(--surface2);border-radius:10px;padding:9px 12px;align-items:center' });
      row.append(el('span', { class: 'grow', style: 'font-weight:600' }, `${p.name}`),
        p.model ? el('span', { class: 'muted small', text: p.model }) : null,
        el('button', { class: 'tag ' + (p.active ? 'dominado' : 'pendiente'), text: p.active ? 'activo' : (p.ready ? 'listo' : 'sin configurar') },));
      list.append(row);
    }

    // Modelos de Ollama descargados en la compu del servidor.
    if (st.order?.includes('ollama')) {
      if (Array.isArray(st.ollamaModels) && st.ollamaModels.length) {
        list.append(el('p', { class: 'muted small', style: 'margin-top:4px' },
          'Modelos en Ollama: ' + st.ollamaModels.join(', ')));
      } else if (st.ollamaOffline) {
        list.append(el('p', { class: 'muted small', style: 'color:var(--warn)', style: 'margin-top:4px' },
          'Ollama no responde en la compu del servidor. Abrí la app de Ollama y recargá acá.'));
      } else {
        list.append(el('p', { class: 'muted small', style: 'margin-top:4px' },
          'Ollama no tiene modelos descargados todavía (corré "ollama pull qwen2.5:7b" en el servidor).'));
      }
    }

    const ready = el('span', { class: 'tag ' + (st.ready ? 'dominado' : 'dificultad'), text: st.ready ? 'IA conectada' : 'IA sin configurar' });
    lines.append(el('div', { class: 'flex wrap', style: 'align-items:center;gap:10px' }, ready));
    lines.append(list);

    // Uso de tokens registrado en la base del servidor.
    const u = st.usage || { calls: 0, prompt: 0, completion: 0, byProvider: [] };
    const tokens = Intl.NumberFormat('es-AR');
    const usageBox = el('div', { style: 'margin-top:14px' },
      el('p', { style: 'font-weight:700;margin-bottom:6px' }, 'Uso de tokens'),
      el('div', { class: 'flex wrap', style: 'gap:10px' },
        el('span', { class: 'tag' }, `${tokens.format(u.calls)} pedidos a la IA`),
        el('span', { class: 'tag' }, `${tokens.format(u.prompt || 0)} tokens de contexto (entrada)`),
        el('span', { class: 'tag' }, `${tokens.format(u.completion || 0)} tokens generados (salida)`)),
      el('p', { class: 'muted small', style: 'margin-top:8px' },
        'Con Ollama no hay costo por uso: los tokens se contabilizan para medir el trabajo del modelo. Con proveedores de nube, más tokens = más gasto.'));
    for (const bp of u.byProvider || []) {
      usageBox.append(el('p', { class: 'muted small' },
        `${bp.provider}: ${tokens.format(bp.calls)} pedidos · ${tokens.format((bp.prompt || 0) + (bp.completion || 0))} tokens`));
    }
    lines.append(usageBox);
    body.append(lines);
  }).catch(() => {
    body.innerHTML = '';
    body.append(el('p', { class: 'muted small' }, 'No se pudo leer el estado de la IA del servidor.'));
  });

  return sec;
}

/* ================= Tema visual ================= */
function themeSection(s) {
  const sec = el('div', { class: 'settings-sec' });
  sec.append(el('h3', { text: 'Tema y apariencia' }));
  sec.append(el('p', { class: 'sub' }, 'Elegí una paleta y ajustala a gusto. Ningún color mejora la concentración o la memoria por sí solo: buscá lo que te resulte cómodo de leer.'));

  const theme = { ...s.prefs.theme };

  // Selector de paletas con preview real
  const grid = el('div', { class: 'theme-grid' });
  PALETTE_LIST.forEach(p => {
    const tile = el('button', {
      class: 'theme-tile' + (theme.palette === p.id ? ' on' : ''),
      onclick: () => { theme.palette = p.id; save(); },
    });
    const prevWrap = el('div', { style: 'padding:10px' });
    prevWrap.append(miniPreview(p.id, { mode: theme.mode }));
    tile.append(prevWrap, el('div', { class: 'tile-body' },
      el('div', { class: 'tile-name', text: p.name }),
      el('div', { class: 'tile-sub', text: p.sub })));
    grid.append(tile);
  });
  sec.append(grid);

  // Controles
  const controls = el('div', { style: 'margin-top:16px' });
  controls.append(
    settingRow('Modo de color', null, seg(['light', 'dark', 'auto'], ['Claro', 'Oscuro', 'Automático'], theme.mode, v => { theme.mode = v; save(); })),
    settingRow('Colores personalizados', 'Solo para Custom Theme', customControls()),
    settingRow('Intensidad del color de acento', null, el('input', {
      class: 'input', type: 'range', min: 0, max: 100, value: theme.intensity,
      oninput: e => { theme.intensity = Number(e.target.value); save(); },
    })),
    settingRow('Contraste', 'Un contraste adecuado (WCAG AA, 4.5:1) favorece la lectura.', seg(['bajo', 'medio', 'alto'], ['Bajo', 'Medio', 'Alto'], theme.contrast, v => { theme.contrast = v; save(); })),
    settingRow('Estilo de los botones', null, seg(['round', 'pill', 'square'], ['Redondeado', 'Píldora', 'Cuadrado'], theme.buttonStyle, v => { theme.buttonStyle = v; save(); })),
    settingRow('Tamaño del texto', null, seg(['-1', '0', '1', '2'], ['Chico', 'Normal', 'Grande', 'Muy grande'], String(theme.textSize), v => { theme.textSize = Number(v); save(); })),
    settingRow('Espaciado', null, seg(['compacta', 'normal', 'espaciosa'], ['Compacto', 'Normal', 'Espacioso'], theme.density, v => { theme.density = v; save(); })),
    settingRow('Animaciones UI', null, toggle(theme.animations, v => { theme.animations = v; save(); })),
  );
  sec.append(controls);
  sec.append(contrastWarn());

  function customControls() {
    const box = el('div', { class: 'swatch-row' });
    const mk = (key, label, defVal) => {
      const inp = el('input', { class: 'input', type: 'color', value: theme.colors[key] || defVal, style: 'width:46px;height:38px', title: label,
        oninput: e => { theme.colors[key] = e.target.value; if (theme.palette === 'custom') save(); } });
      return inp;
    };
    box.append(mk('primary', 'Color principal', '#2F5BEA'), mk('accent', 'Color secundario', '#6B8CFF'), mk('bg', 'Fondo', '#F4F6FB'), mk('surface', 'Tarjetas', '#FFFFFF'));
    box.append(el('span', { class: 'muted small' }, 'Fondo'));
    box.append(el('span', { class: 'muted small' }, 'Tarjetas'));
    box.style.alignItems = 'flex-end';
    return box;
  }

  function contrastWarn() {
    const problems = checkAccessibility(theme);
    const box = el('div');
    if (problems.length) {
      box.append(el('div', { style: 'margin-top:14px;background:color-mix(in srgb, var(--warn) 12%, transparent);border:1px solid color-mix(in srgb, var(--warn) 45%, transparent);border-radius:12px;padding:12px 14px' },
        el('p', { style: 'font-weight:700;color:var(--warn)' }, '⚠ Contraste insuficiente'),
        el('p', { class: 'muted small', style: 'margin:4px 0 10px' }, problems.map(p => `${p.label}: ${p.ratio}:1 (se recomienda al menos ${p.need}:1)`).join(' · ')),
        el('div', { class: 'flex wrap' },
          el('button', { class: 'btn sm ghost', onclick: () => { theme.contrast = 'alto'; save(); } }, 'Subir contraste'),
          el('button', { class: 'btn sm', onclick: () => { theme.palette = 'high-contrast'; theme.contrast = 'alto'; save(); } }, 'Usar alternativa accesible'))));
    }
    return box;
  }

  function save() {
    store.savePrefField('theme', JSON.parse(JSON.stringify(theme)));
  }

  mkModeOverride(theme);
  return sec;
}

function mkModeOverride(theme) {
  // El modo automático necesita re-aplicarse cuando cambia la preferencia del sistema.
  const mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  if (mq && mq.addEventListener) {
    mq.addEventListener('change', () => {
      if (store.get().prefs.theme.mode === 'auto') store.savePrefField('theme', JSON.parse(JSON.stringify(store.get().prefs.theme)));
    });
  }
}

function seg(values, labels, current, onpick) {
  const box = el('div', { class: 'seg' });
  values.forEach((v, i) => {
    box.append(el('button', { class: String(current) === v ? 'on' : '', text: labels[i], onclick: () => { onpick(v); box.querySelectorAll('button').forEach((b, j) => b.classList.toggle('on', j === i)); } }));
  });
  return box;
}

function toggle(value, onchange) {
  const t = el('input', { type: 'checkbox', checked: !!value, style: 'width:20px;height:20px;accent-color:var(--accent)', onchange: e => onchange(e.target.checked) });
  return t;
}

function settingRow(name, desc, control) {
  return el('div', { class: 'setting-row' },
    el('div', el('div', { class: 'name', text: name }), desc ? el('div', { class: 'desc', text: desc }) : null),
    control);
}

/* ================= Preferencias de aprendizaje ================= */
function learningSection(s) {
  const sec = el('div', { class: 'settings-sec' });
  sec.append(el('h3', { text: 'Mi forma de aprender' }));
  sec.append(el('p', { class: 'sub' }, 'Estas preferencias cambian cómo enseña la IA en tus conversaciones, no solo la apariencia. Se puede cambiar cuando quieras.'));
  const d = Object.assign({}, store.get().defaults.learning || {}, s.prefs.learning || {});

  const fields = {};
  for (const key of Object.keys(L_OPTS)) {
    const cfg = L_OPTS[key];
    fields[key] = el('select', { class: 'input' },
      ...cfg.options.map(([v, label]) => el('option', { value: v, ...(d[key] === v ? { selected: '' } : {}) }, label)));
  }
  const formatsWrap = el('div', { class: 'flex wrap' });
  L_FORMATS.forEach(([v, label]) => {
    const cb = el('input', { type: 'checkbox', checked: Array.isArray(d.formats) && d.formats.includes(v), value: v, style: 'width:18px;height:18px;accent-color:var(--accent)' });
    formatsWrap.append(el('label', { class: 'chip', onchange: () => {} }, cb, label));
  });

  const body = el('div', { class: 'stack' });
  for (const key of Object.keys(L_OPTS)) body.append(el('div', { class: 'field' }, el('label', { text: L_OPTS[key].label }), fields[key]));
  body.append(el('div', { class: 'field' }, el('label', { text: 'Formatos que más te ayudan (elegí todos los que quieras)' }), formatsWrap));

  const save = async () => {
    const value = {};
    for (const key of Object.keys(L_OPTS)) value[key] = fields[key].value;
    value.formats = [...formatsWrap.querySelectorAll('input:checked')].map(i => i.value);
    await store.savePrefField('learning', value);
    toast('Preferencias de aprendizaje guardadas', 'ok');
  };
  const foot = el('div', { class: 'flex wrap', style: 'margin-top:14px' });
  foot.append(el('button', { class: 'btn ghost', onclick: async () => {
    const def = store.get().defaults.learning || {};
    for (const key of Object.keys(L_OPTS)) fields[key].value = def[key] || L_OPTS[key].options[0][0];
    formatsWrap.querySelectorAll('input').forEach(i => i.checked = Array.isArray(def.formats) && def.formats.includes(i.value));
  } }, 'Restablecer'));
  foot.append(el('span', { class: 'grow' }));
  foot.append(el('button', { class: 'btn', onclick: save }, 'Guardar preferencias'));
  sec.append(body, foot);
  return sec;
}

/* ================= Modo del profesor ================= */
function teacherSection(s) {
  const sec = el('div', { class: 'settings-sec' });
  sec.append(el('h3', { text: 'Cómo preferís que enseñe' }));
  sec.append(el('p', { class: 'sub' }, 'Ajusta el estilo del profesor IA: nivel, ritmo, correcciones y objetivo. Aplica en todas tus charlas.'));
  const d = Object.assign({}, store.get().defaults.teacher || {}, s.prefs.teacher || {});
  const fields = {};
  const body = el('div', { class: 'stack' });
  for (const key of Object.keys(T_OPTS)) {
    const cfg = T_OPTS[key];
    fields[key] = el('select', { class: 'input' }, ...cfg.options.map(([v, label]) => el('option', { value: v, ...(d[key] === v ? { selected: '' } : {}) }, label)));
    body.append(el('div', { class: 'field' }, el('label', { text: cfg.label }), fields[key]));
  }
  const save = async () => {
    const value = {};
    for (const key of Object.keys(T_OPTS)) value[key] = fields[key].value;
    await store.savePrefField('teacher', value);
    toast('Preferencias del profesor guardadas', 'ok');
  };
  const foot = el('div', { class: 'flex wrap', style: 'margin-top:14px' });
  foot.append(el('button', { class: 'btn ghost', onclick: async () => {
    const def = store.get().defaults.teacher || {};
    for (const key of Object.keys(T_OPTS)) fields[key].value = def[key] || T_OPTS[key].options[0][0];
  } }, 'Restablecer'));
  foot.append(el('span', { class: 'grow' }));
  foot.append(el('button', { class: 'btn', onclick: save }, 'Guardar preferencias'));
  sec.append(body, foot);
  return sec;
}

/* ================= Perfil y privacidad ================= */
function profileSection(s) {
  const sec = el('div', { class: 'settings-sec' });
  sec.append(el('h3', { text: 'Perfil y privacidad' }));
  const name = el('input', { class: 'input grow', value: s.user ? s.user.displayName : '' });
  const lang = el('select', { class: 'input', style: 'max-width:180px' },
    el('option', { value: 'es', ...((s.user && s.user.language) !== 'en' && (s.user && s.user.language) !== 'pt' ? { selected: '' } : {}) }, 'Español'),
    el('option', { value: 'en', ...(s.user && s.user.language === 'en' ? { selected: '' } : {}) }, 'English'),
    el('option', { value: 'pt', ...(s.user && s.user.language === 'pt' ? { selected: '' } : {}) }, 'Português'));
  const saveProfile = async () => {
    try { await api('/profile', { method: 'PUT', body: { displayName: name.value.trim(), language: lang.value } }); await store.loadMe(); toast('Perfil actualizado', 'ok'); }
    catch (e) { toast((e && e.message) || 'No se pudo guardar.', 'err'); }
  };
  sec.append(
    el('div', { class: 'setting-row' },
      el('div', el('div', { class: 'name' }, 'Nombre visible'), el('div', { class: 'desc' }, 'El profesor te saluda con este nombre.')),
      el('button', { class: 'btn sm ghost', onclick: saveProfile }, 'Guardar nombre')),
    el('div', { class: 'setting-row' }, el('div', el('div', { class: 'name' }, 'Nombre'), name)),
    el('div', { class: 'setting-row' }, el('div', el('div', { class: 'name' }, 'Idioma'), lang)),
    el('div', { class: 'setting-row' },
      el('div', el('div', { class: 'name' }, 'Mis datos'), el('div', { class: 'desc' }, 'Descargá un archivo con todo lo que guardamos de tu cuenta (materias, charlas, progreso).')),
      el('button', { class: 'btn sm ghost', onclick: exportData }, 'Descargar JSON')),
    el('div', { class: 'setting-row' },
      el('div', el('div', { class: 'name' }, 'Eliminar cuenta'), el('div', { class: 'desc' }, 'Borra tu cuenta y todos tus datos en el servidor. No se puede deshacer.')),
      el('button', { class: 'btn sm danger', onclick: deleteAccount }, 'Eliminar')),
  );

  async function exportData() {
    try {
      const dump = await api('/auth/data');
      const blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = el('a', { href: url, download: 'nextstep-mis-datos.json' });
      document.body.append(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      toast('Archivo descargado', 'ok');
    } catch (e) { toast((e && e.message) || 'No se pudo exportar.', 'err'); }
  }

  function deleteAccount() {
    const input = el('input', { class: 'input', placeholder: 'Escribí tu usuario para confirmar' });
    const confirmBtn = el('button', { class: 'btn danger', disabled: true, onclick: async () => {
      confirmBtn.disabled = true;
      try {
        await api('/account', { method: 'DELETE' });
        await store.logout();
        location.hash = '#/login';
        toast('Cuenta eliminada. Volvé cuando quieras.', 'ok');
      } catch (e) { toast((e && e.message) || 'No se pudo eliminar.', 'err'); }
    } }, 'Eliminar todo de una vez');
    input.addEventListener('input', () => { confirmBtn.disabled = input.value.trim() !== (s.user ? s.user.username : ''); });
    const holder = el('div', { class: 'stack' });
    holder.append(
      el('p', { class: 'muted small' }, 'Se van a borrar definitivamente tus materias, charlas, rutas, evaluaciones, objetivos y progreso. No se puede deshacer.'),
      el('div', { class: 'field' }, input),
    );
    modal({ title: 'Eliminar tu cuenta', body: holder, footer: [confirmBtn] });
  }
  return sec;
}

/* ================= Modal de onboarding (primer ingreso) ================= */
export function learningModal({ onDone } = {}) {
  const s = store.get();
  const d = Object.assign({}, store.get().defaults.learning || {}, s.prefs.learning || {});
  const fields = {};
  const body = el('div', { class: 'stack' });
  body.append(el('p', { class: 'muted small' }, 'Contanos cómo preferís aprender: esto cambia cómo te enseña el profesor IA en el chat. Podés saltearlo y ajustarlo después en Configuración.'));
  for (const key of Object.keys(L_OPTS)) {
    const cfg = L_OPTS[key];
    fields[key] = el('select', { class: 'input' }, ...cfg.options.map(([v, label]) => el('option', { value: v, ...(d[key] === v ? { selected: '' } : {}) }, label)));
    body.append(el('div', { class: 'field' }, el('label', { text: cfg.label }), fields[key]));
  }
  let close = () => {};
  close = modal({
    title: 'Mi forma de aprender',
    body,
    footer: [
      el('button', { class: 'btn ghost', onclick: () => { close(); onDone && onDone(); } }, 'Ahora no'),
      el('button', { class: 'btn', onclick: async () => {
        const value = {};
        for (const key of Object.keys(L_OPTS)) value[key] = fields[key].value;
        value.formats = Array.isArray(d.formats) && d.formats.length ? d.formats : ['preguntas', 'ejemplos'];
        await store.savePrefField('learning', value);
        toast('¡Listo! Preferencias guardadas', 'ok');
        close();
        onDone && onDone();
      } }, 'Guardar'),
    ],
  });
}