/* NEXTSTEP — Mi aprendizaje: materias, temas, niveles y edición. */
import { api } from '../api.js';
import * as store from '../store.js';
import { el, svgIc, bar, emptyState, modal, toast } from '../ui.js';

const RANKS = ['Iniciante', 'Básico', 'Intermedio', 'Avanzado', 'Experto'];
const STATUS_LABEL = { dominado: 'Dominado', aprendiendo: 'Aprendiendo', dificultad: 'Dificultad', pendiente: 'Pendiente' };

export function learningView(params) {
  const root = el('div', { class: 'stack' });
  if (params[0]) detail(root, Number(params[0]));
  else list(root);
  return root;
}

/* ---------- Lista de materias ---------- */
async function list(root) {
  root.append(el('div', { class: 'skeleton', style: 'height:120px;border-radius:14px' }));
  try {
    const r = await api('/subjects');
    root.innerHTML = '';
    const head = el('div', { class: 'view-head flex wrap' });
    head.append(el('div', { class: 'grow' }, el('h1', { text: 'Mi aprendizaje' }), el('p', { text: 'Tus materias y el detalle de cada una. El nivel se calcula con tu progreso real, no con lo que decís haber estudiado.' })));
    head.append(el('button', { class: 'btn', onclick: () => newSubjectModal() }, svgIc('plus', 18), 'Nueva materia'));
    root.append(head);

    if (!r.subjects.length) {
      root.append(emptyState('Todavía no tenés materias. Agregá la primera y empezá a armar tu camino.', 'learn', el('button', { class: 'btn', onclick: () => newSubjectModal() }, 'Agregar materia')));
      return;
    }
    const grid = el('div', { class: 'grid-2' });
    for (const su of r.subjects) {
      grid.append(el('div', {
        class: 'card', style: 'cursor:pointer',
        onclick: () => store.nav(`/learning/${su.id}`),
      },
        el('div', { class: 'flex' },
          el('div', { class: 'grow' }, el('h3', { text: su.name }), el('p', { class: 'sub' }, `${su.level}${su.goal ? ' · ' + su.goal.slice(0, 60) : ''}`)),
          el('span', { class: 'pct', style: 'font-size:1.2rem' }, `${su.score}%`)),
        el('div', { style: 'margin-top:12px' }, bar(su.score)),
        el('div', { class: 'flex wrap', style: 'margin-top:12px;gap:6px' },
          el('span', { class: 'tag' }, `${su.topicsCount} temas`),
          su.status === 'active' ? el('span', { class: 'tag en_curso' }, 'activa') : el('span', { class: 'tag pendiente' }, su.status),
        ),
      ));
    }
    root.append(grid);
  } catch (e) {
    root.innerHTML = '';
    root.append(emptyState((e && e.message) || 'No se pudo cargar tus materias.', 'warn'));
  }
}

/* Catálogo de materias sugeridas: coinciden con el banco verificado del servidor,
   así esas materias se evalúan solas y dan práctica automática. */
const SUBJECT_CATALOG = ['HTML', 'JavaScript', 'Java', 'Python', 'Bases de datos (SQL)', 'Redes', 'Git', 'Matemática', 'Geografía', 'Historia', 'Ciencias naturales', 'Lengua', 'Inglés'];

function newSubjectModal(edit = null) {
  const name = el('input', { class: 'input', placeholder: 'Ej: Matemática, JavaScript, Inglés…', value: edit ? edit.name : '' });
  const goal = el('textarea', { class: 'input', placeholder: '¿Qué querés lograr con esta materia? (opcional)', value: edit ? edit.goal || '' : '' });
  const level = el('select', { class: 'input' });
  for (const r of RANKS) level.append(el('option', { value: r, ...(edit && edit.level === r ? { selected: '' } : {}) }, r));
  const initialTopic = el('input', { class: 'input', placeholder: 'Primer tema (opcional)', value: '' });
  // Catálogo: al tocar una sugerencia, se completa el nombre.
  const catWrap = el('div', { class: 'flex wrap', style: 'gap:6px' });
  for (const c of SUBJECT_CATALOG) {
    const chip = el('button', { class: 'chip', text: c, onclick: () => { name.value = c; name.focus(); } });
    catWrap.append(chip);
  }
  const body = el('div', { class: 'stack' },
    el('div', { class: 'field' }, el('label', { text: 'Nombre de la materia' }), name),
    !edit ? el('div', { class: 'field' }, el('span', { class: 'muted small', text: 'Sugerencias del catálogo verificado (con banco de preguntas propio):' }), el('div', { style: 'margin-top:6px' }, catWrap)) : null,
    el('div', { class: 'field' }, el('label', { text: 'Objetivo' }), goal),
    el('div', { class: 'field' }, el('label', { text: 'Nivel de partida' }), level),
    !edit ? el('div', { class: 'field' }, el('label', { text: 'Primer tema' }), initialTopic) : null,
  );
  const busy = el('span', { class: 'spin', style: 'display:none' });
  let close = () => {};
  close = modal({
    title: edit ? 'Editar materia' : 'Nueva materia',
    body,
    footer: [
      busy,
      el('button', { class: 'btn ghost', onclick: close }, 'Cancelar'),
      el('button', { class: 'btn', onclick: async () => {
        if (!name.value.trim()) return toast('Ponéle un nombre a la materia.', 'err');
        busy.style.display = '';
        try {
          if (edit) {
            await api(`/subjects/${edit.id}`, { method: 'PUT', body: { goal: goal.value.trim(), level: level.value } });
            toast('Materia actualizada', 'ok');
          } else {
            const r = await api('/subjects', {
              method: 'POST',
              body: { name: name.value.trim(), goal: goal.value.trim(), level: level.value, initialTopic: initialTopic.value.trim() },
            });
            store.bustCache('subjects');
            toast(r.subject ? 'Materia creada: +15 XP' : 'Materia creada', 'ok');
            await store.loadMe();
          }
          close();
          store.nav(edit ? `/learning/${edit.id}` : '/learning');
        } catch (e) { toast((e && e.message) || 'No se pudo guardar.', 'err'); }
        finally { busy.style.display = 'none'; }
      } }, edit ? 'Guardar cambios' : 'Crear materia'),
    ],
  });
}

/* ---------- Detalle de materia ---------- */
async function detail(root, id) {
  root.append(el('div', { class: 'skeleton', style: 'height:200px;border-radius:14px' }));
  let d;
  try {
    d = await api(`/subjects/${id}`);
  } catch (e) {
    root.innerHTML = '';
    root.append(emptyState((e && e.message) || 'No existe esa materia.', 'warn', el('button', { class: 'btn ghost', onclick: () => store.nav('/learning') }, 'Volver a materias')));
    return;
  }
  root.innerHTML = '';
  const su = d.subject;

  const head = el('div', { class: 'view-head flex wrap' });
  const h = el('div', { class: 'grow' });
  h.append(el('h1', { text: su.name }));
  h.append(el('p', { text: su.goal || 'Sin objetivo definido todavía.' }));
  head.append(h,
    el('button', { class: 'btn ghost', onclick: () => editSubject(su, () => detail(root, id)) }, svgIc('pencil', 18), 'Editar'),
    el('button', { class: 'btn ghost', onclick: () => store.nav('/teacher') }, svgIc('chat', 18), 'Hablar de esto'));
  root.append(head);

  const row = el('div', { class: 'stat-row' });
  row.append(stat('star', su.level, 'nivel actual'));
  row.append(stat('route', `${su.score}%`, 'avance real'));
  row.append(stat('list', `${su.topicsCount}`, 'temas'));
  const openCount = d.topics ? d.topics.filter(t => t.status !== 'dominado').length : su.openTopics;
  row.append(stat('book', String(openCount), 'en proceso'));
  root.append(row);

  // Temas
  const topicsCard = el('div', { class: 'card' });
  topicsCard.append(el('div', { class: 'card-title', style: 'margin-bottom:8px' }, svgIc('list', 18), 'Temas de esta materia'));
  const listEl = el('div');
  const addRow = el('div', { class: 'row-input', style: 'margin-top:12px' });
  const newTopic = el('input', { class: 'input', placeholder: 'Agregar un tema…' });
  addRow.append(newTopic, el('button', { class: 'btn', onclick: async () => {
    if (!newTopic.value.trim()) return;
    try {
      await api(`/subjects/${id}/topics`, { method: 'POST', body: { name: newTopic.value.trim() } });
      newTopic.value = '';
      await store.loadMe();
      detail(root, id);
    } catch (e) { toast((e && e.message) || 'No se pudo agregar.', 'err'); }
  } }, svgIc('plus', 18)));
  topicsCard.append(listEl, addRow);
  root.append(topicsCard);

  function renderTopics() {
    listEl.innerHTML = '';
    if (!d.topics.length) {
      listEl.append(emptyState('Sin temas todavía. Agregá el primero o pedile al profesor que te arme el recorrido.', 'list'));
      return;
    }
    for (const t of d.topics) {
      const sel = el('select', { class: 'input', style: 'max-width:150px', onchange: async () => {
        try {
          const r = await api(`/topics/${t.id}`, { method: 'PUT', body: { status: sel.value } });
          if (r.gained) { toast(`Tema dominado: +${r.gained} XP`, 'ok'); await store.loadMe(); }
          detail(root, id);
        } catch (e) { toast((e && e.message) || 'No se pudo actualizar.', 'err'); }
      } });
      for (const st of ['pendiente', 'aprendiendo', 'dominado', 'dificultad']) sel.append(el('option', { value: st, ...(st === t.status ? { selected: '' } : {}) }, STATUS_LABEL[st]));
      const item = el('div', { class: 'li' },
        el('span', { class: 'ic', html: svgIc(t.status === 'dominado' ? 'check' : 'book', 19) }),
        el('div', { class: 'grow' }, el('p', { style: 'font-weight:600' }, t.name), el('p', { class: 'meta' }, `actualizado ${fmtMin(t.updated_at)}`)),
        sel,
        el('button', { class: 'icon-btn danger', title: 'Borrar tema', onclick: async () => {
          if (!confirm('¿Borrar este tema?')) return;
          try { await api(`/topics/${t.id}`, { method: 'DELETE' }); detail(root, id); } catch (e) { toast((e && e.message) || 'No se pudo borrar.', 'err'); }
        }, html: svgIc('trash', 17) }),
      );
      listEl.append(item);
    }
  }
  renderTopics();

  // Evaluaciones y rutas vinculadas
  const evCard = el('div', { class: 'card' });
  evCard.append(el('div', { class: 'card-title', style: 'margin-bottom:8px' }, svgIc('quiz', 18), 'Evaluaciones'));
  if (d.assessments && d.assessments.length) {
    for (const a of d.assessments) {
      const done = a.finished_at;
      evCard.append(el('div', { class: 'flex', style: 'padding:8px 0;border-top:1px dashed var(--line)' },
        el('div', { class: 'grow' }, el('p', { style: 'font-weight:600' }, a.title), el('p', { class: 'meta' }, done ? `${a.score}/${a.total} · ${fmtMin(a.finished_at)}` : 'pendiente de responder')),
        done ? el('span', { class: 'pct' }, `${Math.round(a.score / a.total * 100)}%`) : el('button', { class: 'btn sm', onclick: () => store.nav(`/assessments/${a.id}`) }, 'Responder')));
    }
  } else {
    evCard.append(el('p', { class: 'muted small' }, 'Todavía sin evaluaciones. Generá una desde Evaluaciones.'));
  }
  root.append(evCard);

  const pathCard = el('div', { class: 'card' });
  pathCard.append(el('div', { class: 'card-title', style: 'margin-bottom:8px' }, svgIc('route', 18), 'Rutas'));
  if (d.paths && d.paths.length) {
    for (const p of d.paths) {
      pathCard.append(el('div', { class: 'flex', style: 'padding:8px 0;border-top:1px dashed var(--line)', cursor: 'pointer', onclick: () => store.nav(`/paths/${p.id}`) },
        el('div', { class: 'grow' }, el('p', { style: 'font-weight:600' }, p.title), el('p', { class: 'meta' }, `${p.progress}% avanzado`)),
        el('button', { class: 'btn ghost sm', onclick: () => store.nav(`/paths/${p.id}`) }, 'Ver')));
    }
  } else {
    pathCard.append(el('p', { class: 'muted small' }, 'Sin rutas todavía. Armá una desde Rutas de aprendizaje.'));
  }
  root.append(pathCard);
}

function stat(icon, num, label) {
  return el('div', { class: 'stat' },
    el('div', { class: 'ic', html: svgIc(icon, 18) }),
    el('div', { class: 'num', text: String(num) }),
    el('div', { class: 'lbl', text: label }));
}

function editSubject(su, refresh) {
  newSubjectModal({ id: su.id, name: su.name, goal: su.goal, level: su.level });
}

function fmtMin(iso) {
  if (!iso) return '—';
  try { return new Date(iso).toLocaleDateString('es-AR', { day: 'numeric', month: 'short' }); } catch { return String(iso).slice(0, 10); }
}