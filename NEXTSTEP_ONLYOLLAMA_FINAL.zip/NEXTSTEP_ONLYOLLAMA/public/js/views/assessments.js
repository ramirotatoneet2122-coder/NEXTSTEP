/* NEXTSTEP — Evaluaciones: generación (banco verificado o IA), quiz y corrección. */
import { api } from '../api.js';
import * as store from '../store.js';
import { el, svgIc, emptyState, modal, toast, fmtDate } from '../ui.js';

export function assessmentsView(params) {
  const root = el('div', { class: 'stack' });
  if (params[0]) run(root, Number(params[0]));
  else list(root);
  return root;
}

/* ---------- Lista ---------- */
async function list(root) {
  root.append(el('div', { class: 'skeleton', style: 'height:110px;border-radius:14px' }));
  try {
    const r = await api('/assessments');
    root.innerHTML = '';
    const head = el('div', { class: 'view-head flex wrap' });
    head.append(el('div', { class: 'grow' }, el('h1', { text: 'Evaluaciones' }),
      el('p', { text: 'Medir tu nivel real te ayuda a saber qué seguir. Las materias del banco verificado se corrigen solo; el resto necesita la IA configurada.' })));
    head.append(el('button', { class: 'btn', onclick: openGenerate }, svgIc('quiz', 18), 'Nueva evaluación'));
    root.append(head);

    if (!r.assessments.length) {
      root.append(emptyState('Todavía no hiciste evaluaciones. Generá una para conocer tu punto de partida.', 'quiz', el('button', { class: 'btn', onclick: openGenerate }, 'Crear evaluación')));
      return;
    }
    for (const a of r.assessments) {
      const done = a.finished_at;
      root.append(el('div', { class: 'card', style: 'cursor:pointer', onclick: () => store.nav(`/assessments/${a.id}`) },
        el('div', { class: 'flex' },
          el('div', { class: 'grow' }, el('h3', { text: a.title }), el('p', { class: 'sub' }, `${a.subject_name || 'Sin materia'} · ${fmtDate(a.created_at)}`)),
          done
            ? el('span', { class: 'pct', text: `${Math.round(a.score / a.total * 100)}%` })
            : el('button', { class: 'btn sm', onclick: e => { e.stopPropagation(); store.nav(`/assessments/${a.id}`); } }, 'Responder'))));
    }
  } catch (e) {
    root.innerHTML = '';
    root.append(emptyState((e && e.message) || 'No se pudieron cargar las evaluaciones.', 'warn'));
  }
}

function openGenerate() {
  const wrap = el('div', { class: 'stack' });
  const subjSel = el('select', { class: 'input' }, el('option', { value: '' }, 'Cargando…'));
  const kind = el('select', { class: 'input' },
    el('option', { value: 'inicial' }, 'Evaluación inicial'),
    el('option', { value: 'seguimiento' }, 'De seguimiento'),
    el('option', { value: 'tema' }, 'De un tema'));
  const count = el('input', { class: 'input', type: 'number', min: 3, max: 10, value: 5 });
  wrap.append(
    el('div', { class: 'field' }, el('label', { text: 'Materia' }), subjSel),
    el('div', { class: 'field' }, el('label', { text: 'Tipo' }), kind),
    el('div', { class: 'field' }, el('label', { text: 'Cantidad de preguntas' }), count),
  );
  api('/subjects').then(r => {
    subjSel.innerHTML = '';
    subjSel.append(el('option', { value: '' }, 'Elegí la materia…'));
    for (const su of r.subjects) subjSel.append(el('option', { value: su.id }, su.name));
  }).catch(() => { subjSel.innerHTML = ''; subjSel.append(el('option', { value: '' }, 'No hay materias — creá una primero')); });

  let close = () => {};
  close = modal({
    title: 'Nueva evaluación',
    body: wrap,
    footer: [
      el('button', { class: 'btn ghost', onclick: close }, 'Cancelar'),
      el('button', { class: 'btn', onclick: async (e) => {
        if (!subjSel.value) return toast('Elegí la materia.', 'err');
        const b = e.target; b.disabled = true; b.textContent = 'Generando…';
        try {
          const r = await api('/assessments/generate', {
            method: 'POST',
            body: { subject_id: Number(subjSel.value), kind: kind.value, count: Number(count.value) },
          });
          close();
          toast('Evaluación lista', 'ok');
          store.nav(`/assessments/${r.assessment.id}`);
        } catch (err) { toast((err && err.message) || 'No se pudo generar la evaluación.', 'err'); }
        finally { b.disabled = false; b.textContent = 'Generar'; }
      } }, 'Generar'),
    ],
  });
}

/* ---------- Quiz ---------- */
async function run(root, id) {
  root.append(el('div', { class: 'skeleton', style: 'height:200px;border-radius:14px' }));
  let d;
  try { d = await api(`/assessments/${id}`); } catch (e) {
    root.innerHTML = '';
    root.append(emptyState((e && e.message) || 'No existe esa evaluación.', 'warn', el('button', { class: 'btn ghost', onclick: () => store.nav('/assessments') }, 'Volver')));
    return;
  }
  root.innerHTML = '';
  const a = d.assessment;
  const head = el('div', { class: 'view-head flex wrap' });
  const h = el('div', { class: 'grow' });
  h.append(el('h1', { text: a.title }));
  h.append(el('p', { text: d.subject ? d.subject.name : 'Evaluación de nivel' }));
  head.append(h);
  const meta = el('div', { class: 'flex wrap' });
  meta.append(el('span', { class: 'tag' }, `${d.items.length} preguntas`));
  if (d.subject) meta.append(el('span', { class: 'tag' }, d.subject.name));
  meta.append(el('span', { class: 'tag' }, 'banco verificado'));
  head.append(meta);
  root.append(head);

  if (d.answered) {
    renderResults(d, a);
  } else if (a.finished_at) {
    root.append(emptyState('Esta evaluación ya fue respondida.', 'info', el('button', { class: 'btn', onclick: () => store.nav('/assessments') }, 'Ver evaluaciones')));
  } else {
    renderQuiz(d, a);
  }

  function renderQuiz(data, assessment) {
    const answers = new Array(data.items.length).fill(-1);
    const box = el('div', { class: 'stack' });
    data.items.forEach((it, idx) => {
      const item = el('div', { class: 'quiz-item' });
      item.append(el('div', { class: 'flex' },
        el('span', { class: 'tag' }, `Pregunta ${idx + 1} de ${data.items.length}`),
        el('span', { class: 'tag', text: 'dificultad ' + (it.difficulty || 1) })),
        el('p', { class: 'q', style: 'margin-top:8px' }, it.prompt));
      const opts = el('div', { class: 'opts' });
      it.options.forEach((o, oi) => {
        const opt = el('div', {
          class: 'opt',
          role: 'button',
          tabindex: 0,
          onclick: () => pick(idx, oi),
          onkeydown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(idx, oi); } },
        }, el('span', { class: 'letter', text: 'ABCD'[oi] }), el('span', { text: o }));
        opts.append(opt);
      });
      item.append(opts);
      box.append(item);

      function pick(pi, oi) {
        answers[pi] = oi;
        const itemEl = box.querySelectorAll('.quiz-item')[pi];
        itemEl.querySelectorAll('.opt').forEach((oEl, i) => oEl.classList.toggle('sel', i === oi));
      }
    });

    const foot = el('div', { class: 'flex' });
    const busy = el('span', { class: 'spin', style: 'display:none' });
    foot.append(busy, el('span', { class: 'grow' }),
      el('button', { class: 'btn', onclick: async (e) => {
        const missing = answers.filter(x => x < 0).length;
        if (missing) return toast(`Te faltan ${missing} preguntas por responder.`, 'err');
        const b = e.target; b.disabled = true; busy.style.display = '';
        try {
          const r = await api(`/assessments/${id}/submit`, { method: 'POST', body: { answers } });
          toast(`Evaluación corregida: ${r.pct}%`, 'ok');
          if (r.gained) toast(`+${r.gained} XP`, 'ok');
          await store.loadMe();
          run(root, id);
        } catch (err) { toast((err && err.message) || 'No se pudo corregir.', 'err'); }
        finally { b.disabled = false; busy.style.display = 'none'; }
      } }, 'Corregir evaluación'));
    foot.querySelector('.btn').classList.add('block');
    box.append(foot);
    root.append(box);
  }

  function renderResults(data, assessment) {
    const box = el('div', { class: 'stack' });
    const pct = assessment.total ? Math.round(assessment.score / assessment.total * 100) : 0;
    const resRow = el('div', { class: 'stat-row' });
    resRow.append(stat('check', `${assessment.score}/${assessment.total}`, 'correctas'));
    resRow.append(stat('star', `${pct}%`, 'resultado'));
    box.append(resRow);

    const verdict = el('div', { class: 'card', style: 'border-left:4px solid ' + (pct >= 80 ? 'var(--good)' : pct >= 50 ? 'var(--warn)' : 'var(--danger)') });
    verdict.append(el('p', { style: 'font-weight:700' }, pct >= 80 ? '¡Muy bien! Es buen momento para avanzar a lo siguiente.'
      : pct >= 50 ? 'Vas bien. Repasá lo que te falló y volvé a intentarlo.'
      : 'Conviene reforzar lo básico antes de seguir. El profesor puede ayudarte con eso.'));
    box.append(verdict);

    for (let i = 0; i < data.items.length; i++) {
      const it = data.items[i];
      const res = data.results ? data.results[i] : null;
      const ok = res ? res.ok : false;
      const item = el('div', { class: 'quiz-item' });
      item.append(el('div', { class: 'flex' },
        el('span', { class: 'tag', text: `Pregunta ${i + 1}` }),
        el('span', { class: `tag ${ok ? 'dominado' : 'dificultad'}` }, ok ? 'bien' : 'fallaste')));
      item.append(el('p', { class: 'q', style: 'margin-top:8px' }, it.prompt));
      const opts = el('div', { class: 'opts' });
      it.options.forEach((o, oi) => {
        const cls = ['opt'];
        if (oi === (res && res.correct)) cls.push('ok');
        if (res && oi === res.answer && !ok) cls.push('bad');
        opts.append(el('div', { class: cls.join(' ') },
          el('span', { class: 'letter', text: 'ABCD'[oi] }), el('span', { text: o })));
      });
      item.append(opts);
      const expl = res && res.explanation;
      if (expl) item.append(el('p', { class: 'muted small', style: 'margin-top:10px' }, '💡 ' + expl));
      box.append(item);
    }

    box.append(el('div', { class: 'flex wrap' },
      el('button', { class: 'btn ghost', onclick: () => store.nav('/assessments') }, 'Volver a evaluaciones'),
      el('button', { class: 'btn', onclick: () => store.nav('/teacher') }, svgIc('chat', 18), 'Repasar con el profesor'),
    ));
    root.append(box);
  }
}

function stat(icon, num, label) {
  return el('div', { class: 'stat' },
    el('div', { class: 'ic', html: svgIc(icon, 18) }),
    el('div', { class: 'num', text: String(num) }),
    el('div', { class: 'lbl', text: label }));
}