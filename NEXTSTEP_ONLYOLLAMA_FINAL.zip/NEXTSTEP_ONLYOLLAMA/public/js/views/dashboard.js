/* NEXTSTEP — Inicio (escritorio): saludo con barra de XP, módulo del "Próximo paso
   recomendado" y zona de "Ejercicios y práctica" con selector de respuestas premium. */
import { api } from '../api.js';
import * as store from '../store.js';
import { el, svgIc, bar, fmtRel, minutesText, emptyState, modal, toast } from '../ui.js';

export function dashboardView() {
  const root = el('div', { class: 'stack' });
  root.append(skeletonDash());
  load(root);
  return root;
}

function skeletonDash() {
  const s = el('div');
  for (let i = 0; i < 4; i++) s.append(el('div', { class: 'skeleton', style: 'height:150px;margin-bottom:20px;border-radius:24px' }));
  return s;
}

async function load(root) {
  try {
    const d = await api('/dashboard');
    root.innerHTML = '';
    root.append(build(d));
  } catch (e) {
    root.innerHTML = '';
    root.append(emptyState((e && e.message) || 'No se pudo cargar tu inicio.', 'warn'));
  }
}

function build(d) {
  const out = el('div', { class: 'stack' });
  const s = d.stats || {};
  const lvl = d.level || {};

  /* ---------- Hero: saludo + barra de XP ---------- */
  const hero = el('div', { class: 'card neon' });
  const heroGrid = el('div', { class: 'hero' });

  const left = el('div');
  const h1 = el('h1');
  const words = String(d.greeting || 'Hola').split(' ').filter(Boolean);
  words.forEach((w, i) => {
    const last = i === words.length - 1;
    if (last) h1.append(el('span', { class: 'glow-word', text: w }));
    else h1.append(document.createTextNode(w + ' '));
  });
  left.append(h1);
  left.append(el('p', { class: 'lead', text: 'Acá tenés tu panorama de hoy: por dónde seguir, qué practicar y cómo viene tu constancia. Tu profesor te espera cuando lo necesites.' }));

  const pills = el('div', { class: 'hero-streak' });
  pills.append(el('span', { class: 'pill hot' }, svgIc('flame', 15), `${s.streak || 0} días de racha`));
  pills.append(el('span', { class: 'pill' }, svgIc('clock', 15), `${d.constancy ? d.constancy.minutesToday : 0} min hoy`));
  pills.append(el('span', { class: 'pill' }, svgIc('bolt', 15), `${s.activities || 0} actividades`));
  left.append(pills);
  heroGrid.append(left);

  const xpBox = el('div', { class: 'hero-xp' });
  xpBox.append(el('div', { class: 'lvl' }, `Nivel ${lvl.level || 1}`));
  xpBox.append(el('div', { class: 'xp-total' }, String(lvl.xp || 0), ' ', el('small', { text: 'XP totales' })));
  xpBox.append(bar(Number(lvl.progress) || 0));
  xpBox.append(el('div', { class: 'sub', style: 'margin-top:10px' },
    `${Math.max(0, Number(lvl.progress) || 0)}% hacia el nivel ${(Number(lvl.level) || 1) + 1}`));
  heroGrid.append(xpBox);
  hero.append(heroGrid);
  out.append(hero);

  /* ---------- Próximo paso recomendado (POO) ---------- */
  const rec = (d.recommendations && d.recommendations[0]) || null;
  const poo = el('div', { class: 'card neon' });
  const pooGrid = el('div', { class: 'poo' });
  pooGrid.append(el('div', { class: 'poo-badge', html: svgIc(rec ? 'target' : 'sparkles', 32) }));
  const pooTxt = el('div');
  pooTxt.append(el('div', { class: 'tagline', text: 'Próximo paso recomendado' }));
  pooTxt.append(el('h2', { text: rec ? (rec.action || 'Seguí con esto') : 'Contame qué querés aprender' }));
  pooTxt.append(el('p', { class: 'poo-text', text: rec ? rec.text : 'Cargá tus preferencias o escribile a tu profesor para armar tu camino de aprendizaje a medida.' }));
  const meta = el('div', { class: 'poo-meta' });
  if (d.lastPath) meta.append(el('span', { class: 'tag' }, 'Ruta en curso'));
  if (d.goals && d.goals.length) meta.append(el('span', { class: 'tag' }, `${d.goals.length} objetivo(s) activo(s)`));
  if (d.subjects && d.subjects.length) meta.append(el('span', { class: 'tag' }, `${d.subjects.length} materia(s)`));
  pooTxt.append(meta);
  pooGrid.append(pooTxt);
  const cta = el('div', { class: 'poo-cta' });
  if (rec && rec.route) {
    cta.append(el('button', { class: 'btn', onclick: () => store.nav(`/${rec.route}${rec.ref ? '/' + rec.ref : ''}`) },
      svgIc('arrowR', 18), rec.action || 'Ir'));
  }
  cta.append(el('button', { class: 'btn ghost', onclick: () => store.nav('/teacher') }, svgIc('chat', 18), 'Consultar al profesor'));
  cta.append(el('button', { class: 'btn ghost', onclick: openSession }, svgIc('clock', 18), 'Registrar tiempo'));
  pooGrid.append(cta);
  poo.append(pooGrid);
  out.append(poo);

  /* ---------- Ejercicios y práctica ---------- */
  out.append(practiceZone(d));

  /* ---------- Materias y objetivos ---------- */
  const grid = el('div', { class: 'grid-2' });
  grid.append(subjectsCard(d), goalsCard(d));
  out.append(grid);

  /* ---------- Constancia ---------- */
  const week = el('div', { class: 'card' });
  week.append(el('div', { class: 'flex' },
    el('div', { class: 'grow' },
      el('div', { class: 'card-title' }, svgIc('calendar', 18), 'Constancia de la semana'),
      el('div', { class: 'sub' }, `${d.constancy.minutesWeek} min en los últimos 7 días`)),
    el('span', { class: 'pct' }, d.constancy ? minutesText(d.constancy.minutesWeek) : '')));
  week.append(el('div', { style: 'margin-top:18px' }, weekBars(d.weekSeries)));
  out.append(week);

  /* ---------- Retomar ---------- */
  if (d.lastConversation || d.lastPath) {
    const ret = el('div', { class: 'flex wrap' });
    if (d.lastConversation) ret.append(el('button', { class: 'btn ghost', onclick: () => store.nav(`/teacher/${d.lastConversation.id}`) },
      svgIc('chat', 18), `Retomar la charla de ${fmtRel(d.lastConversation.updated_at)}`));
    if (d.lastPath) ret.append(el('button', { class: 'btn ghost', onclick: () => store.nav(`/paths/${d.lastPath.id}`) },
      svgIc('route', 18), 'Seguir tu ruta'));
    out.append(ret);
  }

  return out;
}

/* ---------- Zona de ejercicios y práctica ---------- */
function practiceZone(d) {
  const zone = el('div', { class: 'practice' });

  const exam = el('div', { class: 'card' });
  const head = el('div', { class: 'exam-head' });
  head.append(el('span', { class: 'q-index', text: 'Ejercicios y práctica' }));
  const topicTag = el('span', { class: 'tag' }, 'banco verificado');
  head.append(topicTag);
  head.append(el('span', { class: 'grow' }));
  const nextBtn = el('button', { class: 'btn ghost sm', onclick: () => loadQuestion() }, svgIc('bolt', 16), 'Otra pregunta');
  head.append(nextBtn);
  exam.append(head);

  const body = el('div', {});
  exam.append(body);
  zone.append(exam);

  /* Columna lateral: materia + resumen */
  const aside = el('div', { class: 'exam-aside' });
  const matCard = el('div', { class: 'card' });
  matCard.append(el('div', { class: 'card-title', style: 'font-size:14px' }, svgIc('learn', 16), 'Practicar sobre'));
  const chips = el('div', { class: 'chips', style: 'margin-top:14px' });
  matCard.append(chips);
  aside.append(matCard);

  const info = el('div', { class: 'card' });
  info.append(el('div', { class: 'card-title', style: 'font-size:14px' }, svgIc('info', 16), 'Cómo funciona'));
  info.append(el('p', { class: 'sub', style: 'margin-top:10px' },
    'Son preguntas del banco verificado de NEXTSTEP: una sola respuesta correcta, con explicación. Practicá sin apuro: el profesor sigue tu progreso y te propone lo que falta.'));
  info.append(el('button', { class: 'btn ghost sm', style: 'margin-top:14px', onclick: () => store.nav('/assessments') },
    svgIc('quiz', 16), 'Evaluación completa'));
  aside.append(info);
  zone.append(aside);

  /* Estado de la zona */
  let subjectId = null;
  let answered = false;

  const subjects = (d.subjects || []);
  if (subjects.length) {
    const all = el('button', { class: 'chip on', text: 'General', onclick: () => { subjectId = null; setChips(all); loadQuestion(); } });
    chips.append(all);
    for (const su of subjects) {
      const b = el('button', { class: 'chip', text: su.name, onclick: () => { subjectId = su.id; setChips(b); loadQuestion(); } });
      chips.append(b);
    }
  } else {
    chips.append(el('span', { class: 'sub', text: 'Sin materias todavía: probá una pregunta general.' }));
  }
  function setChips(active) {
    chips.querySelectorAll('.chip').forEach(c => c.classList.toggle('on', c === active));
  }

  async function loadQuestion() {
    answered = false;
    body.innerHTML = '';
    body.append(el('div', { class: 'skeleton', style: 'height:120px;border-radius:18px' }));
    try {
      const qs = subjectId ? `?subject_id=${subjectId}` : '';
      const r = await api(`/practice/next${qs}`);
      topicTag.textContent = r.topic.name;
      renderQuestion(r.question);
    } catch (e) {
      body.innerHTML = '';
      body.append(emptyState((e && e.message) || 'No se pudo cargar una pregunta.', 'warn'));
    }
  }

  function renderQuestion(q) {
    body.innerHTML = '';
    body.append(el('p', { class: 'exam-q', text: q.prompt }));

    const opts = el('div', { class: 'exam-opts' });
    q.options.forEach((text, i) => {
      const opt = el('div', {
        class: 'opt', role: 'button', tabindex: 0,
        onclick: () => pick(i),
        onkeydown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(i); } },
      }, el('span', { class: 'letter', text: 'ABCD'[i] }), el('span', { text }));
      opts.append(opt);
    });
    body.append(opts);

    function pick(i) {
      if (answered) return;
      answered = true;
      const ok = i === q.correct;
      opts.querySelectorAll('.opt').forEach((o, j) => {
        o.setAttribute('aria-disabled', 'true');
        if (j === q.correct) o.classList.add('ok');
        else if (j === i) o.classList.add('bad');
      });
      const fb = el('div', { class: `exam-feedback ${ok ? 'ok' : 'bad'}` });
      fb.append(el('span', { html: svgIc(ok ? 'check' : 'x', 20) }));
      const t = el('div');
      t.append(el('b', { text: ok ? '¡Correcto!' : 'Casi' }));
      t.append(el('span', { text: ok ? 'Buen manejo del tema.' : 'La respuesta correcta era la ' + 'ABCD'[q.correct] + '.' }));
      t.append(el('p', { class: 'sub', style: 'margin-top:6px', text: q.explanation }));
      fb.append(t);
      body.append(fb);

      const actions = el('div', { class: 'flex', style: 'margin-top:18px' });
      actions.append(el('button', { class: 'btn', onclick: () => loadQuestion() }, svgIc('bolt', 18), 'Siguiente pregunta'));
      actions.append(el('button', { class: 'btn ghost', onclick: () => {
        sessionStorage.setItem('ns_pending_msg', `Repasamos juntos este tema: ${q.subtopic}. ${q.prompt}`);
        store.nav('/teacher');
      } }, svgIc('chat', 18), 'Repasar con el profesor'));
      body.append(actions);
    }
  }

  loadQuestion();
  return zone;
}

/* ---------- Tarjetas de materias y objetivos ---------- */
function subjectsCard(d) {
  const card = el('div', { class: 'card' });
  card.append(el('div', { class: 'flex', style: 'margin-bottom:16px' },
    el('div', { class: 'grow card-title' }, svgIc('learn', 18), 'Materias activas'),
    el('button', { class: 'btn ghost sm', onclick: () => store.nav('/learning') }, 'Ver todas')));
  if (d.subjects && d.subjects.length) {
    for (const sub of d.subjects) {
      card.append(el('div', { style: 'margin-bottom:16px' },
        el('div', { class: 'flex' },
          el('div', { class: 'grow' },
            el('p', { style: 'font-weight:700' }, sub.name),
            el('p', { class: 'sub' }, `${sub.level} · ${sub.topicsCount} temas`)),
          el('span', { class: 'pct' }, `${sub.score}%`)),
        el('div', { style: 'margin-top:8px' }, bar(sub.score))));
    }
  } else {
    card.append(emptyState('Todavía no tenés materias. Agregá la primera para armar tu camino.', 'learn',
      el('button', { class: 'btn sm', onclick: () => store.nav('/learning') }, 'Agregar materia')));
  }
  return card;
}

function goalsCard(d) {
  const card = el('div', { class: 'card' });
  card.append(el('div', { class: 'flex', style: 'margin-bottom:16px' },
    el('div', { class: 'grow card-title' }, svgIc('target', 18), 'Objetivos activos'),
    el('button', { class: 'btn ghost sm', onclick: () => store.nav('/goals') }, 'Ver todos')));
  if (d.goals && d.goals.length) {
    for (const g of d.goals.slice(0, 3)) {
      const pct = g.tasksTotal ? Math.round(g.tasksDone / g.tasksTotal * 100) : 0;
      card.append(el('div', { style: 'margin-bottom:16px' },
        el('div', { class: 'flex' },
          el('p', { class: 'grow', style: 'font-weight:600' }, g.title),
          el('span', { class: 'sub' }, g.deadline ? `vence ${fmtRel(g.deadline + 'T23:59:59')}` : '')),
        el('div', { style: 'margin-top:8px' }, bar(pct))));
    }
  } else {
    card.append(emptyState('Sin objetivos por ahora. Definir una meta chica ayuda a mantener el rumbo.', 'target',
      el('button', { class: 'btn sm', onclick: () => store.nav('/goals') }, 'Crear objetivo')));
  }
  return card;
}

function weekBars(series) {
  const w = el('div', { class: 'minibar' });
  if (Array.isArray(series)) {
    const max = Math.max(1, ...series.map(x => x.minutes));
    for (const day of series) {
      const h = Math.round((day.minutes / max) * 100);
      w.append(el('div', { class: 'd' },
        el('div', { class: 'col', title: `${day.label}: ${day.minutes} min` }, el('i', { style: `height:${Math.max(4, h)}%` })),
        el('div', { class: 'lbl', text: day.label })));
    }
  }
  return w;
}

/* Registrar una sesión de estudio rápida */
function openSession() {
  const wrap = el('div', { class: 'stack' });
  const minutes = el('select', { class: 'input' },
    [15, 25, 45, 60, 90].map(m => (m === 25 ? el('option', { value: m, selected: '' }, `${m} min`) : el('option', { value: m }, `${m} min`))));
  const kind = el('select', { class: 'input' },
    ['estudio', 'repaso', 'practica', 'proyecto', 'lectura'].map(k => (k === 'estudio' ? el('option', { value: k, selected: '' }, k) : el('option', { value: k }, k))));

  const cached = store.cacheKey('subjects');
  let subjects = Array.isArray(cached) ? cached : [];
  const subjSel = el('select', { class: 'input' }, el('option', { value: '' }, 'Sin materia específica'));
  for (const su of subjects) subjSel.append(el('option', { value: su.id }, su.name));

  api('/subjects').then(r => {
    store.setCache('subjects', r.subjects);
    for (const su of r.subjects) {
      if (![...subjSel.options].some(o => o.value === String(su.id))) {
        subjSel.append(el('option', { value: su.id }, su.name));
      }
    }
  }).catch(() => {});

  wrap.append(
    el('div', { class: 'field' }, el('label', { text: '¿Cuánto estudiaste?' }), minutes),
    el('div', { class: 'field' }, el('label', { text: 'Tipo' }), kind),
    el('div', { class: 'field' }, el('label', { text: 'Materia (opcional)' }), subjSel),
  );

  let close = () => {};
  close = modal({
    title: 'Registrar tiempo de estudio',
    body: wrap,
    footer: [
      el('button', { class: 'btn ghost', onclick: close }, 'Cancelar'),
      el('button', { class: 'btn', onclick: async () => {
        try {
          const r = await api('/sessions', {
            method: 'POST',
            body: { minutes: Number(minutes.value), kind: kind.value, subject_id: subjSel.value ? Number(subjSel.value) : null },
          });
          close();
          toast(r.gained > 0 ? `¡${minutes.value} min registrados! +${r.gained} XP` : `${minutes.value} min registrados`, 'ok');
          await store.loadMe();
        } catch (e) { toast((e && e.message) || 'No se pudo registrar.', 'err'); }
      } }, 'Guardar'),
    ],
  });
}
