/* NEXTSTEP — Rutas de aprendizaje: creación manual o con IA, módulos y actividades. */
import { api } from '../api.js';
import * as store from '../store.js';
import { el, svgIc, bar, emptyState, modal, toast, fmtDate } from '../ui.js';
import { setupNotice } from '../app.js';

const KINDS = {
  explicacion: { label: 'Explicación', icon: 'book' },
  recurso: { label: 'Recurso', icon: 'link' },
  practica: { label: 'Práctica', icon: 'pencil' },
  evaluacion: { label: 'Evaluación', icon: 'quiz' },
};
const KIND_ORDER = { explicacion: 0, recurso: 1, practica: 2, evaluacion: 3 };

export function pathsView(params) {
  const root = el('div', { class: 'stack' });
  if (params[0]) detail(root, Number(params[0]));
  else list(root);
  return root;
}

/* ---------- Lista ---------- */
async function list(root) {
  root.append(el('div', { class: 'skeleton', style: 'height:110px;border-radius:14px' }));
  try {
    const r = await api('/paths');
    root.innerHTML = '';
    const head = el('div', { class: 'view-head flex wrap' });
    head.append(el('div', { class: 'grow' }, el('h1', { text: 'Rutas de aprendizaje' }), el('p', { text: 'Un camino ordenado de módulos y actividades, del fundamento al avance. Se adapta a tus resultados.' })));
    head.append(el('button', { class: 'btn', onclick: openGenerateModal }, svgIc('sparkles', 18), 'Generar con IA'));
    head.append(el('button', { class: 'btn ghost', onclick: openManualModal }, svgIc('plus', 18), 'Crear a mano'));
    root.append(head);

    if (!r.paths.length) {
      root.append(emptyState('Todavía no tenés rutas. Generá una con IA para tu materia o armala vos a mano.', 'route',
        el('div', { class: 'flex', style: 'justify-content:center' },
          el('button', { class: 'btn', onclick: openGenerateModal }, 'Generar con IA'),
          el('button', { class: 'btn ghost', onclick: openManualModal }, 'Crear a mano'))));
      return;
    }
    for (const p of r.paths) {
      root.append(el('div', { class: 'card', style: 'cursor:pointer', onclick: () => store.nav(`/paths/${p.id}`) },
        el('div', { class: 'flex' },
          el('div', { class: 'grow' }, el('h3', { text: p.title }), el('p', { class: 'sub' }, p.summary || '')),
          el('span', { class: 'pct' }, `${p.progress}%`)),
        el('div', { style: 'margin-top:12px' }, bar(p.progress)),
        el('div', { class: 'flex wrap', style: 'margin-top:12px' },
          el('span', { class: 'tag' }, `${p.modules} módulos`),
          el('span', { class: 'tag en_curso', text: p.nextModule ? 'Seguís en: ' + p.nextModule.title : (p.status || 'pendiente') }),
          el('span', { class: 'muted small', style: 'margin-left:auto' }, `creada ${fmtDate(p.createdAt)}`))));
    }
  } catch (e) {
    root.innerHTML = '';
    root.append(emptyState((e && e.message) || 'No se pudieron cargar las rutas.', 'warn'));
  }
}

async function subjectsOptions() {
  const r = await api('/subjects');
  store.setCache('subjects', r.subjects);
  return r.subjects;
}

function openGenerateModal() {
  const wrap = el('div', { class: 'stack' });
  const subjSel = el('select', { class: 'input' }, el('option', { value: '' }, 'Cargando materias…'));
  const target = el('select', { class: 'input' });
  for (const t of ['Iniciante', 'Básico', 'Intermedio', 'Avanzado', 'Experto']) target.append(el('option', { value: t, ...(t === 'Intermedio' ? { selected: '' } : {}) }, t));
  const hours = el('input', { class: 'input', type: 'number', min: 1, max: 40, value: 5 });
  wrap.append(
    el('div', { class: 'field' }, el('label', { text: 'Materia' }), subjSel),
    el('div', { class: 'field' }, el('label', { text: 'Nivel que querés alcanzar' }), target),
    el('div', { class: 'field' }, el('label', { text: 'Horas por semana' }), hours),
  );
  subjectsOptions().then(r => {
    subjSel.innerHTML = '';
    subjSel.append(el('option', { value: '' }, 'Elegí la materia…'));
    for (const su of r) subjSel.append(el('option', { value: su.id }, su.name));
  }).catch(() => { subjSel.innerHTML = '<option value="">Sin materias</option>'; });

  let close = () => {};
  close = modal({
    title: 'Generar ruta con IA',
    body: wrap,
    footer: [
      el('button', { class: 'btn ghost', onclick: close }, 'Cancelar'),
      el('button', { class: 'btn', onclick: async (e) => {
        if (!subjSel.value) return toast('Elegí la materia.', 'err');
        const b = e.target; b.disabled = true; b.textContent = 'Generando…';
        try {
          const r = await api('/paths/generate', {
            method: 'POST',
            body: { subject_id: Number(subjSel.value), target: target.value, hoursPerWeek: Number(hours.value) },
          });
          close();
          toast('Ruta generada: +20 XP', 'ok');
          await store.loadMe();
          store.nav(`/paths/${r.path.id}`);
        } catch (err) { toast((err && err.message) || 'No se pudo generar la ruta.', 'err'); }
        finally { b.disabled = false; b.textContent = 'Generar'; }
      } }, 'Generar ruta'),
    ],
  });
}

function openManualModal() {
  const wrap = el('div', { class: 'stack' });
  const title = el('input', { class: 'input', placeholder: 'Título de la ruta' });
  const summary = el('textarea', { class: 'input', placeholder: 'Resumen corto (opcional)' });
  const modulesEl = el('div', { class: 'stack' });
  const addModuleInput = el('input', { class: 'input', placeholder: 'Módulo 1: Fundamentos…' });
  wrap.append(
    el('div', { class: 'field' }, el('label', { text: 'Título' }), title),
    el('div', { class: 'field' }, el('label', { text: 'Resumen' }), summary),
    el('div', { class: 'field' }, el('label', { text: 'Módulos (opcional, se agregan los que cargues)' }), modulesEl, el('div', { class: 'row-input' }, addModuleInput,
      el('button', { class: 'btn ghost', onclick: () => {
        const v = addModuleInput.value.trim();
        if (!v) return;
        addModuleInput.value = '';
        modulesEl.append(moduleChip(v));
      } }, 'Agregar'))),
  );
  function moduleChip(v) {
    const line = el('div', { class: 'flex', style: 'background:var(--surface2);border-radius:9px;padding:7px 12px' },
      el('span', { class: 'grow', text: v }));
    line.append(el('button', { class: 'icon-btn danger', style: 'width:28px;height:28px', 'aria-label': 'Quitar', onclick: () => line.remove() }, '×'));
    return line;
  }
  let close = () => {};
  close = modal({
    title: 'Crear ruta a mano',
    body: wrap,
    footer: [
      el('button', { class: 'btn ghost', onclick: close }, 'Cancelar'),
      el('button', { class: 'btn', onclick: async (e) => {
        const b = e.target; b.disabled = true;
        try {
          const r = await api('/paths', {
            method: 'POST',
            body: {
              title: title.value.trim(),
              summary: summary.value.trim(),
              modules: [...modulesEl.children].map(c => ({ title: c.querySelector('span').textContent, objective: '' })),
            },
          });
          close();
          toast('Ruta creada: +20 XP', 'ok');
          await store.loadMe();
          store.nav(`/paths/${r.path.id}`);
        } catch (err) { toast((err && err.message) || 'No se pudo crear.', 'err'); }
        finally { b.disabled = false; }
      } }, 'Crear ruta'),
    ],
  });
}

/* ---------- Detalle ---------- */
async function detail(root, id) {
  root.append(el('div', { class: 'skeleton', style: 'height:220px;border-radius:14px' }));
  let d;
  try { d = await api(`/paths/${id}`); } catch (e) {
    root.innerHTML = '';
    root.append(emptyState((e && e.message) || 'No existe esa ruta.', 'warn', el('button', { class: 'btn ghost', onclick: () => store.nav('/paths') }, 'Volver a rutas')));
    return;
  }
  root.innerHTML = '';
  const p = d.path;

  const head = el('div', { class: 'view-head flex wrap' });
  const h = el('div', { class: 'grow' });
  h.append(el('h1', { text: p.title }));
  h.append(el('p', { text: p.summary || (d.subject ? `Ruta de ${d.subject.name}` : '') }));
  head.append(h,
    el('button', { class: 'btn ghost', onclick: () => store.nav(`/teacher${d.subject ? `?tema=${p.title}` : ''}`) }, svgIc('chat', 18), 'Hablar con el profesor'));
  root.append(head);

  const statRow = el('div', { class: 'stat-row' });
  statRow.append(stat('route', `${p.progress}%`, 'avance'));
  statRow.append(stat('list', String(p.modules), 'módulos'));
  statRow.append(stat('check', String(p.modulesDone || 0), 'módulos hechos'));
  root.append(statRow);

  const trail = el('div', { class: 'trail' });
  for (const m of d.modules) {
    const acts = [...(m.activities || [])].sort((a, b) => KIND_ORDER[a.kind] - KIND_ORDER[b.kind] || a.id - b.id);
    const doneActs = acts.filter(a => a.status === 'completada').length;
    trail.append(el('div', { class: `node ${m.status}` },
      el('div', { class: 'flex' },
        el('div', { class: 'grow' }, el('p', { style: 'font-weight:700' }, m.title), el('p', { class: 'sub' }, m.objective || '')),
        el('span', { class: 'tag', text: STATUS_MODULE[m.status] || m.status })),
      el('div', { style: 'margin-top:8px' },
        ...acts.map(a => actRow(a, m, () => detail(root, id))),
        el('div', { class: 'row-input', style: 'margin-top:8px' },
          el('input', { class: 'input', placeholder: 'Agregar actividad…', 'data-module': m.id }),
          el('button', { class: 'btn sm', 'data-add': m.id }, svgIc('plus', 16))))));
  }
  // Delegación global para inputs agregados (evita clausuras por fila).
  trail.querySelectorAll('[data-add]').forEach(btn => {
    const mid = btn.dataset.add;
    const inp = trail.querySelector(`[data-module="${mid}"]`);
    btn.addEventListener('click', () => addActivity(mid, inp, () => detail(root, id)));
  });
  trail.querySelectorAll('.node').forEach(node => {
    const acts = node.querySelectorAll('.act');
    acts.forEach(a => {
      a.querySelectorAll('[data-done]').forEach(b => b.addEventListener('click', async () => {
        try {
          const r = await api(`/activities/${b.dataset.done}`, { method: 'PUT', body: { status: b.dataset.next } });
          if (r.gained) { toast(`+${r.gained} XP`, 'ok'); await store.loadMe(); }
          detail(root, id);
        } catch (e) { toast((e && e.message) || 'No se pudo actualizar.', 'err'); }
      }));
    });
  });

  const card = el('div', { class: 'card' }, el('div', { class: 'card-title', style: 'margin-bottom:10px' }, svgIc('route', 18), 'Recorrido'));
  card.append(trail);
  root.append(card);

  root.append(el('div', { class: 'flex wrap' },
    el('button', { class: 'btn ghost', onclick: () => store.nav('/paths') }, 'Volver a rutas'),
    el('button', { class: 'btn ghost danger', onclick: async () => {
      if (!confirm('¿Eliminar esta ruta? Se borran sus módulos y actividades.')) return;
      try { await api(`/paths/${id}`, { method: 'DELETE' }); toast('Ruta eliminada', 'ok'); store.nav('/paths'); } catch (e) { toast((e && e.message) || 'No se pudo borrar.', 'err'); }
    } }, svgIc('trash', 18), 'Eliminar ruta'),
    el('button', { class: 'btn', onclick: () => store.nav('/teacher') }, svgIc('chat', 18), 'Practicar esto en el chat'),
  ));
}

const STATUS_MODULE = { pendiente: 'pendiente', en_curso: 'en curso', completado: 'completado' };

function stat(icon, num, label) {
  return el('div', { class: 'stat' },
    el('div', { class: 'ic', html: svgIc(icon, 18) }),
    el('div', { class: 'num', text: String(num) }),
    el('div', { class: 'lbl', text: label }));
}

function actRow(a, module, refresh) {
  const k = KINDS[a.kind] || KINDS.practica;
  const done = a.status === 'completada';
  const div = el('div', { class: `act${done ? ' done' : ''}`, style: 'flex-wrap:wrap' });
  div.append(el('span', { class: 'ic2', html: svgIc(done ? 'check' : k.icon, 17) , style: 'display:flex;color:var(--muted)'}),
    el('div', { class: 'grow' }, el('p', { style: 'font-weight:600;font-size:.92rem' }, a.title),
      el('p', { class: 'meta', style: 'font-size:.78rem' }, done ? `completada · ${a.score || 0}/100` : 'pendiente')));
  if (!done) div.append(el('button', { class: 'btn sm', 'data-done': a.id, 'data-next': 'completada' }, 'Marcar hecha'));
  else div.append(el('button', { class: 'btn sm ghost', 'data-done': a.id, 'data-next': 'pendiente' }, 'Deshacer'));
  return div;
}

async function addActivity(moduleId, input, refresh) {
  const title = input.value.trim();
  if (!title) return;
  try {
    await api(`/modules/${moduleId}/activities`, { method: 'POST', body: { title } });
    input.value = '';
    refresh();
  } catch (e) { toast((e && e.message) || 'No se pudo agregar.', 'err'); }
}