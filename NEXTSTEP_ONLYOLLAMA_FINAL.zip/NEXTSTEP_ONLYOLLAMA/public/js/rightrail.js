/* NEXTSTEP · Riel derecho de escritorio: widget de Foco (Pomodoro) y acceso directo
   al Profesor IA. Vive en el shell, no en las vistas, así acompaña a todas las secciones. */
import { api } from './api.js';
import * as store from './store.js';
import { el, svgIc, toast } from './ui.js';

const FOCUS_PRESETS = [
  { label: '25 / 5', focus: 25 * 60, rest: 5 * 60 },
  { label: '50 / 10', focus: 50 * 60, rest: 10 * 60 },
  { label: '90 / 20', focus: 90 * 60, rest: 20 * 60 },
];

const SUGGESTIONS = [
  'Explicame esto con otro ejemplo',
  'No me des la solución todavía',
  'Evaluá mi nivel con 3 preguntas',
  'Armame un plan para esta semana',
];

let timer = null;
let state = { focus: 25 * 60, rest: 5 * 60, phase: 'focus', left: 25 * 60, running: false, preset: 0 };

export function mountRightRail(container) {
  container.innerHTML = '';
  container.append(focusCard(), aiCard(), progressCard());

  store.on(evt => { if (evt === 'me') paintProgress(); });
  paintProgress();
}

/* ---------------- Foco (Pomodoro) ---------------- */
function focusCard() {
  const card = el('div', { class: 'rail-card' });

  const head = el('div', { class: 'rail-head' },
    el('span', { class: 'dot' }),
    el('h3', { text: 'Foco' }),
    el('span', { class: 'sub', style: 'margin-left:auto', id: 'focus-phase' }, 'Estudio'));
  card.append(head);

  const ring = el('div', { class: 'focus-ring' });
  ring.innerHTML = `
    <svg viewBox="0 0 168 168" aria-hidden="true">
      <defs>
        <linearGradient id="focusGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="var(--accent)"/>
          <stop offset="100%" stop-color="var(--accent-2)"/>
        </linearGradient>
      </defs>
      <circle class="track" cx="84" cy="84" r="76"/>
      <circle class="prog" cx="84" cy="84" r="76" id="focus-prog"/>
    </svg>`;
  const time = el('div', { class: 'focus-time' });
  time.append(el('span', { id: 'focus-clock' }, '25:00'), el('small', { id: 'focus-label' }, 'listo para empezar'));
  ring.append(time);
  card.append(ring);

  const presets = el('div', { class: 'focus-presets' });
  FOCUS_PRESETS.forEach((p, i) => {
    const b = el('button', { class: i === 0 ? 'on' : '', text: p.label, onclick: () => {
      state.preset = i; state.focus = p.focus; state.rest = p.rest; state.left = p.focus; state.phase = 'focus'; state.running = false;
      stop(); paintFocus(); presets.querySelectorAll('button').forEach((x, j) => x.classList.toggle('on', j === i));
    } });
    presets.append(b);
  });
  card.append(presets);

  const startBtn = el('button', { class: 'btn', onclick: toggle });
  startBtn.append(el('span', { html: svgIc('play', 18) }), document.createTextNode(' Empezar'));
  const resetBtn = el('button', { class: 'btn ghost', title: 'Reiniciar', html: svgIc('stop', 18), onclick: () => {
    stop(); state.left = state.phase === 'focus' ? state.focus : state.rest; paintFocus();
  } });
  card.append(el('div', { class: 'focus-actions' }, startBtn, resetBtn));

  card._paint = paintFocus;
  card._start = startBtn;

  function toggle() {
    if (state.running) { stop(); } else { run(); }
    paintFocus();
  }
  function run() {
    state.running = true;
    clearInterval(timer);
    timer = setInterval(() => {
      state.left -= 1;
      if (state.left <= 0) { finish(); return; }
      paintFocus();
    }, 1000);
  }
  function stop() { state.running = false; clearInterval(timer); timer = null; }
  async function finish() {
    stop();
    const wasFocus = state.phase === 'focus';
    const minutes = Math.round((wasFocus ? state.focus : state.rest) / 60);
    state.phase = wasFocus ? 'rest' : 'focus';
    state.left = wasFocus ? state.rest : state.focus;
    paintFocus();
    if (!wasFocus) return;
    try {
      const r = await api('/sessions', { method: 'POST', body: { minutes, kind: 'estudio', subject_id: null } });
      toast(r.gained > 0 ? `¡Sesión de ${minutes} min! +${r.gained} XP` : `Sesión de ${minutes} min registrada`, 'ok');
      store.loadMe();
    } catch {
      toast(`Sesión de ${minutes} min completada`, 'ok');
    }
  }

  function paintFocus() {
    const clock = card.querySelector('#focus-clock');
    const label = card.querySelector('#focus-label');
    const prog = card.querySelector('#focus-prog');
    const phase = card.querySelector('#focus-phase');
    const btn = card.querySelector('.focus-actions .btn');
    if (!clock) return;
    const m = String(Math.floor(state.left / 60)).padStart(2, '0');
    const s = String(state.left % 60).padStart(2, '0');
    clock.textContent = `${m}:${s}`;
    const total = state.phase === 'focus' ? state.focus : state.rest;
    const C = 2 * Math.PI * 76;
    prog.style.strokeDasharray = C;
    prog.style.strokeDashoffset = C * (1 - (state.left / total));
    label.textContent = state.running ? (state.phase === 'focus' ? 'en curso' : 'descanso') : (state.phase === 'focus' ? 'listo para empezar' : 'descanso');
    phase.textContent = state.phase === 'focus' ? 'Estudio' : 'Descanso';
    btn.innerHTML = '';
    btn.append(el('span', { html: svgIc(state.running ? 'stop' : 'play', 18) }), document.createTextNode(state.running ? ' Pausar' : (state.left < total ? ' Continuar' : ' Empezar')));
  }

  paintFocus();
  return card;
}

/* ---------------- Profesor IA ---------------- */
function aiCard() {
  const card = el('div', { class: 'rail-card' });
  const meta = store.getMeta();

  const head = el('div', { class: 'rail-head' },
    el('span', { class: 'ai-orb', html: svgIc('sparkles', 22) }),
    el('div', {},
      el('h3', { text: 'Profesor IA' }),
      el('div', { class: 'sub', id: 'ai-status' }, 'Consultá lo que necesites')),
    el('span', { class: 'dot', id: 'ai-dot' }));
  card.append(head);

  const s = el('div', { class: 'ai-suggest' });
  for (const q of SUGGESTIONS) {
    s.append(el('button', { text: q, onclick: () => {
      sessionStorage.setItem('ns_pending_msg', q);
      store.nav('/teacher');
    } }));
  }
  card.append(s);

  card.append(el('button', { class: 'btn block', onclick: () => store.nav('/teacher') },
    el('span', { html: svgIc('chat', 18) }), document.createTextNode('Abrir el chat')));

  const status = card.querySelector('#ai-status');
  const dot = card.querySelector('#ai-dot');
  if (meta && meta.requiresSetup) {
    status.textContent = 'IA sin configurar en el servidor';
    dot.classList.add('off');
  } else {
    status.textContent = 'Conectado · responde en vivo';
  }
  return card;
}

/* ---------------- Progreso ---------------- */
function progressCard() {
  const card = el('div', { class: 'rail-card' });
  card.append(el('div', { class: 'rail-head' },
    el('span', { class: 'dot' }),
    el('h3', { text: 'Tu progreso' })));

  const ring = el('div', { class: 'focus-ring', style: 'width:132px;height:132px' });
  ring.innerHTML = `
    <svg viewBox="0 0 168 168" aria-hidden="true">
      <defs>
        <linearGradient id="lvlGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="var(--accent)"/>
          <stop offset="100%" stop-color="var(--accent-2)"/>
        </linearGradient>
      </defs>
      <circle class="track" cx="84" cy="84" r="76"/>
      <circle class="prog" cx="84" cy="84" r="76" id="lvl-prog" style="stroke:url(#lvlGrad)"/>
    </svg>`;
  const time = el('div', { class: 'focus-time', style: 'font-size:30px' });
  time.append(el('span', { id: 'lvl-num' }, '1'), el('small', { id: 'lvl-sub' }, 'nivel'));
  ring.append(time);
  card.append(ring);

  const stats = el('div', { class: 'rail-stats' });
  stats.append(
    el('div', { class: 'rail-stat' }, el('b', { id: 'rail-streak' }, '0'), el('span', { text: 'días de racha' })),
    el('div', { class: 'rail-stat' }, el('b', { id: 'rail-min' }, '0'), el('span', { text: 'min. hoy' })),
  );
  card.append(stats);
  return card;
}

function paintProgress() {
  const lvl = store.get().level || {};
  const stats = store.get().stats || {};
  const num = document.getElementById('lvl-num');
  if (num) num.textContent = String(lvl.level || 1);
  const sub = document.getElementById('lvl-sub');
  if (sub) sub.textContent = `${lvl.xp || 0} XP`;
  const prog = document.getElementById('lvl-prog');
  if (prog) {
    const C = 2 * Math.PI * 76;
    prog.style.strokeDasharray = C;
    prog.style.strokeDashoffset = C * (1 - (Number(lvl.progress) || 0) / 100);
  }
  const streak = document.getElementById('rail-streak');
  if (streak) streak.textContent = String(stats.streak || 0);
}
