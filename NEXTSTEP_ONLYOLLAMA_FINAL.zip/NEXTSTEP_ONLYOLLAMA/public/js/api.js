/* NEXTSTEP — capa de comunicación con el backend. */
let TOKEN = (() => { try { return localStorage.getItem('ns_token') || null; } catch { return null; } })();
export const apiListeners = new Set();
const emit = (t, d) => apiListeners.forEach(f => { try { f(t, d); } catch { /* noop */ } });

export const setToken = t => { TOKEN = t || null; try { if (t) localStorage.setItem('ns_token', t); else localStorage.removeItem('ns_token'); } catch { /* la sesión sigue viva en memoria */ } };
export const getToken = () => TOKEN;

export class ApiError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

async function parse(res) {
  let data = null;
  try { data = await res.json(); } catch { /* sin cuerpo */ }
  if (!res.ok) {
    const msg = (data && data.error) || `Error del servidor (${res.status})`;
    throw new ApiError(msg, res.status);
  }
  return data;
}

export async function api(path, { method = 'GET', body, raw } = {}) {
  const headers = {};
  if (TOKEN) headers.Authorization = `Bearer ${TOKEN}`;
  let opts = { method, headers };
  if (body !== undefined) { headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
  if (raw) opts.body = raw;
  const res = await fetch('/api' + path, { ...opts, cache: 'no-store' });
  return parse(res);
}

/* Lectura del stream del chat (SSE). Devuelve texto y metadatos. */
export function streamChat({ conversationId, content, onChunk, signal }) {
  return new Promise((resolve, reject) => {
    (async () => {
      const ctl = signal || new AbortController();
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(TOKEN ? { Authorization: `Bearer ${TOKEN}` } : {}) },
        body: JSON.stringify({ conversationId, content }),
        signal: ctl.signal,
        cache: 'no-store',
      });
      if (!res.ok) {
        let msg;
        try { const j = await res.json(); msg = j.error; } catch { msg = `Error ${res.status}`; }
        throw new ApiError(msg, res.status);
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = '', text = '', out = { text: '', quick: [], resumen: '', perfil: null, done: false };
      for (;;) {
        let r;
        try { r = await reader.read(); } catch (e) { if (e.name === 'AbortError') { reject(e); return; } throw e; }
        if (r.done) break;
        buf += dec.decode(r.value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim();
          buf = buf.slice(i + 1);
          if (!line.startsWith('data:')) continue;
          let o;
          try { o = JSON.parse(line.slice(5).trim()); } catch { continue; }
          if (o.t) { text += o.t; onChunk && onChunk(o.t); }
          if (o.done) {
            out.done = true; out.quick = o.quick || []; out.resumen = o.resumen || ''; out.perfil = o.perfil || null;
            if (typeof o.clean === 'string' && o.clean.trim()) out.text = o.clean;
          }
          if (o.error) { throw new ApiError(o.error, 502); }
        }
      }
      out.text = text;
      resolve(out);
    })().catch(reject);
  });
}