// NEXTSTEP — plataforma educativa con profesor IA.
// Backend: Express 5 + SQLite (node:sqlite, integrado en Node.js 22.5+).
import dotenv from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import rateLimit from 'express-rate-limit';
import { initDb } from './src/db.js';
import { aiUsageTotals } from './src/db.js';
import { GREETING, START_QUICK, ALLOWED_URLS, MODES as PROMPT_MODES } from './src/prompt.js';
import { providerInfo, providerReady, providerModel, providerName, listOllamaModels, missingConfigMessage } from './src/llm.js';
import { userIdForToken } from './src/auth.js';
import { authRouter } from './src/routes/auth.js';
import { contentRouter } from './src/routes/content.js';
import { richRouter } from './src/routes/rich.js';
import { productivityRouter } from './src/routes/productivity.js';
import { progressRouter } from './src/routes/progress.js';
import { chatRouter } from './src/routes/chat.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// El .env siempre se busca junto al proyecto, sin importar desde dónde se ejecute.
dotenv.config({ path: path.join(__dirname, '.env') });
const PORT = Number(process.env.PORT) || 3000;

// Autenticación opcional: valida el token si viene, pero no lo exige (rutas informativas).
const requireAuthAny = (req, res, next) => {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  const uid = token ? userIdForToken(token) : null;
  req.userId = uid;
  next();
};

initDb();

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '200kb' }));

// Las respuestas de la API dependen de la sesión y de datos que cambian.
// Evita que el navegador reutilice respuestas 304/caché entre inicios de sesión.
app.use('/api', (_req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  next();
});

const limiter = rateLimit({
  windowMs: 60_000,
  limit: Number(process.env.RATE_LIMIT_PER_MIN) || 40,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Hiciste muchas consultas seguidas. Esperá un minuto y probá de nuevo.' },
});

// ---- Público ----
app.get('/api/health', (_req, res) => {
  const { provider, order, model, ready } = providerInfo();
  res.json({ ok: true, provider, order, model, active: provider, ia: ready });
});

app.get('/api/meta', (_req, res) => {
  res.json({
    greeting: GREETING,
    startQuick: START_QUICK,
    allowedUrls: ALLOWED_URLS,
    modes: Object.keys(PROMPT_MODES),
    requiresSetup: !providerInfo().ready,
    setupMessage: missingConfigMessage(),
  });
});

app.get('/api/ai/status', requireAuthAny, async (req, res) => {
  const info = providerInfo();
  const out = { provider: info.provider, order: info.order, model: info.model, ready: info.ready, providers: [] };
  // Vuele la lista de proveedores del .env con si cada uno está listo.
  for (const p of info.order) {
    out.providers.push({ id: p, name: providerName(p), model: providerModel(p) || null, ready: providerReady(p), active: p === info.provider });
  }
  // Si hay Ollama, muestra los modelos que tiene descargados.
  if (info.order.includes('ollama')) {
    try { out.ollamaModels = await listOllamaModels(); }
    catch { out.ollamaModels = null; out.ollamaOffline = true; }
  }
  out.usage = aiUsageTotals();
  res.json(out);
});

app.get('/api/ai/usage', requireAuthAny, (_req, res) => {
  res.json({ usage: aiUsageTotals() });
});

// ---- Rutas autenticadas ----
app.use('/api/auth', limiter, authRouter);
app.use('/api', contentRouter);      // materias, temas, conversaciones
app.use('/api', richRouter);         // rutas, módulos, actividades, evaluaciones
app.use('/api', productivityRouter); // objetivos, tareas, recursos, sesiones
app.use('/api', progressRouter);     // dashboard, estadísticas
app.use('/api', limiter, chatRouter); // chat SSE

// ---- Estáticos y SPA ----
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0,
  setHeaders(res, filePath) {
    if (/\.(?:html|js)$/.test(filePath)) {
      res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    }
  },
}));
app.use((req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Manejo de errores amigable (nunca filtra datos sensibles).
app.use((err, req, res, _next) => {
  const status = typeof err?.status === 'number' && err.status >= 400 && err.status < 500 ? err.status : 500;
  console.error('[error]', status, req.method, req.originalUrl, '\n', err?.stack ?? err);
  if (res.headersSent) return;
  res.status(status).json({ error: status === 500 ? 'Algo salió mal en el servidor. Probá de nuevo.' : err.message });
});

app.listen(PORT, () => {
  console.log(`NEXTSTEP andando en http://localhost:${PORT}`);
  const info = providerInfo();
  console.log(`IA: ${info.provider}${info.model ? ' / ' + info.model : ''} (orden: ${info.order.join(' → ')})`);
  if (!info.ready) console.warn('Atención: ' + missingConfigMessage(info.provider) + ' Copiá .env.example a .env y completalo.');
});