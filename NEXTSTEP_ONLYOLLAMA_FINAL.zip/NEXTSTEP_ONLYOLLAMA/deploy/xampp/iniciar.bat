@echo off
rem ==========================================================================
rem  NEXTSTEP - iniciar con XAMPP (Apache + Node)
rem  Levanta Apache (sirve el frontend y hace de proxy a la API) y la API de Node.
rem  Uso: doble clic en este archivo.
rem ==========================================================================
setlocal enabledelayedexpansion
chcp 65001 >nul

set "HERE=%~dp0"
set "PROJECT=%HERE%..\.."
for %%I in ("%PROJECT%") do set "PROJECT=%%~fI"
set "XAMPP=C:\xampp"
set "HTTPD=%XAMPP%\apache\bin\httpd.exe"
set "HTTPD_CONF=%XAMPP%\apache\conf\httpd.conf"
set "PORT=8080"
set "API_PORT=3000"
set "PIDFILE=%HERE%nextstep.pid"

echo.
echo  ==============================================
echo   NEXTSTEP - servidor XAMPP + Node
echo  ==============================================
echo.

if not exist "%HTTPD%" (
  echo  [X] No encontre Apache en %HTTPD%
  echo      Instala XAMPP o edita la variable XAMPP en este archivo.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%configurar.ps1" -ProjectDir "%PROJECT%" -XamppDir "%XAMPP%" -Port %PORT% -ApiPort %API_PORT%
if errorlevel 2 (
  echo.
  echo  [X] La configuracion de Apache quedo invalida. Revisa el mensaje de arriba.
  pause
  exit /b 2
)

taskkill /IM httpd.exe /F >nul 2>&1
timeout /t 1 /nobreak >nul
start "" "%HTTPD%" -f "%HTTPD_CONF%"
echo  [OK] Apache levantado.

set "NODEEXE="
for /f "delims=" %%n in ('where node 2^>nul') do if not defined NODEEXE set "NODEEXE=%%n"
if not defined NODEEXE (
  if exist "%ProgramFiles%\nodejs\node.exe" set "NODEEXE=%ProgramFiles%\nodejs\node.exe"
)
if not defined NODEEXE (
  echo  [X] No encontre Node.js. Instalalo desde https://nodejs.org (version 22.5 o mas).
  pause
  exit /b 3
)
if not exist "%PROJECT%\node_modules" (
  echo  [i] Instalando dependencias con npm install...
  pushd "%PROJECT%"
  call npm.cmd install
  popd
)

if exist "%PIDFILE%" (
  for /f %%p in ('type "%PIDFILE%"') do (
    taskkill /PID %%p /F >nul 2>&1
  )
  del "%PIDFILE%" >nul 2>&1
)

echo  [i] Levantando la API de Node...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Start-Process -FilePath '%NODEEXE%' -ArgumentList '%PROJECT%\server.js' -WorkingDirectory '%PROJECT%' -WindowStyle Minimized -PassThru; Set-Content -Path '%PIDFILE%' -Value $p.Id"
if errorlevel 1 (
  echo  [X] No se pudo levantar Node.
  pause
  exit /b 4
)
set "NODE_PID="
if exist "%PIDFILE%" set /p NODE_PID=<"%PIDFILE%"
if defined NODE_PID (
  echo  [OK] API de Node ^(PID %NODE_PID%^).
) else (
  echo  [X] No se pudo levantar Node.
  pause
  exit /b 4
)

timeout /t 3 /nobreak >nul
start "" "http://localhost:%PORT%"
echo.
echo  ==============================================
echo   Listo: http://localhost:%PORT%
echo   Para detener todo: detener.bat
echo  ==============================================
echo.
exit /b 0
