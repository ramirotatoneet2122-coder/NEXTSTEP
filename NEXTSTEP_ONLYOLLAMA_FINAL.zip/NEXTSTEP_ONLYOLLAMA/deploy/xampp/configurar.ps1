# ==========================================================================
# NEXTSTEP - configurador de XAMPP (Apache)
# Instala el VirtualHost de NEXTSTEP en Apache, activa mod_proxy y valida la config.
# Es idempotente: se puede volver a ejecutar sin romper nada.
#
#   powershell -ExecutionPolicy Bypass -File configurar.ps1 [-ProjectDir <ruta>] [-XamppDir C:\xampp] [-Port 8080] [-ApiPort 3000]
#
# Nota: el archivo es ASCII puro a proposito (PowerShell 5.1 lo lee como ANSI).
# ==========================================================================
param(
  [string]$ProjectDir = '',
  [string]$XamppDir   = 'C:\xampp',
  [int]$Port          = 8080,
  [int]$ApiPort       = 3000
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not $ProjectDir) { $ProjectDir = (Resolve-Path (Join-Path $here '..\..')).Path }
$ProjectDir = (Resolve-Path $ProjectDir).Path

$confDir   = Join-Path $XamppDir 'apache\conf'
$httpd     = Join-Path $XamppDir 'apache\bin\httpd.exe'
$httpdConf = Join-Path $confDir 'httpd.conf'
$vhostDst  = Join-Path $confDir 'extra\nextstep.conf'
$vhostSrc  = Join-Path $here 'nextstep.conf'

function Say($msg, $color = 'Gray') { Write-Host $msg -ForegroundColor $color }

if (-not (Test-Path $httpd)) {
  Say "XAMPP no encontrado en $XamppDir" 'Red'
  Say "Instala XAMPP o pasa -XamppDir con la ruta correcta." 'Yellow'
  exit 1
}
if (-not (Test-Path (Join-Path $ProjectDir 'public'))) {
  Say "La carpeta $ProjectDir no parece el proyecto NEXTSTEP (falta public/)." 'Red'
  exit 1
}

Say "Proyecto : $ProjectDir" 'Cyan'
Say "XAMPP    : $XamppDir" 'Cyan'
Say "Puertos  : Apache $Port  ->  API Node $ApiPort" 'Cyan'

# ---- 1. Copia de seguridad de httpd.conf (solo la primera vez) ----
$backup = Join-Path $confDir 'httpd.conf.nextstep.bak'
if (-not (Test-Path $backup)) {
  Copy-Item $httpdConf $backup
  Say "Copia de seguridad: $backup" 'DarkGray'
}

# ---- 2. Activar mod_proxy_http (necesario para proxear a http://) ----
$conf = Get-Content $httpdConf -Raw
if ($conf -match '(?m)^#(LoadModule\s+proxy_http_module\s+.*)$') {
  $conf = [regex]::Replace($conf, '(?m)^#(LoadModule\s+proxy_http_module\s+.*)$', '$1')
  Say "mod_proxy_http activado" 'Green'
}
if ($conf -notmatch '(?m)^LoadModule\s+proxy_module\s') {
  $conf = [regex]::Replace($conf, '(?m)^#(LoadModule\s+proxy_module\s+.*)$', '$1')
  Say "mod_proxy activado" 'Green'
}

# ---- 3. Include del vhost de NEXTSTEP ----
$includeLine = 'Include conf/extra/nextstep.conf'
if ($conf -notmatch [regex]::Escape($includeLine)) {
  $conf = $conf.TrimEnd() + "`r`n`r`n# NEXTSTEP (agregado por deploy/xampp/configurar.ps1)`r`n$includeLine`r`n"
  Say "Include agregado a httpd.conf" 'Green'
}

Set-Content -Path $httpdConf -Value $conf -Encoding ASCII

# ---- 4. Escribir el VirtualHost con las rutas reales ----
$vhost = Get-Content $vhostSrc -Raw
$vhost = $vhost.Replace('__PROJECT_DIR__', $ProjectDir.Replace('\', '/'))
$vhost = $vhost.Replace('__PORT__', [string]$Port)
$vhost = $vhost.Replace('__API_PORT__', [string]$ApiPort)
Set-Content -Path $vhostDst -Value $vhost -Encoding ASCII
Say "VirtualHost escrito: $vhostDst" 'Green'

# ---- 5. Validar la configuracion de Apache ----
# httpd -t escribe "Syntax OK" en stderr: se baja el nivel de error para no cortarlo.
$ErrorActionPreference = 'Continue'
$check = (& $httpd -f (Join-Path $confDir 'httpd.conf') -t 2>&1 | Out-String)
$code = $LASTEXITCODE
$ErrorActionPreference = 'Stop'
if ($code -ne 0) {
  Say 'LA CONFIGURACION DE APACHE TIENE ERRORES:' 'Red'
  Write-Host $check -ForegroundColor Red
  Say "Para volver atras: Copy-Item `"$backup`" `"$httpdConf`"" 'Yellow'
  exit 2
}
Say 'Configuracion de Apache valida.' 'Green'
Say "Listo: http://localhost:$Port" 'Cyan'
exit 0
