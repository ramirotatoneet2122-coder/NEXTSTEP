<?php
/*
 * NEXTSTEP — configuración.
 *
 * XAMPP: no hace falta tocar nada de la base de datos (usuario root sin contraseña, es el valor por defecto).
 * Solo pegá tu clave de Gemini en 'gemini_api_key' (se saca gratis en https://aistudio.google.com/apikey).
 *
 * Este archivo es PHP: si alguien lo abre desde el navegador, no se ve nada. La clave nunca llega al navegador.
 */
return [
    // --- Base de datos MySQL (XAMPP / MariaDB) ---
    'db_host' => '127.0.0.1',
    'db_port' => 3306,
    'db_name' => 'nextstep',      // se crea sola si no existe
    'db_user' => 'root',
    'db_pass' => '',              // cambiala si le pusiste contraseña a MySQL (recomendado antes de exponer la app)

    // --- Google Gemini ---
    'gemini_api_key' => 'PEGA_AQUI_TU_CLAVE',

    // Mensajes de IA por usuario y por día (cuida tu cuota de Gemini)
    'chat_daily_limit' => 150,
];
