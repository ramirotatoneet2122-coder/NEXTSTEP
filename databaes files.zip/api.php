<?php
/*
 * NEXTSTEP — backend en PHP + MySQL (funciona en XAMPP y en cualquier hosting con PHP 7.4+).
 * Todo lo que pide la interfaz entra por acá:  api.php?r=<ruta>
 *   Cuentas:  auth/register, auth/login, auth/logout, auth/me, auth/password
 *   Datos:    state, settings, action, reset, chat, health
 * La base de datos y las tablas se crean solas la primera vez.
 */
ini_set('display_errors', '0');
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

$CFG = require __DIR__ . '/config.php';

class HttpError extends Exception
{
    public $status;
    public $extra;
    public function __construct($status, $message, $extra = [])
    {
        parent::__construct($message);
        $this->status = $status;
        $this->extra = $extra;
    }
}

function out($code, $data)
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

set_exception_handler(function ($e) {
    if ($e instanceof HttpError) {
        out($e->status, ['error' => $e->getMessage()] + $e->extra);
    }
    error_log('NEXTSTEP: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    $msg = ($e instanceof PDOException)
        ? 'No se pudo usar la base de datos MySQL. Revisá que MySQL esté iniciado (XAMPP) y los datos de config.php.'
        : 'Error interno del servidor.';
    out(500, ['error' => $msg]);
});

/* ------------------------------------------------------------------ utilidades */

function now_ms() { return (int) round(microtime(true) * 1000); }

function clip_str($v, $max, $fallback)
{
    if (!is_string($v)) return $fallback;
    $v = trim($v);
    if ($v === '') return $fallback;
    return function_exists('mb_substr') ? mb_substr($v, 0, $max, 'UTF-8') : substr($v, 0, $max);
}

function str_len($s) { return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : strlen($s); }

function is_https()
{
    $h = isset($_SERVER['HTTPS']) ? $_SERVER['HTTPS'] : '';
    $p = isset($_SERVER['HTTP_X_FORWARDED_PROTO']) ? $_SERVER['HTTP_X_FORWARDED_PROTO'] : '';
    return ($h !== '' && $h !== 'off') || strtolower($p) === 'https';
}

function client_ip()
{
    $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    // Detrás de un túnel local (ngrok, cloudflared) todo llega desde 127.0.0.1: se usa la IP real que informa el túnel
    if (($ip === '127.0.0.1' || $ip === '::1') && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $parts = array_map('trim', explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']));
        $ip = end($parts);
    }
    return substr($ip, 0, 45);
}

function cookie_base()
{
    $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
    return rtrim($dir, '/') . '/';
}

function body_json()
{
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') return [];
    if (strlen($raw) > 1000000) throw new HttpError(413, 'Solicitud demasiado grande.');
    $d = json_decode($raw, true);
    if (!is_array($d)) throw new HttpError(400, 'JSON inválido.');
    return $d;
}

function arr($v) { return is_array($v) ? $v : []; }

/* ------------------------------------------------------------------ base de datos */

function db()
{
    global $CFG;
    static $pdo = null;
    if ($pdo) return $pdo;

    $opts = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    $name = preg_replace('/[^A-Za-z0-9_]/', '', $CFG['db_name']);
    $base = 'mysql:host=' . $CFG['db_host'] . ';port=' . (int) $CFG['db_port'] . ';charset=utf8mb4';

    $pdo = new PDO($base, $CFG['db_user'], $CFG['db_pass'], $opts);
    try {
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    } catch (PDOException $e) {
        // usuario sin permiso para crear bases: se asume que la base ya existe
    }
    $pdo->exec("USE `$name`");
    ensure_schema($pdo);
    return $pdo;
}

function ensure_schema(PDO $pdo)
{
    if ($pdo->query("SHOW TABLES LIKE 'users'")->fetch()) return;
    $tail = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(30) NOT NULL UNIQUE,
        display_name VARCHAR(40) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_login DATETIME NULL
    ) $tail");
    $pdo->exec("CREATE TABLE IF NOT EXISTS sessions (
        token_hash CHAR(64) PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        created_at INT UNSIGNED NOT NULL,
        expires_at INT UNSIGNED NOT NULL,
        INDEX idx_sessions_user (user_id),
        INDEX idx_sessions_exp (expires_at),
        CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) $tail");
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_state (
        user_id INT UNSIGNED PRIMARY KEY,
        state LONGTEXT NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_state_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) $tail");
    $pdo->exec("CREATE TABLE IF NOT EXISTS login_attempts (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        k VARCHAR(120) NOT NULL,
        ts INT UNSIGNED NOT NULL,
        INDEX idx_attempts (k, ts)
    ) $tail");
    $pdo->exec("CREATE TABLE IF NOT EXISTS chat_usage (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        ts INT UNSIGNED NOT NULL,
        INDEX idx_usage (user_id, ts)
    ) $tail");
}

/* ------------------------------------------------------------------ cuentas y sesiones */

const SESSION_SECONDS = 2592000; // 30 días

function pw_pre($password)
{
    // bcrypt corta en 72 bytes: se pre-hashea para aceptar contraseñas largas sin perder caracteres
    return base64_encode(hash('sha256', $password, true));
}

function cookie_token()
{
    $t = isset($_COOKIE['ns_session']) ? $_COOKIE['ns_session'] : '';
    return preg_match('/^[0-9a-f]{64}$/', $t) ? $t : '';
}

function current_user()
{
    $t = cookie_token();
    if ($t === '') return null;
    $st = db()->prepare('SELECT u.id, u.username, u.display_name FROM sessions s
                         JOIN users u ON u.id = s.user_id
                         WHERE s.token_hash = ? AND s.expires_at > ?');
    $st->execute([hash('sha256', $t), time()]);
    $u = $st->fetch();
    return $u ? ['id' => (int) $u['id'], 'username' => $u['username'], 'displayName' => $u['display_name']] : null;
}

function start_session($userId)
{
    $token = bin2hex(random_bytes(32));
    $exp = time() + SESSION_SECONDS;
    db()->prepare('INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?,?,?,?)')
        ->execute([hash('sha256', $token), $userId, time(), $exp]);
    setcookie('ns_session', $token, [
        'expires' => $exp, 'path' => cookie_base(), 'secure' => is_https(), 'httponly' => true, 'samesite' => 'Lax',
    ]);
    if (mt_rand(1, 50) === 1) db()->prepare('DELETE FROM sessions WHERE expires_at < ?')->execute([time()]);
}

function too_many($key, $max, $windowSeconds)
{
    $st = db()->prepare('SELECT COUNT(*) FROM login_attempts WHERE k = ? AND ts > ?');
    $st->execute([$key, time() - $windowSeconds]);
    return (int) $st->fetchColumn() >= $max;
}

function note_attempt($key)
{
    db()->prepare('INSERT INTO login_attempts (k, ts) VALUES (?, ?)')->execute([$key, time()]);
    if (mt_rand(1, 20) === 1) db()->prepare('DELETE FROM login_attempts WHERE ts < ?')->execute([time() - 7200]);
}

function validate_credentials($username, $password)
{
    if (!is_string($username) || !preg_match('/^[A-Za-z0-9_.-]{3,30}$/', $username)) {
        throw new HttpError(400, 'El usuario debe tener 3 a 30 caracteres: letras, números, punto, guion o guion bajo.');
    }
    if (!is_string($password) || str_len($password) < 8 || str_len($password) > 128) {
        throw new HttpError(400, 'La contraseña debe tener entre 8 y 128 caracteres.');
    }
}

function route_register($body)
{
    $ip = 'reg|' . client_ip();
    if (too_many($ip, 20, 3600)) throw new HttpError(429, 'Demasiados registros desde esta conexión. Probá más tarde.');
    $username = isset($body['username']) ? $body['username'] : null;
    $password = isset($body['password']) ? $body['password'] : null;
    validate_credentials($username, $password);

    $name = clip_str(isset($body['displayName']) ? $body['displayName'] : null, 40, $username);
    if (preg_match('/^[\p{L}\p{N} _.\'-]{1,40}$/u', $name) !== 1) {
        throw new HttpError(400, "El nombre solo puede tener letras, números, espacios y . _ - '");
    }
    $pdo = db();
    $st = $pdo->prepare('SELECT 1 FROM users WHERE username = ?');
    $st->execute([$username]);
    if ($st->fetch()) throw new HttpError(409, 'Ese usuario ya existe. Elegí otro.');
    try {
        $pdo->prepare('INSERT INTO users (username, display_name, password_hash, last_login) VALUES (?,?,?,NOW())')
            ->execute([$username, $name, password_hash(pw_pre($password), PASSWORD_DEFAULT)]);
    } catch (PDOException $e) {
        if ((int) $e->getCode() === 23000) throw new HttpError(409, 'Ese usuario ya existe. Elegí otro.');
        throw $e;
    }
    $id = (int) $pdo->lastInsertId();
    note_attempt($ip);
    start_session($id);
    out(201, ['user' => ['id' => $id, 'username' => $username, 'displayName' => $name]]);
}

function route_login($body)
{
    $username = isset($body['username']) && is_string($body['username']) ? $body['username'] : '';
    $password = isset($body['password']) && is_string($body['password']) ? $body['password'] : '';
    $key = 'login|' . client_ip() . '|' . strtolower(substr($username, 0, 30));
    if (too_many($key, 10, 900)) throw new HttpError(429, 'Demasiados intentos fallidos. Esperá 15 minutos.');

    $st = db()->prepare('SELECT * FROM users WHERE username = ?');
    $st->execute([$username]);
    $u = $st->fetch();
    // Si el usuario no existe se verifica contra un hash de relleno: tarda lo mismo y no revela cuáles usuarios existen
    $dummy = '$2y$10$F6B.2ZAtokf0pJyEUI7Mw.Q6wQWZBNxCQEGxv8fL9i4.8gZh9.636';
    $ok = password_verify(pw_pre($password), $u ? $u['password_hash'] : $dummy);
    if (!$u || !$ok) {
        note_attempt($key);
        throw new HttpError(401, 'Usuario o contraseña incorrectos.');
    }
    db()->prepare('DELETE FROM login_attempts WHERE k = ?')->execute([$key]);
    db()->prepare('UPDATE users SET last_login = NOW() WHERE id = ?')->execute([$u['id']]);
    start_session((int) $u['id']);
    out(200, ['user' => ['id' => (int) $u['id'], 'username' => $u['username'], 'displayName' => $u['display_name']]]);
}

function route_password($user, $body)
{
    $st = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
    $st->execute([$user['id']]);
    $hash = $st->fetchColumn();
    $cur = isset($body['currentPassword']) && is_string($body['currentPassword']) ? $body['currentPassword'] : '';
    if (!password_verify(pw_pre($cur), $hash)) throw new HttpError(401, 'La contraseña actual no es correcta.');
    $new = isset($body['newPassword']) ? $body['newPassword'] : null;
    validate_credentials($user['username'], $new);
    db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
        ->execute([password_hash(pw_pre($new), PASSWORD_DEFAULT), $user['id']]);
    // cierra las demás sesiones, deja la actual
    db()->prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?')
        ->execute([$user['id'], hash('sha256', cookie_token())]);
    out(200, ['ok' => true]);
}

/* ------------------------------------------------------------------ estado de cada usuario */

function default_state($displayName)
{
    $s = json_decode(file_get_contents(__DIR__ . '/defaults.json'), true);
    $ms = now_ms();
    $s['chatHistory'][0]['id'] = 'msg_' . $ms;
    $s['chatHistory'][0]['timestamp'] = $ms;
    if ($displayName !== null) $s['userProfile']['name'] = $displayName;
    return $s;
}

function load_state(PDO $pdo, $uid, $lock = false)
{
    $st = $pdo->prepare('SELECT state FROM user_state WHERE user_id = ?' . ($lock ? ' FOR UPDATE' : ''));
    $st->execute([$uid]);
    $row = $st->fetch();
    if ($row) {
        $s = json_decode($row['state'], true);
        if (is_array($s)) return $s;
    }
    $n = $pdo->prepare('SELECT display_name FROM users WHERE id = ?');
    $n->execute([$uid]);
    $s = default_state($n->fetchColumn() ?: null);
    save_state($pdo, $uid, $s);
    return $s;
}

function save_state(PDO $pdo, $uid, array $s)
{
    $pdo->prepare('INSERT INTO user_state (user_id, state) VALUES (?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)')
        ->execute([$uid, json_encode($s, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION)]);
}

/** Lee, modifica y guarda el estado dentro de una transacción (evita pisar cambios simultáneos). */
function mutate_state($uid, callable $fn)
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $s = load_state($pdo, $uid, true);
        $fn($s);
        save_state($pdo, $uid, $s);
        $pdo->commit();
        return $s;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function add_xp(array &$s, $n)
{
    $p = &$s['userProfile'];
    $p['currentXp'] += (int) $n;
    while ($p['currentXp'] >= $p['nextLevelXp']) {
        $p['levelNumber'] += 1;
        $p['nextLevelXp'] = (int) floor($p['nextLevelXp'] * 1.5);
    }
}

/* ------------------------------------------------------------------ acciones */

function apply_action(array &$s, $action, array $p)
{
    switch ($action) {
        case 'ADD_XP':
            add_xp($s, max(1, min(50, (int) (isset($p['amount']) ? $p['amount'] : 20))));
            break;

        case 'ADD_STUDY_TIME':
            $s['userProfile']['totalMinutesStudied'] += max(1, min(5, (int) (isset($p['minutes']) ? $p['minutes'] : 1)));
            break;

        case 'COMPLETE_MODULE':
            $id = isset($p['moduleId']) ? $p['moduleId'] : null;
            foreach ($s['routes'] as &$route) {
                foreach ($route['modules'] as $i => &$m) {
                    if ($m['id'] === $id && !empty($m['isCurrent']) && empty($m['isCompleted'])) {
                        $m['isCompleted'] = true;
                        $m['isCurrent'] = false;
                        if (isset($route['modules'][$i + 1])) {
                            $route['modules'][$i + 1]['isCurrent'] = true;
                            $route['modules'][$i + 1]['isLocked'] = false;
                        }
                        add_xp($s, 60);
                        break 2;
                    }
                }
                unset($m);
            }
            unset($route, $m);
            break;

        case 'TOGGLE_GOAL_TASK':
            foreach ($s['goals'] as &$g) {
                if ($g['id'] !== (isset($p['goalId']) ? $p['goalId'] : null)) continue;
                foreach ($g['tasks'] as &$t) {
                    if ($t['id'] !== (isset($p['taskId']) ? $p['taskId'] : null)) continue;
                    $t['isCompleted'] = empty($t['isCompleted']);
                    $done = 0;
                    foreach ($g['tasks'] as $x) if (!empty($x['isCompleted'])) $done++;
                    $g['progressPercent'] = (int) round($done / max(1, count($g['tasks'])) * 100);
                    if ($t['isCompleted'] && empty($t['xpGiven'])) { // el XP se da una sola vez por tarea
                        $t['xpGiven'] = true;
                        $award = true;
                    }
                    break;
                }
                unset($t);
                break;
            }
            unset($g);
            if (!empty($award)) add_xp($s, 25);
            break;

        case 'ADD_GOAL':
            $g = arr(isset($p['goal']) ? $p['goal'] : []);
            if (count($s['goals']) >= 50) break;
            $now = now_ms();
            $tasks = [];
            foreach (array_slice(array_values(arr(isset($g['tasks']) ? $g['tasks'] : [])), 0, 15) as $i => $t) {
                $tasks[] = ['id' => "gt_{$now}_{$i}", 'title' => clip_str(is_array($t) && isset($t['title']) ? $t['title'] : null, 120, 'Tarea'), 'isCompleted' => false];
            }
            $prio = isset($g['priority']) ? $g['priority'] : '';
            $s['goals'][] = [
                'id' => 'goal_' . $now,
                'title' => clip_str(isset($g['title']) ? $g['title'] : null, 100, 'Nuevo objetivo'),
                'description' => clip_str(isset($g['description']) ? $g['description'] : null, 300, ''),
                'deadline' => clip_str(isset($g['deadline']) ? $g['deadline'] : null, 40, 'Sin plazo'),
                'priority' => in_array($prio, ['ALTA', 'MEDIA', 'BAJA'], true) ? $prio : 'MEDIA',
                'progressPercent' => 0,
                'tasks' => $tasks,
            ];
            break;

        case 'COMPLETE_EXERCISE':
            // La corrección se hace acá, con la respuesta guardada del ejercicio (el navegador no decide el puntaje)
            foreach ($s['exercises'] as $ex) {
                if ($ex['id'] !== (isset($p['exerciseId']) ? $p['exerciseId'] : null)) continue;
                $s['userProfile']['completedExercisesCount'] += 1;
                if ((int) (isset($p['selectedIndex']) ? $p['selectedIndex'] : -1) === (int) $ex['correctOptionIndex']) {
                    add_xp($s, (int) $ex['xpReward']);
                }
                break;
            }
            break;

        case 'ADD_SUBJECT':
            if (count($s['subjects']) >= 50) break;
            $s['subjects'][] = [
                'id' => 'subj_' . now_ms(),
                'name' => clip_str(isset($p['name']) ? $p['name'] : null, 60, 'Nueva materia'),
                'category' => clip_str(isset($p['category']) ? $p['category'] : null, 40, 'General'),
                'iconEmoji' => '📘',
                'estimatedLevel' => 'Principiante',
                'masteryPercent' => 10,
                'topicsMastered' => [], 'topicsInProgress' => [], 'topicsPending' => [], 'topicsToReinforce' => [],
                'description' => clip_str(isset($p['description']) ? $p['description'] : null, 300, 'Materia personalizada'),
            ];
            break;

        case 'CLEAR_CHAT':
            $ms = now_ms();
            $s['chatHistory'] = [[
                'id' => 'msg_' . $ms, 'sender' => 'tutor',
                'content' => 'Conversación reiniciada. ¿Qué tema quieres explorar hoy?', 'timestamp' => $ms,
            ]];
            break;

        case 'COMPLETE_ONBOARDING':
            $prof = &$s['userProfile'];
            if (!empty($p['skipped'])) {            // omitir: sin cambios de perfil ni XP
                $prof['initialAssessmentDone'] = true;
                break;
            }
            $pref = &$prof['preferences'];
            $pref['studyGoal'] = clip_str(isset($p['goal']) ? $p['goal'] : null, 120, isset($pref['studyGoal']) ? $pref['studyGoal'] : '');
            $pref['explanationDepth'] = clip_str(isset($p['depth']) ? $p['depth'] : null, 120, $pref['explanationDepth']);
            $pref['tutorTone'] = clip_str(isset($p['tone']) ? $p['tone'] : null, 120, $pref['tutorTone']);
            unset($pref);
            $first = empty($prof['initialAssessmentDone']);
            $prof['initialAssessmentDone'] = true;
            unset($prof);
            if ($first) add_xp($s, 100);
            break;

        case 'COMPLETE_EVALUATION':
            foreach ($s['evaluations'] as &$ev) {
                if ($ev['id'] !== (isset($p['evalId']) ? $p['evalId'] : null) || !empty($ev['completed'])) continue;
                $lvl = isset($p['level']) ? $p['level'] : '';
                $list = function ($v) {
                    $o = [];
                    foreach (array_slice(array_values(arr($v)), 0, 10) as $x) $o[] = clip_str($x, 60, '');
                    return array_values(array_filter($o, function ($z) { return $z !== ''; }));
                };
                $ev['completed'] = true;
                $ev['scorePercent'] = max(0, min(100, (int) (isset($p['scorePercent']) ? $p['scorePercent'] : 0)));
                $ev['demonstratedLevel'] = in_array($lvl, ['Principiante', 'Intermedio', 'Avanzado'], true) ? $lvl : 'Principiante';
                $ev['strengths'] = $list(isset($p['strengths']) ? $p['strengths'] : []);
                $ev['weaknessesToReinforce'] = $list(isset($p['weaknesses']) ? $p['weaknesses'] : []);
                $award = true;
                break;
            }
            unset($ev);
            if (!empty($award)) add_xp($s, 120);
            break;

        default:
            throw new HttpError(400, 'Acción desconocida.');
    }
}

function apply_settings(array &$s, array $b)
{
    $palettes = ['FOCUS_BLUE', 'FOREST_GREEN', 'LAVENDER_CALM', 'WARM_STUDY', 'OCEAN_TEAL', 'ROSE_PASTEL', 'HIGH_CONTRAST', 'DARK_FOCUS', 'LIGHT_MINIMAL', 'CUSTOM'];
    $modes = ['CONCENTRATION', 'READING', 'PRACTICE', 'EVALUATION', 'REVIEW', 'PLANNING'];
    $prefKeys = ['explanationDepth', 'languageStyle', 'contentApproach', 'pacing', 'hintStyle', 'tutorTone', 'studyGoal'];

    if (isset($b['themeConfig']) && is_array($b['themeConfig'])) {
        $t = $b['themeConfig'];
        if (isset($t['palette']) && in_array($t['palette'], $palettes, true)) $s['themeConfig']['palette'] = $t['palette'];
        foreach (['isDarkMode', 'useSystemDark'] as $k) if (isset($t[$k])) $s['themeConfig'][$k] = (bool) $t[$k];
        foreach (['customPrimaryHex', 'customAccentHex'] as $k) {
            if (isset($t[$k]) && is_string($t[$k]) && preg_match('/^#[0-9a-fA-F]{6}$/', $t[$k])) $s['themeConfig'][$k] = $t[$k];
        }
    }
    if (isset($b['studyMode']) && in_array($b['studyMode'], $modes, true)) $s['studyMode'] = $b['studyMode'];
    if (isset($b['activeSubjectId']) && is_string($b['activeSubjectId'])) {
        foreach ($s['subjects'] as $sub) if ($sub['id'] === $b['activeSubjectId']) { $s['activeSubjectId'] = $sub['id']; break; }
    }
    if (isset($b['preferences']) && is_array($b['preferences'])) {
        foreach ($prefKeys as $k) {
            if (isset($b['preferences'][$k]) && is_string($b['preferences'][$k])) {
                $s['userProfile']['preferences'][$k] = clip_str($b['preferences'][$k], 120, $s['userProfile']['preferences'][$k]);
            }
        }
    }
    if (array_key_exists('customApiKey', $b) && is_string($b['customApiKey'])) {
        $k = trim($b['customApiKey']);
        if ($k === '') unset($s['customApiKey']);
        elseif (strlen($k) <= 200 && preg_match('/^[A-Za-z0-9_\-]+$/', $k)) $s['customApiKey'] = $k;
    }
}

/* ------------------------------------------------------------------ chat con Gemini */

function gemini_key_from_config()
{
    global $CFG;
    $k = trim((string) $CFG['gemini_api_key']);
    return ($k === '' || strpos($k, 'PEGA_AQUI') === 0) ? '' : $k;
}

function route_chat($uid, $body)
{
    global $CFG;
    $pdo = db();
    $state = load_state($pdo, $uid);

    $message = isset($body['message']) && is_string($body['message']) ? trim($body['message']) : '';
    if ($message === '' || str_len($message) > 2000) throw new HttpError(400, 'El mensaje está vacío o es demasiado largo (máx. 2000 caracteres).');
    $action = isset($body['pedagogicalAction']) && is_string($body['pedagogicalAction']) && preg_match('/^[A-Z_]{1,40}$/', $body['pedagogicalAction'])
        ? $body['pedagogicalAction'] : null;

    $own = isset($body['customApiKey']) && is_string($body['customApiKey']) ? trim($body['customApiKey']) : '';
    $apiKey = $own !== '' ? $own : (!empty($state['customApiKey']) ? $state['customApiKey'] : gemini_key_from_config());
    if ($apiKey === '' || !preg_match('/^[A-Za-z0-9_\-]{10,200}$/', $apiKey)) {
        throw new HttpError(400, 'Clave de Gemini API no configurada. Ingresá tu clave en Configuración o en el archivo config.php.');
    }

    // Límites: 20 por minuto y N por día por usuario (cuida la cuota de Gemini)
    $daily = max(1, (int) $CFG['chat_daily_limit']);
    $c = $pdo->prepare('SELECT SUM(ts > ?) AS min1, COUNT(*) AS day1 FROM chat_usage WHERE user_id = ? AND ts > ?');
    $c->execute([time() - 60, $uid, time() - 86400]);
    $u = $c->fetch();
    if ((int) $u['day1'] >= $daily) throw new HttpError(429, "Llegaste al límite de $daily mensajes de hoy. Volvé mañana.");
    if ((int) $u['min1'] >= 20) throw new HttpError(429, 'Demasiados mensajes seguidos. Esperá un minuto.');
    $pdo->prepare('INSERT INTO chat_usage (user_id, ts) VALUES (?, ?)')->execute([$uid, time()]);
    if (mt_rand(1, 30) === 1) $pdo->prepare('DELETE FROM chat_usage WHERE ts < ?')->execute([time() - 172800]);

    $subj = $state['subjects'][0];
    foreach ($state['subjects'] as $x) if ($x['id'] === ($state['activeSubjectId'] ?? null)) { $subj = $x; break; }
    $pr = $state['userProfile'];
    $pf = $pr['preferences'];
    $instr = "\nEres NEXTSTEP, profesor particular virtual con inteligencia artificial para el alumno {$pr['name']}.\n"
        . "PRINCIPIOS PEDAGÓGICOS:\n"
        . "1. No eres un chatbot genérico. Eres un educador empático, metódico y activo.\n"
        . "2. Comprueba la comprensión haciendo preguntas al final de cada concepto.\n"
        . "3. Si el alumno pide pistas o practica: entrega pistas graduales socráticas, jamás la respuesta completa de golpe.\n"
        . "4. Explica por qué ocurren los errores y guía hacia la solución.\n"
        . "5. Adáptate a las peticiones del usuario inmediatamente.\n\n"
        . "PERFIL:\n"
        . "- Alumno: {$pr['name']} (Nivel {$pr['levelNumber']}, {$pr['currentXp']} XP)\n"
        . "- Materia activa: {$subj['name']} ({$subj['category']}), Dominio actual: {$subj['masteryPercent']}%\n"
        . "- Preferencias: Explicación {$pf['explanationDepth']}, Lenguaje {$pf['languageStyle']}, Enfoque {$pf['contentApproach']}, Tono {$pf['tutorTone']}.\n"
        . "- Modo de estudio: {$state['studyMode']}.\n"
        . ($action ? "INSTRUCCIÓN PEDAGÓGICA SOLICITADA: $action" : '') . "\n";

    $contents = [];
    foreach (array_slice($state['chatHistory'], -8) as $m) {
        $contents[] = ['role' => $m['sender'] === 'user' ? 'user' : 'model', 'parts' => [['text' => (string) $m['content']]]];
    }
    $full = $action ? "[$action]: $message" : $message;
    $contents[] = ['role' => 'user', 'parts' => [['text' => $full]]];

    $payload = json_encode([
        'systemInstruction' => ['parts' => [['text' => $instr]]],
        'contents' => $contents,
        'generationConfig' => ['temperature' => 0.7, 'maxOutputTokens' => 1500],
    ], JSON_UNESCAPED_UNICODE);

    if (!function_exists('curl_init')) throw new HttpError(500, 'Falta la extensión cURL de PHP (en XAMPP viene activada).');
    $ch = curl_init('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'x-goog-api-key: ' . $apiKey],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 60,
    ]);
    $resp = curl_exec($ch);
    $http = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);

    if ($resp === false) throw new HttpError(502, 'Fallo de conexión con Google Gemini: ' . $cerr . ' (¿hay internet? En XAMPP viejos revisá el certificado SSL de cURL).');
    if ($http !== 200) {
        $detail = json_decode($resp, true);
        $why = isset($detail['error']['message']) ? $detail['error']['message'] : substr((string) $resp, 0, 300);
        throw new HttpError($http >= 400 && $http < 600 ? $http : 502, "Error de Gemini API ($http): $why");
    }
    $j = json_decode($resp, true);
    $text = isset($j['candidates'][0]['content']['parts'][0]['text']) ? $j['candidates'][0]['content']['parts'][0]['text'] : '';
    if ($text === '') throw new HttpError(502, 'La IA no retornó contenido legible.');

    $new = mutate_state($uid, function (&$s) use ($full, $action, $text) {
        $ms = now_ms();
        $s['chatHistory'][] = ['id' => 'msg_' . $ms, 'sender' => 'user', 'content' => $full, 'pedagogicalAction' => $action, 'timestamp' => $ms];
        $s['chatHistory'][] = ['id' => 'msg_' . ($ms + 1), 'sender' => 'tutor', 'content' => $text, 'timestamp' => $ms + 1];
        if (count($s['chatHistory']) > 200) $s['chatHistory'] = array_slice($s['chatHistory'], -200);
        add_xp($s, 15);
    });
    out(200, ['reply' => $text, 'state' => $new]);
}

/* ------------------------------------------------------------------ enrutador */

$route = isset($_GET['r']) ? trim((string) $_GET['r'], '/') : '';
$method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';

if ($method === 'POST') {
    // Defensa CSRF: solo se aceptan POST en JSON (un formulario de otro sitio no puede enviarlos) + cookie SameSite=Lax
    $ct = isset($_SERVER['CONTENT_TYPE']) ? strtolower($_SERVER['CONTENT_TYPE']) : '';
    if (strpos($ct, 'application/json') !== 0) throw new HttpError(415, 'Tipo de contenido no permitido.');
}

if ($route === 'health') {
    $n = (int) db()->query('SELECT COUNT(*) FROM users')->fetchColumn();
    out(200, ['ok' => true, 'accounts' => $n, 'geminiConfigured' => gemini_key_from_config() !== '']);
}

if ($route === 'auth/me') {
    $u = current_user();
    $first = !$u && (int) db()->query('SELECT COUNT(*) FROM users')->fetchColumn() === 0;
    out(200, ['user' => $u, 'firstAccount' => $first]);
}
if ($method === 'POST' && $route === 'auth/register') route_register(body_json());
if ($method === 'POST' && $route === 'auth/login') route_login(body_json());
if ($method === 'POST' && $route === 'auth/logout') {
    $t = cookie_token();
    if ($t !== '') db()->prepare('DELETE FROM sessions WHERE token_hash = ?')->execute([hash('sha256', $t)]);
    setcookie('ns_session', '', ['expires' => time() - 3600, 'path' => cookie_base(), 'secure' => is_https(), 'httponly' => true, 'samesite' => 'Lax']);
    out(200, ['ok' => true]);
}

// Todo lo demás requiere sesión iniciada
$user = current_user();
if (!$user) throw new HttpError(401, 'Iniciá sesión para continuar.', ['auth' => true]);
$uid = $user['id'];

if ($method === 'POST' && $route === 'auth/password') route_password($user, body_json());

if ($method === 'GET' && $route === 'state') {
    out(200, load_state(db(), $uid));
}
if ($method === 'POST' && $route === 'settings') {
    $b = body_json();
    $s = mutate_state($uid, function (&$s) use ($b) { apply_settings($s, $b); });
    out(200, ['success' => true, 'state' => $s]);
}
if ($method === 'POST' && $route === 'action') {
    $b = body_json();
    $action = isset($b['action']) && is_string($b['action']) ? $b['action'] : '';
    $payload = arr(isset($b['payload']) ? $b['payload'] : []);
    $s = mutate_state($uid, function (&$s) use ($action, $payload) { apply_action($s, $action, $payload); });
    out(200, ['success' => true, 'state' => $s]);
}
if ($method === 'POST' && $route === 'reset') {
    $fresh = default_state($user['displayName']);
    save_state(db(), $uid, $fresh);
    out(200, ['success' => true, 'state' => $fresh]);
}
if ($method === 'POST' && $route === 'chat') route_chat($uid, body_json());

throw new HttpError(404, 'Ruta no encontrada.');
