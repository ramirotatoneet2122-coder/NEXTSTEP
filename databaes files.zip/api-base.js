// Conecta la interfaz con el backend PHP: convierte /api/<ruta> en api.php?r=<ruta>
// (relativo a la página, así funciona igual en http://localhost/nextstep/ que en un dominio).
(function () {
  const nativeFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    if (typeof input === 'string' && input.startsWith('/api/')) {
      input = 'api.php?r=' + input.slice(5);
    }
    return nativeFetch(input, init);
  };
})();
