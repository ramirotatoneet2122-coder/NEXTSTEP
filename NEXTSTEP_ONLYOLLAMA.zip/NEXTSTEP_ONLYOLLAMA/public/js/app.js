/* NEXTSTEP — bootstrap de la SPA de escritorio: meta, sesión, router y shell
   de 3 columnas (riel de navegación / panel principal / riel de enfoque). */
import { api } from './api.js';
import * as store from './store.js';
import { el, svgIc, bar } from './ui.js';
import { applyTheme } from './theme.js';
import { mountRightRail } from './rightrail.js';
import { authView } from './views/auth.js';
import { dashboardView } from './views/dashboard.js';
import { teacherView } from './views/teacher.js';
import { learningView } from './views/learning.js';
import { pathsView } from './views/paths.js';
import { assessmentsView } from './views/assessments.js';
import { goalsView } from './views/goals.js';
import { resourcesView } from './views/resources.js';
import { statsView } from './views/stats.js';
import { settingsView } from './views/settings.js';
import { learningModal } from './views/settings.js';

const VIEWS = {
  login: authView,
  dashboard: dashboardView,
  teacher: teacherView,
  learning: learningView,
  paths: pathsView,
  assessments: assessmentsView,
  goals: goalsView,
  resources: resourcesView,
  stats: statsView,
  settings: settingsView,
};

/* Secciones principales del riel izquierdo (las demás viven en "Más"). */
const PRIMARY = [
  { id: 'dashboard', name: 'Inicio', icon: 'home', sub: 'Tu panorama de hoy' },
  { id: 'teacher', name: 'Tutor IA', icon: 'chat', sub: 'Tu profesor particular' },
  { id: 'paths', name: 'Rutas', icon: 'route', sub: 'Tu camino de aprendizaje' },
  { id: 'assessments', name: 'Práctica', icon: 'quiz', sub: 'Evaluaciones y ejercicios' },
];
const EXTRA = [
  { id: 'learning', name: 'Mi aprendizaje', icon: 'learn', sub: 'Materias y temas' },
  { id: 'goals', name: 'Objetivos', icon: 'target', sub: 'Metas y tareas' },
  { id: 'resources', name: 'Recursos', icon: 'book', sub: 'Cursos verificados' },
  { id: 'stats', name: 'Estadísticas', icon: 'chart', sub: 'Tu constancia' },
  { id: 'settings', name: 'Configuración', icon: 'gear', sub: 'Tema y preferencias' },
];

const view = document.getElementById('view');
const app = document.getElementById('app');
const authScreen = document.getElementById('auth-screen');
const topbarTitle = document.getElementById('topbar-title');
const topbarSub = document.getElementById('topbar-sub');
const xpLevel = document.getElementById('xp-level');
const xpTotal = document.getElementById('xp-total');
const btnLogout = document.getElementById('btn-logout');
const btnAvatar = document.getElementById('btn-avatar');
const rightRail = document.getElementById('rightrail');

let meta = null;

export function getMeta() { return meta; }

/* ---------- Meta pública (saludo, rápidas, modos, setup de IA) ---------- */
async function loadMeta() {
  try {
    meta = await api('/meta');
  } catch (e) {
    meta = { greeting: '', startQuick: [], allowedUrls: [], modes: [], requiresSetup: false, setupMessage: '' };
    console.warn(e);
  }
  store.setCache('meta', meta);
  store.setMeta(meta);
}

/* ---------- Navegación ---------- */
function navButton(s, extra) {
  return el('button', {
    class: 'nav-item', 'data-nav': s.id,
    html: svgIc(s.icon, 19) + `<span>${s.name}</span>`,
    onclick: () => { store.nav('/' + s.id); if (extra) closeMore(); },
  });
}

function buildNav() {
  const nav = document.getElementById('nav');
  const more = document.getElementById('nav-more-panel');
  nav.innerHTML = '';
  more.innerHTML = '';
  for (const s of PRIMARY) nav.append(navButton(s));
  for (const s of EXTRA) more.append(navButton(s, true));

  const btn = document.getElementById('nav-more');
  btn.onclick = () => {
    const open = more.classList.toggle('open');
    btn.classList.toggle('open', open);
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  };
}
function closeMore() {
  const more = document.getElementById('nav-more-panel');
  const btn = document.getElementById('nav-more');
  if (more) more.classList.remove('open');
  if (btn) { btn.classList.remove('open'); btn.setAttribute('aria-expanded', 'false'); }
}

function markActiveNav() {
  const { section } = store.parseHash();
  document.querySelectorAll('.nav-item[data-nav]').forEach(b => {
    b.classList.toggle('active', b.dataset.nav === section);
  });
  // Si la sección activa está en "Más", abrimos el panel para que se vea dónde estás.
  if (EXTRA.some(s => s.id === section)) {
    const more = document.getElementById('nav-more-panel');
    const btn = document.getElementById('nav-more');
    if (more && !more.classList.contains('open')) { more.classList.add('open'); btn.classList.add('open'); btn.setAttribute('aria-expanded', 'true'); }
  }
}

/* ---------- XP / nivel ---------- */
function paintLevel() {
  const lvl = store.get().level || {};
  if (lvl.level) {
    xpLevel.textContent = `Nv ${lvl.level}`;
    xpTotal.textContent = `${lvl.xp || 0} XP`;
    const side = document.getElementById('side-level');
    const sideXp = document.getElementById('side-xp');
    const sideBar = document.getElementById('side-bar');
    if (side) side.textContent = `Nv ${lvl.level}`;
    if (sideXp) sideXp.textContent = `${lvl.xp || 0} XP`;
    if (sideBar) { sideBar.innerHTML = ''; sideBar.append(bar(Number(lvl.progress) || 0)); }
  }
}

/* ---------- Router ---------- */
async function route() {
  const { section, params } = store.parseHash();
  const s = store.get();

  // Cerrar sesión explícita
  if (section === 'logout') {
    try { await store.logout(); } catch {}
    if (location.hash !== '#/login') store.nav('/login');
    else showAuth(true);
    return;
  }

  // Sin sesión
  if (!s.token) {
    if (section !== 'login' && section !== 'register') {
      if (location.hash !== '#/login') {
        store.nav('/login');
        return;
      }
    }
    showAuth(section === 'register' ? false : true);
    return;
  }

  // Con sesión pero en login/register -> mandar a dashboard
  if (section === 'login' || section === 'register') {
    if (location.hash !== '#/dashboard') {
      store.nav('/dashboard');
      return;
    }
    showApp('dashboard');
    view.dataset.activity = '';
    view.innerHTML = '';
    try {
      const render = VIEWS['dashboard'];
      if (render) {
        const node = await render([]);
        if (node && node.nodeType) view.append(node);
        view.scrollTop = 0;
      }
    } catch (e) {
      console.error('[route]', 'dashboard', e);
    }
    markActiveNav();
    paintLevel();
    maybeOnboard();
    return;
  }

  const render = VIEWS[section];
  if (!render) {
    if (location.hash !== '#/dashboard') {
      store.nav('/dashboard');
      return;
    }
    showApp('dashboard');
    view.innerHTML = '';
    try {
      const node = await VIEWS['dashboard']([]);
      if (node && node.nodeType) view.append(node);
    } catch {}
    markActiveNav();
    paintLevel();
    maybeOnboard();
    return;
  }

  showApp(section);
  view.dataset.activity = ''; // por defecto; teacher la setea según el modo
  view.innerHTML = '';
  try {
    const node = await render(params);
    if (node && node.nodeType) view.append(node);
    view.scrollTop = 0;
  } catch (e) {
    console.error('[route]', section, e);
    if (e && e.status === 401) {
      try { await store.logout(); } catch {}
      if (location.hash !== '#/login') store.nav('/login');
      else showAuth(true);
      try { if (typeof toast === 'function') toast('Tu sesión expiró. Volvé a entrar.', 'err'); } catch {}
      return;
    }
    view.append(el('div', { class: 'card center' },
      el('p', { text: (e && e.message) || 'Algo salió mal al cargar esta sección.' }),
      el('div', { style: 'margin-top:14px' }, el('button', { class: 'btn', onclick: () => route() }, 'Reintentar')),
    ));
  }
  markActiveNav();
  paintLevel();
  if (section === 'dashboard') maybeOnboard();
}

/* Fuerza un re-render de la ruta actual (ej: tras login sin cambio de hash). */
export function refreshRoute() { route(); }

/* ---------- Shell visible ---------- */
function showAuth(loginTab = true) {
  app.hidden = true;
  authScreen.hidden = false;
  authScreen.innerHTML = '';
  authScreen.append(authView({ tab: loginTab ? 'login' : 'register' }));
}
function showApp(section) {
  authScreen.hidden = true;
  app.hidden = false;
  const sec = [...PRIMARY, ...EXTRA].find(x => x.id === section);
  topbarTitle.textContent = sec ? sec.name : 'NEXTSTEP';
  topbarSub.textContent = sec ? sec.sub : 'Tu espacio de aprendizaje';
  if (rightRail && !rightRail.childElementCount) mountRightRail(rightRail);
}

/* ---------- Onboarding de preferencias (primer ingreso, salteable) ---------- */
export function maybeOnboard() {
  if (localStorage.getItem('ns_onboarded') || !store.get().token) return;
  const p = store.get().prefs;
  const configured = p.learning && (p.learning.detail || p.learning.language || (Array.isArray(p.learning.formats) && p.learning.formats.length));
  if (configured) { localStorage.setItem('ns_onboarded', '1'); return; }
  learningModal({ onDone: () => { localStorage.setItem('ns_onboarded', '1'); } });
}

/* ---------- Arranque ---------- */
function boot() {
  // Pinta la app y resuelve la ruta local antes de esperar respuestas de red.
  const cached = store.get().prefs;
  if (cached && cached.theme) applyTheme(cached.theme);

  buildNav();
  btnLogout.addEventListener('click', async () => { try { await store.logout(); } catch {} store.nav('/login'); });
  btnAvatar.addEventListener('click', () => store.nav('/settings'));
  window.addEventListener('hashchange', route);
  window.addEventListener('ns:reroute', () => route());
  store.on(evt => { if (evt === 'me') paintLevel(); });

  // Estado inicial seguro
  if (!location.hash) {
    store.nav(store.get().token ? '/dashboard' : '/login');
  }
  try { route(); } catch (e) { console.error('route init', e); }

  // Meta y perfil son datos secundarios: si el servidor tarda o falla,
  // nunca deben dejar la pantalla inicial en violeta.
  loadMeta();
  if (store.get().token) {
    store.loadMe().catch(async e => {
      if (e && e.status === 401) {
        try { await store.logout(); } catch {}
        if (location.hash !== '#/login') store.nav('/login');
        else showAuth(true);
      } else {
        console.warn('No se pudo restaurar el perfil:', e);
      }
    });
  }
}

boot();

/* Marcar como leído el aviso de que no aparece la clave: usado por vistas que detectan 503. */
export function setupNotice() {
  const m = getMeta();
  const card = el('div', { class: 'card', style: 'display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap' });
  card.append(el('div', { class: 'stat-ic', html: svgIc('warn', 18) }));
  const txt = el('div', { class: 'grow' });
  txt.append(el('p', { style: 'font-weight:700' }, 'La IA todavía no está conectada'));
  txt.append(el('p', { class: 'muted small', text: m && m.setupMessage ? m.setupMessage : 'Configurá la clave del proveedor de IA en el servidor (.env) para usar el profesor, generar rutas y evaluar materias fuera del banco. El resto de la app funciona igual.' }));
  card.append(txt);
  return card;
}
