// XP: lo que se suma al completar se resta al deshacer (nunca por debajo de cero).
import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';

process.env.DB_FILE = path.join(os.tmpdir(), `nextstep-xp-${process.pid}.db`);
const db = await import('../src/db.js');
db.initDb();
const { grantXp, revokeXp } = await import('../src/xp.js');
const uid = db.createUser({ username: 'xp-test', passHash: 'x', displayName: 'XP' });
const U = typeof uid === 'object' ? (uid.id ?? uid.lastInsertRowid) : uid;

test('completar y deshacer deja el XP como estaba', () => {
  const antes = db.totalXp(U);
  grantXp(U, 40, 'Completaste una actividad');
  assert.equal(db.totalXp(U), antes + 40);
  assert.equal(revokeXp(U, 40, 'Revertiste una actividad').lost, 40);
  assert.equal(db.totalXp(U), antes);
});

test('no se puede restar más XP del que hay', () => {
  const total = db.totalXp(U);
  assert.equal(revokeXp(U, 500, 'exceso').lost, total);
  assert.equal(db.totalXp(U), 0);
  assert.equal(revokeXp(U, 30, 'sin saldo').lost, 0);
});
