/* NEXTSTEP — utilidades de UI: constructores DOM, iconos, modal, toasts, formatos. */

export const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h5v-6h4v6h5V9.5"/>',
  chat: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  learn: '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
  route: '<circle cx="6" cy="19" r="3"/><circle cx="6" cy="5" r="3"/><circle cx="18" cy="12" r="3"/><path d="M6 8v8"/><path d="M9 12h6"/>',
  chart: '<line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/>',
  quiz: '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
  book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
  bolt: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  flame: '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
  star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
  pencil: '<path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/>',
  send: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  play: '<polygon points="5 3 19 12 5 21 5 3"/>',
  pause: '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
  warn: '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  arrowR: '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
  eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff: '<path d="M3 3l18 18"/><path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 5.2A10.7 10.7 0 0 1 12 5c6.4 0 10 7 10 7a15 15 0 0 1-3.1 3.8M6.2 6.2C3.5 8 2 12 2 12s3.6 7 10 7a10.4 10.4 0 0 0 3-.4"/>',
  list: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
  sparkles: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 15l.9 2.4L22 18l-2.1.6L19 21l-.9-2.4L16 18l2.1-.6z"/>',
};

export function svgIc(name, size = 20) {
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:${size}px;height:${size}px" aria-hidden="true">${ICONS[name] || ''}</svg>`;
}

/* Crea un elemento DOM de forma declarativa. */
const BOOL_ATTRS = new Set(['disabled', 'checked', 'selected', 'hidden', 'readonly', 'multiple']);
export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined) continue;
    if (k === 'class') node.className = v;
    else if (k === 'html') node.innerHTML = v;
    else if (k === 'text') node.textContent = v;
    else if (k === 'dataset') Object.assign(node.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (BOOL_ATTRS.has(k)) { if (v) node.setAttribute(k, ''); }
    else node.setAttribute(k, v);
  }
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    if (c instanceof Node) node.append(c);
    // Un string de confiancia interna que empieza con < (ej. svgIc) se inserta como HTML;
    // el resto se escapa como texto para no meter HTML de datos sin escapar.
    else if (typeof c === 'string' && c.startsWith('<') && c.endsWith('>')) node.insertAdjacentHTML('beforeend', c);
    else node.append(document.createTextNode(String(c)));
  }
  return node;
}

/* Primera letra en mayúscula ("estudio" -> "Estudio", "en_curso" -> "En curso"). */
export function cap(s) {
  const t = String(s ?? '').replace(/_/g, ' ').trim();
  return t ? t.charAt(0).toUpperCase() + t.slice(1) : '';
}

export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export function fmt(html) { // convierte HTML string (ya escapado) en elemento
  const tpl = document.createElement('template');
  tpl.innerHTML = html.trim();
  return tpl.content.firstElementChild;
}

export function fmtDate(iso, opts = {}) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('es-AR', { day: 'numeric', month: 'short', ...opts });
  } catch { return String(iso).slice(0, 10); }
}

export function fmtRel(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const s = (Date.now() - d.getTime()) / 1000;
  if (s < 60) return 'recién';
  if (s < 3600) return `hace ${Math.floor(s / 60)} min`;
  if (s < 86400) return `hace ${Math.floor(s / 3600)} h`;
  if (s < 172800) return 'ayer';
  if (s < 604800) return `hace ${Math.floor(s / 86400)} días`;
  return fmtDate(iso);
}

export function minutesText(m) {
  const h = Math.floor(m / 60), r = m % 60;
  if (h && r) return `${h} h ${r} min`;
  if (h) return `${h} h`;
  return `${r} min`;
}

export function toast(msg, type = 'info') {
  const root = document.getElementById('toast-root');
  const t = el('div', { class: `toast ${type}` });
  const icon = el('span', { class: 'flex', html: svgIc(type === 'err' ? 'x' : type === 'ok' ? 'check' : 'info', 16) });
  icon.style.cssText = 'flex:0 0 auto;color:var(--' + (type === 'err' ? 'danger' : type === 'ok' ? 'good' : 'accent') + ');';
  const txt = el('span', { text: msg });
  t.append(icon, txt);
  root.append(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 320); }, type === 'err' ? 5200 : 3400);
}

let modalOpen = false;
export function modal({ title, body, footer, onClose }) {
  const root = document.getElementById('modal-root');
  root.hidden = false;
  const backdrop = el('div', { class: 'modal-backdrop', onclick: () => close() });
  const box = el('div', {
    class: 'modal',
    role: 'dialog',
    'aria-modal': 'true',
    onclick: e => e.stopPropagation(),
  });
  const head = el('div', { class: 'modal-head' });
  head.append(el('h3', { text: title || '' }), el('button', { class: 'icon-btn', onclick: () => close(), 'aria-label': 'Cerrar', html: svgIc('x', 18) }));
  box.append(head);
  if (typeof body === 'string') box.append(fmt(body)); else if (body) box.append(body);
  if (footer) box.append(el('div', { class: 'flex', style: 'margin-top:18px;justify-content:flex-end;flex-wrap:wrap' }, ...(Array.isArray(footer) ? footer : [footer])));
  backdrop.append(box);
  root.append(backdrop);
  modalOpen = true;
  function close() {
    root.hidden = true;
    root.innerHTML = '';
    modalOpen = false;
    onClose && onClose();
  }
  const first = box.querySelector('input, select, textarea, button');
  setTimeout(() => first && first.focus(), 50);
  return close;
}

export function emptyState(msg, icon = 'info', action = null) {
  const d = el('div', { class: 'empty' });
  d.append(fmt(svgIc(icon, 36)));
  d.append(el('p', { class: 'muted', text: msg }));
  if (action) d.append(el('div', { style: 'margin-top:14px' }, action));
  return d;
}

export function bar(pct) {
  const w = el('div', { class: 'bar' });
  w.append(el('i', { style: `width:${Math.max(0, Math.min(100, pct || 0))}%` }));
  return w;
}

/* Reemplaza los enlaces de la lista permitida por <a> clickeables (solo esos). */
export function linkify(text, allowedUrls = []) {
  let out = esc(text);
  if (allowedUrls && allowedUrls.length) {
    for (const u of allowedUrls) {
      const safe = u.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      out = out.replace(new RegExp(`(${safe})`, 'g'), `<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>`);
    }
  }
  return out;
}

/* Renderiza texto de chat: párrafos + bloques de código + links permitidos. */
export function chatHTML(text, allowedUrls = []) {
  const html = linkify(text, allowedUrls).split('\n');
  let inCode = false, codeBuf = [], out = [], lang = '';
  for (const line of html) {
    const m = line.match(/^```(.*)$/);
    if (m) {
      if (!inCode) { inCode = true; lang = m[1].trim(); codeBuf = []; }
      else {
        out.push(`<pre><code>${codeBuf.join('\n')}</code></pre>`);
        inCode = false;
      }
      continue;
    }
    if (inCode) { codeBuf.push(line); continue; }
    if (!line.trim()) { out.push('<br>'); continue; }
    out.push(`<span>${line}</span>`);
  }
  return out.join('\n');
}
