/* NEXTSTEP — Rutas de aprendizaje: creación manual o con IA, módulos y actividades. */
import { api } from '../api.js';
import * as store from '../store.js';
import { el, svgIc, bar, emptyState, modal, toast, fmtDate, cap } from '../ui.js';
import { setupNotice } from '../app.js';

const KINDS = {
  explicacion: { label: 'Explicación', icon: 'book' },
  recurso: { label: 'Recurso', icon: 'link' },
  practica: { label: 'Práctica', icon: 'pencil' },
  evaluacion: { label: 'Evaluación', icon: 'quiz' },
};
const KIND_ORDER = { explicacion: 0, recurso: 1, practica: 2, evaluacion: 3 };

export function pathsView(params) {
  const root = el('div', { class: 'stack' });
  if (params[0]) detail(root, Number(params[0]));
  else list(root);
  return root;
}

/* ---------- Lista ---------- */
async function list(root) {
  root.append(el('div', { class: 'skeleton', style: 'height:110px;border-radius:14px' }));
  try {
    const r = await api('/paths');
    root.innerHTML = '';
    const head = el('div', { class: 'view-head flex wrap' });
    head.append(el('div', { class: 'grow' }, el('h1', { text: 'Rutas de aprendizaje' }), el('p', { text: 'Un camino ordenado de módulos y actividades, del fundamento al avance. Se adapta a tus resultados.' })));
    head.append(el('button', { class: 'btn', onclick: openGenerateModal }, svgIc('sparkles', 18), 'Generar con IA'));
    head.append(el('button', { class: 'btn ghost', onclick: openManualModal }, svgIc('plus', 18), 'Crear a mano'));
    root.append(head);

    if (!r.paths.length) {
      root.append(emptyState('Todavía no tenés rutas. Generá una con IA para tu materia o armala vos a mano.', 'route',
        el('div', { class: 'flex', style: 'justify-content:center' },
          el('button', { class: 'btn', onclick: openGenerateModal }, 'Generar con IA'),
          el('button', { class: 'btn ghost', onclick: openManualModal }, 'Crear a mano'))));
      return;
    }
    for (const p of r.paths) {
      root.append(el('div', { class: 'card', style: 'cursor:pointer', onclick: () => store.nav(`/paths/${p.id}`) },
        el('div', { class: 'flex' },
          el('div', { class: 'grow' }, el('h3', { text: p.title }), el('p', { class: 'sub' }, p.summary || '')),
          el('span', { class: 'pct' }, `${p.progress}%`)),
        el('div', { style: 'margin-top:12px' }, bar(p.progress)),
        el('div', { class: 'flex wrap', style: 'margin-top:12px' },
          el('span', { class: 'tag' }, `${p.modules} módulos`),
          el('span', { class: 'tag en_curso', text: p.nextModule ? 'Seguís en: ' + p.nextModule.title : (STATUS_PATH[p.status] || cap(p.status) || 'Pendiente') }),
          el('span', { class: 'muted small', style: 'margin-left:auto' }, `creada ${fmtDate(p.createdAt)}`))));
    }
  } catch (e) {
    root.innerHTML = '';
    root.append(emptyState((e && e.message) || 'No se pudieron cargar las rutas.', 'warn'));
  }
}

async function subjectsOptions() {
  const r = await api('/subjects');
  store.setCache('subjects', r.subjects);
  return r.subjects;
}

function openGenerateModal() {
  const wrap = el('div', { class: 'stack' });
  const subjSel = el('select', { class: 'input' }, el('option', { value: '' }, 'Cargando materias…'));
  const target = el('select', { class: 'input' });
  for (const t of ['Iniciante', 'Básico', 'Intermedio', 'Avanzado', 'Experto']) target.append(el('option', { value: t, ...(t === 'Intermedio' ? { selected: '' } : {}) }, t));
  const hours = el('input', { class: 'input', type: 'number', min: 1, max: 40, value: 5 });
  const progress = el('p', { class: 'muted small', role: 'status', 'aria-live': 'polite', hidden: true });
  wrap.append(
    el('div', { class: 'field' }, el('label', { text: 'Materia' }), subjSel),
    el('div', { class: 'field' }, el('label', { text: 'Nivel que querés alcanzar' }), target),
    el('div', { class: 'field' }, el('label', { text: 'Horas por semana' }), hours),
    progress,
  );
  subjectsOptions().then(r => {
    subjSel.innerHTML = '';
    subjSel.append(el('option', { value: '' }, 'Elegí la materia…'));
    for (const su of r) subjSel.append(el('option', { value: su.id }, su.name));
  }).catch(() => { subjSel.innerHTML = '<option value="">Sin materias</option>'; });

  let close = () => {};
  close = modal({
    title: 'Generar ruta con IA',
    body: wrap,
    footer: [
      el('button', { class: 'btn ghost', onclick: () => close() }, 'Cancelar'),
      el('button', { class: 'btn', onclick: async (e) => {
        if (!subjSel.value) return toast('Elegí la materia.', 'err');
        const b = e.currentTarget;
        subjSel.disabled = target.disabled = hours.disabled = true;
        setModalBusy(b, true);
        b.textContent = 'Generando…';
        progress.hidden = false;
        progress.textContent = 'La IA está armando tu ruta. Puede tardar un poco.';
        const slowTimer = setTimeout(() => {
          progress.textContent = 'El modelo de IA sigue trabajando; con Ollama puede tardar más según la computadora.';
        }, 15000);
        const longTimer = setTimeout(() => {
          progress.textContent = 'La generación está tardando más de lo habitual. Si falla, vas a ver el error acá para saber qué revisar.';
        }, 45000);
        try {
          const r = await api('/paths/generate', {
            method: 'POST',
            body: { subject_id: Number(subjSel.value), target: target.value, hoursPerWeek: Number(hours.value) },
          });
          close();
          toast('Ruta generada: +20 XP', 'ok');
          await store.loadMe();
          store.nav(`/paths/${r.path.id}`);
        } catch (err) {
          progress.textContent = (err && err.message) || 'No se pudo generar la ruta. Revisá que Ollama esté abierto y que haya un modelo descargado.';
          progress.classList.add('error-text');
          toast('No se pudo generar la ruta. El detalle quedó en esta ventana.', 'err');
        } finally {
          clearTimeout(slowTimer); clearTimeout(longTimer);
          subjSel.disabled = target.disabled = hours.disabled = false;
          setModalBusy(b, false);
          b.textContent = 'Reintentar';
        }
      } }, 'Generar ruta'),
    ],
  });
}

function openManualModal() {
  const wrap = el('div', { class: 'stack' });
  const title = el('input', { class: 'input', placeholder: 'Título de la ruta' });
  const summary = el('textarea', { class: 'input', placeholder: 'Resumen corto (opcional)' });
  const modulesEl = el('div', { class: 'stack' });
  const addModuleInput = el('input', { class: 'input', placeholder: 'Módulo 1: Fundamentos…' });
  const addModuleButton = el('button', { class: 'btn ghost', onclick: () => {
    const v = addModuleInput.value.trim();
    if (!v) return;
    addModuleInput.value = '';
    modulesEl.append(moduleChip(v));
  } }, 'Agregar');
  wrap.append(
    el('div', { class: 'field' }, el('label', { text: 'Título' }), title),
    el('div', { class: 'field' }, el('label', { text: 'Resumen' }), summary),
    el('div', { class: 'field' }, el('label', { text: 'Módulos (opcional, se agregan los que cargues)' }), modulesEl, el('div', { class: 'row-input' }, addModuleInput, addModuleButton)),
  );
  function moduleChip(v) {
    const line = el('div', { class: 'flex', style: 'background:var(--surface2);border-radius:9px;padding:7px 12px' },
      el('span', { class: 'grow', text: v }));
    line.append(el('button', { class: 'icon-btn danger', style: 'width:28px;height:28px', 'aria-label': 'Quitar', onclick: () => line.remove() }, '×'));
    return line;
  }
  let close = () => {};
  close = modal({
    title: 'Crear ruta a mano',
    body: wrap,
    footer: [
      el('button', { class: 'btn ghost', onclick: () => close() }, 'Cancelar'),
      el('button', { class: 'btn', onclick: async (e) => {
        const b = e.currentTarget;
        title.disabled = summary.disabled = addModuleInput.disabled = addModuleButton.disabled = true;
        modulesEl.querySelectorAll('button').forEach(button => { button.disabled = true; });
        setModalBusy(b, true);
        b.textContent = 'Creando…';
        try {
          const r = await api('/paths', {
            method: 'POST',
            body: {
              title: title.value.trim(),
              summary: summary.value.trim(),
              modules: [...modulesEl.children].map(c => ({ title: c.querySelector('span').textContent, objective: '' })),
            },
          });
          close();
          toast('Ruta creada: +20 XP', 'ok');
          await store.loadMe();
          store.nav(`/paths/${r.path.id}`);
        } catch (err) {
          toast((err && err.message) || 'No se pudo crear.', 'err');
          title.disabled = summary.disabled = addModuleInput.disabled = addModuleButton.disabled = false;
          modulesEl.querySelectorAll('button').forEach(button => { button.disabled = false; });
          setModalBusy(b, false);
          b.textContent = 'Reintentar';
        }
      } }, 'Crear ruta'),
    ],
  });
}

/* ---------- Detalle ---------- */
async function detail(root, id) {
  root.append(el('div', { class: 'skeleton', style: 'height:220px;border-radius:14px' }));
  let d;
  try { d = await api(`/paths/${id}`); } catch (e) {
    root.innerHTML = '';
    root.append(emptyState((e && e.message) || 'No existe esa ruta.', 'warn', el('button', { class: 'btn ghost', onclick: () => store.nav('/paths') }, 'Volver a rutas')));
    return;
  }
  root.innerHTML = '';
  const p = d.path;

  const head = el('div', { class: 'view-head flex wrap' });
  const h = el('div', { class: 'grow' });
  h.append(el('h1', { text: p.title }));
  h.append(el('p', { text: p.summary || (d.subject ? `Ruta de ${d.subject.name}` : '') }));
  head.append(h,
    el('button', { class: 'btn ghost', onclick: () => editPath(p, d.modules, () => detail(root, id)) }, svgIc('pencil', 18), 'Editar ruta'),
    el('button', { class: 'btn ghost', onclick: () => store.nav(`/teacher${d.subject ? `?tema=${p.title}` : ''}`) }, svgIc('chat', 18), 'Hablar con el profesor'));
  root.append(head);

  const statRow = el('div', { class: 'stat-row' });
  statRow.append(stat('route', `${p.progress}%`, 'avance'));
  statRow.append(stat('list', String(p.modules), 'módulos'));
  statRow.append(stat('check', String(p.modulesDone || 0), 'módulos hechos'));
  root.append(statRow);

  const trail = el('div', { class: 'trail' });
  for (const m of d.modules) {
    const acts = [...(m.activities || [])].sort((a, b) => KIND_ORDER[a.kind] - KIND_ORDER[b.kind] || a.id - b.id);
    const isComplete = acts.length > 0 && acts.every(a => a.status === 'completada') || m.status === 'completado';
    const visibleStatus = isComplete ? 'Realizado' : STATUS_MODULE[m.status] || cap(m.status);
    const moduleDetails = el('details', { class: `node module-details${isComplete ? ' completed' : ''}`, open: !isComplete });
    const summary = el('summary', { class: 'module-summary' });
    summary.append(
      el('span', { class: 'module-chevron', html: svgIc('arrowR', 16), 'aria-hidden': 'true' }),
      el('span', { class: 'module-heading grow' },
        el('span', { class: 'module-title' }, m.title),
        m.objective ? el('span', { class: 'module-objective' }, m.objective) : null),
      el('span', { class: `tag${isComplete ? ' dominado' : ''}`, text: visibleStatus }),
    );
    const content = el('div', { class: 'module-content' },
      ...acts.map(a => actRow(a, m, () => detail(root, id))),
      el('div', { class: 'row-input module-add' },
        el('input', { class: 'input', placeholder: 'Agregar actividad…', 'data-module': m.id }),
        el('button', { class: 'btn sm', 'data-add': m.id }, svgIc('plus', 16))));
    moduleDetails.append(summary, content);
    trail.append(moduleDetails);
  }
  // Delegación global para inputs agregados (evita clausuras por fila).
  trail.querySelectorAll('[data-add]').forEach(btn => {
    const mid = btn.dataset.add;
    const inp = trail.querySelector(`[data-module="${mid}"]`);
    btn.addEventListener('click', () => addActivity(mid, inp, () => detail(root, id)));
  });
  trail.querySelectorAll('.node').forEach(node => {
    const acts = node.querySelectorAll('.act');
    acts.forEach(a => {
      a.querySelectorAll('[data-done]').forEach(b => b.addEventListener('click', async () => {
        try {
          const r = await api(`/activities/${b.dataset.done}`, { method: 'PUT', body: { status: b.dataset.next } });
          if (r.gained) toast(`+${r.gained} XP`, 'ok');
          else if (r.lost) toast(`−${r.lost} XP por deshacer la actividad`, 'info');
          if (r.gained || r.lost) await store.loadMe();
          detail(root, id);
        } catch (e) { toast((e && e.message) || 'No se pudo actualizar.', 'err'); }
      }));
    });
  });

  const card = el('div', { class: 'card' }, el('div', { class: 'card-title', style: 'margin-bottom:10px' }, svgIc('route', 18), 'Recorrido'));
  card.append(trail);
  root.append(card);

  root.append(el('div', { class: 'flex wrap' },
    el('button', { class: 'btn ghost', onclick: () => store.nav('/paths') }, 'Volver a rutas'),
    el('button', { class: 'btn ghost danger', onclick: async () => {
      if (!confirm('¿Eliminar esta ruta? Se borran sus módulos y actividades.')) return;
      try { await api(`/paths/${id}`, { method: 'DELETE' }); toast('Ruta eliminada', 'ok'); store.nav('/paths'); } catch (e) { toast((e && e.message) || 'No se pudo borrar.', 'err'); }
    } }, svgIc('trash', 18), 'Eliminar ruta'),
    el('button', { class: 'btn', onclick: () => store.nav('/teacher') }, svgIc('chat', 18), 'Practicar esto en el chat'),
  ));
}

function editPath(path, modules, refresh) {
  const wrap = el('div', { class: 'stack path-editor' });
  const title = el('input', { class: 'input', maxlength: 100, value: path.title });
  const summary = el('textarea', { class: 'input', rows: 3, maxlength: 300 }, path.summary || '');
  const moduleList = el('div', { class: 'stack path-edit-modules' });
  const addModule = () => moduleList.append(moduleEditorRow({ title: '', objective: '' }));
  modules.forEach(m => moduleList.append(moduleEditorRow(m)));
  wrap.append(
    el('div', { class: 'field' }, el('label', { text: 'Título' }), title),
    el('div', { class: 'field' }, el('label', { text: 'Resumen' }), summary),
    el('div', { class: 'field' }, el('label', { text: 'Módulos y objetivos' }),
      el('p', { class: 'muted small', text: 'Podés cambiar el orden, editar o quitar módulos. Las actividades completadas que quites también descuentan su XP.' }),
      moduleList,
      el('button', { class: 'btn ghost sm', style: 'align-self:flex-start', onclick: addModule }, svgIc('plus', 16), 'Agregar módulo')),
  );
  let close = () => {};
  close = modal({ title: 'Editar ruta', body: wrap, footer: [
    el('button', { class: 'btn ghost', onclick: () => close() }, 'Cancelar'),
    el('button', { class: 'btn', onclick: async e => {
      if (!title.value.trim()) return toast('Ingresá un título para la ruta.', 'err');
      const button = e.currentTarget; button.disabled = true;
      const editedModules = [...moduleList.querySelectorAll('.path-edit-module')].map(row => ({
        id: row.dataset.id ? Number(row.dataset.id) : undefined,
        title: row.querySelector('[data-module-title]').value.trim(),
        objective: row.querySelector('[data-module-objective]').value.trim(),
      })).filter(m => m.title);
      try {
        await api(`/paths/${path.id}`, { method: 'PUT', body: { title: title.value.trim(), summary: summary.value.trim(), modules: editedModules } });
        close(); toast('Ruta actualizada', 'ok'); await store.loadMe(); refresh();
      } catch (err) { toast(err.message || 'No se pudo editar la ruta.', 'err'); }
      finally { button.disabled = false; }
    } }, 'Guardar cambios'),
  ] });
}

function moduleEditorRow(module) {
  const row = el('div', { class: 'path-edit-module', 'data-id': module.id || '' });
  const heading = el('div', { class: 'flex' },
    el('span', { class: 'muted small grow', text: module.id ? `Módulo ${Number(module.position || 0) + 1}` : 'Módulo nuevo' }),
    el('button', { class: 'btn ghost sm danger', title: 'Eliminar módulo y sus actividades', 'aria-label': 'Eliminar módulo', onclick: () => {
      if (module.id && !confirm(`¿Eliminar el módulo «${module.title}» y todas sus actividades? Si tenía progreso, también se descontarán sus XP.`)) return;
      row.remove();
    } }, svgIc('trash', 15), 'Eliminar módulo'));
  row.append(heading,
    el('input', { class: 'input', maxlength: 90, placeholder: 'Nombre del módulo', value: module.title || '', dataset: { moduleTitle: '' } }),
    el('input', { class: 'input', maxlength: 280, placeholder: 'Objetivo (opcional)', value: module.objective || '', dataset: { moduleObjective: '' } }));
  return row;
}

function setModalBusy(button, busy) {
  const box = button.closest('.modal');
  if (!box) return;
  const backdrop = box.parentElement;
  if (backdrop && !backdrop.dataset.busyGuard) {
    backdrop.addEventListener('click', event => {
      if (backdrop.dataset.busy === 'true' && event.target === backdrop) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    }, true);
    backdrop.dataset.busyGuard = 'true';
  }
  if (backdrop) backdrop.dataset.busy = busy ? 'true' : 'false';
  box.querySelectorAll('input, select, textarea, button').forEach(control => { control.disabled = busy; });
}

const STATUS_MODULE = { pendiente: 'Pendiente', en_curso: 'En curso', completado: 'Realizado' };
const STATUS_PATH = { pendiente: 'Pendiente', en_curso: 'En curso', completado: 'Completado' };

function stat(icon, num, label) {
  return el('div', { class: 'stat' },
    el('div', { class: 'ic', html: svgIc(icon, 18) }),
    el('div', { class: 'num', text: String(num) }),
    el('div', { class: 'lbl', text: label }));
}

function actRow(a, module, refresh) {
  const k = KINDS[a.kind] || KINDS.practica;
  const done = a.status === 'completada';
  const div = el('div', { class: `act${done ? ' done' : ''}`, style: 'flex-wrap:wrap' });
  div.append(el('span', { class: 'ic2', html: svgIc(done ? 'check' : k.icon, 17) , style: 'display:flex;color:var(--muted)'}),
    el('div', { class: 'grow' }, el('p', { style: 'font-weight:600;font-size:.92rem' }, a.title),
      el('p', { class: 'meta', style: 'font-size:.78rem' }, done ? (a.score != null ? `Evaluada · ${a.score}/100` : 'Completada') : 'Pendiente')));
  if (!done) div.append(el('button', { class: 'btn sm', 'data-done': a.id, 'data-next': 'completada' }, 'Marcar hecha'));
  else div.append(el('button', { class: 'btn sm ghost', 'data-done': a.id, 'data-next': 'pendiente' }, 'Deshacer'));
  div.append(el('button', { class: 'icon-btn', title: 'Editar actividad', 'aria-label': 'Editar actividad', onclick: () => editActivity(a, refresh), html: svgIc('pencil', 15) }));
  return div;
}

function editActivity(activity, refresh) {
  const title = el('input', { class: 'input', maxlength: 90, value: activity.title });
  const kind = el('select', { class: 'input' });
  Object.entries(KINDS).forEach(([value, cfg]) => kind.append(el('option', { value, selected: activity.kind === value }, cfg.label)));
  const body = el('div', { class: 'stack' },
    el('div', { class: 'field' }, el('label', { text: 'Nombre' }), title),
    el('div', { class: 'field' }, el('label', { text: 'Tipo de actividad' }), kind));
  let close = () => {};
  close = modal({ title: 'Editar actividad', body, footer: [
    el('button', { class: 'btn ghost', onclick: () => close() }, 'Cancelar'),
    el('button', { class: 'btn', onclick: async e => {
      if (!title.value.trim()) return toast('Ingresá un nombre.', 'err');
      const button = e.currentTarget; button.disabled = true;
      try {
        await api(`/activities/${activity.id}`, { method: 'PUT', body: { title: title.value.trim(), kind: kind.value } });
        close(); toast('Actividad actualizada', 'ok'); refresh();
      } catch (err) { toast(err.message || 'No se pudo editar la actividad.', 'err'); }
      finally { button.disabled = false; }
    } }, 'Guardar cambios'),
  ] });
}

async function addActivity(moduleId, input, refresh) {
  const title = input.value.trim();
  if (!title) return;
  try {
    const r = await api(`/modules/${moduleId}/activities`, { method: 'POST', body: { title } });
    input.value = '';
    if (r.gained) toast(`+${r.gained} XP`, 'ok');
    else if (r.lost) toast(`−${r.lost} XP porque el módulo volvió a estar pendiente`, 'info');
    if (r.gained || r.lost) await store.loadMe();
    refresh();
  } catch (e) { toast((e && e.message) || 'No se pudo agregar.', 'err'); }
}
