/* NEXTSTEP — Mi profesor IA: chat con streaming (SSE), modos por actividad y
   lista de conversaciones. Las respuestas de la IA son reales (nunca simuladas):
   si no hay clave configurada se muestra el aviso y el chat queda deshabilitado. */
import { api, streamChat, ApiError } from '../api.js';
import * as store from '../store.js';
import { el, svgIc, esc, chatHTML, fmtRel, toast, modal } from '../ui.js';
import { getMeta, setupNotice } from '../app.js';

const MODE_LABELS = {
  normal: 'Conversación', concentracion: 'Concentración', lectura: 'Lectura',
  practica: 'Práctica', evaluacion: 'Evaluación', planificacion: 'Planificación', repaso: 'Repaso',
};
const KIND_ICON = { normal: 'chat', concentracion: 'star', lectura: 'book', practica: 'pencil', evaluacion: 'quiz', planificacion: 'calendar', repaso: 'clock' };
const TEACHER_SUGGESTIONS = [
  'Explicame esto con otro ejemplo',
  'No me des la solución todavía',
  'Evaluá mi nivel con 3 preguntas',
  'Armame un plan para esta semana',
  'Dame un ejercicio para practicar',
  'Corregime lo que hice',
];

export function teacherView(params) {
  const meta = getMeta() || {};
  const setup = meta.requiresSetup;
  const MODES = meta.modes && meta.modes.length ? meta.modes : Object.keys(MODE_LABELS);
  const root = el('div');
  if (setup) root.append(setupNotice());

  const wrap = el('div', { class: 'chat-wrap' + (setup ? ' with-notice' : '') });

  /* ---- Panel lateral ---- */
  const side = el('div', { class: 'chat-side' });
  // La materia y el modo se eligen UNA vez, al crear la charla, y quedan fijos en esa conversación.
  const newBtn = el('button', {
    class: 'btn block', disabled: !!setup,
    onclick: () => openNewChatPicker(),
  }, svgIc('plus', 18), 'Nueva charla');

  const convList = el('div', { class: 'conv-list' });

  /* ---- Panel principal ---- */
  const main = el('div', { class: 'chat-main' });
  const head = el('div', { class: 'chat-head' });
  const headTitle = el('div', { class: 't' }, 'Nueva conversación');
  const headBadges = el('div', { class: 'chat-badges' });
  head.append(headTitle, headBadges);

  const suggestions = el('details', { class: 'chat-suggestions', hidden: true });
  suggestions.append(el('summary', {}, svgIc('sparkles', 15), ' Sugerencias ', svgIc('arrowR', 14)));
  const suggestionList = el('div', { class: 'chat-suggestion-list' });
  TEACHER_SUGGESTIONS.forEach(text => suggestionList.append(el('button', {
    class: 'chip', type: 'button', text,
    onclick: () => { input.value = text; autoGrow(); input.focus(); },
  })));
  suggestions.append(suggestionList);

  const body = el('div', { class: 'chat-body' });
  const quickBar = el('div', { class: 'chat-quick' });
  const inBar = el('div', { class: 'chat-in' });
  const input = el('textarea', {
    rows: 1, placeholder: setup ? 'La IA no está configurada aún' : 'Escribile a tu profesor… (Enter para enviar)',
    disabled: setup,
    onkeydown: e => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
      if (e.key === 'Enter') input.style.height = 'auto';
    },
    oninput: autoGrow,
  });
  const sendBtn = el('button', { class: 'btn', disabled: setup, 'aria-label': 'Enviar', html: svgIc('send', 18) });
  sendBtn.addEventListener('click', send);
  const stopBtn = el('button', { class: 'btn danger hidden', html: svgIc('stop', 18) });
  inBar.append(input, sendBtn, stopBtn);
  main.append(head, suggestions, body, quickBar, inBar);

  // Atajos que llegan desde otras secciones quedan escritos para que el alumno los envíe.
  const pending = sessionStorage.getItem('ns_pending_msg');
  if (pending) {
    sessionStorage.removeItem('ns_pending_msg');
    input.value = pending;
    autoGrow();
    input.focus();
  }
  wrap.append(side, main);
  root.append(wrap);

  /* ---- Estado ---- */
  let current = null;            // conversación abierta
  let aborter = null;

  side.append(newBtn,
    el('div', { class: 'muted small', style: 'padding:0 4px' }, 'Tus charlas'),
    convList);

  /* ---- Acciones ---- */
  function autoGrow() { input.style.height = 'auto'; input.style.height = Math.min(130, input.scrollHeight) + 'px'; }

  async function subjectList() {
    let subs = store.cacheKey('subjects');
    if (!Array.isArray(subs)) {
      try { subs = (await api('/subjects')).subjects; store.setCache('subjects', subs); }
      catch { subs = []; }
    }
    return subs;
  }

  /* Selector de materia y modo: solo existe al empezar una charla nueva. */
  async function openNewChatPicker() {
    if (setup) return;
    const subs = await subjectList();
    const subjectSel = el('select', { class: 'input' }, el('option', { value: '' }, 'Sin materia'));
    for (const su of subs) subjectSel.append(el('option', { value: su.id }, su.name));
    // Por comodidad arranca con la materia de la charla abierta (se puede cambiar acá, antes de crear).
    if (current && current.subject_id) subjectSel.value = String(current.subject_id);
    const modeSel = el('select', { class: 'input' });
    for (const m of MODES) modeSel.append(el('option', { value: m, ...(m === 'normal' ? { selected: '' } : {}) }, MODE_LABELS[m] || m));
    const body = el('div', { class: 'stack' },
      el('div', { class: 'field' }, el('label', { text: 'Materia' }), subjectSel),
      el('div', { class: 'field' }, el('label', { text: 'Modo' }), modeSel),
      el('p', { class: 'muted small' }, 'Se guardan con la charla y no se pueden cambiar después: si necesitás otra materia o modo, empezá una charla nueva.'));
    let close = () => {};
    close = modal({
      title: 'Nueva charla',
      body,
      footer: [
        el('button', { class: 'btn ghost', onclick: () => close() }, 'Cancelar'),
        el('button', { class: 'btn', onclick: async (e) => {
          const b = e.currentTarget; b.disabled = true;
          const ok = await createConversation({ subject_id: subjectSel.value ? Number(subjectSel.value) : null, mode: modeSel.value });
          if (ok) close(); else b.disabled = false;
        } }, 'Empezar charla'),
      ],
    });
  }

  async function createConversation({ subject_id = null, mode = 'normal' } = {}) {
    try {
      const r = await api('/conversations', {
        method: 'POST',
        body: { subject_id, mode, title: 'Nueva conversación' },
      });
      localStorage.setItem('ns_teacher_conv', String(r.conversation.id));
      await openConversation(r.conversation.id, true);
      return true;
    } catch (e) { toast((e && e.message) || 'No se pudo crear la charla.', 'err'); return false; }
  }

  /* Sin ninguna charla abierta: se invita a empezar una (con su selector de materia y modo). */
  function showEmptyChat() {
    current = null;
    suggestions.hidden = true;
    headTitle.textContent = 'Sin charla abierta';
    headBadges.innerHTML = '';
    body.innerHTML = '';
    quickBar.innerHTML = '';
    applyActivityMode('');
    body.append(el('div', { class: 'chat-empty' },
      el('p', {}, 'Empezá una charla y elegí la materia y el modo con los que querés trabajar.'),
      el('button', { class: 'btn', disabled: !!setup, onclick: () => openNewChatPicker() }, svgIc('plus', 18), 'Nueva charla')));
  }

  async function openConversation(id, isNew = false) {
    try {
      const d = await api(`/conversations/${id}`);
      current = d.conversation;
      suggestions.hidden = false;
      localStorage.setItem('ns_teacher_conv', String(id));
      headTitle.textContent = d.conversation.title === 'Nueva conversación' ? 'Nueva conversación' : d.conversation.title;
      headTitle.title = d.conversation.title;

      // Materia y modo: solo se muestran (quedaron guardados al crear la charla).
      const subs = d.conversation.subject_id ? await subjectList() : [];
      const subj = subs.find(su => su.id === d.conversation.subject_id);
      headBadges.innerHTML = '';
      headBadges.append(
        el('span', { class: 'chat-badge', title: 'Materia de esta charla' }, svgIc('learn', 14), 'Materia: ', el('b', {}, subj ? subj.name : 'Sin materia')),
        el('span', { class: 'chat-badge', title: 'Modo de esta charla' }, svgIc(KIND_ICON[d.conversation.mode] || 'chat', 14), 'Modo: ', el('b', {}, MODE_LABELS[d.conversation.mode] || 'Conversación')));

      body.innerHTML = '';
      quickBar.innerHTML = '';
      if (!d.messages || !d.messages.length) {
        body.append(greetingBubble(meta));
      } else {
        for (const m of d.messages) body.append(messageBubble(m.role, m.content, m.role === 'assistant'));
      }
      applyActivityMode(d.conversation.mode);
      body.scrollTop = body.scrollHeight;
      refreshConvList();
      input.focus();
      if (isNew) window.history.replaceState(null, '', `#/teacher/${id}`);
    } catch (e) { toast((e && e.message) || 'No se pudo abrir la charla.', 'err'); }
  }

  function applyActivityMode(mode) {
    const v = document.getElementById('view');
    if (v) v.dataset.activity = mode || '';
  }

  function greetingBubble(meta) {
    const m = el('div', { class: 'msg ai' });
    const b = el('div', { class: 'bub' });
    b.textContent = meta && meta.greeting ? meta.greeting : '¡Hola! Soy NEXTSTEP, tu profesor particular. Contame qué querés aprender.';
    m.append(b);
    if (meta && meta.startQuick && meta.startQuick.length) {
      for (const q of meta.startQuick) quickBar.append(chip(q, () => input.value = q));
    }
    return m;
  }

  function messageBubble(role, content, isAi = false) {
    const m = el('div', { class: `msg ${isAi ? 'ai' : 'user'}` });
    const b = el('div', { class: 'bub' });
    if (isAi) {
      b.innerHTML = chatHTML(content, (getMeta() || {}).allowedUrls);
    } else {
      b.textContent = content;
    }
    m.append(b);
    return m;
  }

  function chip(text, onclick) {
    return el('button', { class: 'chip', onclick }, text);
  }

  /* Oculta las etiquetas de control (<opciones>, <perfil>, <resumen>) mientras llega el streaming:
     quita las completas y recorta si hay una a medias al final del texto parcial. */
  function stripStreamTags(t) {
    let s = t.replace(/<opciones>[\s\S]*?<\/opciones>/g, '')
      .replace(/<perfil>[\s\S]*?<\/perfil>/g, '')
      .replace(/<resumen>[\s\S]*?<\/resumen>/g, '');
    const cut = s.search(/<(opciones|perfil|resumen)[^<>]*>?[^<]*$/);
    if (cut >= 0) s = s.slice(0, cut);
    return s;
  }

  function addQuickOptions(list) {
    quickBar.innerHTML = '';
    if (!Array.isArray(list) || !list.length) return;
    for (const o of list) {
      if (o.startsWith('#')) {
        const mode = o.slice(1);
        if (MODE_LABELS[mode]) { /* modo referenciado por la IA */ continue; }
      }
      quickBar.append(chip(o, () => { input.value = o; input.focus(); }));
    }
  }

  async function send() {
    const text = input.value.trim();
    if (!text || !current || setup) return;
    if (aborter) return; // ya está enviando

    body.append(messageBubble('user', text));
    input.value = '';
    autoGrow();
    sendBtn.classList.add('hidden');
    stopBtn.classList.remove('hidden');
    quickBar.innerHTML = '';

    const aiMsg = el('div', { class: 'msg ai' });
    const bubble = el('div', { class: 'bub' });
    const typing = el('span', { class: 'muted' }, 'Escribiendo…');
    bubble.append(typing);
    aiMsg.append(bubble);
    body.append(aiMsg);
    body.scrollTop = body.scrollHeight;

    aborter = new AbortController();
    const started = Date.now();
    try {
      const out = await streamChat({
        conversationId: current.id,
        content: text,
        signal: aborter.signal,
        onChunk: t => {
          if (typing) typing.remove();
          bubble._acc = bubble._acc ? bubble._acc + t : t;
          bubble.innerHTML = chatHTML(stripStreamTags(bubble._acc), (getMeta() || {}).allowedUrls);
          body.scrollTop = body.scrollHeight;
        },
      });
      const elapsed = Date.now() - started;
      if (!out.text) {
        if (elapsed < 2500) await new Promise(r => setTimeout(r, 2500 - elapsed));
        bubble.textContent = 'No recibí respuesta. Probá de nuevo.';
      } else {
        if (typing) typing.remove();
        bubble.innerHTML = chatHTML(out.text, (getMeta() || {}).allowedUrls);
        if (out.resumen) {
          const res = el('div', {
            class: 'muted small', style: 'margin-top:10px;padding-top:8px;border-top:1px dashed var(--line);display:flex;gap:8px;align-items:flex-start',
          }, svgIc('info', 14), el('span', { text: 'Resumen: ' + out.resumen }));
          bubble.append(res);
        }
        addQuickOptions(out.quick);
      }
    } catch (e) {
      if (typing) typing.remove();
      if (e && e.name === 'AbortError') {
        bubble.textContent = 'Paraste la respuesta.';
      } else {
        const msg = (e && e.message) || 'No se pudo usar la IA ahora.';
        if (e instanceof ApiError && e.status === 503) {
          bubble.innerHTML = '';
          bubble.append(setupNotice());
        } else {
          bubble.textContent = msg + ' Quedó guardado lo que escribiste: podés volver a pedirle que responda.';
        }
      }
    } finally {
      aborter = null;
      sendBtn.classList.remove('hidden');
      stopBtn.classList.add('hidden');
      body.scrollTop = body.scrollHeight;
      await store.loadMe().catch(() => {});
      refreshConvList();
    }
  }

  stopBtn.addEventListener('click', () => { if (aborter) aborter.abort(); });

  async function deleteConversation(id) {
    if (!confirm('¿Eliminar esta charla y todos sus mensajes? Esta acción no se puede deshacer.')) return;
    const deletingCurrent = current && String(current.id) === String(id);
    try {
      await api(`/conversations/${id}`, { method: 'DELETE' });
      if (String(localStorage.getItem('ns_teacher_conv')) === String(id)) localStorage.removeItem('ns_teacher_conv');
      if (deletingCurrent) {
        current = null;
        headTitle.textContent = 'Sin charla abierta';
        headBadges.innerHTML = '';
        body.innerHTML = '';
        quickBar.innerHTML = '';
        applyActivityMode('');
      }
      await refreshConvList();
      if (deletingCurrent) {
        const remaining = await api('/conversations');
        if (remaining.conversations.length) await openConversation(remaining.conversations[0].id);
        else showEmptyChat();
      }
      toast('Charla eliminada.', 'ok');
    } catch (e) { toast((e && e.message) || 'No se pudo eliminar la charla.', 'err'); }
  }
  async function refreshConvList() {
    try {
      const r = await api('/conversations');
      convList.innerHTML = '';
      for (const c of r.conversations) {
        const item = el('div', { class: `conv-item${current && c.id === current.id ? ' on' : ''}`, onclick: () => openConversation(c.id) });
        const titleRow = el('div', { class: 'conv-title-row' },
          el('span', { class: 'name', title: c.title }, c.title),
          el('button', { class: 'icon-btn danger conv-delete', type: 'button', title: 'Eliminar charla', 'aria-label': `Eliminar ${c.title}`, onclick: e => { e.stopPropagation(); deleteConversation(c.id); } }, svgIc('trash', 15)));
        item.append(titleRow);
        item.append(el('div', { class: 'm' }, `${fmtRel(c.updated_at)} · ${MODE_LABELS[c.mode] || 'Conversación'}${c.subject_name ? ' · ' + c.subject_name : ''}${c.last_msg ? ' · ' + c.last_msg.slice(0, 40) : ''}`));
        convList.append(item);
      }
      if (!r.conversations.length) {
        convList.append(el('div', { class: 'muted small', style: 'padding:8px 4px;line-height:1.5' }, 'Todavía no tenés charlas. Arrancá una nueva y contale qué querés aprender.'));
      }
    } catch { /* silencioso */ }
  }

  // Abrir una conversación específica (o la última guardada).
  const seed = async () => {
    await refreshConvList();
    if (params[0]) { openConversation(Number(params[0])); return; }
    const last = Number(localStorage.getItem('ns_teacher_conv')) || null;
    const r = await api('/conversations').catch(() => null);
    if (r && last && r.conversations.some(c => c.id === last)) { openConversation(last); return; }
    if (r && r.conversations.length) { openConversation(r.conversations[0].id); return; }
    // Sin charlas previas: no se crea una "a ciegas". Se muestra el selector de materia y modo
    // (si el alumno venía con un mensaje listo desde el riel o el inicio, se abre directo).
    showEmptyChat();
    if (!setup && input.value.trim()) openNewChatPicker();
  };
  seed();

  return root;
}
