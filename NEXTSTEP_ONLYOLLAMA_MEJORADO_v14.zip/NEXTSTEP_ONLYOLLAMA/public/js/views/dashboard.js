/* NEXTSTEP — Inicio minimalista: primer paso o recomendación y accesos directos. */
import { api } from '../api.js';
import * as store from '../store.js';
import { el, svgIc, emptyState, modal, toast } from '../ui.js';

export function dashboardView() {
  const root = el('div', { class: 'stack' });
  root.append(skeletonDash());
  load(root);
  return root;
}

function skeletonDash() {
  const s = el('div');
  for (let i = 0; i < 2; i++) s.append(el('div', { class: 'skeleton', style: 'height:110px;margin-bottom:16px;border-radius:20px' }));
  return s;
}

async function load(root) {
  try {
    const d = await api('/dashboard');
    root.innerHTML = '';
    root.append(build(d));
  } catch (e) {
    root.innerHTML = '';
    root.append(emptyState((e && e.message) || 'No se pudo cargar tu inicio.', 'warn'));
  }
}

function build(d) {
  const out = el('div', { class: 'stack home-minimal' });
  const h1 = el('h1');
  String(d.greeting || 'Hola').split(' ').filter(Boolean).forEach((word, index, words) => {
    if (index === words.length - 1) h1.append(el('span', { class: 'glow-word', text: word }));
    else h1.append(document.createTextNode(word + ' '));
  });
  out.append(el('div', { class: 'card neon home-welcome' }, h1,
    el('p', { class: 'lead', text: 'Estudiá paso a paso. Elegí qué querés hacer ahora.' })));

  const subjects = d.subjects || [];
  const recommendation = (d.recommendations || [])[0] || null;
  const start = el('div', { class: 'card home-start' });
  if (!subjects.length) {
    start.append(el('div', { class: 'card-title' }, svgIc('learn', 18), 'Primer paso: agregá tus materias'),
      el('p', { class: 'sub', text: 'Cargalas en “Mi aprendizaje”. Así NEXTSTEP puede organizar tus rutas, prácticas y recomendaciones.' }),
      el('button', { class: 'btn', style: 'margin-top:14px', onclick: () => store.nav('/learning') }, svgIc('arrowR', 18), 'Ir a Mi aprendizaje'));
  } else {
    start.append(el('div', { class: 'card-title' }, svgIc('target', 18), 'Tu próximo paso'),
      el('p', { class: 'home-next-title', text: recommendation?.action || 'Seguí avanzando con tus materias' }),
      el('p', { class: 'sub', text: recommendation?.text || 'Elegí una ruta o consultá a tu profesor para continuar.' }),
      el('button', { class: 'btn', style: 'margin-top:14px', onclick: () => recommendation?.route ? store.nav(`/${recommendation.route}${recommendation.ref ? '/' + recommendation.ref : ''}`) : store.nav('/paths') }, svgIc('arrowR', 18), recommendation?.action || 'Ver mis rutas'));
  }
  out.append(start);
  out.append(el('div', { class: 'home-actions' },
    el('button', { class: 'btn ghost', onclick: () => store.nav('/learning') }, svgIc('learn', 18), 'Mi aprendizaje'),
    el('button', { class: 'btn ghost', onclick: () => store.nav('/paths') }, svgIc('route', 18), 'Mis rutas'),
    el('button', { class: 'btn ghost', onclick: () => store.nav('/teacher') }, svgIc('chat', 18), 'Profesor IA'),
    el('button', { class: 'btn ghost', onclick: openSession }, svgIc('clock', 18), 'Registrar estudio')));
  return out;
}

/* Registrar una sesión de estudio rápida */
function openSession() {
  const wrap = el('div', { class: 'stack' });
  const minutes = el('input', { class: 'input', type: 'number', min: 1, max: 600, step: 1, value: 25, inputmode: 'numeric', placeholder: 'Minutos' });
  const kinds = [['estudio', 'Estudio'], ['repaso', 'Repaso'], ['practica', 'Práctica'], ['proyecto', 'Proyecto'], ['lectura', 'Lectura']];
  const kind = el('select', { class: 'input' },
    kinds.map(([value, label]) => el('option', { value, ...(value === 'estudio' ? { selected: '' } : {}) }, label)));

  const cached = store.cacheKey('subjects');
  let subjects = Array.isArray(cached) ? cached : [];
  const subjSel = el('select', { class: 'input' }, el('option', { value: '' }, 'Sin materia específica'));
  for (const su of subjects) subjSel.append(el('option', { value: su.id }, su.name));

  api('/subjects').then(r => {
    store.setCache('subjects', r.subjects);
    for (const su of r.subjects) {
      if (![...subjSel.options].some(o => o.value === String(su.id))) {
        subjSel.append(el('option', { value: su.id }, su.name));
      }
    }
  }).catch(() => {});

  wrap.append(
    el('div', { class: 'field' }, el('label', { text: '¿Cuánto estudiaste?' }), minutes),
    el('div', { class: 'field' }, el('label', { text: 'Tipo' }), kind),
    el('div', { class: 'field' }, el('label', { text: 'Materia (opcional)' }), subjSel),
  );

  let close = () => {};
  const save = el('button', { class: 'btn', onclick: async () => {
    const value = Number(minutes.value);
    if (!Number.isInteger(value) || value < 1 || value > 600) {
      toast('Ingresá una cantidad de minutos entre 1 y 600.', 'err');
      minutes.focus();
      return;
    }
    save.disabled = true;
    try {
      const r = await api('/sessions', {
        method: 'POST',
        body: { minutes: value, kind: kind.value, subject_id: subjSel.value ? Number(subjSel.value) : null },
      });
      close();
      toast(r.gained > 0 ? `¡${value} min registrados! +${r.gained} XP` : `${value} min registrados`, 'ok');
      await store.loadMe();
      // Refresca las tarjetas de Inicio (minutos de hoy/semana y constancia)
      // con los datos recién guardados por el servidor.
      store.nav('/dashboard');
    } catch (e) {
      toast((e && e.message) || 'No se pudo registrar.', 'err');
      save.disabled = false;
    }
  } }, 'Guardar');
  close = modal({
    title: 'Registrar tiempo de estudio',
    body: wrap,
    footer: [
      el('button', { class: 'btn ghost', onclick: () => close() }, 'Cancelar'),
      save,
    ],
  });
}
