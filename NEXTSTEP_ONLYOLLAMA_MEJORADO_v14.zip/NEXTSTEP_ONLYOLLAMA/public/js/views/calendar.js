/* NEXTSTEP — calendario personal de evaluaciones y fechas importantes. */
import { api } from '../api.js';
import { el, svgIc, emptyState, modal, toast, cap } from '../ui.js';

const EVENT_TYPES = {
  evaluacion: 'Evaluación', entrega: 'Entrega', recordatorio: 'Recordatorio', fecha: 'Fecha importante',
};
const pad = n => String(n).padStart(2, '0');
const dateKey = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const dateLabel = value => new Date(`${value}T12:00:00`).toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

export function calendarView() {
  const root = el('div', { class: 'stack' });
  root.append(el('div', { class: 'skeleton', style: 'height:360px;border-radius:20px' }));
  load(root);
  return root;
}

async function load(root) {
  try {
    const [eventData, subjectData] = await Promise.all([api('/calendar-events'), api('/subjects')]);
    const events = eventData.events || [];
    let month = new Date(); month.setDate(1);
    let selected = dateKey(new Date());
    const render = () => {
      root.innerHTML = '';
      root.append(build(events, subjectData.subjects || [], month, selected, (nextMonth, nextSelected) => {
        month = nextMonth; selected = nextSelected; render();
      }, refresh));
    };
    const refresh = async () => {
      try {
        const fresh = await api('/calendar-events');
        events.splice(0, events.length, ...(fresh.events || []));
        render();
      } catch (e) { toast(e.message || 'No se pudo actualizar el calendario.', 'err'); }
    };
    render();
  } catch (e) {
    root.innerHTML = '';
    root.append(emptyState(e.message || 'No se pudo cargar el calendario.', 'warn'));
  }
}

function build(events, subjects, month, selected, change, refresh) {
  const wrap = el('div', { class: 'stack calendar-page' });
  const head = el('div', { class: 'view-head flex wrap calendar-head' });
  head.append(el('div', { class: 'grow' }, el('h1', { text: 'Calendario' }),
    el('p', { text: 'Organizá evaluaciones, entregas y fechas importantes en un solo lugar.' })));
  head.append(el('button', { class: 'btn', onclick: () => editEvent(null, selected, subjects, refresh) }, svgIc('plus', 18), 'Agregar fecha'));
  wrap.append(head);

  const card = el('div', { class: 'card calendar-card' });
  const toolbar = el('div', { class: 'calendar-toolbar' });
  const title = month.toLocaleDateString('es-AR', { month: 'long', year: 'numeric' });
  toolbar.append(el('div', { class: 'calendar-month', text: cap(title) }),
    el('div', { class: 'flex wrap' },
      el('button', { class: 'btn ghost sm', title: 'Mes anterior', 'aria-label': 'Mes anterior', onclick: () => change(new Date(month.getFullYear(), month.getMonth() - 1, 1), selected) }, '‹'),
      el('button', { class: 'btn ghost sm', onclick: () => change(new Date(new Date().getFullYear(), new Date().getMonth(), 1), dateKey(new Date())) }, 'Hoy'),
      el('button', { class: 'btn ghost sm', title: 'Mes siguiente', 'aria-label': 'Mes siguiente', onclick: () => change(new Date(month.getFullYear(), month.getMonth() + 1, 1), selected) }, '›')));
  card.append(toolbar);
  const grid = el('div', { class: 'calendar-grid' });
  for (const day of ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom']) grid.append(el('div', { class: 'calendar-weekday', text: day }));
  const first = new Date(month.getFullYear(), month.getMonth(), 1);
  const offset = (first.getDay() + 6) % 7;
  const start = new Date(first.getFullYear(), first.getMonth(), 1 - offset);
  const byDate = new Map();
  events.forEach(event => { if (!byDate.has(event.event_date)) byDate.set(event.event_date, []); byDate.get(event.event_date).push(event); });
  for (let i = 0; i < 42; i++) {
    const day = new Date(start.getFullYear(), start.getMonth(), start.getDate() + i);
    const key = dateKey(day);
    const dayEvents = byDate.get(key) || [];
    const cell = el('button', { class: `calendar-day${day.getMonth() !== month.getMonth() ? ' outside' : ''}${key === selected ? ' selected' : ''}${key === dateKey(new Date()) ? ' today' : ''}`, 'aria-label': `${dateLabel(key)}${dayEvents.length ? `, ${dayEvents.length} evento(s)` : ''}`, onclick: () => change(new Date(month), key) });
    cell.append(el('span', { class: 'calendar-day-number', text: String(day.getDate()) }));
    if (dayEvents.length) {
      const tags = el('span', { class: 'calendar-day-events' });
      dayEvents.slice(0, 2).forEach(event => tags.append(el('span', { class: `calendar-event-chip ${event.kind}`, text: event.title, title: `${EVENT_TYPES[event.kind] || 'Fecha'}: ${event.title}` })));
      if (dayEvents.length > 2) tags.append(el('span', { class: 'calendar-more', text: `+${dayEvents.length - 2} más` }));
      cell.append(tags);
    }
    grid.append(cell);
  }
  card.append(grid);
  wrap.append(card);

  const selectedEvents = byDate.get(selected) || [];
  const list = el('div', { class: 'card calendar-agenda' });
  list.append(el('div', { class: 'calendar-agenda-head' },
    el('div', { class: 'card-title' }, svgIc('calendar', 18), cap(dateLabel(selected))),
    el('button', { class: 'btn ghost sm', onclick: () => editEvent(null, selected, subjects, refresh) }, svgIc('plus', 16), 'Agregar')));
  if (!selectedEvents.length) list.append(el('p', { class: 'muted small', text: 'No hay fechas para este día. Elegí otro día o agregá un evento.' }));
  selectedEvents.forEach(event => {
    const row = el('div', { class: 'calendar-event-row' });
    row.append(el('span', { class: `calendar-event-mark ${event.kind}` }),
      el('div', { class: 'grow' }, el('div', { class: 'calendar-event-title', text: event.title }),
        el('div', { class: 'muted small' }, `${EVENT_TYPES[event.kind] || 'Fecha importante'}${event.subject_name ? ` · ${event.subject_name}` : ''}${event.notes ? ` · ${event.notes}` : ''}`)),
      el('button', { class: 'icon-btn', title: 'Editar fecha', 'aria-label': 'Editar fecha', onclick: () => editEvent(event, selected, subjects, refresh), html: svgIc('pencil', 16) }),
      el('button', { class: 'icon-btn danger', title: 'Eliminar fecha', 'aria-label': 'Eliminar fecha', onclick: async () => {
        if (!confirm(`¿Eliminar “${event.title}”?`)) return;
        try { await api(`/calendar-events/${event.id}`, { method: 'DELETE' }); toast('Fecha eliminada', 'ok'); await refresh(); }
        catch (e) { toast(e.message || 'No se pudo eliminar.', 'err'); }
      }, html: svgIc('trash', 16) }));
    list.append(row);
  });
  wrap.append(list);
  return wrap;
}

function editEvent(event, defaultDate, subjects, refresh) {
  const wrap = el('div', { class: 'stack' });
  const title = el('input', { class: 'input', maxlength: 120, placeholder: 'Ej.: Evaluación de matemática', value: event?.title || '' });
  const date = el('input', { class: 'input', type: 'date', value: event?.event_date || defaultDate });
  const kind = el('select', { class: 'input' });
  Object.entries(EVENT_TYPES).forEach(([value, label]) => kind.append(el('option', { value, selected: (event?.kind || 'evaluacion') === value }, label)));
  const subject = el('select', { class: 'input' }, el('option', { value: '' }, 'Sin materia'));
  subjects.forEach(s => subject.append(el('option', { value: s.id, selected: Number(event?.subject_id) === Number(s.id) }, s.name)));
  const notes = el('textarea', { class: 'input', rows: 3, maxlength: 500, placeholder: 'Detalles o temas para recordar…' }, event?.notes || '');
  wrap.append(
    field('Título', title), field('Fecha', date), field('Tipo', kind), field('Materia (opcional)', subject), field('Notas (opcional)', notes),
  );
  let close = () => {};
  close = modal({ title: event ? 'Editar fecha' : 'Agregar al calendario', body: wrap, footer: [
    el('button', { class: 'btn ghost', onclick: () => close() }, 'Cancelar'),
    el('button', { class: 'btn', onclick: async e => {
      if (!title.value.trim()) return toast('Escribí un título.', 'err');
      if (!date.value) return toast('Elegí una fecha.', 'err');
      const button = e.currentTarget; button.disabled = true;
      try {
        const payload = { title: title.value.trim(), event_date: date.value, kind: kind.value, subject_id: subject.value ? Number(subject.value) : null, notes: notes.value.trim() };
        await api(event ? `/calendar-events/${event.id}` : '/calendar-events', { method: event ? 'PUT' : 'POST', body: payload });
        close(); toast(event ? 'Fecha actualizada' : 'Fecha agregada', 'ok'); await refresh();
      } catch (err) { toast(err.message || 'No se pudo guardar.', 'err'); }
      finally { button.disabled = false; }
    } }, event ? 'Guardar cambios' : 'Agregar fecha'),
  ] });
}

function field(label, control) { return el('div', { class: 'field' }, el('label', { text: label }), control); }
