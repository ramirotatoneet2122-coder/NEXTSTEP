/* NEXTSTEP — vista de acceso: ingreso y registro. */
import * as store from '../store.js';
import { el, svgIc } from '../ui.js';


export function authView({ tab = 'login', fieldError = '' } = {}) {
  let mode = tab;
  const emailNotice = new URLSearchParams(location.search).get('email');

  const card = el('div', { class: 'auth-card', role: 'main' });
  card.append(el('div', { class: 'brand' },
    el('svg', { viewBox: '0 0 32 32', fill: 'none', 'aria-hidden': 'true', style: 'width:34px;height:34px' },
      el('circle', { cx: 16, cy: 16, r: 14, stroke: 'var(--accent)', 'stroke-width': 2.5, fill: 'none' }),
      el('path', { d: 'M16 6l5 12-5-2-5 2 5-12z', fill: 'var(--accent)' }),
    ),
    el('span', { text: 'NEXTSTEP' }),
  ));
  card.append(el('p', { class: 'tagline', text: 'Tu profesor particular con IA. Aprendé a tu ritmo, con seguimiento real.' }));

  const tabs = el('div', { class: 'auth-tabs' });
  const mkTab = (id, label) => el('button', {
    class: mode === id ? 'on' : '',
    text: label,
    onclick: () => { mode = id; renderTabs(); formArea.innerHTML = ''; formArea.append(renderForm(mode)); },
  });
  const tabLogin = mkTab('login', 'Ingresar');
  const tabRegister = mkTab('register', 'Crear cuenta');
  tabs.append(tabLogin, tabRegister);
  card.append(tabs);

  function renderTabs() { tabLogin.classList.toggle('on', mode === 'login'); tabRegister.classList.toggle('on', mode === 'register'); }

  const formArea = el('div');
  card.append(formArea);

  const errorBox = el('div', { class: 'field', role: 'alert' });
  function setStatus(msg, type = 'error') {
    errorBox.innerHTML = '';
    if (!msg) { errorBox.hidden = true; return; }
    errorBox.hidden = false;
    const color = type === 'success' ? 'var(--good)' : 'var(--danger)';
    errorBox.append(el('p', { class: 'muted small', style: `color:${color};font-weight:600` }, msg));
  }
  function setError(msg) { setStatus(msg, 'error'); }

  function renderForm(m) {
    setError(fieldError || '');
    const form = el('form', { novalidate: true, onsubmit: async e => {
      e.preventDefault();
      const btn = form.querySelector('button[type=submit]');
      btn.disabled = true;
      btn.textContent = 'Un momento…';
      try {
        try { localStorage.removeItem('ns_onboarded'); } catch { /* noop */ }
        if (m === 'login') {
          await store.login(username.value.trim(), password.value);
          // Recarga la SPA con la sesión guardada y abre la ruta protegida.
          location.hash = '#/dashboard';
          location.reload();
        } else {
          const createdUsername = username.value.trim();
          const result = await store.register(createdUsername, password.value, displayName.value.trim(), email.value.trim());
          mode = 'login';
          renderTabs();
          formArea.innerHTML = '';
          const loginForm = renderForm('login');
          formArea.append(loginForm);
          loginForm.querySelector('input[autocomplete="username"]').value = createdUsername;
          setStatus(`Te enviamos un enlace a ${result.email}. Abrilo para confirmar el correo y activar la cuenta.`, 'success');
        }
      } catch (err) {
        setError((err && err.message) || 'No se pudo conectar. Probá de nuevo.');
      } finally {
        btn.disabled = false;
        btn.textContent = m === 'login' ? 'Entrar' : 'Crear cuenta';
      }
    } });

    const username = el('input', { class: 'input', autocomplete: 'username', placeholder: 'Nombre de usuario', required: true });
    const email = m === 'register' ? el('input', { class: 'input', type: 'email', autocomplete: 'email', maxlength: 254, placeholder: 'tu@email.com', required: true }) : null;
    const password = el('input', { class: 'input', type: 'password', autocomplete: m === 'login' ? 'current-password' : 'new-password', placeholder: 'Contraseña (mínimo 6 caracteres)', required: true });
    const passwordVisibility = el('button', {
      class: 'password-visibility', type: 'button', 'aria-label': 'Mostrar contraseña', 'aria-pressed': 'false',
      html: svgIc('eye', 18),
      onclick: e => {
        const show = password.type === 'password';
        password.type = show ? 'text' : 'password';
        e.currentTarget.setAttribute('aria-label', show ? 'Ocultar contraseña' : 'Mostrar contraseña');
        e.currentTarget.setAttribute('aria-pressed', String(show));
        e.currentTarget.innerHTML = svgIc(show ? 'eyeOff' : 'eye', 18);
      },
    });
    const passwordField = el('div', { class: 'password-input-wrap' }, password, passwordVisibility);
    const displayName = el('input', { class: 'input', autocomplete: 'name', placeholder: 'Cómo querés que te diga (opcional)' });
    let strength = null;
    if (m === 'register') {
      const meter = el('div', { class: 'password-meter', role: 'progressbar', 'aria-label': 'Seguridad de la contraseña', 'aria-valuemin': '0', 'aria-valuemax': '5', 'aria-valuenow': '0' },
        el('span', { class: 'password-meter-fill' }));
      const label = el('span', { class: 'password-strength-label', text: 'Escribí una contraseña' });
      const hint = el('span', { class: 'muted small', text: 'Mejorá la seguridad con 12 o más caracteres y una combinación de letras, números y símbolos.' });
      strength = el('div', { class: 'password-strength', 'data-strength': 'empty' }, meter, el('div', { class: 'password-strength-copy' }, label, hint));
      password.addEventListener('input', () => {
        const value = password.value;
        const checks = [value.length >= 8, value.length >= 12, /[a-z]/.test(value) && /[A-Z]/.test(value), /\d/.test(value), /[^A-Za-z0-9]/.test(value)];
        let score = checks.filter(Boolean).length;
        if (/^(?:123456|password|contrase(?:ña|na)|qwerty|abcdef)/i.test(value)) score = Math.min(score, 1);
        const level = !value ? 'empty' : score <= 1 ? 'weak' : score <= 3 ? 'fair' : score === 4 ? 'good' : 'strong';
        const names = { empty: 'Escribí una contraseña', weak: 'Muy débil', fair: 'Aceptable', good: 'Fuerte', strong: 'Muy fuerte' };
        strength.dataset.strength = level;
        meter.setAttribute('aria-valuenow', String(score));
        meter.setAttribute('aria-valuetext', names[level]);
        label.textContent = names[level];
        meter.querySelector('.password-meter-fill').style.width = value ? `${Math.max(10, score * 20)}%` : '0%';
      });
    }

    form.append(
      el('div', { class: 'field' }, el('label', { text: 'Usuario' }), username),
      el('div', { class: 'field' }, el('label', { text: 'Contraseña' }), passwordField),
    );
    // No pasar null directo a .append: el append nativo del navegador lo convierte en texto "null".
    if (m === 'register') {
      form.append(
        el('div', { class: 'field' }, el('label', { text: 'Correo electrónico' }), email,
          el('span', { class: 'hint', text: 'Te enviaremos un enlace para activar la cuenta.' })),
        el('div', { class: 'field' }, el('label', { text: 'Nombre visible' }), displayName,
          el('span', { class: 'hint', text: 'Lo usamos para saludarte. Lo podés cambiar después.' })),
        el('div', { class: 'field' }, strength),
      );
    }
    form.append(
      errorBox,
      el('button', { class: 'btn block', type: 'submit' }, m === 'login' ? 'Entrar' : 'Crear cuenta'),
      el('p', { class: 'muted small center', style: 'margin-top:14px;line-height:1.6' }, m === 'login'
        ? '¿No tenés cuenta? Tocá «Crear cuenta» arriba. Tus datos quedan guardados en el servidor del grupo, nunca en el navegador.'
        : 'Al registrarte creás tu propio seguimiento: materias, rutas, evaluaciones y progreso. Cada alumno ve solo lo suyo.'),
    );
    return form;
  }

  formArea.append(renderForm(mode));
  if (emailNotice) {
    const messages = {
      verified: ['Correo confirmado. Ya podés iniciar sesión.', 'success'],
      invalid: ['El enlace no es válido o ya venció. Volvé a crear la cuenta para recibir otro.', 'error'],
      conflict: ['No se pudo activar porque ese usuario o correo ya está registrado.', 'error'],
      error: ['No se pudo completar el registro. Volvé a crear la cuenta para intentarlo otra vez.', 'error'],
    };
    const [message, type] = messages[emailNotice] || messages.invalid;
    setStatus(message, type);
    history.replaceState(null, '', `${location.pathname}${location.hash}`);
  }
  return card;
}
