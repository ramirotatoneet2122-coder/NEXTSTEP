/* NEXTSTEP — Objetivos: metas con fecha, descomposición en tareas y seguimiento. */
import { api } from '../api.js';
import * as store from '../store.js';
import { el, svgIc, bar, emptyState, modal, toast, fmtDate, fmtRel } from '../ui.js';

export function goalsView() {
  const root = el('div', { class: 'stack' });
  root.append(el('div', { class: 'skeleton', style: 'height:110px;border-radius:14px' }));
  load(root);
  return root;
}

async function load(root) {
  try {
    const r = await api('/goals');
    root.innerHTML = '';
    const head = el('div', { class: 'view-head flex wrap' });
    head.append(el('div', { class: 'grow' }, el('h1', { text: 'Objetivos' }),
      el('p', { text: 'Metas claras y chicas: se cumplen con tareas concretas, no con buenas intenciones. El profesor puede descomponerlas con IA.' })));
    head.append(el('button', { class: 'btn', onclick: openCreate }, svgIc('plus', 18), 'Nuevo objetivo'));
    root.append(head);

    const active = r.goals.filter(g => g.status === 'activo');
    if (!active.length) {
      root.append(emptyState('Sin objetivos activos. Definir una meta (con fecha si puede ser) y descomponerla en tareas es de lo mejor que podés hacer para avanzar.', 'target', el('button', { class: 'btn', onclick: openCreate }, 'Crear objetivo')));
    } else {
      for (const g of active) root.append(goalCard(g));
    }

    const closed = r.goals.filter(g => g.status !== 'activo');
    if (closed.length) {
      const sec = el('div', { class: 'card' });
      sec.append(el('div', { class: 'card-title', style: 'margin-bottom:8px' }, 'Historial'));
      for (const g of closed) {
        sec.append(el('div', { class: 'li' },
          el('span', { class: 'ic', html: svgIc(g.status === 'hecho' ? 'check' : 'x', 19) }),
          el('div', { class: 'grow' }, el('p', { style: 'font-weight:600' }, g.title), el('p', { class: 'meta' }, (g.status === 'hecho' ? 'Completado' : 'Abandonado') + ' · ' + fmtDate(g.created_at))),
          el('span', { class: `tag ${g.status === 'hecho' ? 'dominado' : 'pendiente'}` }, g.status === 'hecho' ? 'Hecho' : 'Abandonado')));
      }
      root.append(sec);
    }
  } catch (e) {
    root.innerHTML = '';
    root.append(emptyState((e && e.message) || 'No se pudieron cargar los objetivos.', 'warn'));
  }
}

function goalCard(g) {
  const card = el('div', { class: 'card' });
  const head = el('div', { class: 'flex wrap' });
  const h = el('div', { class: 'grow' });
  h.append(el('h3', { text: g.title }));
  h.append(el('p', { class: 'sub' }, g.deadline ? `vence ${fmtDate(g.deadline)}` : 'sin fecha límite'));
  head.append(h);
  head.append(el('span', { class: 'pct' }, `${g.progress}%`));
  card.append(head);
  card.append(el('div', { style: 'margin:10px 0' }, bar(g.progress)));

  const list = el('div');
  if (!g.tasks || !g.tasks.length) {
    list.append(el('p', { class: 'muted small' }, 'Todavía sin tareas. Descomponelo con IA o agregalas a mano.'));
  }
  for (const t of (g.tasks || [])) {
    list.append(el('div', { class: 'flex', style: 'padding:6px 0;border-top:1px dashed var(--line)' },
      el('input', {
        type: 'checkbox', checked: !!t.done, style: 'width:20px;height:20px;accent-color:var(--good)',
        onclick: async (e) => {
          e.target.disabled = true;
          try {
            const r = await api(`/tasks/${t.id}`, { method: 'PUT', body: { done: e.target.checked } });
            if (r.gained) toast(`+${r.gained} XP`, 'ok');
            else if (r.lost) toast(`−${r.lost} XP por deshacer la tarea`, 'info');
            if (r.gained || r.lost) await store.loadMe();
            load(goalsRoot());
          } catch (err) { toast((err && err.message) || 'No se pudo actualizar la tarea.', 'err'); e.target.disabled = false; }
        },
      }),
      el('p', { class: 'grow', style: t.done ? 'text-decoration:line-through;color:var(--muted)' : 'font-weight:500' }, t.title),
      el('button', { class: 'icon-btn danger hidden', style: 'width:30px;height:30px' }, ''),
    ));
  }
  card.append(list);

  const addRow = el('div', { class: 'row-input', style: 'margin-top:10px' });
  const input = el('input', { class: 'input', placeholder: 'Agregar tarea…' });
  addRow.append(input, el('button', { class: 'btn sm', onclick: async () => {
    if (!input.value.trim()) return;
    try { await api(`/goals/${g.id}/tasks`, { method: 'POST', body: { title: input.value.trim() } }); load(goalsRoot()); } catch (e) { toast((e && e.message) || 'No se pudo agregar.', 'err'); }
  } }, svgIc('plus', 16)));
  card.append(addRow);

  const foot = el('div', { class: 'flex wrap', style: 'margin-top:12px' });
  foot.append(el('button', { class: 'btn sm ghost', onclick: async () => {
    if (!confirm(`¿Marcar "${g.title}" como alcanzado?`)) return;
    try { await api(`/goals/${g.id}`, { method: 'PUT', body: { status: 'hecho' } }); toast('¡Objetivo cumplido! +120 XP', 'ok'); await store.loadMe(); load(goalsRoot()); } catch (e) { toast((e && e.message) || 'Error.', 'err'); }
  } }, svgIc('check', 16), 'Marcar hecho'));
  foot.append(el('button', { class: 'btn sm ghost', onclick: async () => {
    if (!confirm('¿Abandonar este objetivo?')) return;
    try { await api(`/goals/${g.id}`, { method: 'PUT', body: { status: 'abandonado' } }); load(goalsRoot()); } catch (e) { toast((e && e.message) || 'Error.', 'err'); }
  } }, 'Abandonar'));
  foot.append(el('span', { class: 'grow' }));
  foot.append(el('button', { class: 'btn sm ghost danger', onclick: async () => {
    if (!confirm('¿Eliminar el objetivo?')) return;
    try { await api(`/goals/${g.id}`, { method: 'DELETE' }); load(goalsRoot()); } catch (e) { toast((e && e.message) || 'Error.', 'err'); }
  } }, svgIc('trash', 16), 'Eliminar'));
  card.append(foot);
  return card;
}

function goalsRoot() { return document.querySelector('#view > .stack'); }

function openCreate() {
  const title = el('input', { class: 'input', placeholder: 'Ej: Aprobar el parcial de Matemática' });
  const desc = el('textarea', { class: 'input', placeholder: 'Detalle corto (opcional)' });
  const deadline = el('input', { class: 'input', type: 'date' });
  const subjSel = el('select', { class: 'input' }, el('option', { value: '' }, 'Sin materia'));
  api('/subjects').then(r => { for (const su of r.subjects) subjSel.append(el('option', { value: su.id }, su.name)); }).catch(() => {});
  const useIa = el('label', { class: 'flex', style: 'cursor:pointer;font-weight:600' },
    el('input', { type: 'checkbox', checked: true, style: 'width:18px;height:18px;accent-color:var(--accent)' }),
    'Descomponer en tareas con IA');
  const wrap = el('div', { class: 'stack' },
    el('div', { class: 'field' }, el('label', { text: 'Objetivo' }), title),
    el('div', { class: 'field' }, el('label', { text: 'Descripción' }), desc),
    el('div', { class: 'field' }, el('label', { text: 'Fecha límite (opcional)' }), deadline),
    el('div', { class: 'field' }, el('label', { text: 'Materia (opcional)' }), subjSel),
    useIa);
  let close = () => {};
  close = modal({
    title: 'Nuevo objetivo',
    body: wrap,
    footer: [
      el('button', { class: 'btn ghost', onclick: () => close() }, 'Cancelar'),
      el('button', { class: 'btn', onclick: async (e) => {
        if (!title.value.trim()) return toast('Ingresá el objetivo.', 'err');
        const b = e.target; b.disabled = true; b.textContent = 'Creando…';
        const body = { title: title.value.trim(), description: desc.value.trim(), deadline: deadline.value || null, subject_id: subjSel.value ? Number(subjSel.value) : null };
        try {
          const r = useIa.querySelector('input').checked
            ? await api('/goals/generate', { method: 'POST', body })
            : await api('/goals', { method: 'POST', body: { ...body, tasks: [] } });
          const gid = r.goal && r.goal.id;
          close();
          toast('Objetivo creado: +25 XP', 'ok');
          await store.loadMe();
          load(goalsRoot());
        } catch (err) { toast((err && err.message) || 'No se pudo crear.', 'err'); }
        finally { b.disabled = false; b.textContent = 'Crear'; }
      } }, 'Crear'),
    ],
  });
}