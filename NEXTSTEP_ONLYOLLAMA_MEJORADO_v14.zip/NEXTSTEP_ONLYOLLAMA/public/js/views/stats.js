/* NEXTSTEP — Estadísticas: progreso real agregado, evolución, fortalezas y logros. */
import { api } from '../api.js';
import { el, svgIc, bar, emptyState, minutesText } from '../ui.js';

export function statsView() {
  const root = el('div', { class: 'stack' });
  root.append(el('div', { class: 'skeleton', style: 'height:180px;border-radius:14px' }));
  load(root);
  return root;
}

async function load(root) {
  try {
    const [s, ach] = await Promise.all([
      api('/stats'),
      api('/auth/achievements').catch(() => null),
    ]);
    root.innerHTML = '';
    root.append(build(s, ach && ach.catalog ? ach.catalog : null));
  } catch (e) {
    root.innerHTML = '';
    root.append(emptyState((e && e.message) || 'No se pudieron cargar las estadísticas.', 'warn'));
  }
}

function build(s, catalog) {
  const out = el('div', { class: 'stack' });
  const head = el('div', { class: 'view-head' });
  head.append(el('h1', { text: 'Estadísticas' }));
  head.append(el('p', { text: 'Tu progreso se calcula con datos reales: temas dominados, evaluaciones y actividad. No con lo que decís haber estudiado.' }));
  out.append(head);

  const row = el('div', { class: 'stat-row stats-overview-row' });
  const levelXp = stat('star', `Nv ${s.level.level}`, `${s.level.xp} XP acumulados`);
  levelXp.classList.add('stats-level-xp');
  row.append(levelXp);
  row.append(stat('flame', String(s.stats.streak), 'días de racha'));
  row.append(stat('clock', String(s.stats.minutes), 'min. totales'));
  row.append(stat('check', String(s.stats.activities), 'actividades hechas'));
  row.append(stat('quiz', String(s.stats.assessments), 'evaluaciones'));
  out.append(row);

  // Evolución de nivel (XP acumulado por día)
  if (s.xpEvolution && s.xpEvolution.length) {
    const card = el('div', { class: 'card' });
    card.append(el('div', { class: 'card-title' }, svgIc('chart', 18), 'Evolución de tu nivel'));
    card.append(evolutionBars(s.xpEvolution));
    out.append(card);
  }

  // Constancia semanal
  const week = el('div', { class: 'card' });
  week.append(el('div', { class: 'card-title' }, svgIc('calendar', 18), 'Constancia de la semana'));
  week.append(el('div', { style: 'margin-top:12px' }, weekBars(s.weekSeries)));
  out.append(week);

  // Materias con puntaje
  if (s.subjects && s.subjects.length) {
    const card = el('div', { class: 'card' });
    card.append(el('div', { class: 'card-title', style: 'margin-bottom:10px' }, svgIc('learn', 18), 'Materias'));
    for (const su of s.subjects) {
      card.append(el('div', { style: 'margin-bottom:12px' },
        el('div', { class: 'flex' },
          el('p', { class: 'grow', style: 'font-weight:600' }, su.name),
          el('span', { class: 'tag' }, su.level),
          el('span', { class: 'pct' }, `${su.score}%`)),
        el('div', { style: 'margin-top:6px' }, bar(su.score)),
        el('p', { class: 'meta', text: `${su.dominados}/${su.topics} temas dominados` })));
    }
    out.append(card);
  }

  // Evaluaciones
  if (s.assessments && s.assessments.length) {
    const card = el('div', { class: 'card' });
    card.append(el('div', { class: 'card-title', style: 'margin-bottom:8px' }, svgIc('quiz', 18), 'Evaluaciones'));
    for (const a of s.assessments) {
      const pct = a.total ? Math.round(a.score / a.total * 100) : 0;
      card.append(el('div', { class: 'li' },
        el('span', { class: 'ic', html: svgIc(pct >= 80 ? 'check' : pct >= 50 ? 'info' : 'warn', 19) }),
        el('div', { class: 'grow' }, el('p', { style: 'font-weight:600' }, a.title), el('p', { class: 'meta' }, `${a.subject_name || ''} · ${a.kind}`)),
        el('span', { class: 'pct' }, `${pct}%`)));
    }
    out.append(card);
  }

  // Fortalezas y dificultades
  if ((s.strengths && s.strengths.length) || (s.weaknesses && s.weaknesses.length)) {
    const card = el('div', { class: 'card' });
    card.append(el('div', { class: 'card-title', style: 'margin-bottom:8px' }, svgIc('target', 18), 'Qué te va bien y qué te cuesta'));
    if (s.strengths && s.strengths.length) {
      card.append(el('p', { style: 'font-weight:600;margin:8px 0 4px' }, 'Fortalezas'));
      card.append(el('div', { class: 'flex wrap' }, ...s.strengths.map(t => el('span', { class: 'tag dominado' }, t.name || t))));
    }
    if (s.weaknesses && s.weaknesses.length) {
      card.append(el('p', { style: 'font-weight:600;margin:8px 0 4px' }, 'Para reforzar'));
      card.append(el('div', { class: 'flex wrap' }, ...s.weaknesses.map(t => el('span', { class: 'tag dificultad' }, t.name || t))));
    }
    out.append(card);
  }

  // Sesiones recientes
  if (s.sessions && s.sessions.length) {
    const card = el('div', { class: 'card' });
    card.append(el('div', { class: 'card-title', style: 'margin-bottom:8px' }, svgIc('clock', 18), 'Sesiones recientes'));
    for (const se of s.sessions.slice(0, 8)) {
      card.append(el('div', { class: 'flex', style: 'padding:7px 0;border-top:1px dashed var(--line)' },
        el('span', { class: 'grow' }, se.subject_name || 'estudio'),
        el('span', { class: 'pct' }, minutesText(se.minutes))));
    }
    out.append(card);
  }

  // Logros
  if (catalog) {
    const card = el('div', { class: 'card' });
    card.append(el('div', { class: 'card-title', style: 'margin-bottom:8px' }, svgIc('sparkles', 18), `Logros (${catalog.filter(c => c.earned).length}/${catalog.length})`));
    const grid = el('div', { class: 'grid-2' });
    for (const a of catalog) {
      grid.append(el('div', { style: 'display:flex;gap:10px;align-items:flex-start;padding:9px 11px;border-radius:10px;background:var(--surface2);opacity:' + (a.earned ? 1 : .55) },
        el('span', { style: 'font-size:1.1rem' }, a.earned ? '🏆' : '🔒'),
        el('div', el('p', { style: 'font-weight:700;font-size:.9rem' }, a.title), el('p', { class: 'meta', text: a.desc }))));
    }
    card.append(grid);
    out.append(card);
  }

  return out;
}

function stat(icon, num, label) {
  return el('div', { class: 'stat' },
    el('div', { class: 'ic', html: svgIc(icon, 18) }),
    el('div', { class: 'num', text: String(num) }),
    el('div', { class: 'lbl', text: label }));
}

function weekBars(series) {
  const w = el('div', { class: 'minibar' });
  if (Array.isArray(series)) {
    const max = Math.max(1, ...series.map(x => x.minutes));
    for (const day of series) {
      const h = Math.round((day.minutes / max) * 100);
      w.append(el('div', { class: 'd' },
        el('div', { class: 'col', title: `${day.label}: ${day.minutes} min` }, el('i', { style: `height:${Math.max(4, h)}%` })),
        el('div', { class: 'lbl', text: day.label })));
    }
  }
  return w;
}

function evolutionBars(xpByDay) {
  const max = Math.max(1, ...xpByDay.map(x => x.xp));
  const w = el('div', { class: 'minibar', style: 'margin-top:12px' });
  for (const x of xpByDay) {
    const h = Math.round((x.xp / max) * 100);
    w.append(el('div', { class: 'd' },
      el('div', { class: 'col', title: `${x.day} → ${x.xp} XP (nivel ${x.level})` }, el('i', { style: `height:${Math.max(4, h)}%` })),
      el('div', { class: 'lbl', text: String(x.level) })));
  }
  return w;
}