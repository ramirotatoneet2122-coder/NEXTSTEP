/* NEXTSTEP · Riel derecho de escritorio: widget de Foco (Pomodoro) y acceso directo
   al Profesor IA. Vive en el shell, no en las vistas, así acompaña a todas las secciones. */
import { api } from './api.js';
import * as store from './store.js';
import { el, svgIc, toast } from './ui.js';

const FOCUS_PRESETS = [
  { label: '25 / 5', focus: 25 * 60, rest: 5 * 60 },
  { label: '50 / 10', focus: 50 * 60, rest: 10 * 60 },
  { label: '90 / 20', focus: 90 * 60, rest: 20 * 60 },
];

let timer = null;
let timerEndsAt = 0;
let state = { focus: 25 * 60, rest: 5 * 60, phase: 'focus', left: 25 * 60, running: false, preset: 0 };

export function mountRightRail(container) {
  container.innerHTML = '';
  container.append(focusCard(), aiCard(), progressCard());

  store.on(evt => { if (evt === 'me') paintProgress(); });
  paintProgress();
}

/* ---------------- Foco (Pomodoro) ---------------- */
const MIN_SECONDS = 10;          // el tiempo del cronómetro se puede fijar desde 10 s...
const MAX_SECONDS = 180 * 60;    // ...hasta 3 horas.

// "25", "25:30" o "90" (minutos) -> segundos; null si no se entiende.
function parseClock(text) {
  const t = String(text).trim();
  let m = t.match(/^(\d{1,3}):(\d{1,2})$/);
  let sec = null;
  if (m) sec = Number(m[1]) * 60 + Number(m[2]);
  else if ((m = t.match(/^(\d{1,3})$/))) sec = Number(m[1]) * 60;
  if (sec === null || sec < MIN_SECONDS || sec > MAX_SECONDS) return null;
  return sec;
}

function focusCard() {
  const card = el('div', { class: 'rail-card' });
  const head = el('div', { class: 'rail-head' },
    el('span', { class: 'dot' }), el('h3', { text: 'Foco' }),
    el('span', { class: 'sub', style: 'margin-left:auto', id: 'focus-phase' }, 'Estudio'));
  card.append(head);

  const ring = el('div', { class: 'focus-ring' });
  ring.innerHTML = `<svg viewBox="0 0 168 168" aria-hidden="true"><defs><linearGradient id="focusGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="var(--accent)"/><stop offset="100%" stop-color="var(--accent-2)"/></linearGradient></defs><circle class="track" cx="84" cy="84" r="76"/><circle class="prog" cx="84" cy="84" r="76" id="focus-prog"/></svg>`;
  // El reloj inicia o pausa el foco al tocarlo; el tiempo exacto se edita desde “Editar exacto”.
  const clockBtn = el('button', {
    class: 'focus-clock-btn', type: 'button', id: 'focus-clock-btn',
    title: 'Tocá el reloj para iniciar', 'aria-label': 'Iniciar el cronómetro',
    onclick: () => toggle(),
  }, el('span', { id: 'focus-clock' }, '25:00'));
  ring.append(el('div', { class: 'focus-time' }, clockBtn, el('small', { id: 'focus-label' }, 'tocá el reloj')));
  card.append(ring);

  const durationValue = el('b', { id: 'focus-duration-value' }, '25 min');
  const duration = el('input', {
    id: 'focus-duration', class: 'focus-slider', type: 'range', min: 5, max: 180, step: 5, value: 25,
    'aria-label': 'Duración del foco en minutos',
    oninput: () => setTotal(Number(duration.value) * 60, { fromSlider: true }),
  });
  card.append(el('div', { class: 'focus-config' },
    el('div', { class: 'focus-duration-label' }, el('label', { for: 'focus-duration', text: 'Duración de foco' }), durationValue,
      el('button', { class: 'focus-edit-time', type: 'button', text: 'Editar exacto', onclick: () => editClock() })),
    duration));

  const presets = el('div', { class: 'focus-presets' });
  const presetButtons = [];
  FOCUS_PRESETS.forEach((p, i) => {
    const b = el('button', { class: i === 0 ? 'on' : '', text: p.label, onclick: () => {
      stop(); state.preset = i; state.focus = p.focus; state.rest = p.rest;
      state.left = p.focus; state.phase = 'focus';
      syncSlider();
      presetButtons.forEach((x, j) => x.classList.toggle('on', j === i));
      paintFocus();
    } });
    presetButtons.push(b); presets.append(b);
  });
  card.append(presets);

  const startBtn = el('button', { class: 'btn focus-start', type: 'button', onclick: toggle });
  const resetBtn = el('button', { class: 'btn ghost focus-reset', type: 'button', title: 'Reiniciar', 'aria-label': 'Reiniciar', html: svgIc('stop', 18), onclick: () => {
    stop(); state.left = state.phase === 'focus' ? state.focus : state.rest; syncConfig(); paintFocus();
  } });
  const focusActions = el('div', { class: 'focus-actions' }, startBtn, resetBtn);
  ring.after(focusActions);

  /* ----- tiempo editable ----- */
  // Fija el total de la fase actual (foco o descanso) y reinicia lo que queda.
  function setTotal(seconds, { fromSlider = false } = {}) {
    if (state.running) return;
    seconds = Math.max(MIN_SECONDS, Math.min(MAX_SECONDS, Math.round(seconds)));
    if (fromSlider) state.phase = 'focus';   // el deslizador siempre es de la duración de foco
    if (state.phase === 'focus') { state.focus = seconds; if (!fromSlider) state.rest = state.rest || 5 * 60; }
    else state.rest = seconds;
    state.left = seconds;
    state.preset = -1;
    presetButtons.forEach(b => b.classList.remove('on'));
    syncSlider();
    paintFocus();
  }
  function syncSlider() {
    const mins = Math.round(state.focus / 60);
    duration.value = String(Math.max(5, Math.min(180, mins)));
    durationValue.textContent = state.focus % 60 === 0 ? `${state.focus / 60} min` : `${Math.floor(state.focus / 60)}:${String(state.focus % 60).padStart(2, '0')} min`;
  }
  function editClock() {
    // Si está corriendo, se pausa para poder escribir tranquilo.
    if (state.running) { stop(); syncConfig(); paintFocus(); }
    if (card.querySelector('.focus-clock-input')) return;
    const span = clockBtn.querySelector('#focus-clock');
    const input = el('input', {
      class: 'focus-clock-input', type: 'text', inputmode: 'numeric', value: span.textContent,
      'aria-label': 'Nuevo tiempo (minutos o mm:ss)', maxlength: 6,
    });
    span.hidden = true;
    clockBtn.hidden = true;
    clockBtn.after(input);
    input.focus(); input.select();
    let done = false;
    const finish = apply => {
      if (done) return; done = true;
      const val = input.value;
      input.remove(); span.hidden = false; clockBtn.hidden = false;
      if (!apply) return;
      const sec = parseClock(val);
      if (sec === null) { toast('Escribí los minutos (por ejemplo 30) o mm:ss, entre 0:10 y 180:00.', 'err'); return; }
      setTotal(sec);
    };
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      else if (e.key === 'Escape') { e.preventDefault(); finish(false); }
    });
    input.addEventListener('blur', () => finish(true));
  }

  /* ----- control del cronómetro: empezar / pausar / reanudar ----- */
  function syncConfig() {
    duration.disabled = state.running;
    presetButtons.forEach(b => { b.disabled = state.running; });
    clockBtn.title = state.running ? 'Tocá el reloj para pausar' : 'Tocá el reloj para iniciar';
  }
  function toggle() {
    if (state.running) stop(); else run();   // run() y stop() ya repintan
    syncConfig(); paintFocus();
  }
  function run() {
    if (state.left <= 0) state.left = state.phase === 'focus' ? state.focus : state.rest;
    state.running = true;
    clearInterval(timer);
    timerEndsAt = Date.now() + state.left * 1000;   // reanuda justo desde lo que quedaba
    timer = setInterval(() => {
      state.left = Math.max(0, Math.ceil((timerEndsAt - Date.now()) / 1000));
      if (state.left === 0) { finish(); return; }
      paintFocus();
    }, 200);
    syncConfig();
    paintFocus();
  }
  function stop() {
    if (state.running && timerEndsAt) state.left = Math.max(0, Math.ceil((timerEndsAt - Date.now()) / 1000));
    state.running = false;
    clearInterval(timer);
    timer = null;
    timerEndsAt = 0;
    syncConfig();
  }
  async function finish() {
    stop();
    const wasFocus = state.phase === 'focus';
    const minutes = Math.max(1, Math.round((wasFocus ? state.focus : state.rest) / 60));
    state.phase = wasFocus ? 'rest' : 'focus';
    state.left = wasFocus ? state.rest : state.focus;
    paintFocus();
    if (!wasFocus) return;
    try {
      const r = await api('/sessions', { method: 'POST', body: { minutes, kind: 'estudio', subject_id: null } });
      toast(r.gained > 0 ? `¡Sesión de ${minutes} min! +${r.gained} XP` : `Sesión de ${minutes} min registrada`, 'ok');
      store.loadMe();
    } catch { toast(`Sesión de ${minutes} min completada`, 'ok'); }
  }
  function paintFocus() {
    const clock = card.querySelector('#focus-clock');
    const label = card.querySelector('#focus-label');
    const prog = card.querySelector('#focus-prog');
    const phase = card.querySelector('#focus-phase');
    if (!clock) return;
    const m = String(Math.floor(state.left / 60)).padStart(2, '0');
    const s = String(state.left % 60).padStart(2, '0');
    clock.textContent = `${m}:${s}`;
    const total = state.phase === 'focus' ? state.focus : state.rest;
    const C = 2 * Math.PI * 76;
    prog.style.strokeDasharray = C;
    prog.style.strokeDashoffset = C * (1 - state.left / total);
    const paused = !state.running && state.left < total;
    label.textContent = state.running ? (state.phase === 'focus' ? 'en curso' : 'descanso')
      : paused ? 'en pausa' : state.phase === 'focus' ? 'tocá el reloj' : 'descanso';
    phase.textContent = state.phase === 'focus' ? 'Estudio' : 'Descanso';
    startBtn.innerHTML = '';
    startBtn.append(el('span', { html: svgIc(state.running ? 'pause' : 'play', 18) }),
      document.createTextNode(state.running ? ' Pausar' : (paused ? ' Reanudar' : ' Iniciar temporizador')));
    startBtn.setAttribute('aria-label', state.running ? 'Pausar el cronómetro' : (paused ? 'Reanudar el cronómetro' : 'Iniciar el cronómetro'));
    startBtn.title = state.running ? 'Pausar el cronómetro' : (paused ? 'Reanudar el cronómetro' : 'Iniciar el cronómetro');
    clockBtn.setAttribute('aria-label', state.running ? 'Pausar el cronómetro' : (paused ? 'Reanudar el cronómetro' : 'Iniciar el cronómetro'));
  }
  syncSlider(); syncConfig(); paintFocus();
  return card;
}
/* ---------------- Profesor IA ---------------- */
function aiCard() {
  const card = el('div', { class: 'rail-card' });
  const meta = store.getMeta();

  const head = el('div', { class: 'rail-head' },
    el('span', { class: 'ai-orb', html: svgIc('sparkles', 22) }),
    el('div', {},
      el('h3', { text: 'Profesor IA' }),
      el('div', { class: 'sub', id: 'ai-status' }, 'Consultá lo que necesites')),
    el('span', { class: 'dot', id: 'ai-dot' }));
  card.append(head);

  card.append(el('button', { class: 'btn block', onclick: () => store.nav('/teacher') },
    el('span', { html: svgIc('chat', 18) }), document.createTextNode('Abrir el chat')));

  const status = card.querySelector('#ai-status');
  const dot = card.querySelector('#ai-dot');
  if (meta && meta.requiresSetup) {
    status.textContent = 'IA sin configurar en el servidor';
    dot.classList.add('off');
  } else {
    status.textContent = 'Conectado · responde en vivo';
  }
  return card;
}

/* ---------------- Progreso ---------------- */
function progressCard() {
  const card = el('div', { class: 'rail-card' });
  card.append(el('div', { class: 'rail-head' },
    el('span', { class: 'dot' }),
    el('h3', { text: 'Tu progreso' })));

  const ring = el('div', { class: 'focus-ring progress-level-ring' });
  ring.innerHTML = `
    <svg viewBox="0 0 168 168" aria-hidden="true">
      <defs>
        <linearGradient id="lvlGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="var(--accent)"/>
          <stop offset="100%" stop-color="var(--accent-2)"/>
        </linearGradient>
      </defs>
      <circle class="track" cx="84" cy="84" r="76"/>
      <circle class="prog" cx="84" cy="84" r="76" id="lvl-prog" style="stroke:url(#lvlGrad)"/>
    </svg>`;
  const time = el('div', { class: 'focus-time level-ring-time' });
  time.append(el('span', { id: 'lvl-num' }, '1'), el('small', {}, 'nivel'));
  ring.append(time);
  card.append(ring, el('div', { class: 'progress-xp-total', id: 'lvl-sub' }, '0 XP acumulados'));

  const stats = el('div', { class: 'rail-stats' });
  stats.append(
    el('div', { class: 'rail-stat' }, el('b', { id: 'rail-streak' }, '0'), el('span', { text: 'días de racha' })),
    el('div', { class: 'rail-stat' }, el('b', { id: 'rail-min' }, '0'), el('span', { text: 'min. hoy' })),
  );
  card.append(stats);
  return card;
}

function paintProgress() {
  const lvl = store.get().level || {};
  const stats = store.get().stats || {};
  const num = document.getElementById('lvl-num');
  if (num) num.textContent = String(lvl.level || 1);
  const sub = document.getElementById('lvl-sub');
  if (sub) sub.textContent = `${Number(lvl.xp || 0).toLocaleString('es-AR')} XP acumulados`;
  const prog = document.getElementById('lvl-prog');
  if (prog) {
    const C = 2 * Math.PI * 76;
    prog.style.strokeDasharray = C;
    prog.style.strokeDashoffset = C * (1 - (Number(lvl.progress) || 0) / 100);
  }
  const streak = document.getElementById('rail-streak');
  if (streak) streak.textContent = String(stats.streak || 0);
}
