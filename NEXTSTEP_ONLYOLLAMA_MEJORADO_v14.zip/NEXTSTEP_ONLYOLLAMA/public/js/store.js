/* NEXTSTEP — estado global: sesión, preferencias, caché de datos y navegación. */
import { api, setToken } from './api.js';
import { applyTheme, THEME_DEFAULTS } from './theme.js';

export const SECTIONS = [
  { id: 'dashboard', name: 'Inicio', icon: 'home' },
  { id: 'teacher', name: 'Mi profesor IA', icon: 'chat' },
  { id: 'learning', name: 'Mi aprendizaje', icon: 'learn' },
  { id: 'paths', name: 'Rutas de aprendizaje', icon: 'route' },
  { id: 'assessments', name: 'Evaluaciones', icon: 'quiz' },
  { id: 'calendar', name: 'Calendario', icon: 'calendar' },
  { id: 'goals', name: 'Objetivos', icon: 'target' },
  { id: 'resources', name: 'Recursos', icon: 'book' },
  { id: 'stats', name: 'Estadísticas', icon: 'chart' },
  { id: 'settings', name: 'Configuración', icon: 'gear' },
];

function readLocal(key) {
  try { return localStorage.getItem(key); } catch { return null; }
}
function readPrefs() {
  try {
    const value = JSON.parse(readLocal('ns_prefs') || 'null');
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch { return null; }
}

const state = {
  token: readLocal('ns_token') || null,
  user: null,
  meta: { greeting: '', startQuick: [], allowedUrls: [], modes: [], requiresSetup: false, setupMessage: '' },
  prefs: readPrefs() || { theme: THEME_DEFAULTS, learning: {}, teacher: {}, ui: {} },
  defaults: { learning: {}, teacher: {} },
  level: { level: 1, xp: 0, floor: 0, ceil: 100, progress: 0 },
  stats: null,
  cache: {},
};
const listeners = new Set();
export const emit = (evt, data) => listeners.forEach(f => { try { f(evt, data); } catch { /* noop */ } });
export const on = f => { listeners.add(f); return () => listeners.delete(f); };

export const get = () => state;
export const getMeta = () => state.meta;
export function setMeta(m) { state.meta = m || state.meta; }
export function cacheKey(k) { return state.cache[k] || null; }
export function setCache(k, v) { state.cache[k] = v; }
export function bustCache(pattern) {
  for (const k of Object.keys(state.cache)) if (!pattern || k.startsWith(pattern)) delete state.cache[k];
}

/* ---- Sesión ---- */
export async function login(username, password) {
  const r = await api('/auth/login', { method: 'POST', body: { username, password } });
  // La autenticación ya se completó. No bloquees la navegación por la carga
  // secundaria del perfil: /auth/me puede fallar aunque el token sea válido.
  setToken(r.token);
  state.token = r.token;
  state.user = r.user;
  emit('session');
  loadMe().catch(e => console.warn('No se pudo cargar el perfil después del login:', e));
  return r.user;
}
export async function register(username, password, displayName, email) {
  return api('/auth/register', { method: 'POST', body: { username, password, displayName, email } });
}
export async function logout() {
  try { await api('/auth/logout', { method: 'POST' }); } catch { /* sigue */ }
  setToken(null); state.token = null; state.user = null; state.prefs = { theme: THEME_DEFAULTS, learning: {}, teacher: {}, ui: {} };
  localStorage.removeItem('ns_prefs');
  emit('session');
}

export async function loadMe() {
  if (!state.token) return null;
  const r = await api('/auth/me');
  state.user = r.user;
  fillPrefs(r.preferences);
  if (r.defaults) state.defaults = r.defaults;
  if (r.level) state.level = r.level;
  if (r.stats) state.stats = r.stats;
  applyTheme(state.prefs.theme);
  emit('me');
  return r;
}

function fillPrefs(p) {
  const cur = state.prefs;
  state.prefs = {
    theme: Object.assign({}, THEME_DEFAULTS, p.theme || {}),
    learning: Object.assign({}, p.learning || {}),
    teacher: Object.assign({}, p.teacher || {}),
    ui: Object.assign({}, p.ui || {}),
  };
  cur.theme = state.prefs.theme;
  persistPrefs();
}

/* ---- Preferencias ---- */
function persistPrefs() {
  try { localStorage.setItem('ns_prefs', JSON.stringify(state.prefs)); } catch { /* sin espacio */ }
}
export async function savePrefField(field, value) {
  const v = JSON.parse(JSON.stringify(value));
  state.prefs[field] = v;
  persistPrefs();
  if (field === 'theme') applyTheme(v);
  emit('prefs', { field, value: v });
  try {
    await api(`/auth/prefs/${field}`, { method: 'PUT', body: { value: v } });
  } catch (e) { console.warn('No se pudo sincronizar preferencia:', e.message); }
}

/* ---- Navegación ---- */
export function nav(path) {
  const target = path.startsWith('#') ? path : '#' + path;
  if (location.hash === target) {
    // Misma ruta: forzamos re-render (la app escucha este evento). Ej: crear una
    // materia estando en /learning, o reaprender una vista tras una acción.
    window.dispatchEvent(new CustomEvent('ns:reroute'));
  } else {
    location.hash = target;
  }
}
export function parseHash() {
  const h = location.hash.replace(/^#/, '') || '/dashboard';
  const parts = h.split('/').filter(Boolean);
  return { section: parts[0] || 'dashboard', params: parts.slice(1) };
}
export function currentSection() { return parseHash().section; }
