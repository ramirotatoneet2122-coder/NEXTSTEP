/* NEXTSTEP — motor de temas y personalización visual.
   Las 10 paletas se definen acá como tokens (variables CSS) y se aplican sobre :root.
   Los componentes NO tienen colores propios: usan las variables. */

export const PALETTE_LIST = [
  { id: 'cyberspace',   name: 'Cyberspace',   sub: 'Espacio profundo con neón magenta y cristal' },
  { id: 'focus-blue',    name: 'Focus Blue',    sub: 'Azules suaves, tecnológica y ordenada' },
  { id: 'forest-green',  name: 'Forest Green',  sub: 'Verdes naturales, estética tranquila' },
  { id: 'lavender-calm', name: 'Lavender Calm', sub: 'Violetas suaves y tonos fríos' },
  { id: 'warm-study',    name: 'Warm Study',    sub: 'Beige y tonos cálidos, acogedora' },
  { id: 'ocean-teal',    name: 'Ocean Teal',    sub: 'Turquesas modernas y azul verdoso' },
  { id: 'rose-pastel',   name: 'Rose Pastel',   sub: 'Rosas suaves y neutros pastel' },
  { id: 'high-contrast', name: 'High Contrast', sub: 'Máxima legibilidad' },
  { id: 'dark-focus',    name: 'Dark Focus',    sub: 'Oscuro con acentos moderados' },
  { id: 'light-minimal', name: 'Light Minimal', sub: 'Fondo claro y pocos adornos' },
  { id: 'custom',        name: 'Custom Theme',  sub: 'Tus propios colores' },
];

const T = {
  // paleta: { light: {...}, dark: {...} }
  'cyberspace': {
    light: { bg:'#F3EEFF', bg2:'#E9E1FF', surface:'#FFFFFF', surface2:'#F4EFFF', ink:'#180E2E', muted:'#5E5480', line:'#E0D6F8', lineStrong:'#C6B7EE', accent:'#C81E7A', accent2:'#7A3CF0', accentInk:'#FFFFFF', good:'#0E8F5E', warn:'#A65A00', danger:'#C43D5E', track:'#E8E0FA' },
    dark:  { bg:'#080512', bg2:'#0E0A22', surface:'#141026', surface2:'#1C1536', ink:'#F2ECFF', muted:'#A396C8', line:'#2A2150', lineStrong:'#3D2F6B', accent:'#FF2D9B', accent2:'#C44BFF', accentInk:'#14001F', good:'#3DE0A0', warn:'#FFC24B', danger:'#FF6B8A', track:'#221A44' },
  },
  'focus-blue': {
    light: { bg:'#F4F7FD', bg2:'#EAF0FA', surface:'#FFFFFF', surface2:'#F1F5FC', ink:'#17213B', muted:'#5B6888', line:'#DCE4F2', lineStrong:'#C6D2E8', accent:'#2F5BEA', accent2:'#6B8CFF', accentInk:'#FFFFFF', good:'#1E9E63', warn:'#B96E00', danger:'#D14343', track:'#E2E8F5' },
    dark:  { bg:'#0B1220', bg2:'#0F1830', surface:'#131D31', surface2:'#1A2540', ink:'#E7EDFB', muted:'#94A3C0', line:'#26324D', lineStrong:'#334063', accent:'#5B8CFF', accent2:'#8FABFF', accentInk:'#0B1220', good:'#34C98D', warn:'#FFB43B', danger:'#FF6B6B', track:'#1D2A45' },
  },
  'forest-green': {
    light: { bg:'#F2F7F3', bg2:'#E6F0E8', surface:'#FFFFFF', surface2:'#F0F7F1', ink:'#17301F', muted:'#57705E', line:'#DCEAE0', lineStrong:'#C2DCCB', accent:'#2E7D4F', accent2:'#55A874', accentInk:'#FFFFFF', good:'#1F8A4C', warn:'#A86A00', danger:'#C94F4F', track:'#DFEBE2' },
    dark:  { bg:'#0B150E', bg2:'#0E1D14', surface:'#13231A', surface2:'#1A2D22', ink:'#E4F2E8', muted:'#93AB9B', line:'#243B2E', lineStrong:'#32513F', accent:'#4CAF7F', accent2:'#7CCFA3', accentInk:'#0B150E', good:'#3DD18A', warn:'#FFB43B', danger:'#FF6B6B', track:'#1B2E23' },
  },
  'lavender-calm': {
    light: { bg:'#F7F5FC', bg2:'#EFEBF8', surface:'#FFFFFF', surface2:'#F4F1FA', ink:'#251C3C', muted:'#6A6290', line:'#E5E0F2', lineStrong:'#D0C7E7', accent:'#7C5CC4', accent2:'#A488E0', accentInk:'#FFFFFF', good:'#2FA37A', warn:'#B27400', danger:'#C94F6D', track:'#E6E0F3' },
    dark:  { bg:'#13101F', bg2:'#191531', surface:'#1E1930', surface2:'#262041', ink:'#EFEAFB', muted:'#9C92C0', line:'#322B4D', lineStrong:'#45396B', accent:'#9D82E0', accent2:'#BEABF0', accentInk:'#13101F', good:'#46C99D', warn:'#FFB947', danger:'#FF7D96', track:'#292244' },
  },
  'warm-study': {
    light: { bg:'#FAF5EC', bg2:'#F3E9D8', surface:'#FFFDF8', surface2:'#F7F0E2', ink:'#3A2F1F', muted:'#7A6D54', line:'#EAE0CB', lineStrong:'#D8C9A9', accent:'#B4552A', accent2:'#D98E5F', accentInk:'#FFFFFF', good:'#3E8E5A', warn:'#A86E00', danger:'#C14A3E', track:'#EFE6D2' },
    dark:  { bg:'#191208', bg2:'#22190C', surface:'#251B0E', surface2:'#322613', ink:'#F6EEDF', muted:'#B5A68B', line:'#3D2F1C', lineStrong:'#55432A', accent:'#E09A62', accent2:'#F0BE8E', accentInk:'#21150A', good:'#6FC48D', warn:'#F5C860', danger:'#F07C6E', track:'#33271A' },
  },
  'ocean-teal': {
    light: { bg:'#F0F9FA', bg2:'#E1F2F4', surface:'#FFFFFF', surface2:'#EFF7F8', ink:'#0F2E33', muted:'#4D6E74', line:'#D0E8EA', lineStrong:'#B3D9DD', accent:'#0E7C86', accent2:'#37A8B0', accentInk:'#FFFFFF', good:'#1E9E63', warn:'#B46900', danger:'#C94F4F', track:'#DCEEF0' },
    dark:  { bg:'#0A1517', bg2:'#0D1D20', surface:'#122226', surface2:'#182F34', ink:'#E3F1F2', muted:'#8FB0B4', line:'#22403F', lineStrong:'#305C61', accent:'#41B3BC', accent2:'#6CCBD0', accentInk:'#062124', good:'#3DD18A', warn:'#FFB43B', danger:'#FF7B7B', track:'#1B3034' },
  },
  'rose-pastel': {
    light: { bg:'#FDF4F6', bg2:'#F9E8ED', surface:'#FFFFFF', surface2:'#FAF0F3', ink:'#3A2230', muted:'#8A6071', line:'#F0DCE3', lineStrong:'#E1C4D0', accent:'#C25B83', accent2:'#DE85A6', accentInk:'#FFFFFF', good:'#2E9C77', warn:'#B06C00', danger:'#C94F6D', track:'#F4E4EA' },
    dark:  { bg:'#1B0F15', bg2:'#241219', surface:'#29161E', surface2:'#351E27', ink:'#FBEDF2', muted:'#C4A0AC', line:'#452434', lineStrong:'#5C3248', accent:'#E585A8', accent2:'#F3A6C0', accentInk:'#2A0E18', good:'#55C99B', warn:'#FFC65C', danger:'#FF8799', track:'#331B24' },
  },
  'high-contrast': {
    light: { bg:'#FFFFFF', bg2:'#F2F2F2', surface:'#FFFFFF', surface2:'#F7F7F7', ink:'#000000', muted:'#1F1F1F', line:'#1A1A1A', lineStrong:'#000000', accent:'#0033CC', accent2:'#0033CC', accentInk:'#FFFFFF', good:'#006B3C', warn:'#7A4A00', danger:'#C00000', track:'#D9D9D9' },
    dark:  { bg:'#000000', bg2:'#111111', surface:'#111111', surface2:'#1E1E1E', ink:'#FFFFFF', muted:'#C9C9C9', line:'#7A7A7A', lineStrong:'#FFFFFF', accent:'#6FA0FF', accent2:'#6FA0FF', accentInk:'#001133', good:'#37E08B', warn:'#FFD166', danger:'#FF5C5C', track:'#2A2A2A' },
  },
  'dark-focus': {
    light: { bg:'#101B30', bg2:'#162338', surface:'#16223C', surface2:'#1C2A4A', ink:'#E6EDFB', muted:'#93A3C2', line:'#28365A', lineStrong:'#35466F', accent:'#5B8CFF', accent2:'#8FABFF', accentInk:'#0B1526', good:'#3BCB93', warn:'#FFB43B', danger:'#FF6B6B', track:'#1C2A48' },
    dark:  { bg:'#060B16', bg2:'#0A1220', surface:'#0E1626', surface2:'#131E33', ink:'#E9EEFB', muted:'#8C9CBB', line:'#202C48', lineStrong:'#2C3C60', accent:'#4E7FFF', accent2:'#82A1FF', accentInk:'#060B16', good:'#3CCB93', warn:'#FFB43B', danger:'#FF6F6F', track:'#131F39' },
  },
  'light-minimal': {
    light: { bg:'#F7F7F9', bg2:'#EFEFF2', surface:'#FFFFFF', surface2:'#F3F3F5', ink:'#20242B', muted:'#6B7280', line:'#E6E7EA', lineStrong:'#C9CCD4', accent:'#334155', accent2:'#64748B', accentInk:'#FFFFFF', good:'#17864C', warn:'#A15C00', danger:'#C0392B', track:'#E8E9EC' },
    dark:  { bg:'#16181D', bg2:'#1D2026', surface:'#20232A', surface2:'#282C35', ink:'#EEF0F4', muted:'#9AA1AF', line:'#2E323C', lineStrong:'#414651', accent:'#B9C0CE', accent2:'#D7DCE6', accentInk:'#14161B', good:'#57C58A', warn:'#FFC65C', danger:'#F26D6D', track:'#2B2F39' },
  },
  custom: {
    light: { bg:'#F4F6FB', bg2:'#E9ECF5', surface:'#FFFFFF', surface2:'#F1F3F9', ink:'#1B2333', muted:'#62697A', line:'#DDE2EE', lineStrong:'#C5CDDF', accent:'#2F5BEA', accent2:'#6B8CFF', accentInk:'#FFFFFF', good:'#1E9E63', warn:'#B96E00', danger:'#D14343', track:'#E3E7F1' },
    dark:  { bg:'#0D111A', bg2:'#111726', surface:'#161D2C', surface2:'#1D2638', ink:'#E8EDF6', muted:'#97A0B3', line:'#273147', lineStrong:'#34415D', accent:'#5B8CFF', accent2:'#8FABFF', accentInk:'#0B111C', good:'#34C98D', warn:'#FFB43B', danger:'#FF6B6B', track:'#1E273A' },
  },
};

/* ---------- Utilidades de color (WCAG) ---------- */
function hexToRgb(h) {
  const s = String(h || '').replace('#', '').trim();
  if (s.length === 3) return [0, 1, 2].map(i => parseInt(s[i] + s[i], 16));
  if (s.length === 6) return [0, 2, 4].map(i => parseInt(s.slice(i, i + 2), 16));
  return [0, 0, 0];
}
function lum([r, g, b]) {
  const c = x => { const v = x / 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
  return 0.2126 * c(r) + 0.7152 * c(g) + 0.0722 * c(b);
}
export function contrastRatio(a, b) {
  const l1 = lum(hexToRgb(a)), l2 = lum(hexToRgb(b));
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}
export function readableInk(bg) {
  return contrastRatio('#FFFFFF', bg) >= 4.5 ? '#FFFFFF' : '#111111';
}
function mix(a, b, t) {
  const A = hexToRgb(a), B = hexToRgb(b);
  const c = A.map((v, i) => Math.round(v + (B[i] - v) * t));
  return '#' + c.map(v => v.toString(16).padStart(2, '0')).join('');
}
function hexToHsl(h) {
  let [r, g, b] = hexToRgb(h).map(v => v / 255);
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let l = (max + min) / 2, s = 0, hue = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === r) hue = ((g - b) / d + (g < b ? 6 : 0));
    else if (max === g) hue = (b - r) / d + 2;
    else hue = (r - g) / d + 4;
    hue *= 60;
  }
  return [hue, s, l];
}
function hslToHex(h, s, l) {
  h = ((h % 360) + 360) % 360;
  const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
  const [r, g, b] = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x] : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
  return '#' + [r, g, b].map(v => Math.round((v + m) * 255).toString(16).padStart(2, '0')).join('');
}
// Intensidad: ajusta la viveza (saturación) y el peso (luminosidad) del acento.
function tone(hex, intensity) {
  const [h, s, l] = hexToHsl(hex);
  // La saturación nunca baja demasiado: los acentos neón deben seguir:vivos.
  const vivid = 0.78 + (intensity / 100) * 0.22;
  return hslToHex(h, Math.min(1, Math.max(0.15, s * vivid)), Math.min(0.92, Math.max(0.08, l * (0.96 + (intensity - 50) / 100 * 0.08))));
}

/* ---------- Aplicación del tema ---------- */
export const THEME_DEFAULTS = {
  palette: 'cyberspace',
  mode: 'dark',              // light | dark | auto
  intensity: 55,             // 0-100
  contrast: 'medio',         // bajo | medio | alto
  buttonStyle: 'round',      // round | pill | square
  textSize: 0,               // -1 | 0 | 1 | 2
  density: 'normal',         // compacta | normal | espaciosa
  animations: true,
  colors: { primary: '#FF2D9B', accent: '#C44BFF', bg: '', surface: '' },
};

export function effectiveMode(prefs) {
  const m = prefs?.mode || 'auto';
  if (m === 'auto') return (window.matchMedia?.('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
  return m;
}

// Devuelve las variables de la paleta para un modo; aplica personalización opcional.
export function paletteVars(p, mode, extra = {}) {
  const pal = T[p] || T['focus-blue'];
  let v = { ...pal[mode] };
  if (p === 'custom' && extra.colors) {
    const c = extra.colors || {};
    if (c.bg) v.bg = c.bg;
    if (c.surface) v.surface = c.surface;
    if (c.primary) { v.accent = c.primary; v.accentInk = readableInk(c.primary); }
    if (c.accent) v.accent2 = c.accent;
    v.bg2 = mix(v.bg, v.surface, 0.5);
    v.surface2 = mix(v.surface, v.accent, 0.06);
  }
  if (extra.intensity !== undefined) {
    const it = Number(extra.intensity);
    v.accent = tone(v.accent, it);
    v.accent2 = tone(v.accent2, Math.max(0, it - 15));
    v.accentInk = readableInk(v.accent);
  }
  if (extra.contrast === 'alto') {
    v.ink = mode === 'dark' ? '#FFFFFF' : '#000000';
    v.muted = mode === 'dark' ? mix(v.muted, '#FFFFFF', 0.4) : mix(v.muted, '#000000', 0.45);
    v.line = v.lineStrong;
  } else if (extra.contrast === 'bajo') {
    v.muted = mix(v.muted, v.bg, 0.35);
    v.line = mix(v.line, v.bg, 0.35);
  }
  return v;
}

// Nombres de variables CSS: coinciden con los tokens de style.css.
const CSS_NAMES = {
  bg: '--bg', bg2: '--bg2', surface: '--surface', surface2: '--surface2', ink: '--ink',
  muted: '--muted', line: '--line', lineStrong: '--line-strong', accent: '--accent',
  accent2: '--accent-2', accentInk: '--accent-ink', good: '--good', warn: '--warn',
  danger: '--danger', track: '--track',
};

export function applyTheme(prefs) {
  const p = Object.assign({}, THEME_DEFAULTS, prefs || {});
  const mode = effectiveMode(p);
  const v = paletteVars(p.palette, mode, p);
  const root = document.documentElement;
  root.dataset.mode = mode;
  root.dataset.btn = p.buttonStyle || 'round';
  root.dataset.motion = p.animations ? '' : 'reduced';
  root.dataset.density = p.density || 'normal';
  const sizes = { '-1': '0.88', 0: '1', 1: '1.12', 2: '1.25' };
  root.style.setProperty('--text-scale', sizes[String(p.textSize)] || '1');
  for (const k of Object.keys(CSS_NAMES)) {
    root.style.setProperty(CSS_NAMES[k], v[k]);
  }
  root.style.setProperty('--grad', `linear-gradient(135deg, ${v.accent}, ${v.accent2})`);
  root.style.setProperty('--halo-1', v.accent);
  root.style.setProperty('--halo-2', v.accent2);
  root.style.setProperty('--glow', `color-mix(in srgb, ${v.accent} 55%, transparent)`);
  root.style.setProperty('--shadow', mode === 'dark'
    ? '0 34px 90px -44px rgba(0,0,0,.95), 0 0 60px -34px ' + v.accent
    : '0 26px 70px -40px rgba(40,20,80,.28)');
  return { vars: v, mode };
}

// Verifica contraste de una configuración; devuelve problemas accesibles (WCAG).
export function checkAccessibility(prefs) {
  const mode = effectiveMode(prefs);
  const v = paletteVars(prefs.palette, mode, prefs);
  const problems = [];
  const need = (a, b, min, label) => { const r = contrastRatio(a, b); if (r < min) problems.push({ label, ratio: r.toFixed(2), need: min }); };
  need(v.ink, v.bg, 4.5, 'Texto principal sobre el fondo');
  need(v.muted, v.bg, 4.5, 'Texto secundario sobre el fondo');
  need(v.accentInk, v.accent, 4.5, 'Texto sobre el color principal');
  return problems;
}

/* Vista previa en miniatura de la interfaz (para el selector de paletas). */
export function miniPreview(paletteId, extra = {}) {
  const mode = effectiveMode({ mode: extra.mode || 'auto' });
  const v = paletteVars(paletteId, mode, Object.assign({}, extra, { intensity: 55 }));
  const div = document.createElement('div');
  div.className = 'mini-ui';
  div.style.cssText = `background:${v.bg};border:1px solid ${v.line};padding:10px;border-radius:10px;display:flex;flex-direction:column;gap:7px;`;
  div.innerHTML = `
    <div style="display:flex;gap:6px;">
      <div style="flex:1;background:${v.surface};border:1px solid ${v.line};border-radius:8px;padding:8px;display:flex;flex-direction:column;gap:6px;">
        <div style="height:6px;width:60%;border-radius:3px;background:${v.ink};opacity:.85"></div>
        <div style="height:5px;width:88%;border-radius:3px;background:${v.track}"></div>
        <div style="height:12px;border-radius:6px;background:linear-gradient(135deg, ${v.accent}, ${v.accent2})"></div>
      </div>
      <div style="flex:1;background:${v.surface};border:1px solid ${v.line};border-radius:8px;padding:8px;display:flex;flex-direction:column;gap:6px;">
        <div style="align-self:flex-start;font-size:7px;font-weight:800;border-radius:99px;padding:2px 7px;background:${v.accent};color:${v.accentInk}">NIVEL</div>
        <div style="height:5px;width:70%;border-radius:3px;background:${v.accent2};opacity:.6"></div>
        <div style="height:5px;width:45%;border-radius:3px;background:${v.track}"></div>
      </div>
    </div>
    <div style="display:flex;gap:6px;">
      <span style="flex:1;height:16px;border-radius:6px;border:1px solid ${v.lineStrong};"></span>
      <span style="flex:1;height:16px;border-radius:6px;background:linear-gradient(135deg, ${v.accent}, ${v.accent2})"></span>
    </div>`;
  return div;
}