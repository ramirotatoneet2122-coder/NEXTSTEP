// Sistema de niveles, experiencia y logros.
// La experiencia se otorga SOLO desde el servidor con estas reglas; el frontend nunca la asigna.
import { q, qa, run, now } from './db.js';

export const RANKS = ['Iniciante', 'Básico', 'Intermedio', 'Avanzado', 'Experto'];
export const RANK_MIN = [0, 25, 50, 75, 90];
export const rankOf = p => { let r = 0; RANK_MIN.forEach((m, i) => { if (p >= m) r = i; }); return r; };

// Experiencia acumulada necesaria para cada nivel general.
const LEVEL_XP = [0, 100, 260, 480, 760, 1100, 1500, 1970, 2510, 3120,
  3800, 4560, 5400, 6320, 7330, 8430, 9620, 10900, 12270, 13730];

export const levelFromXp = xp => {
  let lvl = 1;
  LEVEL_XP.forEach((need, i) => { if (xp >= need) lvl = i + 1; });
  return lvl;
};

export const levelInfo = xp => {
  const level = levelFromXp(xp);
  const floor = LEVEL_XP[level - 1];
  const ceil = LEVEL_XP[level] ?? floor + 1000;
  return { level, xp, floor, ceil, progress: ceil > floor ? Math.round(((xp - floor) / (ceil - floor)) * 100) : 100 };
};

export const ACHIEVEMENTS = {
  primera_charla: { title: 'Primera charla', desc: 'Tuviste tu primer intercambio con el profesor.' },
  primera_materia: { title: 'Primera materia', desc: 'Agregaste una materia a tu aprendizaje.' },
  primera_ruta: { title: 'Camino trazado', desc: 'Generaste tu primera ruta de aprendizaje.' },
  primera_evaluacion: { title: 'A evaluarse', desc: 'Completaste tu primera evaluación.' },
  primer_objetivo: { title: 'Meta clara', desc: 'Registraste tu primer objetivo.' },
  racha_3: { title: 'Racha de 3', desc: 'Estudiaste 3 días seguidos.' },
  racha_7: { title: 'Racha de 7', desc: 'Estudiaste 7 días seguidos.' },
  racha_15: { title: 'Racha de 15', desc: 'Estudiaste 15 días seguidos.' },
  diez_actividades: { title: 'En movimiento', desc: 'Completaste 10 actividades.' },
  cincuenta_actividades: { title: 'Máquina de los lunes', desc: 'Completaste 50 actividades.' },
  cinco_horas: { title: '5 horas de estudio', desc: 'Llevás 5 horas de estudio registradas.' },
  veinte_horas: { title: '20 horas de estudio', desc: 'Llevás 20 horas de estudio registradas.' },
  nivel_5: { title: 'Nivel 5', desc: 'Alcanzaste el nivel general 5.' },
  nivel_10: { title: 'Nivel 10', desc: 'Alcanzaste el nivel general 10.' },
};

// Registra una ganancia de XP y evalúa logros. Devuelve lo nuevo ganado.
export function grantXp(userId, amount, reason, subjectId = null) {
  const amt = Math.max(0, Math.min(500, Math.round(Number(amount) || 0)));
  if (amt > 0) run('INSERT INTO xp_events (user_id, amount, reason, subject_id, created_at) VALUES (?,?,?,?,?)',
    userId, amt, String(reason).slice(0, 120), subjectId, now());
  const unlocked = checkAchievements(userId);
  return { gained: amt, unlocked };
}

// Revierte puntos asignados a una acción que dejó de estar completada.
export function revokeXp(userId, amount, reason, subjectId = null) {
  const requested = Math.max(0, Math.min(500, Math.round(Number(amount) || 0)));
  const current = Math.max(0, Number(q('SELECT COALESCE(SUM(amount),0) AS xp FROM xp_events WHERE user_id = ?', userId)?.xp) || 0);
  const lost = Math.min(requested, current);
  if (lost > 0) run('INSERT INTO xp_events (user_id, amount, reason, subject_id, created_at) VALUES (?,?,?,?,?)',
    userId, -lost, String(reason).slice(0, 120), subjectId, now());
  return { lost };
}

export function unlockAchievement(userId, code, title) {
  try {
    run('INSERT OR IGNORE INTO achievements (user_id, code, title, created_at) VALUES (?,?,?,?)',
      userId, code, String(title).slice(0, 60), now());
  } catch { /* ya existe */ }
}

export function hasAchievement(userId, code) {
  return q('SELECT 1 FROM achievements WHERE user_id = ? AND code = ?', userId, code);
}

export function checkAchievements(userId) {
  const unlockedNow = [];
  const has = c => hasAchievement(userId, c);
  const stats = userStats(userId);
  if (!has('primera_charla') && stats.messages > 0) { unlockAchievement(userId, 'primera_charla', ACHIEVEMENTS.primera_charla.title); unlockedNow.push('primera_charla'); }
  if (!has('primera_materia') && stats.subjects > 0) { unlockAchievement(userId, 'primera_materia', ACHIEVEMENTS.primera_materia.title); unlockedNow.push('primera_materia'); }
  if (!has('primera_ruta') && stats.paths > 0) { unlockAchievement(userId, 'primera_ruta', ACHIEVEMENTS.primera_ruta.title); unlockedNow.push('primera_ruta'); }
  if (!has('primera_evaluacion') && stats.assessments > 0) { unlockAchievement(userId, 'primera_evaluacion', ACHIEVEMENTS.primera_evaluacion.title); unlockedNow.push('primera_evaluacion'); }
  if (!has('primer_objetivo') && stats.goals > 0) { unlockAchievement(userId, 'primer_objetivo', ACHIEVEMENTS.primer_objetivo.title); unlockedNow.push('primer_objetivo'); }
  if (!has('racha_3') && stats.streak >= 3) { unlockAchievement(userId, 'racha_3', ACHIEVEMENTS.racha_3.title); unlockedNow.push('racha_3'); }
  if (!has('racha_7') && stats.streak >= 7) { unlockAchievement(userId, 'racha_7', ACHIEVEMENTS.racha_7.title); unlockedNow.push('racha_7'); }
  if (!has('racha_15') && stats.streak >= 15) { unlockAchievement(userId, 'racha_15', ACHIEVEMENTS.racha_15.title); unlockedNow.push('racha_15'); }
  if (!has('diez_actividades') && stats.activities >= 10) { unlockAchievement(userId, 'diez_actividades', ACHIEVEMENTS.diez_actividades.title); unlockedNow.push('diez_actividades'); }
  if (!has('cincuenta_actividades') && stats.activities >= 50) { unlockAchievement(userId, 'cincuenta_actividades', ACHIEVEMENTS.cincuenta_actividades.title); unlockedNow.push('cincuenta_actividades'); }
  if (!has('cinco_horas') && stats.minutes >= 300) { unlockAchievement(userId, 'cinco_horas', ACHIEVEMENTS.cinco_horas.title); unlockedNow.push('cinco_horas'); }
  if (!has('veinte_horas') && stats.minutes >= 1200) { unlockAchievement(userId, 'veinte_horas', ACHIEVEMENTS.veinte_horas.title); unlockedNow.push('veinte_horas'); }
  if (!has('nivel_5') && stats.level >= 5) { unlockAchievement(userId, 'nivel_5', ACHIEVEMENTS.nivel_5.title); unlockedNow.push('nivel_5'); }
  if (!has('nivel_10') && stats.level >= 10) { unlockAchievement(userId, 'nivel_10', ACHIEVEMENTS.nivel_10.title); unlockedNow.push('nivel_10'); }
  return unlockedNow;
}

export function userStats(userId) {
  const messages = q('SELECT COUNT(*) AS c FROM messages WHERE conversation_id IN (SELECT id FROM conversations WHERE user_id = ?)', userId).c || 0;
  const subjects = q('SELECT COUNT(*) AS c FROM subjects WHERE user_id = ?', userId).c || 0;
  const paths = q('SELECT COUNT(*) AS c FROM paths WHERE user_id = ?', userId).c || 0;
  const assessments = q('SELECT COUNT(*) AS c FROM assessments WHERE user_id = ?', userId).c || 0;
  const goals = q('SELECT COUNT(*) AS c FROM goals WHERE user_id = ?', userId).c || 0;
  const activities = q('SELECT COUNT(*) AS c FROM activities WHERE user_id = ? AND status = ?', userId, 'completada').c || 0;
  const minutes = q('SELECT COALESCE(SUM(minutes),0) AS c FROM study_sessions WHERE user_id = ?', userId).c || 0;
  const xp = q('SELECT COALESCE(SUM(amount),0) AS c FROM xp_events WHERE user_id = ?', userId).c || 0;
  const streak = computeStreak(userId);
  return { messages, subjects, paths, assessments, goals, activities, minutes, xp, level: levelFromXp(xp), streak };
}

// Racha real de estudio: días consecutivos con al menos una sesión, hasta hoy (o ayer si hoy todavía no se registró).
export function computeStreak(userId) {
  const rows = qa('SELECT DISTINCT substr(started_at,1,10) AS d FROM study_sessions WHERE user_id = ? ORDER BY d DESC', userId).map(r => r.d);
  if (!rows.length) return 0;
  const seen = new Set(rows);
  const today = new Date().toISOString().slice(0, 10);
  const iso = d => d.toISOString().slice(0, 10);
  let cursor;
  if (seen.has(today)) cursor = new Date(today + 'T00:00:00Z');
  else {
    const yesterday = new Date(Date.UTC(new Date(today + 'T00:00:00Z').getUTCFullYear(), new Date(today + 'T00:00:00Z').getUTCMonth(), new Date(today + 'T00:00:00Z').getUTCDate() - 1));
    if (!seen.has(iso(yesterday))) return 0;
    cursor = yesterday;
  }
  let streak = 0;
  while (seen.has(iso(cursor))) { streak++; cursor.setUTCDate(cursor.getUTCDate() - 1); }
  return streak;
}