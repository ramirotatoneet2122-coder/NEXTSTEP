// Envío de correos transaccionales por la API de Brevo. La clave solo vive en el servidor.
const BREVO_EMAILS_URL = 'https://api.brevo.com/v3/smtp/email';

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[ch]);
}

export async function sendVerificationEmail({ email, displayName, token }) {
  const apiKey = process.env.BREVO_API_KEY;
  const sender = process.env.EMAIL_FROM;
  const baseUrl = process.env.APP_BASE_URL || 'http://localhost:3000';
  if (!apiKey || !sender) {
    const error = new Error('Falta configurar BREVO_API_KEY o EMAIL_FROM.');
    error.code = 'EMAIL_NOT_CONFIGURED';
    throw error;
  }

  let link;
  try {
    const url = new URL('/api/auth/verify-email', baseUrl);
    url.searchParams.set('token', token);
    link = url.toString();
  } catch {
    const error = new Error('APP_BASE_URL no es una dirección válida.');
    error.code = 'EMAIL_NOT_CONFIGURED';
    throw error;
  }

  const name = escapeHtml(displayName || 'estudiante');
  const response = await fetch(BREVO_EMAILS_URL, {
    method: 'POST',
    headers: { 'api-key': apiKey, 'content-type': 'application/json', accept: 'application/json' },
    signal: AbortSignal.timeout(12_000),
    body: JSON.stringify({
      sender: { name: 'NEXTSTEP', email: sender },
      to: [{ email }],
      subject: 'Confirmá tu correo para NEXTSTEP',
      textContent: `Hola ${displayName || 'estudiante'}. Para terminar de crear tu cuenta de NEXTSTEP, abrí este enlace: ${link}\n\nEl enlace vence en 30 minutos. Si no pediste esta cuenta, ignorá este correo.`,
      htmlContent: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:32px auto;padding:28px;border:1px solid #ddd;border-radius:16px"><h1 style="color:#783cf5">NEXTSTEP</h1><p>Hola ${name},</p><p>Confirmá tu correo para terminar de crear tu cuenta.</p><p><a href="${link}" style="display:inline-block;padding:13px 20px;background:#783cf5;color:#fff;text-decoration:none;border-radius:10px">Confirmar mi correo</a></p><p>El enlace vence en 30 minutos. Si no pediste esta cuenta, ignorá este correo.</p></div>`,
    }),
  });

  if (!response.ok) {
    const error = new Error(`Brevo respondió ${response.status}.`);
    error.code = 'EMAIL_SEND_FAILED';
    throw error;
  }
}
