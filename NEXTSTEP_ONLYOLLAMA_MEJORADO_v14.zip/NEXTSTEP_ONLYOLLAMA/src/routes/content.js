// Materias, temas y conversaciones de cada alumno.
import { Router } from 'express';
import { run, q, qa, rowToJson, now, tx } from '../db.js';
import { requireAuth } from '../auth.js';
import { grantXp, revokeXp } from '../xp.js';
import { MODES, listSubjects, getSubject, loadSubjectSummary, modeLabel, matchBankKey } from '../domain.js';
import { RANKS, TOPICS } from '../data.js';

export const contentRouter = Router();
contentRouter.use(requireAuth);

const VALID_TOPIC_STATUS = ['dominado', 'aprendiendo', 'dificultad', 'pendiente'];

// ---------- Materias ----------
contentRouter.get('/subjects', (req, res) => {
  res.json({ subjects: listSubjects(req.userId) });
});

contentRouter.post('/subjects', (req, res) => {
  const name = String(req.body?.name || '').trim();
  if (!name || name.length > 60) return res.status(400).json({ error: 'Ingresá el nombre de la materia (hasta 60 caracteres).' });
  const goal = String(req.body?.goal || '').trim().slice(0, 300);
  const level = RANKS.includes(req.body?.level) ? req.body.level : 'Iniciante';
  const id = run('INSERT INTO subjects (user_id, name, goal, level, created_at, updated_at) VALUES (?,?,?,?,?,?)',
    req.userId, name, goal, level, now(), now()).lastInsertRowid;
  // Primera materia tópica con su respaldo.
  const defaultTopicName = req.body?.initialTopic ? String(req.body.initialTopic).trim().slice(0, 60) : 'Conceptos generales';
  if (defaultTopicName) {
    run('INSERT INTO topics (subject_id, user_id, name, status, updated_at) VALUES (?,?,?,?,?)',
      id, req.userId, defaultTopicName, 'pendiente', now());
  }
  grantXp(req.userId, 15, 'Registraste una materia nueva');
  res.status(201).json({ subject: loadSubjectSummary(getSubject(req.userId, id)) });
});

contentRouter.put('/subjects/:id', (req, res) => {
  const s = getSubject(req.userId, Number(req.params.id));
  if (!s) return res.status(404).json({ error: 'No existe esa materia.' });
  const goal = req.body?.goal !== undefined ? String(req.body.goal).slice(0, 300) : s.goal;
  const status = ['active', 'paused', 'finished'].includes(req.body?.status) ? req.body.status : s.status;
  const level = RANKS.includes(req.body?.level) ? req.body.level : s.level;
  run('UPDATE subjects SET goal = ?, status = ?, level = ?, updated_at = ? WHERE id = ?', goal, status, level, now(), s.id);
  const sub = getSubject(req.userId, s.id);
  res.json({ subject: loadSubjectSummary(sub) });
});

contentRouter.delete('/subjects/:id', (req, res) => {
  const s = getSubject(req.userId, Number(req.params.id));
  if (!s) return res.status(404).json({ error: 'No existe esa materia.' });
  run('DELETE FROM subjects WHERE id = ?', s.id);
  res.json({ ok: true });
});

contentRouter.get('/subjects/:id', (req, res) => {
  const s = getSubject(req.userId, Number(req.params.id));
  if (!s) return res.status(404).json({ error: 'No existe esa materia.' });
  const topics = qa('SELECT * FROM topics WHERE subject_id = ? ORDER BY CASE status WHEN ? THEN 0 WHEN ? THEN 1 WHEN ? THEN 2 ELSE 3 END, updated_at DESC',
    s.id, 'dominado', 'aprendiendo', 'dificultad').map(rowToJson);
  const paths = qa('SELECT * FROM paths WHERE subject_id = ? ORDER BY created_at DESC', s.id).map(rowToJson);
  const evals = qa('SELECT id, title, kind, score, total, created_at, finished_at FROM assessments WHERE subject_id = ? ORDER BY created_at DESC', s.id);
  res.json({ subject: loadSubjectSummary(s), topics, paths, assessments: evals });
});

// ---------- Temas ----------
contentRouter.post('/subjects/:id/topics', (req, res) => {
  const s = getSubject(req.userId, Number(req.params.id));
  if (!s) return res.status(404).json({ error: 'No existe esa materia.' });
  const name = String(req.body?.name || '').trim();
  if (!name || name.length > 60) return res.status(400).json({ error: 'Ingresá el nombre del tema.' });
  const status = VALID_TOPIC_STATUS.includes(req.body?.status) ? req.body.status : 'pendiente';
  const id = run('INSERT INTO topics (subject_id, user_id, name, status, updated_at) VALUES (?,?,?,?,?)',
    s.id, req.userId, name, status, now()).lastInsertRowid;
  res.status(201).json({ topic: rowToJson(q('SELECT * FROM topics WHERE id = ?', id)) });
});

contentRouter.put('/topics/:id', (req, res) => {
  const t = q('SELECT * FROM topics WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!t) return res.status(404).json({ error: 'No existe ese tema.' });
  const status = VALID_TOPIC_STATUS.includes(req.body?.status) ? req.body.status : t.status;
  const prev = t.status;
  run('UPDATE topics SET status = ?, updated_at = ? WHERE id = ?', status, now(), t.id);
  const gained = grantXp(req.userId, status === 'dominado' && prev !== 'dominado' ? 25 : 0, 'Progresaste en un tema');
  const lost = status !== 'dominado' && prev === 'dominado' ? revokeXp(req.userId, 25, 'Revertiste un tema dominado').lost : 0;
  res.json({ topic: rowToJson(q('SELECT * FROM topics WHERE id = ?', t.id)), gained: gained.gained, lost });
});

contentRouter.delete('/topics/:id', (req, res) => {
  const t = q('SELECT * FROM topics WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!t) return res.status(404).json({ error: 'No existe ese tema.' });
  run('DELETE FROM topics WHERE id = ?', t.id);
  res.json({ ok: true });
});

// ---------- Práctica rápida (banco verificado, no necesita IA) ----------
// Devuelve una pregunta del banco para la zona "Ejercicios y práctica" del inicio.
contentRouter.get('/practice/next', (req, res) => {
  const key = String(req.query.topic || '').trim().toLowerCase();
  const subjectId = req.query.subject_id ? Number(req.query.subject_id) : null;

  let bankKey = TOPICS[key] ? key : null;
  if (!bankKey && subjectId) {
    const s = getSubject(req.userId, subjectId);
    if (s) bankKey = matchBankKey(s.name);
  }
  if (!bankKey) {
    // Primera materia del alumno que exista en el banco verificado.
    for (const s of listSubjects(req.userId)) {
      const k = matchBankKey(s.name);
      if (k) { bankKey = k; break; }
    }
  }
  if (!bankKey) {
    const keys = Object.keys(TOPICS);
    bankKey = keys[Math.floor(Math.random() * keys.length)];
  }

  const topic = TOPICS[bankKey];
  const idx = Math.floor(Math.random() * topic.qs.length);
  const it = topic.qs[idx];
  res.json({
    topic: { key: bankKey, name: topic.name },
    question: {
      id: `${bankKey}:${idx}`,
      prompt: it.q,
      options: it.o,
      difficulty: it.d,
      subtopic: it.s,
      correct: it.a,
      explanation: it.e,
    },
  });
});

// ---------- Conversaciones ----------
contentRouter.get('/conversations', (req, res) => {
  const rows = qa(`SELECT c.*, s.name AS subject_name, (SELECT COUNT(*) FROM messages WHERE conversation_id = c.id) AS msg_count,
    (SELECT content FROM messages WHERE conversation_id = c.id AND role='user' ORDER BY id DESC LIMIT 1) AS last_msg
    FROM conversations c LEFT JOIN subjects s ON s.id = c.subject_id WHERE c.user_id = ? ORDER BY c.updated_at DESC`, req.userId);
  res.json({ conversations: rows.map(rowToJson) });
});

contentRouter.post('/conversations', (req, res) => {
  const subject = req.body?.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
  const mode = MODES.includes(req.body?.mode) ? req.body.mode : 'normal';
  const title = String(req.body?.title || '').trim().slice(0, 80) || 'Nueva conversación';
  const id = run('INSERT INTO conversations (user_id, subject_id, title, mode, created_at, updated_at) VALUES (?,?,?,?,?,?)',
    req.userId, subject ? subject.id : null, title, mode, now(), now()).lastInsertRowid;
  res.status(201).json({ conversation: rowToJson(q('SELECT * FROM conversations WHERE id = ?', id)) });
});

contentRouter.get('/conversations/:id', (req, res) => {
  const c = q('SELECT * FROM conversations WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!c) return res.status(404).json({ error: 'No existe esa conversación.' });
  const msgs = qa('SELECT id, role, content, created_at FROM messages WHERE conversation_id = ? ORDER BY id', c.id);
  const subject = c.subject_id ? loadSubjectSummary(getSubject(req.userId, c.subject_id)) : null;
  res.json({ conversation: rowToJson(c), messages: msgs, subject });
});

contentRouter.put('/conversations/:id', (req, res) => {
  const c = q('SELECT * FROM conversations WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!c) return res.status(404).json({ error: 'No existe esa conversación.' });
  const title = req.body?.title !== undefined ? String(req.body.title).trim().slice(0, 80) : c.title;
  const mode = MODES.includes(req.body?.mode) ? req.body.mode : c.mode;
  let subjectId = c.subject_id;
  if (req.body?.subject_id !== undefined) {
    const s = req.body.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
    subjectId = s ? s.id : null;
  }
  run('UPDATE conversations SET title = ?, mode = ?, subject_id = ?, updated_at = ? WHERE id = ?',
    title, mode, subjectId, now(), c.id);
  res.json({ conversation: rowToJson(q('SELECT * FROM conversations WHERE id = ?', c.id)) });
});

contentRouter.delete('/conversations/:id', (req, res) => {
  const c = q('SELECT * FROM conversations WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!c) return res.status(404).json({ error: 'No existe esa conversación.' });
  run('DELETE FROM conversations WHERE id = ?', c.id);
  res.json({ ok: true });
});

// Guardar el perfil de seguimiento de una conversación (lo manda la etiqueta <perfil> de la IA).
contentRouter.put('/conversations/:id/perfil', (req, res) => {
  const c = q('SELECT * FROM conversations WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!c) return res.status(404).json({ error: 'No existe esa conversación.' });
  const perfil = req.body?.perfil;
  if (!perfil || typeof perfil !== 'object') return res.status(400).json({ error: 'Perfil inválido.' });
  const prev = {};
  try { Object.assign(prev, JSON.parse(c.perfil_json || '{}')); } catch { /* vacío */ }
  const merged = { ...prev, ...perfil };
  run('UPDATE conversations SET perfil_json = ?, updated_at = ? WHERE id = ?', JSON.stringify(merged), now(), c.id);
  res.json({ ok: true, perfil: merged });
});

// Obtener el perfil de seguimiento de una conversación (para retomar contexto).
contentRouter.get('/conversations/:id/perfil', (req, res) => {
  const c = q('SELECT * FROM conversations WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!c) return res.status(404).json({ error: 'No existe esa conversación.' });
  try {
    res.json({ perfil: JSON.parse(c.perfil_json || '{}') });
  } catch {
    res.json({ perfil: {} });
  }
});