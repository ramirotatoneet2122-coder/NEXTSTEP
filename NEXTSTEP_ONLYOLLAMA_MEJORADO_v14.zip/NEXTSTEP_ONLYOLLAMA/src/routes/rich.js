// Rutas de aprendizaje, módulos, actividades y evaluaciones.
import { Router } from 'express';
import { run, q, qa, rowToJson, now, tx } from '../db.js';
import { requireAuth } from '../auth.js';
import { grantXp, revokeXp } from '../xp.js';
import { getSubject, loadSubjectSummary, matchBankKey } from '../domain.js';
import { bankQuiz } from '../data.js';
import { aiConfigured, completeJSON, friendlyAiError } from '../llm.js';
import { buildJSONSystem } from '../prompt.js';

export const richRouter = Router();
richRouter.use(requireAuth);

const KIND_ACTIVITY = ['explicacion', 'recurso', 'practica', 'evaluacion'];
const ACT_STATUS = ['pendiente', 'completada'];
function syncModuleFromActivities(moduleId, userId) {
  const m = q('SELECT * FROM modules WHERE id = ? AND user_id = ?', moduleId, userId);
  if (!m) return { status: null, gained: 0, lost: 0 };
  const counts = q(`SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'completada' THEN 1 ELSE 0 END) AS done
    FROM activities WHERE module_id = ? AND user_id = ?`, m.id, userId);
  const total = Number(counts?.total) || 0;
  const done = Number(counts?.done) || 0;
  const status = total > 0 && done === total ? 'completado' : done > 0 ? 'en_curso' : 'pendiente';
  let gained = 0, lost = 0;
  if (status !== m.status) {
    run('UPDATE modules SET status = ? WHERE id = ?', status, m.id);
    if (status === 'completado') gained = grantXp(userId, 25, 'Completaste un módulo').gained;
    else if (m.status === 'completado') lost = revokeXp(userId, 25, 'Revertiste un módulo').lost;
  }
  const modules = qa('SELECT status FROM modules WHERE path_id = ?', m.path_id);
  const path = q('SELECT status FROM paths WHERE id = ?', m.path_id);
  const pathStatus = modules.length && modules.every(x => x.status === 'completado') ? 'completado'
    : modules.some(x => x.status === 'en_curso' || x.status === 'completado') ? 'en_curso' : 'pendiente';
  if (path && path.status !== pathStatus) run('UPDATE paths SET status = ?, updated_at = ? WHERE id = ?', pathStatus, now(), m.path_id);
  return { status, gained, lost };
}

// ---------- Rutas ----------
function pathSummary(row) {
  const modules = qa('SELECT * FROM modules WHERE path_id = ? ORDER BY position', row.id);
  const done = modules.filter(m => m.status === 'completado').length;
  const inCourse = modules.find(m => m.status === 'en_curso') || modules[0];
  return {
    id: row.id,
    title: row.title,
    summary: row.summary,
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    subjectId: row.subject_id,
    modules: modules.length,
    modulesDone: done,
    progress: modules.length ? Math.round(done / modules.length * 100) : 0,
    nextModule: inCourse ? { id: inCourse.id, title: inCourse.title, status: inCourse.status } : null,
  };
}

richRouter.get('/paths', (req, res) => {
  const rows = qa('SELECT * FROM paths WHERE user_id = ? ORDER BY created_at DESC', req.userId);
  res.json({ paths: rows.map(pathSummary) });
});

richRouter.post('/paths', (req, res) => {
  const subject = req.body?.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
  const title = String(req.body?.title || '').trim().slice(0, 100);
  if (!title) return res.status(400).json({ error: 'Ingresá un título para la ruta.' });
  const summary = String(req.body?.summary || '').trim().slice(0, 300);
  const id = run('INSERT INTO paths (user_id, subject_id, title, summary, created_at, updated_at) VALUES (?,?,?,?,?,?)',
    req.userId, subject ? subject.id : null, title, summary, now(), now()).lastInsertRowid;

  const modules = Array.isArray(req.body?.modules) ? req.body.modules.slice(0, 12) : [];
  modules.forEach((m, i) => {
    const mTitle = String(m.title || '').trim().slice(0, 90);
    if (!mTitle) return;
    const objectivo = String(m.objective || '').trim().slice(0, 280);
    const mid = run('INSERT INTO modules (path_id, user_id, title, objective, position, created_at) VALUES (?,?,?,?,?,?)',
      id, req.userId, mTitle, objectivo, i, now()).lastInsertRowid;
    const acts = Array.isArray(m.activities) ? m.activities.slice(0, 5) : [{ title: 'Explicación inicial', kind: 'explicacion' }, { title: 'Práctica y ejercicios', kind: 'practica' }];
    acts.forEach(a => {
      const aTitle = String(a.title || '').trim().slice(0, 90) || 'Actividad';
      const kind = KIND_ACTIVITY.includes(a.kind) ? a.kind : 'practica';
      run('INSERT INTO activities (module_id, user_id, title, kind, created_at) VALUES (?,?,?,?,?)',
        mid, req.userId, aTitle, kind, now());
    });
  });
  grantXp(req.userId, 20, 'Creaste una ruta de aprendizaje');
  res.status(201).json({ path: pathSummary(q('SELECT * FROM paths WHERE id = ?', id)) });
});

// Genera una ruta de aprendizaje personalizada con IA.
richRouter.post('/paths/generate', async (req, res) => {
  const subject = req.body?.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
  if (!subject) return res.status(400).json({ error: 'Elegí la materia para la ruta.' });
  const timePerWeek = Math.max(1, Math.min(40, Number(req.body?.hoursPerWeek) || 5));
  const targetLevel = ['Iniciante', 'Básico', 'Intermedio', 'Avanzado', 'Experto'].includes(req.body?.target)
    ? req.body.target : 'Intermedio';

  if (!aiConfigured()) {
    return res.status(503).json({ error: 'Para generar rutas con IA, configurá el proveedor de IA en el servidor (ver README). Mientras tanto podés crear la ruta a mano.' });
  }

  // Prompt corto a propósito: con un modelo local en CPU cada token de salida cuesta segundos.
  // Pocos módulos y objetivos breves mantienen la respuesta chica (~250 tokens) y rápida.
  const task = `Armá una ruta de aprendizaje de "${subject.name}". Nivel actual: ${subject.level}. Meta: ${subject.goal || 'sin especificar'}. Nivel a alcanzar: ${targetLevel}. Tiempo: ${timePerWeek} h por semana.
Devolvé SOLO este JSON: {"title":"título corto","summary":"una frase","modules":[{"title":"nombre","objective":"objetivo en menos de 15 palabras"}]}
De 4 a 6 módulos, del fundamento al avance. Sin links, cursos ni marcas.`;
  const t0 = Date.now();
  try {
    const out = await completeJSON({
      system: buildJSONSystem(task),
      messages: [{ role: 'user', content: 'Generá la ruta.' }],
      maxTokens: 480,
      timeoutMs: Math.max(30_000, Math.min(180_000, Number(process.env.AI_PATH_TIMEOUT_MS) || 150_000)),
      retries: 0,
    });
    // Los modelos chicos a veces cambian los nombres de los campos: aceptamos las variantes comunes en español.
    const rawModules = [out?.modules, out?.modulos, out?.módulos, out?.etapas, out?.steps].find(Array.isArray) || [];
    const modules = rawModules
      .map(m => (typeof m === 'string' ? { title: m } : { title: m?.title ?? m?.titulo ?? m?.título ?? m?.nombre ?? m?.name, objective: m?.objective ?? m?.objetivo ?? m?.descripcion ?? m?.descripción ?? '' }))
      .filter(m => String(m.title || '').trim())
      .slice(0, 8);
    if (!modules.length) return res.status(502).json({ error: 'La IA no devolvió una ruta válida. Probá de nuevo.' });
    const title = String(out.title || out.titulo || out.título || `Ruta de ${subject.name}`).slice(0, 100);
    const summary = String(out.summary || out.resumen || '').slice(0, 300);
    const id = run('INSERT INTO paths (user_id, subject_id, title, summary, created_at, updated_at) VALUES (?,?,?,?,?,?)',
      req.userId, subject.id, title, summary, now(), now()).lastInsertRowid;
    modules.forEach((m, i) => {
      const mTitle = String(m.title || `Módulo ${i + 1}`).trim().slice(0, 90);
      const objectivo = String(m.objective || '').trim().slice(0, 280);
      const mid = run('INSERT INTO modules (path_id, user_id, title, objective, position, created_at) VALUES (?,?,?,?,?,?)',
        id, req.userId, mTitle, objectivo, i, now()).lastInsertRowid;
      const defaultActs = [
        { title: `Explicación: ${mTitle}`, kind: 'explicacion' },
        { title: `Práctica: ${mTitle}`, kind: 'practica' },
        { title: `Evaluación del módulo`, kind: 'evaluacion' },
      ];
      defaultActs.forEach(a => run('INSERT INTO activities (module_id, user_id, title, kind, created_at) VALUES (?,?,?,?,?)',
        mid, req.userId, a.title, a.kind, now()));
    });
    grantXp(req.userId, 20, 'Generaste una ruta con IA');
    console.log(`[gen path] "${title}" (${modules.length} módulos) en ${Math.round((Date.now() - t0) / 1000)} s`);
    res.status(201).json({ path: pathSummary(q('SELECT * FROM paths WHERE id = ?', id)) });
  } catch (e) {
    console.error(`[gen path] falló tras ${Math.round((Date.now() - t0) / 1000)} s:`, e?.message ?? e);
    res.status(502).json({ error: friendlyAiError(e) + ' Mientras tanto podés crear la ruta a mano.' });
  }
});

richRouter.get('/paths/:id', (req, res) => {
  const p = q('SELECT * FROM paths WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!p) return res.status(404).json({ error: 'No existe esa ruta.' });
  const modules = qa('SELECT * FROM modules WHERE path_id = ? ORDER BY position', p.id).map(rowToJson).map(m => ({
    ...m,
    activities: qa('SELECT * FROM activities WHERE module_id = ? ORDER BY id', m.id).map(rowToJson),
  }));
  const subject = p.subject_id ? loadSubjectSummary(getSubject(req.userId, p.subject_id)) : null;
  res.json({ path: pathSummary(p), modules, subject });
});

richRouter.put('/paths/:id', (req, res) => {
  const p = q('SELECT * FROM paths WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!p) return res.status(404).json({ error: 'No existe esa ruta.' });
  const title = req.body?.title !== undefined ? String(req.body.title).trim().slice(0, 100) : p.title;
  if (!title) return res.status(400).json({ error: 'El título de la ruta no puede quedar vacío.' });
  const summary = req.body?.summary !== undefined ? String(req.body.summary).trim().slice(0, 300) : p.summary;
  run('UPDATE paths SET title = ?, summary = ?, updated_at = ? WHERE id = ?', title, summary, now(), p.id);

  if (Array.isArray(req.body?.modules)) {
    const edits = req.body.modules.slice(0, 20);
    const existing = qa('SELECT * FROM modules WHERE path_id = ? AND user_id = ?', p.id, req.userId);
    const retained = new Set();
    edits.forEach((m, position) => {
      const mTitle = String(m?.title || '').trim().slice(0, 90);
      if (!mTitle) return;
      const objective = String(m?.objective || '').trim().slice(0, 280);
      const old = m.id ? existing.find(x => x.id === Number(m.id)) : null;
      if (old) {
        retained.add(old.id);
        run('UPDATE modules SET title = ?, objective = ?, position = ? WHERE id = ?', mTitle, objective, position, old.id);
      } else {
        const moduleId = run('INSERT INTO modules (path_id,user_id,title,objective,position,created_at) VALUES (?,?,?,?,?,?)',
          p.id, req.userId, mTitle, objective, position, now()).lastInsertRowid;
        for (const activity of [
          { title: `Explicación: ${mTitle}`, kind: 'explicacion' },
          { title: `Práctica: ${mTitle}`, kind: 'practica' },
        ]) run('INSERT INTO activities (module_id,user_id,title,kind,created_at) VALUES (?,?,?,?,?)',
          moduleId, req.userId, activity.title, activity.kind, now());
      }
    });
    for (const old of existing) {
      if (retained.has(old.id)) continue;
      const completed = Number(q("SELECT COUNT(*) AS n FROM activities WHERE module_id = ? AND status = 'completada'", old.id)?.n) || 0;
      let xpToRevoke = completed * 40 + (old.status === 'completado' ? 25 : 0);
      while (xpToRevoke > 0) {
        const removed = revokeXp(req.userId, Math.min(500, xpToRevoke), 'Editaste una ruta y quitaste progreso');
        xpToRevoke -= removed.lost;
        if (!removed.lost) break;
      }
      run('DELETE FROM modules WHERE id = ?', old.id);
    }
    const statuses = qa('SELECT status FROM modules WHERE path_id = ?', p.id);
    const status = statuses.length && statuses.every(m => m.status === 'completado') ? 'completado'
      : statuses.some(m => m.status === 'en_curso' || m.status === 'completado') ? 'en_curso' : 'pendiente';
    run('UPDATE paths SET status = ?, updated_at = ? WHERE id = ?', status, now(), p.id);
  }
  res.json({ path: pathSummary(q('SELECT * FROM paths WHERE id = ?', p.id)) });
});

// ---------- Calendario personal ----------
const EVENT_KINDS = ['evaluacion', 'entrega', 'recordatorio', 'fecha'];
const validDate = value => /^\d{4}-\d{2}-\d{2}$/.test(String(value || ''))
  && !Number.isNaN(Date.parse(`${value}T00:00:00Z`))
  && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value;

richRouter.get('/calendar-events', (req, res) => {
  const events = qa(`SELECT e.*, s.name AS subject_name FROM calendar_events e
    LEFT JOIN subjects s ON s.id = e.subject_id WHERE e.user_id = ? ORDER BY e.event_date, e.id`, req.userId);
  res.json({ events: events.map(rowToJson) });
});

richRouter.post('/calendar-events', (req, res) => {
  const title = String(req.body?.title || '').trim().slice(0, 120);
  const eventDate = String(req.body?.event_date || '');
  if (!title) return res.status(400).json({ error: 'Escribí un título para la fecha.' });
  if (!validDate(eventDate)) return res.status(400).json({ error: 'Elegí una fecha válida.' });
  const subject = req.body?.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
  const kind = EVENT_KINDS.includes(req.body?.kind) ? req.body.kind : 'fecha';
  const notes = String(req.body?.notes || '').trim().slice(0, 500);
  const stamp = now();
  const id = run('INSERT INTO calendar_events (user_id,subject_id,title,event_date,kind,notes,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)',
    req.userId, subject?.id || null, title, eventDate, kind, notes, stamp, stamp).lastInsertRowid;
  res.status(201).json({ event: rowToJson(q('SELECT * FROM calendar_events WHERE id = ?', id)) });
});

richRouter.put('/calendar-events/:id', (req, res) => {
  const event = q('SELECT * FROM calendar_events WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!event) return res.status(404).json({ error: 'No existe esa fecha.' });
  const title = req.body?.title !== undefined ? String(req.body.title).trim().slice(0, 120) : event.title;
  const eventDate = req.body?.event_date !== undefined ? String(req.body.event_date) : event.event_date;
  if (!title) return res.status(400).json({ error: 'Escribí un título para la fecha.' });
  if (!validDate(eventDate)) return res.status(400).json({ error: 'Elegí una fecha válida.' });
  let subjectId = event.subject_id;
  if (req.body?.subject_id !== undefined) subjectId = req.body.subject_id ? getSubject(req.userId, Number(req.body.subject_id))?.id || null : null;
  const kind = EVENT_KINDS.includes(req.body?.kind) ? req.body.kind : event.kind;
  const notes = req.body?.notes !== undefined ? String(req.body.notes).trim().slice(0, 500) : event.notes;
  run('UPDATE calendar_events SET title=?,event_date=?,subject_id=?,kind=?,notes=?,updated_at=? WHERE id=?',
    title, eventDate, subjectId, kind, notes, now(), event.id);
  res.json({ event: rowToJson(q('SELECT * FROM calendar_events WHERE id = ?', event.id)) });
});

richRouter.delete('/calendar-events/:id', (req, res) => {
  const event = q('SELECT id FROM calendar_events WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!event) return res.status(404).json({ error: 'No existe esa fecha.' });
  run('DELETE FROM calendar_events WHERE id = ?', event.id);
  res.json({ ok: true });
});

richRouter.delete('/paths/:id', (req, res) => {
  const p = q('SELECT * FROM paths WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!p) return res.status(404).json({ error: 'No existe esa ruta.' });
  run('DELETE FROM paths WHERE id = ?', p.id);
  res.json({ ok: true });
});

// ---------- Módulos ----------
richRouter.put('/modules/:id', (req, res) => {
  const m = q('SELECT * FROM modules WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!m) return res.status(404).json({ error: 'No existe ese módulo.' });
  const status = ['pendiente', 'en_curso', 'completado'].includes(req.body?.status) ? req.body.status : m.status;
  run('UPDATE modules SET status = ?, created_at = created_at WHERE id = ?', status, m.id);
  const prev = m.status;
  let gained = 0;
  let lost = 0;
  if (status === 'completado' && prev !== 'completado') gained = grantXp(req.userId, 25, 'Completaste un módulo').gained;
  else if (status !== 'completado' && prev === 'completado') lost = revokeXp(req.userId, 25, 'Revertiste un módulo').lost;
  // Si todos los módulos están completados, la ruta pasa a completado; si se deshace uno, vuelve a "en curso".
  const p = q('SELECT * FROM paths WHERE id = ?', m.path_id);
  const others = qa('SELECT status FROM modules WHERE path_id = ?', m.path_id);
  if (others.length && others.every(o => o.status === 'completado')) {
    run('UPDATE paths SET status = ?, updated_at = ? WHERE id = ?', 'completado', now(), m.path_id);
  } else if (p && p.status === 'completado') {
    run('UPDATE paths SET status = ?, updated_at = ? WHERE id = ?', 'en_curso', now(), m.path_id);
  }
  res.json({ ok: true, gained, lost });
});

// ---------- Actividades ----------
richRouter.post('/modules/:id/activities', (req, res) => {
  const m = q('SELECT * FROM modules WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!m) return res.status(404).json({ error: 'No existe ese módulo.' });
  const title = String(req.body?.title || '').trim().slice(0, 90);
  if (!title) return res.status(400).json({ error: 'Ingresá un título para la actividad.' });
  const kind = KIND_ACTIVITY.includes(req.body?.kind) ? req.body.kind : 'practica';
  const id = run('INSERT INTO activities (module_id, user_id, title, kind, created_at) VALUES (?,?,?,?,?)',
    m.id, req.userId, title, kind, now()).lastInsertRowid;
  const moduleState = syncModuleFromActivities(m.id, req.userId);
  res.status(201).json({ activity: rowToJson(q('SELECT * FROM activities WHERE id = ?', id)), module: moduleState.status, gained: moduleState.gained, lost: moduleState.lost });
});

richRouter.put('/activities/:id', (req, res) => {
  const a = q('SELECT * FROM activities WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!a) return res.status(404).json({ error: 'No existe esa actividad.' });
  const status = ACT_STATUS.includes(req.body?.status) ? req.body.status : a.status;
  const title = req.body?.title !== undefined ? String(req.body.title).trim().slice(0, 90) : a.title;
  if (!title) return res.status(400).json({ error: 'El título de la actividad no puede quedar vacío.' });
  const kind = KIND_ACTIVITY.includes(req.body?.kind) ? req.body.kind : a.kind;
  const score = req.body?.score !== undefined && !isNaN(Number(req.body.score))
    ? Math.max(0, Math.min(100, Math.round(Number(req.body.score)))) : a.score;
  run('UPDATE activities SET title = ?, kind = ?, status = ?, score = ?, completed_at = ? WHERE id = ?',
    title, kind, status, score, status === 'completada' ? now() : a.completed_at, a.id);
  let gained = 0;
  let lost = 0;
  if (status === 'completada' && a.status !== 'completada') {
    gained = grantXp(req.userId, 40, 'Completaste una actividad').gained;
  } else if (status !== 'completada' && a.status === 'completada') {
    // Al desmarcar la actividad se resta lo mismo que se había sumado.
    lost = revokeXp(req.userId, 40, 'Revertiste una actividad').lost;
  }
  const moduleState = syncModuleFromActivities(a.module_id, req.userId);
  res.json({ ok: true, gained: gained + moduleState.gained, lost: lost + moduleState.lost, module: moduleState.status });
});

richRouter.delete('/activities/:id', (req, res) => {
  const a = q('SELECT * FROM activities WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!a) return res.status(404).json({ error: 'No existe esa actividad.' });
  run('DELETE FROM activities WHERE id = ?', a.id);
  res.json({ ok: true });
});

// ---------- Evaluaciones ----------
function sanitizeItem(i) {
  let options = [];
  try { options = JSON.parse(i.options_json || '[]'); } catch { options = []; }
  return { id: i.id, prompt: i.prompt, type: i.question_type || 'choice', options,
    expectedAnswer: i.expected_answer || '', explanation: i.explanation, topic: i.topic, difficulty: i.difficulty };
}

// La búsqueda de la materia del banco verificado vive en domain.js (matchBankKey).

function storeItems(assessmentId, userId, subjectId, items) {
  items.forEach(it => {
    run('INSERT INTO assessment_items (assessment_id, user_id, subject_id, prompt, options_json, correct, explanation, topic, difficulty, answer, question_type, expected_answer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
      assessmentId, userId, subjectId,
      String(it.q || it.prompt || '').slice(0, 500),
      JSON.stringify(Array.isArray(it.options) ? it.options.map(o => String(o).slice(0, 200)) : []),
      Number(it.correct) || 0,
      String(it.explanation || '').slice(0, 400),
      String(it.topic || '').slice(0, 80),
      Number(it.d || it.difficulty || 1),
      -1, it.type === 'development' ? 'development' : 'choice', String(it.expectedAnswer || '').slice(0, 1200));
  });
}

richRouter.post('/assessments/generate', async (req, res) => {
  const subject = req.body?.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
  const kind = ['inicial', 'seguimiento', 'tema'].includes(req.body?.kind) ? req.body.kind : 'inicial';
  const format = ['choice', 'mixed', 'development'].includes(req.body?.question_format) ? req.body.question_format : 'choice';
  const count = Math.max(3, Math.min(10, Number(req.body?.count) || 5));
  if (!subject) return res.status(400).json({ error: 'Elegí la materia a evaluar.' });

  const key = matchBankKey(subject.name);
  let items = null;
  let title = `Evaluación ${kind === 'inicial' ? 'inicial' : kind === 'tema' ? 'de tema' : 'de seguimiento'} de ${subject.name}`;
  let used = 'banco';

  if (key && format === 'choice') {
    items = bankQuiz(key, count, 2, subject.id);
  } else if (aiConfigured()) {
    used = 'ia';
    try {
      const desired = format === 'choice' ? 'Todas las preguntas deben ser de opción múltiple.'
        : format === 'development' ? 'Todas las preguntas deben ser de desarrollo, sin opciones ni respuesta de selección.'
          : `Combiná preguntas de opción múltiple y de desarrollo, con al menos una de cada tipo (aproximadamente ${Math.ceil(count / 2)} de opción múltiple).`;
      const task = `Generá una evaluación de nivel ${kind} para la materia "${subject.name}". Objetivo: ${subject.goal || 'no especificado'}.
Formato pedido: ${desired}
Devolvé SOLO un objeto JSON con esta forma:
{"title":"título corto","items":[{"type":"choice","q":"pregunta","options":["opA","opB","opC","opD"],"correct":0,"expectedAnswer":"","explanation":"explicación breve","topic":"tema corto","d":1},{"type":"development","q":"consigna abierta","options":[],"correct":-1,"expectedAnswer":"guía de respuesta correcta para que el alumno pueda comparar al entregar","explanation":"criterios o explicación breve","topic":"tema corto","d":1}]}
Reglas: exactamente ${count} ítems; cada ítem debe tener type choice o development según el formato pedido; las preguntas choice llevan 2 a 4 opciones y un correct válido desde 0; las de desarrollo no llevan opciones y sí expectedAnswer; todo en español claro.`;
      const out = await completeJSON({ system: buildJSONSystem(task), messages: [{ role: 'user', content: 'Generá la evaluación ahora. Solo el JSON.' }] });
      let raw = out && Array.isArray(out.items) ? out.items : [];
      // Validación dura: sin ítems bien formados no se guarda nada.
      const valid = raw.map((it, idx) => {
        if (!it || typeof it !== 'object') return null;
        const q = String(it.q || it.prompt || '').trim();
        const type = format === 'choice' ? 'choice' : format === 'development' ? 'development'
          : (it.type === 'development' || it.question_type === 'development' ? 'development' : it.type === 'choice' ? 'choice' : (idx % 2 ? 'development' : 'choice'));
        if (!q || q.length < 5) return null;
        const d = Math.max(1, Math.min(3, Math.round(Number(it.d) || 1)));
        if (type === 'development') {
          const expectedAnswer = String(it.expectedAnswer || it.expected_answer || it.modelAnswer || '').trim();
          if (expectedAnswer.length < 8) return null;
          return { q: q.slice(0, 500), options: [], correct: -1, expectedAnswer: expectedAnswer.slice(0, 1200), explanation: String(it.explanation || '').slice(0, 400), topic: String(it.topic || subject.name).slice(0, 80), d, type };
        }
        let options = Array.isArray(it.options) ? it.options.map(o => String(o).trim()).filter(Boolean) : [];
        let correct = Number(it.correct);
        if (!Number.isInteger(correct) || typeof it.correct === 'string') {
          const letter = String(it.correct ?? '').trim().toUpperCase().charAt(0);
          correct = 'ABCD'.indexOf(letter);
        }
        options = options.slice(0, 6).map(o => o.slice(0, 200));
        if (options.length < 2 || options.length > 6) return null;
        if (!Number.isInteger(correct) || correct < 0 || correct >= options.length) return null;
        return { q: q.slice(0, 500), options, correct, expectedAnswer: '', explanation: String(it.explanation || '').slice(0, 400), topic: String(it.topic || subject.name).slice(0, 80), d, type };
      }).filter(Boolean).slice(0, 10);
      const hasRequiredTypes = format !== 'mixed' || (valid.some(it => it.type === 'choice') && valid.some(it => it.type === 'development'));
      if (valid.length >= 3 && hasRequiredTypes) {
        title = String(out.title || title).slice(0, 100);
        items = valid;
      } else {
        console.warn(`[assessments] IA devolvió ${raw.length} ítems, solo ${valid.length} válidos`);
      }
    } catch (e) {
      if (e?.message === 'AI_NOT_CONFIGURED') throw e;
      used = 'ia-error';
      console.error('[assessments gen]', e?.message ?? e);
    }
  }

  if (!items && !aiConfigured() && format !== 'choice' && key) {
    return res.status(503).json({ error: 'Los formatos mixto y de desarrollo necesitan IA configurada. El formato solo opción múltiple sigue disponible sin IA para las materias del banco verificado.' });
  }
  if (!items && !aiConfigured()) {
    return res.status(503).json({ error: 'Para evaluar esta materia la IA tiene que estar configurada en el servidor. Para las materias del banco verificado (HTML, JavaScript, Python, Java, SQL, Redes, Matemática, Geografía, Historia, Ciencias, Lengua e Inglés) se evalúa automáticamente sin clave.' });
  }
  if (!items) {
    return res.status(502).json({ error: 'No se pudo generar la evaluación ahora. Probá de nuevo en un momento.' });
  }

  const id = run('INSERT INTO assessments (user_id, subject_id, kind, title, score, total, question_format, created_at) VALUES (?,?,?,?,NULL,?,?,?)',
    req.userId, subject.id, kind, title, items.length, format, now()).lastInsertRowid;
  storeItems(id, req.userId, subject.id, items);

  const stored = qa('SELECT * FROM assessment_items WHERE assessment_id = ? ORDER BY id', id);
  const detail = stored.map(sanitizeItem);
  run('UPDATE assessments SET detail_json = ? WHERE id = ?', JSON.stringify(detail), id);
  res.status(201).json({ assessment: rowToJson(q('SELECT * FROM assessments WHERE id = ?', id)), items: detail.map(({ expectedAnswer, ...item }) => item) });
});

richRouter.get('/assessments', (req, res) => {
  const rows = qa('SELECT a.*, s.name AS subject_name FROM assessments a LEFT JOIN subjects s ON s.id = a.subject_id WHERE a.user_id = ? ORDER BY a.created_at DESC', req.userId);
  res.json({ assessments: rows.map(rowToJson) });
});

richRouter.get('/assessments/:id', (req, res) => {
  const a = q('SELECT * FROM assessments WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!a) return res.status(404).json({ error: 'No existe esa evaluación.' });
  const items = qa('SELECT * FROM assessment_items WHERE assessment_id = ? ORDER BY id', a.id);
  const answered = Boolean(a.finished_at);
  const subject = a.subject_id ? loadSubjectSummary(getSubject(req.userId, a.subject_id)) : null;
  res.json({
    assessment: rowToJson(a),
    items: items.map(i => answered ? { ...sanitizeItem(i), correct: i.correct, answer: i.answer, writtenAnswer: i.written_answer || '' } : { ...sanitizeItem(i), expectedAnswer: '' }),
    subject,
    answered,
  });
});

richRouter.post('/assessments/:id/submit', (req, res) => {
  const a = q('SELECT * FROM assessments WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!a) return res.status(404).json({ error: 'No existe esa evaluación.' });
  if (a.finished_at) return res.status(400).json({ error: 'Esta evaluación ya fue respondida.' });
  const answers = req.body?.answers;
  if (!Array.isArray(answers)) return res.status(400).json({ error: 'Faltan las respuestas.' });

  const items = qa('SELECT * FROM assessment_items WHERE assessment_id = ? ORDER BY id', a.id);
  const missing = items.some((it, idx) => it.question_type === 'development'
    ? !String(answers[idx] ?? '').trim()
    : !Number.isInteger(answers[idx]) || answers[idx] < 0 || answers[idx] >= JSON.parse(it.options_json || '[]').length);
  if (missing) return res.status(400).json({ error: 'Respondé todas las preguntas antes de entregar.' });
  const results = items.map((it, idx) => {
    const ans = answers[idx];
    if (it.question_type === 'development') {
      const written = String(ans || '').trim().slice(0, 5000);
      run('UPDATE assessment_items SET written_answer = ? WHERE id = ?', written, it.id);
      return { id: it.id, prompt: it.prompt, type: 'development', writtenAnswer: written, expectedAnswer: it.expected_answer, explanation: it.explanation, topic: it.topic, ok: null };
    }
    const valid = Number.isInteger(ans) && ans >= 0 && ans < JSON.parse(it.options_json || '[]').length ? ans : -1;
    run('UPDATE assessment_items SET answer = ? WHERE id = ?', valid, it.id);
    return { id: it.id, prompt: it.prompt, type: 'choice', options: JSON.parse(it.options_json || '[]'), correct: it.correct, answer: valid, explanation: it.explanation, topic: it.topic, ok: valid === it.correct };
  });
  const objective = results.filter(r => r.type === 'choice');
  const okCount = objective.filter(r => r.ok).length;
  const total = objective.length;
  const pct = total ? Math.round(okCount / total * 100) : null;
  run('UPDATE assessments SET score = ?, total = ?, finished_at = ? WHERE id = ?', total ? okCount : null, total, now(), a.id);

  // Adaptación pedagógica: ajustar temas según resultados.
  if (a.subject_id) {
    const cache = {};
    results.filter(r => r.type === 'choice').forEach(r => {
      const label = r.topic.toLowerCase().trim();
      let t = cache[label];
      if (!t) {
        t = q('SELECT * FROM topics WHERE subject_id = ? AND lower(name) = lower(?)', a.subject_id, label.trim());
        if (!t) t = q('SELECT * FROM topics WHERE subject_id = ? AND instr(lower(name), lower(?)) > 0', a.subject_id, label.slice(0, 8));
        cache[label] = t;
      }
      if (!t) return;
      if (r.ok) {
        const conf = Math.min(3, (t.confidence || 0) + 1);
        const status = conf >= 2 ? 'dominado' : 'aprendiendo';
        run('UPDATE topics SET confidence = ?, status = ?, updated_at = ? WHERE id = ?', conf, status, now(), t.id);
      } else {
        run('UPDATE topics SET status = ?, updated_at = ? WHERE id = ?', t.status === 'dominado' ? 'aprendiendo' : 'dificultad', now(), t.id);
      }
    });
  }

  const xp = grantXp(req.userId, total ? Math.round(okCount / total * 50) : 25, 'Completaste una evaluación', a.subject_id || null);
  res.json({ ok: true, score: total ? okCount : null, total, pct, results, gained: xp.gained, unlocked: xp.unlocked });
});
