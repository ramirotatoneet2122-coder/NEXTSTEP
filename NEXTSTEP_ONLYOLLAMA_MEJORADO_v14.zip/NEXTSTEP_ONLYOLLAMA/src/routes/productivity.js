// Objetivos y proyectos, tareas, recursos y sesiones de estudio.
import { Router } from 'express';
import { run, q, qa, rowToJson, now } from '../db.js';
import { requireAuth } from '../auth.js';
import { grantXp, revokeXp } from '../xp.js';
import { getSubject } from '../domain.js';
import { COURSES, GOALS as GOAL_TYPES, TOPICS } from '../data.js';
import { aiConfigured, completeJSON } from '../llm.js';
import { buildJSONSystem } from '../prompt.js';

export const productivityRouter = Router();
productivityRouter.use(requireAuth);

// ---------- Objetivos ----------
function goalWithTasks(g) {
  const tasks = qa('SELECT * FROM tasks WHERE goal_id = ? ORDER BY position, id', g.id).map(rowToJson);
  const done = tasks.filter(t => t.done).length;
  return {
    ...rowToJson(g),
    tasks,
    tasksTotal: tasks.length,
    tasksDone: done,
    progress: tasks.length ? Math.round(done / tasks.length * 100) : 0,
  };
}

productivityRouter.get('/goals', (req, res) => {
  const rows = qa('SELECT * FROM goals WHERE user_id = ? ORDER BY CASE status WHEN ? THEN 0 ELSE 1 END, created_at DESC',
    req.userId, 'activo');
  res.json({ goals: rows.map(goalWithTasks) });
});

productivityRouter.post('/goals', (req, res) => {
  const title = String(req.body?.title || '').trim().slice(0, 120);
  if (!title) return res.status(400).json({ error: 'Ingresá el título del objetivo.' });
  const description = String(req.body?.description || '').trim().slice(0, 600);
  const deadline = req.body?.deadline ? String(req.body.deadline).slice(0, 10) : null;
  const subject = req.body?.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
  const id = run('INSERT INTO goals (user_id, subject_id, title, description, deadline, created_at, updated_at) VALUES (?,?,?,?,?,?,?)',
    req.userId, subject ? subject.id : null, title, description, deadline, now(), now()).lastInsertRowid;
  grantXp(req.userId, 25, 'Registraste un objetivo');
  const tasks = Array.isArray(req.body?.tasks) ? req.body.tasks.slice(0, 15) : [];
  tasks.forEach((t, i) => {
    const tt = String(t).trim().slice(0, 140);
    if (tt) run('INSERT INTO tasks (goal_id, user_id, title, position, created_at) VALUES (?,?,?,?,?)', id, req.userId, tt, i, now());
  });
  res.status(201).json({ goal: goalWithTasks(q('SELECT * FROM goals WHERE id = ?', id)) });
});

productivityRouter.put('/goals/:id', (req, res) => {
  const g = q('SELECT * FROM goals WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!g) return res.status(404).json({ error: 'No existe ese objetivo.' });
  const title = req.body?.title !== undefined ? String(req.body.title).trim().slice(0, 120) : g.title;
  const description = req.body?.description !== undefined ? String(req.body.description).slice(0, 600) : g.description;
  const deadline = req.body?.deadline !== undefined ? (String(req.body.deadline).slice(0, 10) || null) : g.deadline;
  const status = ['activo', 'hecho', 'abandonado'].includes(req.body?.status) ? req.body.status : g.status;
  run('UPDATE goals SET title = ?, description = ?, deadline = ?, status = ?, updated_at = ? WHERE id = ?',
    title, description, deadline, status, now(), g.id);
  if (status === 'hecho' && g.status !== 'hecho') grantXp(req.userId, 120, 'Alcanzaste un objetivo');
  else if (status !== 'hecho' && g.status === 'hecho') revokeXp(req.userId, 120, 'Reabriste un objetivo');
  res.json({ goal: goalWithTasks(q('SELECT * FROM goals WHERE id = ?', g.id)) });
});

productivityRouter.delete('/goals/:id', (req, res) => {
  const g = q('SELECT * FROM goals WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!g) return res.status(404).json({ error: 'No existe ese objetivo.' });
  run('DELETE FROM goals WHERE id = ?', g.id);
  res.json({ ok: true });
});

// Descomponer un objetivo en tareas con IA (o marcarlo para cuando haya IA configurada).
productivityRouter.post('/goals/generate', async (req, res) => {
  const title = String(req.body?.title || '').trim().slice(0, 120);
  const description = String(req.body?.description || '').trim().slice(0, 600);
  const deadline = req.body?.deadline ? String(req.body.deadline).slice(0, 10) : null;
  if (!title) return res.status(400).json({ error: 'Ingresá el título del objetivo.' });
  const subject = req.body?.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
  const subjName = subject ? subject.name : 'general';

  const gid = run('INSERT INTO goals (user_id, subject_id, title, description, deadline, created_at, updated_at) VALUES (?,?,?,?,?,?,?)',
    req.userId, subject ? subject.id : null, title, description, deadline, now(), now()).lastInsertRowid;
  grantXp(req.userId, 25, 'Registraste un objetivo');

  if (!aiConfigured()) {
    return res.status(201).json({ goal: goalWithTasks(q('SELECT * FROM goals WHERE id = ?', gid)), aiPending: true });
  }

  try {
    const task = `La persona tiene este objetivo: "${title}". Descripción: ${description}. Fecha límite: ${deadline || 'sin fecha'}. Materia: ${subjName}.
Descomponelo en una planificación realista de 4 a 10 tareas alcanzables, ordenadas (las primeras son las que conviene hacer antes). Devolvé EXCLUSIVAMENTE JSON: {"tasks": ["tarea 1", "tarea 2", ...]}.`;
    const out = await completeJSON({ system: buildJSONSystem(task), messages: [{ role: 'user', content: 'Descomponé el objetivo.' }] });
    const tasks = Array.isArray(out?.tasks) ? out.tasks.slice(0, 15).map(t => String(t).slice(0, 140)).filter(Boolean) : [];
    tasks.forEach((t, i) => run('INSERT INTO tasks (goal_id, user_id, title, position, created_at) VALUES (?,?,?,?,?)', gid, req.userId, t, i, now()));
    res.status(201).json({ goal: goalWithTasks(q('SELECT * FROM goals WHERE id = ?', gid)) });
  } catch {
    res.status(201).json({ goal: goalWithTasks(q('SELECT * FROM goals WHERE id = ?', gid)), aiPending: true });
  }
});

// ---------- Tareas ----------
productivityRouter.post('/goals/:id/tasks', (req, res) => {
  const g = q('SELECT * FROM goals WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!g) return res.status(404).json({ error: 'No existe ese objetivo.' });
  const title = String(req.body?.title || '').trim().slice(0, 140);
  if (!title) return res.status(400).json({ error: 'Ingresá la tarea.' });
  const pos = q('SELECT COUNT(*) AS c FROM tasks WHERE goal_id = ?', g.id).c;
  const id = run('INSERT INTO tasks (goal_id, user_id, title, position, created_at) VALUES (?,?,?,?,?)', g.id, req.userId, title, pos, now()).lastInsertRowid;
  res.status(201).json({ task: rowToJson(q('SELECT * FROM tasks WHERE id = ?', id)) });
});

productivityRouter.put('/tasks/:id', (req, res) => {
  const t = q('SELECT * FROM tasks WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!t) return res.status(404).json({ error: 'No existe esa tarea.' });
  const done = req.body?.done ? 1 : 0;
  run('UPDATE tasks SET done = ? WHERE id = ?', done, t.id);
  let gained = 0;
  let lost = 0;
  if (done && !t.done) gained = grantXp(req.userId, 30, 'Completaste una tarea del objetivo').gained;
  else if (!done && t.done) lost = revokeXp(req.userId, 30, 'Revertiste una tarea del objetivo').lost;
  const g = q('SELECT * FROM goals WHERE id = ?', t.goal_id);
  res.json({ task: rowToJson(q('SELECT * FROM tasks WHERE id = ?', t.id)), goal: goalWithTasks(g), gained, lost });
});

productivityRouter.delete('/tasks/:id', (req, res) => {
  const t = q('SELECT * FROM tasks WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!t) return res.status(404).json({ error: 'No existe esa tarea.' });
  run('DELETE FROM tasks WHERE id = ?', t.id);
  res.json({ ok: true });
});

// ---------- Recursos ----------
productivityRouter.get('/resources', (req, res) => {
  const rows = qa('SELECT r.*, s.name AS subject_name FROM resources r LEFT JOIN subjects s ON s.id = r.subject_id WHERE r.user_id = ? ORDER BY r.created_at DESC', req.userId);
  res.json({ resources: rows.map(rowToJson) });
});

productivityRouter.post('/resources', (req, res) => {
  const title = String(req.body?.title || '').trim().slice(0, 120);
  if (!title) return res.status(400).json({ error: 'Ingresá el título del recurso.' });
  const url = String(req.body?.url || '').trim().slice(0, 300);
  const kind = ['curso', 'documentacion', 'tutorial', 'video', 'proyecto', 'otro'].includes(req.body?.kind) ? req.body.kind : 'otro';
  const notes = String(req.body?.notes || '').trim().slice(0, 400);
  const subject = req.body?.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
  // Regla de oro: la URL tiene que ser http(s).
  const cleanUrl = /^https?:\/\//.test(url) ? url : (url ? 'https://' + url : '');
  const id = run('INSERT INTO resources (user_id, subject_id, title, url, kind, notes, created_at) VALUES (?,?,?,?,?,?,?)',
    req.userId, subject ? subject.id : null, title, cleanUrl.slice(0, 300), kind, notes, now()).lastInsertRowid;
  res.status(201).json({ resource: rowToJson(q('SELECT * FROM resources WHERE id = ?', id)) });
});

productivityRouter.delete('/resources/:id', (req, res) => {
  const r = q('SELECT * FROM resources WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!r) return res.status(404).json({ error: 'No existe ese recurso.' });
  run('DELETE FROM resources WHERE id = ?', r.id);
  res.json({ ok: true });
});

// Recomendaciones de recursos: los enlaces SIEMPRE vienen del banco verificado (COURSES).
productivityRouter.get('/resources/recommended', (req, res) => {
  const subjects = qa('SELECT * FROM subjects WHERE user_id = ? AND status = ?', req.userId, 'active');
  const goalRow = q('SELECT * FROM goals WHERE user_id = ? AND status = ? LIMIT 1', req.userId, 'activo');
  const suggestions = [];
  subjects.forEach(s => {
    const key = matchBank(s.name);
    COURSES.forEach(c => {
      if (key && c.topics.includes(key)) {
        suggestions.push({
          title: c.title, org: c.org, url: c.url, kind: c.kind,
          free: c.free, effort: c.effort, min: c.min,
          subjectName: s.name, wouldHelp: c.goals.map(g => GOAL_TYPES[g]).filter(Boolean).slice(0, 2),
        });
      } else if (s.goal && c.goals.some(g => GOAL_TYPES[g] && s.goal.toLowerCase().includes(GOAL_TYPES[g].toLowerCase().split(' ')[0]))) {
        const exists = suggestions.some(x => x.url === c.url && x.subjectName === s.name);
        if (!exists) suggestions.push({
          title: c.title, org: c.org, url: c.url, kind: c.kind,
          free: c.free, effort: c.effort, min: c.min,
          subjectName: s.name, wouldHelp: c.goals.map(g => GOAL_TYPES[g]).filter(Boolean).slice(0, 2),
        });
      }
    });
  });
  res.json({ recommendations: suggestions.slice(0, 8) });
});

function matchBank(name) {
  const n = String(name).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const aliases = {
    html: ['html'], js: ['javascript', 'js', 'scripts'], java: ['java'], python: ['python', 'py'],
    sql: ['sql', 'base de datos', 'bases de datos', 'database'], redes: ['redes', 'network'],
    mate: ['matematica', 'matematicas', 'algebra', 'mate'], geografia: ['geografia'], historia: ['historia'],
    ciencia: ['ciencia', 'ciencias', 'naturales', 'biologia', 'fisica', 'quimica'],
    lengua: ['lengua', 'castellano', 'espanol'], ingles: ['ingles', 'english', 'idioma'],
    git: ['git', 'github', 'control de versiones'],
  };
  for (const k of Object.keys(aliases)) if (aliases[k].some(a => a && n.includes(a))) return k;
  return null;
}

// ---------- Sesiones de estudio ----------
productivityRouter.post('/sessions', (req, res) => {
  const minutes = Math.max(1, Math.min(600, Math.round(Number(req.body?.minutes) || 25)));
  const kind = String(req.body?.kind || 'estudio').slice(0, 30);
  const subject = req.body?.subject_id ? getSubject(req.userId, Number(req.body.subject_id)) : null;
  const id = run('INSERT INTO study_sessions (user_id, subject_id, minutes, kind, started_at, ended_at) VALUES (?,?,?,?,?,?)',
    req.userId, subject ? subject.id : null, minutes, kind, now(), now()).lastInsertRowid;
  const gained = minutes >= 10 ? grantXp(req.userId, 20, 'Registraste una sesión de estudio', subject ? subject.id : null).gained : 0;
  res.status(201).json({ session: rowToJson(q('SELECT * FROM study_sessions WHERE id = ?', id)), gained });
});

productivityRouter.get('/sessions', (req, res) => {
  const rows = qa(`SELECT s.*, su.name AS subject_name FROM study_sessions s LEFT JOIN subjects su ON su.id = s.subject_id WHERE s.user_id = ? ORDER BY s.started_at DESC LIMIT 60`, req.userId);
  res.json({ sessions: rows.map(rowToJson) });
});