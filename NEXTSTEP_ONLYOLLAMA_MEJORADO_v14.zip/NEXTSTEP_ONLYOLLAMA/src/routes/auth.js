// Autenticación, perfil, preferencias y gestión de datos personales.
import crypto from 'node:crypto';
import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { getUser, getUserByUsername, createUser, getPreferences, setPreference, q, qa, run, tx, now } from '../db.js';
import { hashPassword, verifyPassword, createToken, deleteToken, requireAuth, validateCredentials, purgeUserData, purgeTokens } from '../auth.js';
import { userStats, levelInfo, ACHIEVEMENTS } from '../xp.js';
import { LEARNING_DEFAULTS, TEACHER_DEFAULTS } from '../prompt.js';
import { sendVerificationEmail } from '../email.js';

export const authRouter = Router();

const registrationLimiter = rateLimit({
  windowMs: 15 * 60_000,
  limit: 6,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Se pidieron muchas confirmaciones desde esta conexión. Esperá 15 minutos y probá de nuevo.' },
});

authRouter.post('/register', registrationLimiter, validateCredentials, async (req, res) => {
  const { username, password, displayName } = req.body;
  const email = String(req.body?.email || '').trim().toLowerCase();
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'Ingresá un correo electrónico válido.' });
  }
  if (getUserByUsername(username)) {
    return res.status(409).json({ error: 'Ese nombre de usuario ya está en uso. Elegí otro.' });
  }
  if (q('SELECT id FROM users WHERE email = ? COLLATE NOCASE', email)) {
    return res.status(409).json({ error: 'Ese correo ya está asociado a una cuenta.' });
  }

  const stamp = now();
  run('DELETE FROM pending_registrations WHERE expires_at <= ?', stamp);
  const pending = q('SELECT * FROM pending_registrations WHERE username = ? COLLATE NOCASE OR email = ? COLLATE NOCASE', username, email);
  if (pending && (pending.username.toLowerCase() !== username.toLowerCase() || pending.email.toLowerCase() !== email)) {
    return res.status(409).json({ error: 'Ya hay una solicitud de registro pendiente con ese usuario o correo.' });
  }

  const token = crypto.randomBytes(32).toString('hex');
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const pendingValues = {
    username, email, passHash: hashPassword(password),
    displayName: String(displayName || username).trim().slice(0, 40),
    tokenHash, createdAt: stamp, expiresAt: new Date(Date.now() + 30 * 60_000).toISOString(),
  };
  let pendingId;
  if (pending) {
    pendingId = pending.id;
    run(`UPDATE pending_registrations SET pass_hash=?,display_name=?,token_hash=?,created_at=?,expires_at=? WHERE id=?`,
      pendingValues.passHash, pendingValues.displayName, tokenHash, stamp, pendingValues.expiresAt, pendingId);
  } else {
    pendingId = run(`INSERT INTO pending_registrations (username,email,pass_hash,display_name,token_hash,created_at,expires_at)
      VALUES (?,?,?,?,?,?,?)`, username, email, pendingValues.passHash, pendingValues.displayName, tokenHash, stamp, pendingValues.expiresAt).lastInsertRowid;
  }

  try {
    await sendVerificationEmail({ email, displayName: pendingValues.displayName, token });
    return res.status(202).json({ pending: true, email });
  } catch (error) {
    run('DELETE FROM pending_registrations WHERE id = ?', pendingId);
    console.error('[email verification] no se pudo enviar el correo:', error?.code || error?.message || error);
    if (error?.code === 'EMAIL_NOT_CONFIGURED') {
      return res.status(503).json({ error: 'El servidor todavía no tiene configurado el envío de correos. Revisá BREVO_API_KEY, EMAIL_FROM y APP_BASE_URL.' });
    }
    return res.status(502).json({ error: 'No pudimos enviar el correo de confirmación. Revisá la dirección e intentá de nuevo más tarde.' });
  }
});

authRouter.get('/verify-email', (req, res) => {
  const token = String(req.query?.token || '');
  if (!/^[a-f0-9]{64}$/.test(token)) return res.status(400).send('El enlace de confirmación no es válido. Volvé a crear la cuenta.');
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const pending = q('SELECT id FROM pending_registrations WHERE token_hash = ? AND expires_at > ?', tokenHash, now());
  if (!pending) return res.status(410).send('El enlace venció o ya fue usado. Volvé a crear la cuenta para recibir otro.');
  res.type('html').send(`<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Confirmar correo · NEXTSTEP</title><body style="font:16px system-ui;max-width:560px;margin:12vh auto;padding:24px;color:#222"><h1>NEXTSTEP</h1><h2>Confirmá tu correo</h2><p>Al confirmar, se terminará de crear tu cuenta y ya vas a poder iniciar sesión.</p><form method="post" action="/api/auth/verify-email"><input type="hidden" name="token" value="${token}"><button style="padding:12px 18px;border:0;border-radius:10px;background:#783cf5;color:white;font-weight:700;cursor:pointer">Confirmar correo y crear cuenta</button></form></body></html>`);
});

authRouter.post('/verify-email', (req, res) => {
  const token = String(req.body?.token || '');
  const redirect = emailNotice => {
    const base = process.env.APP_BASE_URL || 'http://localhost:3000';
    const url = new URL('/', base);
    url.searchParams.set('email', emailNotice);
    url.hash = emailNotice === 'verified' ? '/login' : '/register';
    return res.redirect(303, url.toString());
  };
  if (!/^[a-f0-9]{64}$/.test(token)) return redirect('invalid');
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const pending = q('SELECT * FROM pending_registrations WHERE token_hash = ? AND expires_at > ?', tokenHash, now());
  if (!pending) return redirect('invalid');
  if (getUserByUsername(pending.username) || q('SELECT id FROM users WHERE email = ? COLLATE NOCASE', pending.email)) {
    run('DELETE FROM pending_registrations WHERE id = ?', pending.id);
    return redirect('conflict');
  }
  try {
    tx(() => {
      createUser({ username: pending.username, email: pending.email, passHash: pending.pass_hash, displayName: pending.display_name });
      run('DELETE FROM pending_registrations WHERE id = ?', pending.id);
    });
    return redirect('verified');
  } catch (error) {
    console.error('[email verification] no se pudo finalizar el registro:', error?.message || error);
    return redirect('error');
  }
});

authRouter.post('/login', (req, res) => {
  const username = String(req.body?.username || '').trim();
  const password = String(req.body?.password || '');
  if (!username || !password) return res.status(400).json({ error: 'Ingresá tu usuario y contraseña.' });
  const user = getUserByUsername(username);
  if (!user || !verifyPassword(password, user.pass_hash)) {
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos.' });
  }
  if (!user.email_verified) return res.status(403).json({ error: 'Tu correo todavía no está confirmado. Abrí el enlace que te enviamos para activar tu cuenta.' });
  const token = createToken(user.id);
  res.json({ token, user: publicUser(user) });
});

authRouter.post('/logout', (req, res) => {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (token) deleteToken(token);
  res.json({ ok: true });
});

function publicUser(u) {
  return { id: u.id, username: u.username, email: u.email || '', emailVerified: !!u.email_verified, displayName: u.display_name, language: u.language, createdAt: u.created_at };
}

function prefsPayload(userId) {
  const prefs = getPreferences(userId);
  return {
    user: publicUser(getUser(userId)),
    preferences: prefs,
    defaults: { learning: LEARNING_DEFAULTS, teacher: TEACHER_DEFAULTS },
    stats: userStats(userId),
    level: levelInfo(userStats(userId).xp),
  };
}

authRouter.get('/me', requireAuth, (req, res) => {
  res.json(prefsPayload(req.userId));
});

authRouter.put('/prefs/:field', requireAuth, (req, res) => {
  const field = req.params.field;
  if (!['theme', 'learning', 'teacher', 'ui'].includes(field)) {
    return res.status(400).json({ error: 'Preferencia inválida.' });
  }
  const value = req.body?.value;
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return res.status(400).json({ error: 'La preferencia tiene que ser un objeto.' });
  }
  const prefs = setPreference(req.userId, field, JSON.parse(JSON.stringify(value)));
  res.json({ ok: true, preferences: prefs });
});

authRouter.put('/profile', requireAuth, (req, res) => {
  const { displayName, language } = req.body || {};
  const user = getUser(req.userId);
  const name = typeof displayName === 'string' && displayName.trim()
    ? displayName.trim().slice(0, 40) : user.display_name;
  const lang = ['es', 'en', 'pt'].includes(language) ? language : user.language;
  run('UPDATE users SET display_name = ?, language = ? WHERE id = ?', name, lang, req.userId);
  res.json({ ok: true, user: publicUser(getUser(req.userId)) });
});

// Exportar los datos del usuario (privacidad: el alumno puede ver qué guardamos).
authRouter.get('/data', requireAuth, (req, res) => {
  const uid = req.userId;
  const dump = {
    user: publicUser(getUser(uid)),
    preferences: getPreferences(uid),
    subjects: qa('SELECT * FROM subjects WHERE user_id = ?', uid),
    goals: qa('SELECT * FROM goals WHERE user_id = ?', uid),
    conversations: qa('SELECT * FROM conversations WHERE user_id = ?', uid),
    paths: qa('SELECT * FROM paths WHERE user_id = ?', uid),
    assessments: qa('SELECT * FROM assessments WHERE user_id = ?', uid),
    calendarEvents: qa('SELECT * FROM calendar_events WHERE user_id = ?', uid),
    resources: qa('SELECT * FROM resources WHERE user_id = ?', uid),
    achievements: qa('SELECT * FROM achievements WHERE user_id = ?', uid),
    xpEvents: qa('SELECT * FROM xp_events WHERE user_id = ?', uid),
    studySessions: qa('SELECT * FROM study_sessions WHERE user_id = ?', uid),
  };
  res.json(dump);
});

// Eliminar la cuenta y todos los datos.
authRouter.delete('/account', requireAuth, (req, res) => {
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  const user = getUser(req.userId);
  if (!password || !user || !verifyPassword(password, user.pass_hash)) {
    return res.status(401).json({ error: 'La contraseña es incorrecta. La cuenta no se eliminó.' });
  }
  purgeTokens(req.userId);
  purgeUserData(req.userId);
  res.json({ ok: true });
});

// Logros conocidos (catálogo) y obtenidos.
authRouter.get('/achievements', requireAuth, (req, res) => {
  const earned = qa('SELECT code, title, created_at FROM achievements WHERE user_id = ? ORDER BY created_at', req.userId);
  const catalog = Object.entries(ACHIEVEMENTS).map(([code, v]) => ({
    code, title: v.title, desc: v.desc,
    earned: earned.some(e => e.code === code),
    earnedAt: earned.find(e => e.code === code)?.created_at ?? null,
  }));
  res.json({ catalog });
});
