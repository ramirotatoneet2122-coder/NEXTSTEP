import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import rateLimit from 'express-rate-limit';
import { buildSystem, GREETING, START_QUICK, ALLOWED_URLS, buildEvaluationSystem, buildEvaluationPrompt, buildPathSystem, buildPathPrompt } from './src/prompt.js';
import { streamChat, completeJson, providerInfo, missingConfigMessage } from './src/llm.js';
import { RANKS, rankOf, TOPICS, COURSES, TEMPLATES } from './src/data.js';
import { authUser, requireAuth, hashPassword, verifyPassword, cleanUserInput, createLoginSession, sessionCookie, clearCookie } from './src/auth.js';
import { earn } from './src/xp.js';
import * as db from './src/db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;

const app = express();
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(authUser);

const limiter = rateLimit({
  windowMs: 60_000,
  limit: Number(process.env.RATE_LIMIT_PER_MIN) || 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Hiciste muchas consultas seguidas. Esperá un minuto y probá de nuevo.' },
});

/* ============================ Utilidades ============================ */
const str = (v, max) => String(v ?? '').slice(0, max ?? 4000);
const int = v => { const n = Number(v); return Number.isFinite(n) ? Math.trunc(n) : null; };
const bool = v => v === true || v === 1 || v === '1' || v === 'true';

function friendlyError(e) {
  const s = e?.status;
  if (s === 401 || s === 403) return 'La clave del servicio de IA no es válida.';
  if (s === 429) return 'La IA tiene muchas consultas ahora. Probá de nuevo en un rato.';
  if (s === 529 || s === 503) return 'La IA está saturada. Probá de nuevo en un momento.';
  return 'No se pudo usar la IA ahora.';
}

// Contexto del alumno que se le pasa al profesor en cada sesión. Solo datos autorizados y relevantes.
function buildContext(userId, opts = {}) {
  const profile = db.getProfile(userId);
  const subjects = db.listSubjects(userId).map(s => ({
    id: s.id, name: s.name, goal: s.goal, current_level: s.current_level,
    mastery: s.mastery, status: s.status,
    topics: db.listTopics(s.id).filter(t => t.state !== 'pendiente').map(t => ({ name: t.name, state: t.state })),
  }));
  const activeSubjects = subjects.filter(s => s.status === 'activa');
  const goals = db.listGoals(userId).filter(g => g.status === 'activo').slice(0, 5)
    .map(g => ({ title: g.title, due_date: g.due_date, progress: g.progress }));
  const evals = db.listEvaluations(userId).filter(e => e.status === 'completada').slice(0, 3)
    .map(e => ({ title: e.title || 'Evaluación', score: e.score, summary: e.summary }));
  const struggling = [];
  for (const s of activeSubjects) {
    for (const t of db.listTopics(s.id)) {
      if (t.state === 'dificultad') struggling.push(`${t.name} (${s.name})`);
    }
  }
  let relevantResources = [];
  const names = activeSubjects.map(s => s.name.toLowerCase());
  relevantResources = COURSES.filter(c => c.topics.some(t => names.some(n => n.includes(t) || TOPICS[t]?.name.toLowerCase().includes(n) || n.includes(TOPICS[t]?.name.toLowerCase()))))
    .map(c => `${c.title} (${c.org}) · ${c.kind}, ${c.free ? 'gratis' : 'pago'} · ${c.url}`);
  return {
    studentName: profile.nickname || undefined,
    date: new Date().toISOString().slice(0, 10),
    subjects: activeSubjects,
    goals,
    recentEvaluations: evals,
    struggling: struggling.slice(0, 8),
    relevantResources: relevantResources.slice(0, 5),
    mode: opts.mode,
    preferences: profile.preferences,
  };
}

/* ============================ Público: salud y meta ============================ */
app.get('/api/health', (_req, res) => {
  const { provider, model, ready } = providerInfo();
  res.json({ ok: true, provider, model, ia: ready });
});
app.get('/api/meta', (_req, res) => {
  res.json({ greeting: GREETING, startQuick: START_QUICK, allowedUrls: ALLOWED_URLS });
});

/* ============================ Autenticación ============================ */
app.post('/api/auth/signup', async (req, res) => {
  const input = cleanUserInput(req.body || {});
  if (input.error) return res.status(400).json({ error: input.error });
  if (db.getUserByEmail(input.email)) return res.status(409).json({ error: 'Ya existe una cuenta con ese email.' });
  const userId = db.createUser({ name: input.name, email: input.email, passHash: hashPassword(input.password) });
  const token = await createLoginSession(userId);
  res.set('Set-Cookie', sessionCookie(token));
  res.status(201).json({ ok: true });
});

app.post('/api/auth/login', async (req, res) => {
  const email = str(req.body?.email).trim().toLowerCase();
  const password = String(req.body?.password || '');
  const user = db.getUserByEmail(email);
  if (!user || !verifyPassword(password, user.pass_hash)) return res.status(401).json({ error: 'Email o contraseña incorrectos.' });
  const token = await createLoginSession(user.id);
  res.set('Set-Cookie', sessionCookie(token));
  res.json({ ok: true });
});

app.post('/api/auth/logout', (req, res) => {
  if (req.user) db.deleteUserSessions(req.user.id);
  res.set('Set-Cookie', clearCookie());
  res.json({ ok: true });
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  const profile = db.getProfile(req.user.id);
  res.json({
    user: { id: req.user.id, name: req.user.name, email: req.user.email },
    profile: {
      nickname: profile.nickname || req.user.name,
      xp: profile.xp, level: profile.level, streak: profile.streak,
      best_streak: profile.best_streak, total_minutes: profile.total_minutes,
      last_study_date: profile.last_study_date, onboarding_done: Boolean(profile.onboarding_done),
      preferences: profile.preferences, appearance: profile.appearance, settings: profile.settings,
    },
  });
});

app.get('/api/dashboard', requireAuth, (req, res) => {
  const profile = db.getProfile(req.user.id);
  const conversations = db.listConversations(req.user.id).slice(0, 4);
  const subjects = db.listSubjects(req.user.id);
  const goals = db.listGoals(req.user.id).filter(g => g.status === 'activo');
  const week = db.minutesByDay(req.user.id, 7);
  const weekMinutes = week.reduce((a, d) => a + Number(d.minutes || 0), 0);
  // Próxima actividad recomendada, basada en datos reales.
  let nextActivity = null;
  const paths = db.listPaths(req.user.id).filter(p => p.status === 'activa');
  outer:
  for (const p of paths) {
    for (const m of db.listModules(p.id)) {
      if (m.state === 'en_curso' || m.state === 'pendiente') {
        const acts = db.listPathActivities(m.id);
        const first = acts.find(a => a.state !== 'completado');
        if (first) { nextActivity = { type: 'ruta', title: first.title, module: m.title, path: p.title, activityId: first.id }; break outer; }
        if (m.state === 'en_curso') { nextActivity = { type: 'ruta', title: m.title, module: m.title, path: p.title }; break outer; }
      }
    }
  }
  const todayStr = new Date().toISOString().slice(0, 10);
  const studiedToday = profile.last_study_date === todayStr;
  const pendingEvals = db.listEvaluations(req.user.id).filter(e => e.status === 'en_curso');
  const lastConv = conversations[0] || null;
  res.json({
    profile: { xp: profile.xp, level: profile.level, streak: profile.streak, best_streak: profile.best_streak, total_minutes: profile.total_minutes, nickname: profile.nickname || req.user.name },
    stats: { total_activities: db.statsOverview(req.user.id).activities, correct_activities: db.statsOverview(req.user.id).correct, evaluations: db.statsOverview(req.user.id).evaluations },
    week_minutes: weekMinutes, minutes_by_day: week, studied_today: studiedToday,
    subjects, goals, conversations,
    next_activity: nextActivity, pending_evaluations: pendingEvals.length, last_conversation: lastConv,
    recommendations: makeRecommendations(req.user.id),
    achievements: db.listAchievements(req.user.id),
  });
});

function makeRecommendations(userId) {
  const out = [];
  const subjects = db.listSubjects(userId).filter(s => s.status === 'activa');
  const paths = db.listPaths(userId).filter(p => p.status === 'activa');
  for (const s of subjects) {
    if (!paths.some(p => p.subject_id === s.id)) {
      out.push({ id: `path-${s.id}`, kind: 'ruta', text: `Empezá una ruta de aprendizaje de ${s.name}.`, subject_id: s.id });
    }
    if (s.mastery < 40) {
      out.push({ id: `eval-${s.id}`, kind: 'evaluacion', text: `Te conviene una evaluación para calibrar tu nivel real en ${s.name}.`, subject_id: s.id });
    }
  }
  const struggling = [];
  for (const s of subjects) for (const t of db.listTopics(s.id)) if (t.state === 'dificultad') struggling.push(t);
  if (struggling.length) {
    out.push({ id: 'repaso', kind: 'repaso', text: `Repasá los temas donde venís flaqueando: ${struggling.slice(0, 3).map(t => t.name).join(', ')}.`, subject_id: struggling[0].subject_id });
  }
  if (db.listGoals(userId).filter(g => g.status === 'activo' && g.progress < 100).length) {
    out.push({ id: 'metas', kind: 'objetivo', text: 'Revisá tus objetivos activos y marcá las tareas que ya hiciste.' });
  }
  return out.slice(0, 4);
}

/* ============================ Conversaciones ============================ */
app.get('/api/conversations', requireAuth, (req, res) => res.json(db.listConversations(req.user.id)));
app.post('/api/conversations', requireAuth, (req, res) => {
  const subjectId = int(req.body?.subject_id) || null;
  if (subjectId && !db.getSubject(req.user.id, subjectId)) return res.status(404).json({ error: 'Materia no encontrada.' });
  const mode = ['explicar', 'practicar', 'evaluar', 'proyecto'].includes(req.body?.mode) ? req.body.mode : 'explicar';
  const id = db.createConversation(req.user.id, { subjectId, title: str(req.body?.title, 60) || 'Nueva sesión', mode });
  res.status(201).json(db.getConversation(req.user.id, id));
});
app.get('/api/conversations/:id', requireAuth, (req, res) => {
  const c = db.getConversation(req.user.id, int(req.params.id));
  if (!c) return res.status(404).json({ error: 'No existe.' });
  res.json({ ...c, messages: db.listMessages(c.id) });
});
app.delete('/api/conversations/:id', requireAuth, (req, res) => {
  db.deleteConversation(req.user.id, int(req.params.id));
  res.json({ ok: true });
});

/* ---------- Chat con streaming ---------- */
app.post('/api/chat', requireAuth, limiter, async (req, res) => {
  if (!providerInfo().ready) return res.status(503).json({ error: missingConfigMessage() });
  const message = str(req.body?.message, 6000).trim();
  if (!message) return res.status(400).json({ error: 'Mensaje vacío.' });
  const userId = req.user.id;

  let convId = int(req.body?.conversation_id);
  let conv = convId ? db.getConversation(userId, convId) : null;
  let subjectId = int(req.body?.subject_id) || conv?.subject_id || null;
  if (subjectId && !db.getSubject(userId, subjectId)) subjectId = null;
  if (!conv) {
    convId = db.createConversation(userId, { subjectId, mode: ['explicar','practicar','evaluar','proyecto'].includes(req.body?.mode) ? req.body.mode : 'explicar' });
    conv = db.getConversation(userId, convId);
  }

  db.addMessage(convId, 'user', message);
  if (conv.title === 'Nueva sesión') {
    db.updateConversation(userId, convId, { title: message.slice(0, 45) + (message.length > 45 ? '…' : '') });
  }
  earn(userId, 'chat_message', `conv:${convId}`);

  const history = db.listMessages(convId).slice(-40).map(m => ({ role: m.role, content: m.content }));
  const profile = db.getProfile(userId);
  const system = buildSystem({ profile, context: buildContext(userId, { mode: conv.mode }) });

  res.set({ 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive' });
  res.flushHeaders();
  const send = o => res.write(`data: ${JSON.stringify(o)}\n\n`);
  const abort = new AbortController();
  let finished = false;
  res.on('close', () => { if (!finished) abort.abort(); });

  let text = '';
  try {
    await streamChat({ system, messages: history, signal: abort.signal, onText: t => { text += t; send({ t }); } });
    db.addMessage(convId, 'assistant', text);
    applyTeacherTags(userId, conv, text);
    send({ done: true, conversation_id: convId });
  } catch (e) {
    const cancelled = e?.name === 'AbortError' || e?.name === 'APIUserAbortError';
    if (!cancelled) {
      console.error('[chat]', e?.status ?? '', e?.message ?? e);
      if (text.trim()) db.addMessage(convId, 'assistant', text);
      if (!res.writableEnded && !res.destroyed) send({ error: friendlyError(e) });
    }
  } finally {
    finished = true;
    res.end();
  }
});

// Lee las etiquetas <resumen> y <perfil> que emite la IA y las guarda como memoria del alumno.
function applyTeacherTags(userId, conv, text) {
  const summary = text.match(/<resumen>([\s\S]*?)<\/resumen>/);
  if (summary) db.updateConversation(userId, conv.id, { summary: summary[1].trim().slice(0, 800) });
  const pf = text.match(/<perfil>([\s\S]*?)<\/perfil>/);
  if (!pf) return;
  let o;
  try { o = JSON.parse(pf[1]); } catch { return; }
  if (!o || typeof o !== 'object') return;
  const subjectId = conv.subject_id;
  if (subjectId) {
    if (typeof o.objetivo === 'string' && o.objetivo.trim()) db.updateSubject(userId, subjectId, { goal: o.objetivo.trim().slice(0, 140) });
    if (o.temas && typeof o.temas === 'object') {
      const allowed = ['dominado', 'aprendiendo', 'dificultad'];
      Object.entries(o.temas).slice(0, 15).forEach(([name, v]) => {
        const st = v?.estado;
        if (allowed.includes(st)) db.upsertTopic(subjectId, String(name).slice(0, 60), st, 1);
      });
    }
    if (Array.isArray(o.dificultades)) {
      o.dificultades.slice(0, 5).map(s => String(s).slice(0, 80)).filter(Boolean).forEach(d => db.upsertTopic(subjectId, d, 'dificultad', 1));
    }
  }
  if (typeof o.objetivo === 'string' && !subjectId) {
    db.updateConversation(userId, conv.id, { summary: o.objetivo.trim().slice(0, 200) });
  }
}

/* ============================ Materias ============================ */
app.get('/api/subjects', requireAuth, (req, res) => {
  const subjects = db.listSubjects(req.user.id).map(s => ({ ...s, topics: db.listTopics(s.id) }));
  res.json(subjects);
});
app.post('/api/subjects', requireAuth, (req, res) => {
  const name = str(req.body?.name, 60).trim();
  if (!name) return res.status(400).json({ error: 'Poné el nombre de la materia.' });
  const statuses = ['activa', 'pausada', 'finalizada'];
  const id = db.createSubject(req.user.id, {
    name, emoji: str(req.body?.emoji, 4) || '📘', goal: str(req.body?.goal, 200),
    current_level: RANKS.includes(req.body?.current_level) ? req.body.current_level : '',
  });
  if (req.body?.topics) {
    String(req.body.topics).split(',').map(s => s.trim()).filter(Boolean).slice(0, 20)
      .forEach(t => db.upsertTopic(id, String(t).slice(0, 60), 'pendiente', 0));
  }
  const created = db.getSubject(req.user.id, id);
  const autoPath = req.body?.auto_path === false ? null : createPathFromData(req.user.id, id, name, req.body?.goal, req.body?.current_level);
  res.status(201).json({ subject: created, path: autoPath ? db.getPath(req.user.id, autoPath) : null });
});
app.patch('/api/subjects/:id', requireAuth, (req, res) => {
  const id = int(req.params.id);
  if (!db.getSubject(req.user.id, id)) return res.status(404).json({ error: 'No existe.' });
  const fields = {};
  for (const k of ['name', 'emoji', 'goal', 'status', 'current_level']) if (k in req.body) fields[k] = str(req.body[k], 200);
  if (fields.status && !['activa', 'pausada', 'finalizada'].includes(fields.status)) delete fields.status;
  db.updateSubject(req.user.id, id, fields);
  res.json(db.getSubject(req.user.id, id));
});
app.delete('/api/subjects/:id', requireAuth, (req, res) => {
  db.deleteSubject(req.user.id, int(req.params.id));
  res.json({ ok: true });
});

/* ============================ Rutas de aprendizaje ============================ */
function matchTemplate(subjectName) {
  const n = String(subjectName || '').toLowerCase();
  for (const t of Object.values(TEMPLATES)) {
    if (t.match.some(m => n.includes(m))) return t;
  }
  return null;
}
function createPathFromData(userId, subjectId, subjectName, goal, levelStart, source = 'plantilla') {
  const template = matchTemplate(subjectName);
  const pathTitle = template ? template.title : `Aprender ${subjectName}`;
  const pathId = db.createPath(userId, { subjectId, title: pathTitle, goal: goal || '', levelStart: levelStart || '', source });
  const modules = template ? template.modules : [{ title: 'Primeros pasos', objective: `Entender los fundamentos de ${subjectName}.`, adds: [{ kind: 'explicacion', title: `¿Qué es ${subjectName}?` }, { kind: 'practica', title: 'Ejercicio introductorio' }] }];
  modules.forEach((m, mi) => {
    const modId = db.addModule(pathId, { position: mi, title: m.title, objective: m.objective });
    m.adds.forEach((a, ai) => db.addPathActivity(modId, { position: ai, kind: a.kind, title: a.title, content: '' }));
  });
  return pathId;
}
async function createPathFromAI(userId, subjectId, subjectName, goal, level, weeks) {
  const pathId = await (async () => {
    const json = await completeJson({ system: buildPathSystem(), prompt: buildPathPrompt({ subject: subjectName, level, goal, weeks }) });
    const modules = Array.isArray(json?.modules) ? json.modules.slice(0, 8) : null;
    if (!modules) throw new Error('Formato inválido');
    const pid = db.createPath(userId, { subjectId, title: str(json.title, 80) || `Aprender ${subjectName}`, goal: goal || '', levelStart: level || '', source: 'ia' });
    modules.forEach((m, mi) => {
      const modId = db.addModule(pid, { position: mi, title: str(m.title, 90), objective: str(m.objective, 200) });
      (Array.isArray(m.activities) ? m.activities.slice(0, 4) : []).forEach((a, ai) => {
        const kinds = ['explicacion', 'practica', 'evaluacion', 'proyecto'];
        db.addPathActivity(modId, { position: ai, kind: kinds.includes(a.kind) ? a.kind : 'practica', title: str(a.title, 120), content: str(a.content, 500) });
      });
    });
    return pid;
  })();
  return pathId;
}
app.get('/api/paths', requireAuth, (req, res) => {
  const paths = db.listPaths(req.user.id).map(p => ({ ...p, progress: pathProgress(p.id), modules: db.listModules(p.id).map(m => ({ ...m, count: db.listPathActivities(m.id).length, done: db.listPathActivities(m.id).filter(a => a.state === 'completado').length })) }));
  res.json(paths);
});
app.get('/api/paths/:id', requireAuth, (req, res) => {
  const p = db.getPath(req.user.id, int(req.params.id));
  if (!p) return res.status(404).json({ error: 'No existe.' });
  const modules = db.listModules(p.id).map(m => ({ ...m, activities: db.listPathActivities(m.id) }));
  res.json({ ...p, progress: pathProgress(p.id), modules });
});
app.post('/api/paths', requireAuth, async (req, res) => {
  const subjectId = int(req.body?.subject_id);
  const subject = subjectId ? db.getSubject(req.user.id, subjectId) : null;
  if (subjectId && !subject) return res.status(404).json({ error: 'Materia no encontrada.' });
  const subjectName = subject?.name || str(req.body?.name, 60).trim();
  if (!subjectName) return res.status(400).json({ error: 'Indicá la materia.' });
  const goal = str(req.body?.goal, 200);
  const level = RANKS.includes(req.body?.level) ? req.body.level : '';
  const weeks = int(req.body?.weeks) || 0;
  let pathId;
  if (providerInfo().ready && req.body?.from_ai) {
    try { pathId = await createPathFromAI(req.user.id, subjectId || undefined, subjectName, goal, level, weeks); }
    catch (e) { pathId = createPathFromData(req.user.id, subjectId || undefined, subjectName, goal, level, 'fallback'); }
  } else {
    pathId = createPathFromData(req.user.id, subjectId || undefined, subjectName, goal, level);
  }
  res.status(201).json(db.getPath(req.user.id, pathId));
});
app.patch('/api/paths/:id', requireAuth, (req, res) => {
  const p = db.getPath(req.user.id, int(req.params.id));
  if (!p) return res.status(404).json({ error: 'No existe.' });
  if (req.body?.status && ['activa', 'pausada', 'finalizada'].includes(req.body.status)) db.updatePathStatus(p.id, req.body.status);
  res.json(db.getPath(req.user.id, p.id));
});
app.delete('/api/paths/:id', requireAuth, (req, res) => {
  db.deletePath(req.user.id, int(req.params.id));
  res.json({ ok: true });
});
app.post('/api/paths/activities/:aid/complete', requireAuth, (req, res) => {
  const aid = int(req.params.aid);
  const act = db.getPathActivity(aid);
  if (!act) return res.status(404).json({ error: 'No existe.' });
  const mod = db.getModule(act.module_id);
  const paths = db.listPaths(req.user.id);
  const p = mod ? paths.find(x => x.id === mod.path_id) : null;
  if (!p) return res.status(403).json({ error: 'No tenés acceso a esta actividad.' });
  if (act.state === 'completado') return res.json(activityDone(p, mod, act));
  db.setPathActivity(aid, { state: 'completado' });
  db.logActivity(req.user.id, { subjectId: p.subject_id, pathActivityId: aid, kind: 'ruta', title: act.title, correct: 1, xp: 25 });
  earn(req.user.id, 'path_activity', `path:${p.id}`);
  const result = activityDone(p, mod, act);
  res.json(result);
});

function activityDone(p, mod, act) {
  db.recalcModule(mod.id);
  const updated = db.listModules(p.id).find(m => m.id === mod.id);
  const outcomes = { activity: db.getPathActivity(act.id) };
  if (updated.state === 'completado' && mod.state !== 'completado') {
    earn(p.user_id, 'module_done', `module:${mod.id}`);
    outcomes.module_just_done = true;
  }
  outcomes.path_progress = pathProgress(p.id);
  return outcomes;
}
function pathProgress(pathId) {
  const mods = db.listModules(pathId);
  if (!mods.length) return 0;
  const counts = mods.map(m => {
    const acts = db.listPathActivities(m.id);
    return acts.length ? acts.filter(a => a.state === 'completado').length / acts.length : (m.state === 'completado' ? 1 : 0);
  });
  return Math.round((counts.reduce((a, b) => a + b, 0) / counts.length) * 100);
}

/* ============================ Evaluaciones ============================ */
const TOPIC_KEYS = Object.keys(TOPICS);
function pickBankQuestions(subjectName, count = 5) {
  const key = TOPIC_KEYS.find(k => TOPICS[k].name.toLowerCase() === String(subjectName || '').toLowerCase()
    || String(subjectName || '').toLowerCase().includes(TOPICS[k].name.toLowerCase().split(' ')[0]));
  if (!key) return null;
  const qs = [...TOPICS[key].qs];
  qs.sort(() => Math.random() - 0.5);
  return qs.slice(0, count);
}
app.get('/api/evaluations', requireAuth, (req, res) => res.json(db.listEvaluations(req.user.id)));
app.post('/api/evaluations', requireAuth, async (req, res) => {
  const subjectId = int(req.body?.subject_id);
  const subject = subjectId ? db.getSubject(req.user.id, subjectId) : null;
  if (!subject) return res.status(404).json({ error: 'Elegí una materia.' });
  const kind = req.body?.kind === 'inicial' ? 'inicial' : 'seguimiento';
  const evalId = db.createEvaluation(req.user.id, { subjectId, kind, source: 'banco' });
  const bank = pickBankQuestions(subject.name);
  if (bank) {
    bank.forEach((q, i) => db.addEvalItem(evalId, { position: i, topic: q.s, difficulty: q.d, question: q.q, options: q.o, correctIdx: q.a, explanation: q.e }));
    return res.status(201).json(detailedEvaluation(req.user.id, evalId));
  }
  if (providerInfo().ready) {
    try {
      const json = await completeJson({ system: buildEvaluationSystem(), prompt: buildEvaluationPrompt({ subject: subject.name, level: subject.current_level, goal: subject.goal }) });
      const items = Array.isArray(json.items) ? json.items.slice(0, 6) : [];
      if (!items.length) throw new Error('Sin ítems');
      db.setEvalSource(evalId, 'ia');
      items.forEach((it, i) => db.addEvalItem(evalId, { position: i, topic: str(it.topic, 60), difficulty: int(it.difficulty) || 2, question: str(it.question, 300), options: Array.isArray(it.options) ? it.options.slice(0, 4) : null, correctIdx: int(it.correctIdx), explanation: str(it.explanation, 300) }));
      return res.json(detailedEvaluation(req.user.id, evalId));
    } catch (e) {
      console.error('[eval ia]', e.message);
    }
  }
  // Sin banco ni IA: devolvemos un error claro, no una simulación.
  return res.status(503).json({ error: 'No tengo banco verificado para esta materia ni IA configurada para generarla. Configurá una clave de IA (ver .env.example) o elegí una materia de la lista.' });
});
app.get('/api/evaluations/:id', requireAuth, (req, res) => {
  const ev = db.getEvaluation(req.user.id, int(req.params.id));
  if (!ev) return res.status(404).json({ error: 'No existe.' });
  res.json(detailedEvaluation(req.user.id, ev.id));
});
app.post('/api/evaluations/:id/submit', requireAuth, (req, res) => {
  const ev = db.getEvaluation(req.user.id, int(req.params.id));
  if (!ev) return res.status(404).json({ error: 'No existe.' });
  if (ev.status === 'completada') return res.status(400).json({ error: 'Esta evaluación ya fue corregida.' });
  const answers = req.body?.answers;
  const items = db.listEvalItems(ev.id);
  let correct = 0;
  const perTopic = {};
  items.forEach(it => {
    const a = answers?.[String(it.id)];
    let isCorrect = null, answerIdx = null, answerText = null;
    if (it.options) {
      answerIdx = int(a);
      isCorrect = answerIdx === it.correct_idx ? 1 : 0;
    } else if (typeof a === 'string') {
      answerText = str(a, 2000);
      if (it.correct_text && it.correct_text.trim().toLowerCase() === answerText.trim().toLowerCase()) isCorrect = 1;
    }
    if (isCorrect === 1) correct++;
    db.saveEvalAnswer(it.id, { answerIdx, answerText, isCorrect });
    if (isCorrect !== null) {
      perTopic[it.topic || 'general'] = (perTopic[it.topic || 'general'] || 0) + (isCorrect === 1 ? 1 : 0);
      if (isCorrect === 1) db.upsertTopic(ev.subject_id, it.topic || 'general', 'dominado', 1);
      else db.upsertTopic(ev.subject_id, it.topic || 'general', 'dificultad', 1);
    }
  });
  const score = items.length ? Math.round((correct / items.length) * 100) : 0;
  const mastery = ev.subject_id && db.getSubject(req.user.id, ev.subject_id)
    ? (() => { const prev = db.getSubject(req.user.id, ev.subject_id).mastery; return Math.round(prev * 0.6 + score * 0.4); })()
    : null;
  if (ev.subject_id) {
    const su = db.getSubject(req.user.id, ev.subject_id);
    if (su) {
      db.updateSubject(req.user.id, ev.subject_id, { mastery: mastery ?? 0, xp: su.xp + correct * 10, current_level: rankOf(mastery ?? 0) >= 0 ? RANKS[rankOf(mastery ?? 0)] : '' });
    }
  }
  const weak = Object.keys(perTopic).length ? Object.entries(perTopic).filter(([, c]) => c === 0).map(([t]) => t) : [];
  const summary = score >= 85 ? 'Muy buen nivel. Podés avanzar.' : score >= 60 ? 'Nivel aceptable, con algunos temas para reforzar.' : 'Hay varios temas para reforzar antes de avanzar.';
  db.completeEvaluation(ev.id, { score, summary });
  db.logActivity(req.user.id, { subjectId: ev.subject_id, kind: 'evaluacion', title: ev.title || 'Evaluación', correct: score >= 60 ? 1 : 0, score, xp: 40 });
  earn(req.user.id, 'evaluation_ok', `eval:${ev.id}`);
  const trophy = ['Primeros pasos', 'Se viene', 'Bien encaminado', 'Ritmo fuerte', 'Nivel top'][Math.min(4, Math.max(0, Math.floor(score / 20)))];
  res.json({ score, correct, total: items.length, mastery, summary, weak_topics: weak.slice(0, 5), eval: detailedEvaluation(req.user.id, ev.id), badge: trophy, xp: { earned: 40 } });
});
function detailedEvaluation(userId, evalId) {
  const ev = db.getEvaluation(userId, evalId);
  return { ...ev, items: db.listEvalItems(evalId).map(i => ({ id: i.id, position: i.position, topic: i.topic, difficulty: i.difficulty, question: i.question, options: i.options, explanation: i.explanation, answer_idx: i.answer_idx, answer_text: i.answer_text, is_correct: i.is_correct })) };
}

/* ============================ Objetivos ============================ */
app.get('/api/goals', requireAuth, (req, res) => {
  const goals = db.listGoals(req.user.id).map(g => ({ ...g, tasks: db.listGoalTasks(g.id) }));
  res.json(goals);
});
app.post('/api/goals', requireAuth, (req, res) => {
  const title = str(req.body?.title, 120).trim();
  if (!title) return res.status(400).json({ error: 'Poné el título del objetivo.' });
  const subjectId = int(req.body?.subject_id) || null;
  if (subjectId && !db.getSubject(req.user.id, subjectId)) return res.status(404).json({ error: 'Materia no encontrada.' });
  const id = db.createGoal(req.user.id, { subjectId, title, description: str(req.body?.description, 600), dueDate: str(req.body?.due_date, 20) || null });
  const positions = Array.isArray(req.body?.tasks) ? req.body.tasks.map(t => str(t, 120).trim()).filter(Boolean).slice(0, 12) : [];
  positions.forEach((t, i) => db.addGoalTask(id, { position: i, title: t }));
  if (!positions.length) db.addGoalTask(id, { position: 0, title: 'Definir el plan' });
  res.status(201).json({ ...db.getGoal(req.user.id, id), tasks: db.listGoalTasks(id) });
});
app.patch('/api/goals/:id', requireAuth, (req, res) => {
  const id = int(req.params.id);
  if (!db.getGoal(req.user.id, id)) return res.status(404).json({ error: 'No existe.' });
  const f = {};
  for (const k of ['title', 'description', 'due_date', 'status']) if (k in req.body) f[k] = str(req.body[k], 400);
  if (f.status && !['activo', 'logrado', 'cancelado'].includes(f.status)) delete f.status;
  db.updateGoal(req.user.id, id, f);
  res.json(db.getGoal(req.user.id, id));
});
app.delete('/api/goals/:id', requireAuth, (req, res) => { db.deleteGoal(req.user.id, int(req.params.id)); res.json({ ok: true }); });
app.post('/api/goals/:id/tasks', requireAuth, (req, res) => {
  const goal = db.getGoal(req.user.id, int(req.params.id));
  if (!goal) return res.status(404).json({ error: 'No existe.' });
  const title = str(req.body?.title, 120).trim();
  if (!title) return res.status(400).json({ error: 'Tarea vacía.' });
  const tasks = db.listGoalTasks(goal.id);
  const taskId = db.addGoalTask(goal.id, { position: tasks.length, title });
  res.status(201).json({ id: taskId, title });
});
app.patch('/api/goals/tasks/:tid', requireAuth, (req, res) => {
  const t = db.getGoalTask(int(req.params.tid));
  if (!t) return res.status(404).json({ error: 'No existe.' });
  const goal = db.getGoal(req.user.id, t.goal_id);
  if (!goal) return res.status(403).json({ error: 'No tenés acceso.' });
  const done = bool(req.body?.done);
  db.setGoalTask(t.id, done);
  const progress = db.recalcGoal(goal.id);
  if (done) {
    db.logActivity(req.user.id, { subjectId: goal.subject_id, kind: 'objetivo', title: `Tarea: ${t.title}`, correct: 1, xp: 10 });
    earn(req.user.id, 'goal_task_done', `goal:${goal.id}`);
  }
  res.json({ ok: true, progress, status: db.getGoal(req.user.id, goal.id).status });
});
app.delete('/api/goals/tasks/:tid', requireAuth, (req, res) => {
  const t = db.getGoalTask(int(req.params.tid));
  if (!t) return res.status(404).json({ error: 'No existe.' });
  const goal = db.getGoal(req.user.id, t.goal_id);
  if (!goal) return res.status(403).json({ error: 'No tenés acceso.' });
  db.deleteGoalTask(t.id);
  db.recalcGoal(goal.id);
  res.json({ ok: true });
});

/* ============================ Estadísticas ============================ */
app.get('/api/stats', requireAuth, (req, res) => {
  const overall = db.statsOverview(req.user.id);
  const profile = db.getProfile(req.user.id);
  const weekMinutes = db.minutesByDay(req.user.id, 7);
  const monthMinutes = db.minutesByDay(req.user.id, 30);
  const xpDays = db.xpByDay(req.user.id, 14);
  const subjects = db.listSubjects(req.user.id).map(s => ({ id: s.id, name: s.name, mastery: s.mastery, level: s.current_level, xp: s.xp }));
  const evals = db.listEvaluations(req.user.id).map(e => ({ id: e.id, title: e.title, score: e.score, kind: e.kind, created_at: e.created_at }));
  const sessions = db.listStudySessions(req.user.id, 30);
  const activities = db.listActivities(req.user.id, 50);
  const correctByKind = {};
  for (const a of activities) { correctByKind[a.kind] = (correctByKind[a.kind] || 0) + (a.correct === 1 ? 1 : 0); }
  res.json({
    profile: { xp: profile.xp, level: profile.level, streak: profile.streak, best_streak: profile.best_streak, total_minutes: profile.total_minutes },
    overall,
    week_minutes: weekMinutes,
    month_minutes: monthMinutes,
    xp_by_day: xpDays,
    subjects,
    evaluations: evals,
    sessions: sessions.map(s => ({ minutes: s.minutes, started_at: s.started_at })),
    recent_activities: activities.slice(0, 20),
    correct_by_kind: correctByKind,
    achievements: db.listAchievements(req.user.id),
    strengths: subjects.filter(s => s.mastery >= 70).map(s => s.name),
    needs_refuerzo: (() => { const out = []; for (const s of db.listSubjects(req.user.id)) for (const t of db.listTopics(s.id)) if (t.state === 'dificultad') out.push(t.name); return [...new Set(out)].slice(0, 8); })(),
  });
});

/* ============================ Tiempo de estudio ============================ */
app.post('/api/study/track', requireAuth, (req, res) => {
  let minutes = int(req.body?.minutes) || 0;
  minutes = Math.max(0, Math.min(minutes, 120));
  if (!minutes) return res.json({ ok: true });
  const profile = db.getProfile(req.user.id);
  db.updateProfile(req.user.id, { total_minutes: profile.total_minutes + minutes });
  const convId = int(req.body?.conversation_id) || null;
  const subjectId = int(req.body?.subject_id) || null;
  if (convId && !db.getConversation(req.user.id, convId)) return res.status(400).json({ error: 'Conversación inválida.' });
  if (subjectId && !db.getSubject(req.user.id, subjectId)) return res.status(400).json({ error: 'Materia inválida.' });
  const sessionId = db.startStudySession(req.user.id, { conversationId: convId, subjectId });
  db.endStudySession(sessionId, minutes);
  let xpGained = 0;
  for (let i = 0; i < Math.floor(minutes / 10); i++) xpGained += earn(req.user.id, 'study_10min', 'study').amount;
  res.json({ ok: true, minutes, total: profile.total_minutes + minutes, streak: db.getProfile(req.user.id).streak, xp: xpGained });
});

/* ============================ Recursos ============================ */
app.get('/api/resources', requireAuth, (req, res) => {
  const mine = db.listResources(req.user.id);
  const subjects = db.listSubjects(req.user.id).filter(s => s.status === 'activa');
  const names = subjects.map(s => s.name.toLowerCase());
  const suggested = COURSES.filter(c => c.topics.some(t => names.some(n => n.includes(t) || TOPICS[t]?.name.toLowerCase().includes(n))))
    .map(c => ({ title: c.title, org: c.org, url: c.url, kind: c.kind, free: c.free, topics: c.topics.map(t => TOPICS[t].name) }));
  res.json({ mine, suggested });
});
app.post('/api/resources', requireAuth, (req, res) => {
  const title = str(req.body?.title, 120).trim();
  if (!title) return res.status(400).json({ error: 'Poné el título.' });
  const url = str(req.body?.url, 300).trim();
  if (url && !/^https?:\/\//.test(url)) return res.status(400).json({ error: 'La URL tiene que empezar con http:// o https://' });
  const subjectId = int(req.body?.subject_id) || null;
  if (subjectId && !db.getSubject(req.user.id, subjectId)) return res.status(404).json({ error: 'Materia no encontrada.' });
  const kinds = ['curso', 'documentacion', 'tutorial', 'video', 'libro', 'otro'];
  const id = db.createResource(req.user.id, { subjectId, title, url, kind: kinds.includes(req.body?.kind) ? req.body.kind : 'curso', note: str(req.body?.note, 400) });
  res.status(201).json(db.listResources(req.user.id).find(r => r.id === id));
});
app.delete('/api/resources/:id', requireAuth, (req, res) => { db.deleteResource(req.user.id, int(req.params.id)); res.json({ ok: true }); });

/* ============================ Perfil y configuración ============================ */
app.get('/api/profile', requireAuth, (req, res) => {
  const p = db.getProfile(req.user.id);
  res.json({
    user: { name: req.user.name, email: req.user.email },
    nickname: p.nickname || req.user.name,
    preferences: p.preferences,
    appearance: p.appearance,
    settings: p.settings,
    onboarding_done: Boolean(p.onboarding_done),
    xp: p.xp, level: p.level, streak: p.streak, best_streak: p.best_streak, total_minutes: p.total_minutes,
  });
});
app.patch('/api/profile', requireAuth, (req, res) => {
  const fields = {};
  if ('nickname' in req.body) fields.nickname = str(req.body.nickname, 60).trim() || req.user.name;
  if ('preferences' in req.body && req.body.preferences && typeof req.body.preferences === 'object') fields.preferences = sanitizePrefs(req.body.preferences);
  if ('appearance' in req.body && req.body.appearance && typeof req.body.appearance === 'object') fields.appearance = sanitizeAppearance(req.body.appearance);
  if ('settings' in req.body && req.body.settings && typeof req.body.settings === 'object') fields.settings = sanitizeSettings(req.body.settings);
  if ('onboarding_done' in req.body) fields.onboarding_done = bool(req.body.onboarding_done) ? 1 : 0;
  db.updateProfile(req.user.id, fields);
  res.json({ ok: true });
});
app.get('/api/profile/data', requireAuth, (req, res) => {
  res.json({
    user: { name: req.user.name, email: req.user.email },
    profile: db.getProfile(req.user.id),
    subjects: db.listSubjects(req.user.id).map(s => ({ ...s, topics: db.listTopics(s.id) })),
    conversations: db.listConversations(req.user.id).map(c => ({ ...c, messages: db.listMessages(c.id) })),
    paths: db.listPaths(req.user.id),
    evaluations: db.listEvaluations(req.user.id),
    goals: db.listGoals(req.user.id).map(g => ({ ...g, tasks: db.listGoalTasks(g.id) })),
    resources: db.listResources(req.user.id),
    achievements: db.listAchievements(req.user.id),
    activities: db.listActivities(req.user.id, 200),
  });
});
app.post('/api/profile/data/export', requireAuth, (req, res) => {
  res.set('Content-Disposition', 'attachment; filename="nextstep-datos.json"');
  res.set('Content-Type', 'application/json');
  // no use del rate limiter: exportación puntual
});
app.delete('/api/profile/data', requireAuth, (req, res) => {
  const confirm = String(req.body?.confirm || '');
  if (confirm !== 'BORRAR') return res.status(400).json({ error: 'Para borrar todo, escribí BORRAR como confirmación.' });
  if (int(req.body?.all) === 1) {
    db.purgeUserData(req.user.id);
    db.deleteUserSessions(req.user.id);
    res.set('Set-Cookie', clearCookie());
    return res.json({ ok: true });
  }
  res.status(400).json({ error: 'Confirmación inválida.' });
});

function sanitizePrefs(p) {
  const prefs = {};
  const list = { explanationLength: ['breve', 'detallada'], languageStyle: ['simple', 'tecnico'], examples: ['practicos', 'teoricos'], sequence: ['paso_a_paso', 'panorama'], difficulty: ['facil', 'intermedio', 'avanzado'], practiceMix: ['mas_practica', 'mas_explicacion'], hints: ['progresivas', 'directas'], sessionLength: ['corta', 'prolongada'], explanationLevel: ['basica', 'intermedia', 'avanzada'], pace: ['tranquilo', 'equilibrado', 'intensivo'], teachingForm: ['mas_ejemplos', 'mas_teoria', 'mas_ejercicios', 'equilibrado'], correction: ['pistas', 'completa'], autonomy: ['guiada', 'libre'], goalKind: ['comprender', 'examen', 'habilidad', 'proyecto'], tone: ['neutral', 'cercano', 'motivador'] };
  for (const [k, allowed] of Object.entries(list)) if (allowed.includes(p[k])) prefs[k] = p[k];
  if (Array.isArray(p.methods)) prefs.methods = p.methods.filter(m => ['preguntas', 'ejemplos', 'esquemas', 'resumenes', 'problemas'].includes(m)).slice(0, 5);
  if (typeof p.language === 'string' && /^[a-z]{2}$/.test(p.language)) prefs.language = p.language;
  return prefs;
}
function sanitizeAppearance(a) {
  const out = {};
  const colors = ['bg', 'surface', 'ink', 'muted', 'line', 'accent', 'accent2', 'good', 'warn', 'track'];
  for (const k of colors) if (typeof a[k] === 'string' && /^#[0-9a-fA-F]{3,8}$/.test(a[k])) out[k] = a[k];
  for (const k of ['theme', 'mode', 'buttonStyle', 'contrast', 'textSize', 'density']) if (typeof a[k] === 'string') out[k] = a[k].slice(0, 40);
  if ('animations' in a) out.animations = bool(a.animations);
  return out;
}
function sanitizeSettings(s) {
  const out = {};
  for (const k of ['notifications', 'privacy', 'language']) if (typeof s[k] === 'boolean' || typeof s[k] === 'string') out[k] = s[k];
  return out;
}

// SPA: cualquier GET que no sea de la API cae en index.html.
app.use((req, res, next) => {
  if (req.method === 'GET' && !req.path.startsWith('/api/')) return res.sendFile(path.join(__dirname, 'public', 'index.html'));
  next();
});

app.listen(PORT, () => {
  console.log(`NEXTSTEP andando en http://localhost:${PORT}`);
  console.log(`Base de datos: ${db.getDbPath()} (SQLite)`);
  const info = providerInfo();
  console.log(`IA: ${info.provider}${info.model ? ' / ' + info.model : ''}`);
  if (!info.ready) console.warn('Atención: ' + missingConfigMessage() + ' Copiá .env.example a .env y completalo.');
});