# NEXTSTEP

Profesor particular virtual con IA: te conoce, evalúa tu nivel real, te arma un camino de aprendizaje,
te explica, te hace practicar, corrige tus errores y lleva el seguimiento de tu progreso.

## Estado actual

Aplicación web completa con cuenta por alumno y persistencia en SQLite (sin base de datos externa):

- **Cuentas**: registro, login y sesiones (cookie httpOnly, contraseñas con scrypt).
- **Profesor IA**: chat con streaming, modo de estudio (explicar / practicar / evaluar / proyecto),
  respuestas que se adaptan a las preferencias de aprendizaje del alumno.
- **Materias y temas**: el dominio por materia se mide con evaluaciones reales.
- **Rutas de aprendizaje**: se crean automáticamente al agregar una materia, o las diseña la IA.
- **Evaluaciones**: con banco de preguntas verificado a mano (o generadas por IA si hay clave) y corrección
  con explicación de cada respuesta.
- **Seguimiento**: XP, niveles, racha, estadísticas, logros y sesiones de estudio.
- **Temas visuales**: 10 paletas aplicables a todo el sitio (focus, bosque, lavanda, cálido, océano, rosa,
  alto contraste, enfoque oscuro, claro simple y personalizado), con modo claro/oscuro y densidad.

## Arrancar

1. Instalá **Node.js 22.5 o más nuevo** (usa el módulo `node:sqlite` integrado, no hace falta compilar nada).
2. En esta carpeta: `npm install`
3. Copiá `.env.example` como `.env`: pegá tu clave de Anthropic en `ANTHROPIC_API_KEY`
   (se crea en https://console.anthropic.com) y generá un `SESSION_SECRET`.
4. `npm start` y abrí http://localhost:3000

La base `data/nextstep.db` se crea sola (está en `.gitignore`). Probá `http://localhost:3000/api/health`:
si dice `"ia":true`, la clave está cargada.

## Comandos

| Comando | Qué hace |
|---|---|
| `npm start` | Levanta el servidor en http://localhost:3000 |
| `npm run dev` | Igual, pero se reinicia solo al guardar (`node --watch`) |
| `npm run init-db` | Crea/verifica la base de datos |
| `npm test` | Corre las pruebas (`node --test test/`) |

## Qué IA usa por detrás

La app corre en tu servidor: los alumnos nunca entran a Claude ni a ninguna cuenta ajena. Lo único que se
elige es qué modelo responde, en `.env`:

| Opción | Cuándo conviene |
|---|---|
| `PROVIDER=anthropic` (API de Claude) | Mejor calidad para enseñar. Cuesta por uso. |
| `PROVIDER=openai` con Ollama | Corre en tu compu, sin cuenta ni costo, los datos no salen de la máquina. Los modelos chicos enseñan peor. |
| `PROVIDER=openai` con Groq u OpenRouter | En la nube, a veces con plan gratis y límites. |

## Estructura

- `server.js`: API REST completa (auth, dashboard, chat SSE, materias, rutas, evaluaciones, objetivos,
  estadísticas, recursos, perfil) + SPA fallback.
- `src/db.js`: esquema y acceso a SQLite (`node:sqlite`). Toda la persistencia está acá.
- `src/auth.js`: scrypt, sesiones y cookie.
- `src/xp.js`: reglas de XP y racha.
- `src/llm.js`: streaming y JSON de la IA (Claude API u OpenAI-compatible).
- `src/prompt.js`: el "cerebro" del profesor: estilo, proceso, etiquetas de control, preferencias del alumno.
- `src/data.js`: banco de preguntas verificadas (`TOPICS`), recursos (`COURSES`) y plantillas de rutas.
- `public/`: SPA sin framework (`index.html`, `css/style.css`, `js/{api,store,ui,themes,modals,app}.js`,
  `js/views/*`). Rutas con hash: `#/chat`, `#/aprendizaje`, `#/rutas`, `#/evaluaciones`, `#/objetivos`,
  `#/estadisticas`, `#/recursos`, `#/config`.

## Pruebas manuales rápidas

- `GET /api/health` → `{"ok":true,"ia":false}` sin clave; `"ia":true` con la clave cargada.
- Crear cuenta y entrar → se abre el onboarding y queda todo el panel.
- Agregar una materia → se crea sola su ruta de aprendizaje.
- Hacer una evaluación → cambia el dominio de la materia y deja temas "dominado/dificultad".

## Costos y seguridad

- Las claves van solo en `.env` (gitignore). Si se filtra, generá una nueva.
- El servidor limita los pedidos por minuto y corta la llamada si cerrás la pestaña.
- Los links de `src/data.js` conviene revisarlos: pueden cambiar precios o condiciones.