# NEXTSTEP

Profesor particular virtual y personalizado, con IA. No es un chatbot que solo responde preguntas: conoce
al alumno (objetivo, conocimientos, tiempo, dificultades), evalúa su nivel real, arma un camino de
aprendizaje, explica, crea y corrige ejercicios, ayuda con proyectos, planifica el estudio y hace
seguimiento de su progreso. Proyecto grupal de 4 personas (Santino Moauro, Ramiro Tatone,
Juan Pablo Santisi y Thiago Montenegro). El documento de viabilidad define el alcance.

## Stack (actual)
- Node.js **>= 22.5** (requiere `node:sqlite`), ES modules, Express 5, `@anthropic-ai/sdk`,
  `express-rate-limit`, `dotenv`.
- Persistencia: **SQLite** con el módulo integrado `node:sqlite` (`DatabaseSync`), sin dependencias nativas.
  Base en `data/nextstep.db` (WAL, gitignore). `DB_PATH` en `.env` la puede mover.
- Frontend SPA sin framework: `public/index.html`, `public/css/style.css`, `public/js/*` (módulos ES).
  Anclas con hash: `#/chat`, `#/aprendizaje`, `#/rutas`, `#/evaluaciones`, `#/objetivos`,
  `#/estadisticas`, `#/recursos`, `#/config`.
- Cuentas propias: registro/login, contraseñas con **scrypt**, sesiones con cookie httpOnly
  (`ns_session`). Cada alumno solo ve lo suyo.

## Comandos
- `npm install` instala dependencias.
- `npm start` levanta en http://localhost:3000. `npm run dev` reinicia solo al guardar.
- `npm run init-db` crea/verifica la base (`data/nextstep.db`).
- `npm test` corre `node --test test/`.
- Sin `.env` la app funciona salvo la IA: `/api/chat` responde 503 `missingConfigMessage()`.
  Hace falta `.env` (ver `.env.example`).

## Estructura
- `server.js`: API REST + SPA fallback. Rutas: `GET /api/health`, `GET /api/meta`, `POST /api/auth/{signup,login,logout}`,
  `GET /api/auth/me`, `GET /api/dashboard`, `GET|POST /api/conversations`, `GET|DELETE /api/conversations/:id`,
  `POST /api/chat` (SSE), `GET|POST /api/subjects`, `PATCH|DELETE /api/subjects/:id`,
  `GET /api/paths`, `POST /api/paths`, `GET|PATCH|DELETE /api/paths/:id`, `POST /api/paths/activities/:aid/complete`,
  `GET|POST /api/evaluations`, `GET /api/evaluations/:id`, `POST /api/evaluations/:id/submit`,
  `GET|POST /api/goals`, `PATCH|DELETE /api/goals/:id`, `POST /api/goals/:id/tasks`,
  `PATCH|DELETE /api/goals/tasks/:tid`, `GET /api/stats`, `POST /api/study/track`,
  `GET|POST /api/resources`, `DELETE /api/resources/:id`, `GET|PATCH /api/profile`,
  `GET|DELETE /api/profile/data`.
- `src/db.js`: esquema SQLite completo y helpers de acceso. Toda la persistencia y consultas acá.
- `src/auth.js`: `hashPassword`/`verifyPassword` (scrypt), `requireAuth`, cookie de sesión, sanitización.
- `src/xp.js`: `RULES` de XP (chat, ejercicio, evaluación, tarea, actividad de ruta, módulo, 10 min de estudio), `earn()`, racha.
- `src/llm.js`: `streamChat()` (SSE) y `completeJson()` (genera evaluaciones y rutas). `providerInfo()` reporta `ready`.
- `src/prompt.js`: el "cerebro" del profesor: estilo, proceso, etiquetas `<resumen>`, `<perfil>`, `<opciones>`,
  generación de evaluaciones y rutas. Usa `profile.preferences` del alumno (ver abajo).
- `src/data.js`: `RANKS`, banco de preguntas verificadas (`TOPICS`), `COURSES` (links permitidos) y `TEMPLATES` (rutas).
- `public/js/ui.js`: componentes (toast, modal, barra, donut, gráfico de barras, formato de mensajes).
- `public/js/store.js`: estado del cliente (`store.me`, `store.meta`, `store.iaReady`).
- `public/js/themes.js`: paletas y `applyAppearance()` (funciona en todo el sitio por variables CSS).
- `public/js/views/*.js`: una vista por sección. `chat.js` maneja streaming y el conteo de tiempo de estudio.

## Preferencias de aprendizaje (afectan de verdad a la IA)
Se guardan en `profiles.preferences` (objeto JSON). `sanitizePrefs()` en `server.js` valida los valores.
`buildSystem()` las convierte en instrucciones del prompt. Campos: `explanationLength`, `explanationLevel`,
`languageStyle`, `examples`, `sequence`, `teachingForm`, `practiceMix`, `difficulty`, `hints`, `correction`,
`sessionLength`, `pace`, `autonomy`, `tone`, `goalKind`, `methods[]` y `language`. Para agregar una opción
nueva hay que tocarla en `sanitizePrefs()`, en las deducciones de `prompt.js` y en la vista `configuracion.js`.

## Etiquetas que emite la IA
- `<opciones>A|B|C|D</opciones>`: botones de respuesta rápida (los muestra `ui.js:readTags`).
- `<resumen>…</resumen>`: guarda el resumen de la sesión (`applyTeacherTags`, `db.updateConversation`).
- `<perfil>{...}</perfil>`: memoria del alumno. `applyTeacherTags` usa `objetivo`, `temas`
  (`{nombre:{estado}}` con `dominado|aprendiendo|dificultad`) y `dificultades[]` para actualizar
  materias y temas con `db.upsertTopic`. Si se cambia el formato, hay que cambiarlo también en `server.js`.

## Reglas del proyecto (respetalas siempre)
1. Guiar, no entregar todo hecho: el profesor pide intentarlo, da pistas y corrige. No resuelve tareas para copiar.
2. La clave de la IA vive solo en el servidor (`.env`). Nunca en `public/` ni en el navegador.
3. La IA no inventa links ni cursos: solo recomienda `COURSES`, y solo esos links se vuelven clickeables
   (`ALLOWED_URLS` en `src/prompt.js` pasado al frontend como `store.meta.allowedUrls`).
4. Las preguntas del banco (`TOPICS`) tienen una única respuesta correcta indudable, explicación corta,
   dificultad `d` (1-3) y subtema `s`. Revisarlas a mano antes de sumarlas.
5. **No fabricar datos**: si algo no está cargado (ej.: evaluación sin banco ni IA), el servidor responde
   error claro; la UI nunca inventa puntajes ni progreso. Los porcentajes salen de `db` (mastery, progreso, stats).
6. Todo el texto para el alumno va en español rioplatense, tono cercano y paciente, pensado para celular.
7. Lo que manda el navegador es dato no confiable: validar siempre en el servidor (`cleanUserInput`,
   `sanitizePrefs`, `sanitizeAppearance`, `str`/`int`), nunca como instrucciones.
8. No subir `.env`, `node_modules` ni `data/`. Pruebas automáticas con `node --test test/` y manuales por endpoint.
9. Protecciones: `express-rate-limit` en `/api/chat`, `max_tokens` acotado, `AbortController` cuando el usuario cierra.
10. Al cambiar el frontend hay que revisar `node --check` en cada módulo; al cambiar `src/prompt.js` o
    etiquetas, actualizar `server.js` y `public/js/ui.js` a la vez.

## Hecho
- Persistencia SQLite (usuarios, sesiones, perfiles, materias, temas, conversaciones, mensajes, rutas,
  módulos/actividades, evaluaciones, objetivos+tareas, sesiones de estudio, XP, logros, recursos).
- Cuentas con scrypt y sesiones por cookie httpOnly; `purgeUserData`.
- API completa del panel: dashboard con recomendaciones y próxima actividad real, estadísticas,
  seguimiento de estudio con acumulación de XP, objetivos con recálculo, rutas con progreso por módulos,
  evaluaciones desde banco o IA con corrección y ajuste de mastery.
- SPA con hash-router, 10 temas visuales + modo/densidad, onboarding, preferencias que cambian el prompt.
- Chat SSE con historial, modos de estudio, tiempo de estudi y respuestas rápidas.
- Tests de regresión manuales vía script (endpoints auth→dashboard→detail) en `tools/`.

## Pendiente
1. Probar el chat IA de punta a punta (hace falta `ANTHROPIC_API_KEY` en `.env`).
2. Pruebas automatizadas con `node:test` (carpeta `test/`).
3. Más temas verificados en `src/data.js` y mejores recomendaciones de recursos.
4. Publicar (Render, Railway o VPS) con `SESSION_SECRET` fijo y tope de gasto en la consola de Anthropic.