// Estado global del cliente (no es la fuente de verdad: los datos viven en el backend).
export const store = {
  me: null,          // { user, profile }
  meta: { greeting: '', startQuick: [], allowedUrls: [] },
  iaReady: false,    // si el servidor tiene clave de IA configurada
  currentRoute: '#/',
};

export async function loadMeta() {
  try {
    const m = await fetch('/api/meta').then(r => r.json());
    store.meta = { ...store.meta, ...m };
  } catch { /* valores por defecto */ }
  try {
    const h = await fetch('/api/health').then(r => r.json());
    store.iaReady = Boolean(h.ia);
  } catch { /* desconectado */ }
}

export async function loadMe() {
  const r = await fetch('/api/auth/me');
  if (r.ok) {
    store.me = await r.json();
    return store.me;
  }
  store.me = null;
  return null;
}