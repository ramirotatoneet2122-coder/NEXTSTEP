import { api, streamChat, esc, fmtDate } from '../api.js';
import { toast, fmt, readTags, empty } from '../ui.js';
import { store } from '../store.js';

let cleanups = [];

export default {
  title: 'Mi profesor IA',
  show(el, params) { mount(el, params.id ? Number(params.id) : null); },
  hide() { cleanups.forEach(fn => { try { fn(); } catch { /* */ } }); cleanups = []; },
};

const MODES = [
  { id: 'explicar', label: 'Explicar', ico: '📖' },
  { id: 'practicar', label: 'Practicar', ico: '✏️' },
  { id: 'evaluar', label: 'Evaluar', ico: '📝' },
  { id: 'proyecto', label: 'Proyecto', ico: '🛠' },
];

async function mount(el, openId) {
  el.innerHTML = `<div class="chatwrap">
    <aside class="clist" id="clist"><div class="skeleton" style="height:44px;margin-bottom:8px"></div><div class="skeleton" style="height:44px"></div></aside>
    <section class="chatmain" id="chatmain"><div style="padding:20px"><div class="skeleton" style="height:60%"></div></div></section>
  </div>`;

  let convs = [];
  let activeId = openId;
  let streaming = false;
  let ctl = null;
  let lastTrack = Date.now();
  let currentSubjectId = null;

  try { convs = await api('/api/conversations'); } catch (e) { toast(e.message, 'err'); }

  // Si no hay id y hay conversaciones, abrimos la más reciente.
  if (!activeId && convs.length) activeId = convs[0].id;

  renderList();
  if (activeId) await openConversation(activeId);
  else renderNew();

  // El tiempo de estudio se cuenta solo mientras esta vista está abierta y visible.
  const heartbeat = setInterval(() => {
    if (document.hidden || !activeId) return;
    const mins = Math.round((Date.now() - lastTrack) / 60000);
    if (mins >= 1) { api('/api/study/track', { method: 'POST', body: { minutes: mins, conversation_id: activeId } }).catch(() => {}); lastTrack = Date.now(); }
  }, 60000);
  cleanups.push(() => clearInterval(heartbeat));
  const onVis = () => { if (!document.hidden) lastTrack = Date.now(); };
  document.addEventListener('visibilitychange', onVis);
  cleanups.push(() => document.removeEventListener('visibilitychange', onVis));

  /* ---------- Lista de conversaciones ---------- */
  function renderList() {
    const list = document.getElementById('clist');
    const newBtn = `<button class="btn primary block" data-action="newconv">＋ Nueva sesión</button>`;
    const items = convs.map(c => `
      <button class="conv ${c.id === activeId ? 'active' : ''}" data-conv="${c.id}">
        <b>${esc(c.title)}</b>
        <small>${c.summary ? esc(c.summary.slice(0, 60)) : fmtDate(c.updated_at)} · ${c.message_count} mens.</small>
      </button>`).join('');
    list.innerHTML = newBtn + (convs.length ? `<div class="divider"></div>${items}` : `<p class="sub center" style="margin-top:14px">Todavía no hay sesiones.</p>`);
    list.querySelector('[data-action="newconv"]').onclick = () => { activeId = null; currentSubjectId = null; renderNew(); renderList(); };
    list.querySelectorAll('[data-conv]').forEach(b => b.onclick = () => {
      if (streaming) { ctl?.abort(); streaming = false; setBtn(document.getElementById('chatmain'), false); }
      location.hash = '#/chat/' + b.dataset.conv;
    });
  }

  /* ---------- Nueva sesión ---------- */
  async function renderNew() {
    const subjects = await api('/api/subjects').catch(() => []);
    const main = document.getElementById('chatmain');
    const quick = (store.meta.startQuick || []).map(q => `<button class="chip secondary" data-quick="${esc(q)}">${esc(q)}</button>`).join('');
    main.innerHTML = `
      <div class="msgs" id="msgs" style="justify-content:center">
        <div style="max-width:560px;margin:auto;display:flex;flex-direction:column;gap:16px">
          <div class="center">
            <div class="brand big" style="margin-bottom:8px">NEXTSTEP</div>
            <p class="sub">${esc(store.meta.greeting || '¡Hola! Soy tu profesor particular. ¿Qué querés aprender hoy?')}</p>
          </div>
          ${!store.iaReady ? `<div class="contrast-warn">⚠️ El servidor todavía no tiene clave de IA configurada. Cuando alguien la agregue al <code>.env</code> y reinicie, el profesor va a poder responderte.</div>` : ''}
          <div class="card">
            <div class="field"><span class="flabel">¿Sobre qué materia? (opcional)</span>
              <select class="select" id="newSubject"><option value="">Sin materia específica</option>
                ${subjects.filter(s => s.status === 'activa').map(s => `<option value="${s.id}">${esc(s.emoji)} ${esc(s.name)}</option>`).join('')}</select></div>
            <div class="field mt"><span class="flabel">¿Qué querés hacer?</span>
              <div class="seg" id="newMode">${MODES.map((m, i) => `<button type="button" class="segbtn ${i === 0 ? 'on' : ''}" data-mode="${m.id}">${m.ico} ${m.label}</button>`).join('')}</div></div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center">${quick}</div>
        </div>
      </div>
      <div class="inrow">
        <textarea id="msgInp" rows="1" placeholder="Escribile a NEXTSTEP…" aria-label="Tu mensaje"></textarea>
        <button class="btn primary" id="sendBtn">Enviar</button>
      </div>`;
    let mode = 'explicar';
    main.querySelector('#newMode').addEventListener('click', e => {
      const b = e.target.closest('[data-mode]'); if (!b) return;
      main.querySelectorAll('#newMode .segbtn').forEach(x => x.classList.remove('on'));
      b.classList.add('on'); mode = b.dataset.mode;
    });
    wireComposer(main, async text => {
      const subjectId = Number(main.querySelector('#newSubject').value) || null;
      const conv = await api('/api/conversations', { method: 'POST', body: { subject_id: subjectId, mode, title: text.slice(0, 45) } });
      convs.unshift(conv); activeId = conv.id; currentSubjectId = subjectId;
      history.replaceState(null, '', '#/chat/' + conv.id);
      startConversationUI(conv, [{ role: 'user', content: text }]);
      renderList();
      await send(text, text);
    });
    main.querySelectorAll('[data-quick]').forEach(b => b.onclick = () => { const inp = main.querySelector('#msgInp'); inp.value = b.dataset.quick; autosize(inp); inp.focus(); });
  }

  /* ---------- Conversación existente ---------- */
  async function openConversation(id) {
    let conv;
    try { conv = await api('/api/conversations/' + id); }
    catch (e) { toast('No pude abrir esa sesión.', 'err'); renderNew(); return; }
    currentSubjectId = conv.subject_id;
    startConversationUI(conv, conv.messages);
    // reflejar cambios (título/resumen) en la lista
    const c = convs.find(x => x.id === id);
    if (c) { c.title = conv.title; c.summary = conv.summary; }
  }

  function startConversationUI(conv, messages) {
    const main = document.getElementById('chatmain');
    main.innerHTML = `
      <div class="between" style="padding:12px 16px;border-bottom:1px solid var(--line)">
        <div style="min-width:0">
          <b style="display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(conv.title)}</b>
          <small class="muted">${MODES.find(m => m.id === conv.mode)?.ico || ''} Modo ${esc(MODES.find(m => m.id === conv.mode)?.label || conv.mode)}</small>
        </div>
        <button class="iconbtn danger" id="delConv" title="Borrar sesión" aria-label="Borrar sesión">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M8 6V4h8v2m-9 0 1 14h8l1-14"/></svg>
        </button>
      </div>
      <div class="msgs" id="msgs"></div>
      <div class="quickrow" id="quick"></div>
      <div class="inrow">
        <textarea id="msgInp" rows="1" placeholder="Escribile a NEXTSTEP…" aria-label="Tu mensaje"></textarea>
        <button class="btn primary" id="sendBtn">Enviar</button>
      </div>`;
    const msgs = main.querySelector('#msgs');
    messages.forEach(m => msgs.appendChild(bubble(m.role, m.role === 'user' ? esc(m.content) : fmt(m.content))));
    const last = [...messages].reverse().find(m => m.role === 'assistant');
    renderQuick(last ? readTags(last.content) : []);
    scrollBottom();
    main.querySelector('#delConv').onclick = async () => {
      if (!confirm('¿Borrar esta sesión y sus mensajes?')) return;
      try {
        await api('/api/conversations/' + conv.id, { method: 'DELETE' });
        convs = convs.filter(c => c.id !== conv.id);
        activeId = convs[0]?.id || null;
        if (activeId) { openConversation(activeId); } else { renderNew(); }
        renderList(); toast('Sesión borrada', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
    wireComposer(main, text => send(text));
  }

  /* ---------- Envío con streaming ---------- */
  function wireComposer(main, onSend) {
    const inp = main.querySelector('#msgInp');
    const btn = main.querySelector('#sendBtn');
    inp.addEventListener('input', () => autosize(inp));
    inp.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && window.matchMedia('(hover:hover)').matches) { e.preventDefault(); onSend(inp.value); }
    });
    btn.onclick = () => { if (streaming) { ctl?.abort(); } else { onSend(inp.value); } };
    main._getInput = () => inp;
    main._btn = btn;
  }
  function autosize(i) { i.style.height = 'auto'; i.style.height = Math.min(i.scrollHeight, 130) + 'px'; }

  async function send(text, retitle) {
    text = (text || '').trim();
    if (!text || streaming) return;
    const main = document.getElementById('chatmain');
    const msgs = main.querySelector('#msgs');
    const inp = main._getInput();
    inp.value = ''; autosize(inp);
    if (!retitle) msgs.appendChild(bubble('user', esc(text)));
    scrollBottom();
    renderQuick([]);
    const live = msgs.appendChild(bubble('ai', '<span class="think">Pensando…</span>')).querySelector('.bub');
    streaming = true; setBtn(main, true); lastTrack = Date.now();
    ctl = new AbortController();
    let full = '';
    try {
      const res = await streamChat({ conversation_id: activeId, subject_id: currentSubjectId, message: text }, t => {
        full = t; live.innerHTML = fmt(t) || '<span class="think">Pensando…</span>';
        scrollBottomIfNear();
      }, ctl.signal);
      full = res.full || full;
      if (!full.trim()) throw new Error('La IA no devolvió nada.');
      live.innerHTML = fmt(full);
      renderQuick(readTags(full));
      // refrescar metadatos de la conversación
      try { const c = await api('/api/conversations/' + activeId); const cc = convs.find(x => x.id === activeId); if (cc) { cc.title = c.title; cc.summary = c.summary; cc.message_count = c.messages.length; } renderList(); } catch { /* */ }
    } catch (e) {
      if (e.name === 'AbortError') { if (full.trim()) live.innerHTML = fmt(full); else live.closest('.msg')?.remove(); }
      else { live.innerHTML = `<span class="err">${esc(e.message)}</span>`; toast(e.message, 'err'); }
    } finally { streaming = false; ctl = null; setBtn(main, false); refreshHeader(); }
  }

  function renderQuick(list) {
    const q = document.getElementById('quick'); if (!q) return;
    q.innerHTML = list.map(t => `<button class="chip" data-q="${esc(t)}">${esc(t)}</button>`).join('');
    q.querySelectorAll('[data-q]').forEach(b => b.onclick = () => send(b.dataset.q));
  }
  function setBtn(main, busy) { if (main._btn) main._btn.textContent = busy ? 'Parar' : 'Enviar'; }
  function bubble(role, html) {
    const d = document.createElement('div');
    d.className = 'msg ' + (role === 'user' ? 'user' : 'ai');
    d.innerHTML = `<div class="bub">${html}</div>`;
    return d;
  }
  function scrollBottom() { const m = document.getElementById('msgs'); if (m) m.scrollTop = m.scrollHeight; }
  function scrollBottomIfNear() { const m = document.getElementById('msgs'); if (m && m.scrollHeight - m.scrollTop - m.clientHeight < 200) m.scrollTop = m.scrollHeight; }
  async function refreshHeader() {
    try {
      const me = await api('/api/auth/me');
      store.me = me;
      window.dispatchEvent(new CustomEvent('profile-updated', { detail: me }));
    } catch { /* */ }
  }
}
