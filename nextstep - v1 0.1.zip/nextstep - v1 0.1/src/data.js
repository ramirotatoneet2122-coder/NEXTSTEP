// Banco de preguntas, recursos verificados y plantillas de rutas de NEXTSTEP.
// Las preguntas están verificadas a mano: la IA usa ESTE banco para el test.
// Los links de COURSES son los únicos que la IA puede recomendar.

const RANKS = ['Iniciante', 'Básico', 'Intermedio', 'Avanzado', 'Experto'];
const RANK_MIN = [0, 25, 50, 75, 90];
const rankOf = p => { let r = 0; RANK_MIN.forEach((m, i) => { if (p >= m) r = i; }); return r; };
const GOALS = { examen: 'Rendir un examen', trabajo: 'Conseguir trabajo', cv: 'Mejorar mi CV', proyecto: 'Hacer un proyecto' };

const TOPICS = {
  html: {
    name: 'HTML', qs: [
      { d: 1, s: 'Etiquetas básicas', q: '¿Qué etiqueta se usa para crear un enlace?', o: ['<link>', '<a>', '<href>', '<url>'], a: 1, e: 'La etiqueta <a> con href crea enlaces.' },
      { d: 1, s: 'Estructura de la página', q: '¿Dónde va el contenido visible de la página?', o: ['<head>', '<meta>', '<html>', '<body>'], a: 3, e: '<body> contiene lo que se ve; <head> guarda metadatos.' },
      { d: 2, s: 'Accesibilidad', q: '¿Qué atributo da el texto alternativo de una imagen?', o: ['alt', 'src', 'title', 'name'], a: 0, e: 'alt describe la imagen para lectores de pantalla.' },
      { d: 2, s: 'Listas', q: '¿Qué etiqueta crea una lista numerada?', o: ['<ul>', '<li>', '<dl>', '<ol>'], a: 3, e: '<ol> es la lista ordenada; <ul> es de viñetas.' },
      { d: 3, s: 'HTML semántico', q: '¿Cuál de estas es una etiqueta semántica?', o: ['<div>', '<span>', '<article>', '<b>'], a: 2, e: '<article> da significado; <div> y <span> son genéricas.' },
      { d: 3, s: 'Formularios', q: '¿Qué atributo hace obligatorio un campo de formulario?', o: ['required', 'mandatory', 'validate', 'needed'], a: 0, e: 'required impide enviar el formulario con el campo vacío.' },
    ],
  },
  js: {
    name: 'JavaScript', qs: [
      { d: 1, s: 'Variables', q: '¿Cuál declara una constante?', o: ['var x', 'let x', 'const x', 'static x'], a: 2, e: 'const declara un valor que no se reasigna.' },
      { d: 1, s: 'Consola', q: '¿Cómo se muestra un mensaje en la consola?', o: ['print("hola")', 'console.log("hola")', 'echo "hola"', 'log.console("hola")'], a: 1, e: 'console.log() escribe en la consola.' },
      { d: 2, s: 'Comparaciones', q: '¿Qué devuelve 5 === "5"?', o: ['true', 'false', 'undefined', 'Error'], a: 1, e: '=== compara valor y tipo.' },
      { d: 2, s: 'Arrays', q: '¿Qué método agrega un elemento al final de un array?', o: ['shift', 'add', 'push', 'append'], a: 2, e: 'push agrega al final; shift saca el primero.' },
      { d: 3, s: 'Funciones flecha', q: '¿Qué imprime? const f = x => x * 2; console.log(f(4))', o: ['4', '8', 'x*2', 'undefined'], a: 1, e: 'Duplica el argumento: 8.' },
      { d: 3, s: 'Asincronía', q: '¿Para qué sirve await?', o: ['Repetir una función', 'Esperar el resultado de una promesa', 'Declarar una variable', 'Cortar un bucle'], a: 1, e: 'await pausa la función async hasta que la promesa se resuelve.' },
    ],
  },
  java: {
    name: 'Java', qs: [
      { d: 1, s: 'Tipos de datos', q: '¿Qué tipo guarda texto?', o: ['char', 'text', 'String', 'Str'], a: 2, e: 'String guarda cadenas; char, un solo carácter.' },
      { d: 1, s: 'Objetos', q: '¿Qué palabra clave crea un objeto nuevo?', o: ['new', 'make', 'create', 'object'], a: 0, e: 'new llama al constructor.' },
      { d: 2, s: 'Método main', q: '¿Cómo se declara el método principal?', o: ['void start()', 'public static void main(String[] args)', 'main()', 'static int run()'], a: 1, e: 'La JVM busca public static void main(String[] args).' },
      { d: 2, s: 'Bucles', q: '¿Cuál es una estructura de repetición?', o: ['if', 'switch', 'return', 'for'], a: 3, e: 'for repite un bloque; if y switch son condicionales.' },
      { d: 3, s: 'Herencia', q: '¿Qué palabra clave permite heredar de otra clase?', o: ['implements', 'extends', 'inherits', 'super'], a: 1, e: 'extends hereda de una clase; implements es para interfaces.' },
      { d: 3, s: 'Encapsulamiento', q: '¿Qué modificador impide acceder a un atributo desde otra clase?', o: ['public', 'private', 'static', 'final'], a: 1, e: 'private limita el acceso a la propia clase.' },
    ],
  },
  sql: {
    name: 'Bases de datos (SQL)', qs: [
      { d: 1, s: 'Consultas básicas', q: '¿Qué sentencia lee datos de una tabla?', o: ['GET', 'SELECT', 'READ', 'FETCH'], a: 1, e: 'SELECT consulta datos.' },
      { d: 1, s: 'Filtros', q: '¿Qué cláusula filtra filas?', o: ['WHERE', 'ORDER BY', 'GROUP BY', 'LIMIT'], a: 0, e: 'WHERE deja las filas que cumplen la condición.' },
      { d: 2, s: 'Claves', q: '¿Qué identifica de forma única cada fila de una tabla?', o: ['Clave foránea', 'Índice', 'Clave primaria', 'Vista'], a: 2, e: 'La clave primaria es única y no nula.' },
      { d: 2, s: 'Ordenar resultados', q: '¿Qué cláusula ordena los resultados?', o: ['SORT', 'ORDER BY', 'ARRANGE', 'GROUP BY'], a: 1, e: 'ORDER BY ordena por columnas.' },
      { d: 3, s: 'JOIN', q: '¿Qué hace un INNER JOIN?', o: ['Trae todas las filas de ambas tablas', 'Trae solo las filas con coincidencia en ambas tablas', 'Borra filas duplicadas', 'Une dos bases de datos'], a: 1, e: 'Devuelve solo las filas con par en las dos tablas.' },
      { d: 3, s: 'Funciones de agregación', q: '¿Qué función cuenta filas?', o: ['SUM()', 'COUNT()', 'TOTAL()', 'LEN()'], a: 1, e: 'COUNT() cuenta filas; SUM() suma valores.' },
    ],
  },
  redes: {
    name: 'Redes', qs: [
      { d: 1, s: 'Direcciones IP', q: '¿Qué identifica una dirección IP?', o: ['Un usuario', 'Un programa', 'Un dispositivo en una red', 'Un sitio web'], a: 2, e: 'La IP identifica un dispositivo en una red.' },
      { d: 1, s: 'Protocolos web', q: '¿Qué protocolo cifra la comunicación web?', o: ['HTTP', 'FTP', 'HTTPS', 'SMTP'], a: 2, e: 'HTTPS es HTTP con cifrado TLS.' },
      { d: 2, s: 'Dispositivos de red', q: '¿Qué dispositivo enruta paquetes entre redes distintas?', o: ['Switch', 'Router', 'Hub', 'Repetidor'], a: 1, e: 'El router conecta redes; el switch conecta equipos de una misma red.' },
      { d: 2, s: 'DNS', q: '¿Para qué sirve el DNS?', o: ['Cifrar archivos', 'Traducir nombres de dominio a direcciones IP', 'Acelerar el Wi-Fi', 'Bloquear virus'], a: 1, e: 'Convierte nombres de dominio en direcciones IP.' },
      { d: 3, s: 'Puertos', q: '¿Cuál es el puerto por defecto de HTTPS?', o: ['80', '21', '443', '25'], a: 2, e: 'HTTPS usa el 443; HTTP, el 80.' },
      { d: 3, s: 'Subredes', q: '¿Cuántas direcciones útiles para dispositivos tiene una red /24?', o: ['256', '254', '255', '128'], a: 1, e: '256 menos la de red y la de broadcast: 254.' },
    ],
  },
  mate: {
    name: 'Matemática', qs: [
      { d: 1, s: 'Porcentajes', q: '¿Cuánto es el 15% de 200?', o: ['20', '30', '15', '45'], a: 1, e: '200 × 0,15 = 30.' },
      { d: 1, s: 'Orden de operaciones', q: '¿Cuánto es 3 + 4 × 2?', o: ['14', '11', '10', '9'], a: 1, e: 'Primero 4 × 2 = 8; luego 3 + 8 = 11.' },
      { d: 2, s: 'Ecuaciones', q: 'Resolvé: 2x + 6 = 14', o: ['x = 3', 'x = 10', 'x = 4', 'x = 8'], a: 2, e: '2x = 8, entonces x = 4.' },
      { d: 2, s: 'Geometría', q: '¿Cuál es el área de un círculo de radio 3?', o: ['6π', '3π', '12π', '9π'], a: 3, e: 'π × r² = 9π.' },
      { d: 3, s: 'Funciones', q: 'Si f(x) = 2x² − 3, ¿cuánto vale f(3)?', o: ['15', '9', '12', '18'], a: 0, e: '2 × 9 − 3 = 15.' },
      { d: 3, s: 'Sistemas de ecuaciones', q: 'Si x + y = 10 y x − y = 2, ¿cuánto vale x?', o: ['4', '6', '8', '2'], a: 1, e: 'Sumando: 2x = 12, entonces x = 6.' },
    ],
  },
  lengua: {
    name: 'Lengua', qs: [
      { d: 1, s: 'Tildes', q: '¿Cuál de estas palabras está bien escrita?', o: ['Cancion', 'Cancíon', 'Canción', 'Cáncion'], a: 2, e: 'Aguda terminada en n: lleva tilde.' },
      { d: 1, s: 'Clases de palabras', q: '¿Cuál de estas palabras es un verbo?', o: ['Mesa', 'Correr', 'Rápido', 'Azul'], a: 1, e: 'Correr expresa una acción.' },
      { d: 2, s: 'Hay, ahí y ay', q: 'Completá: "___ muchos libros en la mesa."', o: ['Ahí', 'Hay', 'Ay', 'Ahy'], a: 1, e: '"Hay" (de haber) indica existencia; "ahí" indica lugar.' },
      { d: 2, s: 'Sujeto y predicado', q: 'En "Los chicos juegan en la plaza", ¿cuál es el sujeto?', o: ['juegan', 'en la plaza', 'Los chicos', 'la plaza'], a: 2, e: 'Es quien realiza la acción: "Los chicos".' },
      { d: 3, s: 'Conectores', q: '¿Qué conector expresa oposición?', o: ['Además', 'Sin embargo', 'Por lo tanto', 'Es decir'], a: 1, e: '"Sin embargo" contrasta ideas.' },
      { d: 3, s: 'Tipos de texto', q: 'Un texto que busca convencer con argumentos es:', o: ['Narrativo', 'Instructivo', 'Argumentativo', 'Descriptivo'], a: 2, e: 'El argumentativo defiende una postura con razones.' },
    ],
  },
  ingles: {
    name: 'Inglés', qs: [
      { d: 1, s: 'Vocabulario', q: '¿Qué significa "knowledge"?', o: ['Rodilla', 'Conocimiento', 'Cuchillo', 'Noticia'], a: 1, e: 'Knowledge es conocimiento.' },
      { d: 1, s: 'Verbo to be', q: 'Completá: She ___ a student.', o: ['am', 'are', 'is', 'be'], a: 2, e: 'Con she, he, it: "is".' },
      { d: 2, s: 'Pasado simple', q: '¿Cuál es el pasado de "go"?', o: ['goed', 'went', 'gone', 'going'], a: 1, e: 'go, went, gone.' },
      { d: 2, s: 'Preposiciones', q: 'Completá: "I\'ll see you ___ Monday."', o: ['in', 'at', 'by', 'on'], a: 3, e: 'Con días se usa "on".' },
      { d: 3, s: 'Present perfect', q: '¿Cuál oración es correcta?', o: ['I have lived here since 2020', 'I live here since 2020', 'I am living here since 2020', 'I lived here since 2020'], a: 0, e: 'Algo que empezó en el pasado y sigue: present perfect con since.' },
      { d: 3, s: 'Condicionales', q: 'Completá: "If I ___ more time, I would study more."', o: ['have', 'had', 'will have', 'would have'], a: 1, e: 'Segundo condicional: pasado simple en el "if".' },
    ],
  },
};
const EFF_H = [15, 60, 200];
const FCC = 'https://www.freecodecamp.org/espanol/learn/';
const COURSES = [
  { topics: ['html'], title: 'Diseño web responsivo', org: 'freeCodeCamp', url: FCC, kind: 'Certificado', cert: 1, free: 1, effort: 2, min: 0, goals: ['trabajo', 'cv'] },
  { topics: ['html', 'js'], title: 'Aprender desarrollo web', org: 'MDN Web Docs', url: 'https://developer.mozilla.org/es/docs/Learn', kind: 'Curso', cert: 0, free: 1, effort: 1, min: 0, goals: ['examen', 'proyecto'] },
  { topics: ['html', 'js'], title: 'Desafíos de frontend', org: 'Frontend Mentor', url: 'https://www.frontendmentor.io/', kind: 'Proyecto', cert: 0, free: 1, effort: 1, min: 1, goals: ['proyecto', 'cv'] },
  { topics: ['js'], title: 'Algoritmos y estructuras de datos con JavaScript', org: 'freeCodeCamp', url: FCC, kind: 'Certificado', cert: 1, free: 1, effort: 2, min: 1, goals: ['trabajo', 'cv'] },
  { topics: ['js', 'html'], title: 'Ruta completa de desarrollo web', org: 'The Odin Project', url: 'https://www.theodinproject.com/', kind: 'Proyecto', cert: 0, free: 1, effort: 2, min: 2, goals: ['trabajo', 'proyecto', 'cv'] },
  { topics: ['java', 'js'], title: 'Ejercicios de práctica con mentores', org: 'Exercism', url: 'https://exercism.org/', kind: 'Práctica', cert: 0, free: 1, effort: 1, min: 1, goals: ['examen', 'trabajo'] },
  { topics: ['java'], title: 'Learn Java', org: 'Codecademy', url: 'https://www.codecademy.com/learn/learn-java', kind: 'Curso', cert: 2, free: 0, effort: 1, min: 0, goals: ['examen', 'cv'] },
  { topics: ['java'], title: 'Certificaciones de Java', org: 'Oracle', url: 'https://education.oracle.com/', kind: 'Certificado', cert: 2, free: 0, effort: 2, min: 3, goals: ['trabajo', 'cv', 'examen'] },
  { topics: ['sql'], title: 'Bases de datos relacionales', org: 'freeCodeCamp', url: FCC, kind: 'Certificado', cert: 1, free: 1, effort: 2, min: 1, goals: ['trabajo', 'cv'] },
  { topics: ['sql'], title: 'Lecciones interactivas de SQL', org: 'SQLBolt', url: 'https://sqlbolt.com/', kind: 'Curso', cert: 0, free: 1, effort: 0, min: 0, goals: ['examen', 'proyecto'] },
  { topics: ['redes'], title: 'Cursos de redes con insignia', org: 'Cisco Networking Academy', url: 'https://www.netacad.com/', kind: 'Certificado', cert: 1, free: 1, effort: 1, min: 0, goals: ['trabajo', 'cv', 'examen'] },
  { topics: ['redes'], title: 'Google IT Support', org: 'Coursera', url: 'https://www.coursera.org/professional-certificates/google-it-support', kind: 'Certificado', cert: 2, free: 0, effort: 2, min: 1, goals: ['trabajo', 'cv'] },
  { topics: ['mate'], title: 'Matemática', org: 'Khan Academy', url: 'https://es.khanacademy.org/math', kind: 'Curso', cert: 0, free: 1, effort: 1, min: 0, goals: ['examen'] },
  { topics: ['lengua', 'mate'], title: 'Recursos para el secundario', org: 'Educ.ar', url: 'https://www.educ.ar/', kind: 'Curso', cert: 0, free: 1, effort: 0, min: 0, goals: ['examen'] },
  { topics: ['ingles'], title: 'LearnEnglish', org: 'British Council', url: 'https://learnenglish.britishcouncil.org/', kind: 'Curso', cert: 0, free: 1, effort: 1, min: 0, goals: ['examen', 'cv'] },
  { topics: ['ingles'], title: 'Exámenes de inglés', org: 'Cambridge English', url: 'https://www.cambridgeenglish.org/', kind: 'Certificado', cert: 2, free: 0, effort: 2, min: 2, goals: ['trabajo', 'cv', 'examen'] },
  { topics: ['html', 'js', 'java', 'sql'], title: 'Subí tus proyectos a GitHub', org: 'GitHub', url: 'https://github.com/', kind: 'Proyecto', cert: 0, free: 1, effort: 0, min: 1, goals: ['cv', 'trabajo', 'proyecto'] },
];

// Plantillas de rutas de aprendizaje: se usan como base cuando la IA no está configurada o cuando el
// tema coincide. El progreso se calcula de las actividades completadas, no de un número arbitrario.
const TEMPLATES = {
  java: {
    title: 'Aprender Java desde cero',
    match: ['java'],
    modules: [
      { title: 'Fundamentos de programación', objective: 'Entender qué es un programa, un algoritmo y cómo funciona un compilador.', adds: [
        { kind: 'explicacion', title: '¿Qué es un programa y cómo corre?' },
        { kind: 'practica', title: 'Escribí en palabras los pasos para "multiplicar dos números"' },
        { kind: 'evaluacion', title: 'Mini-evaluación de fundamentos' },
      ] },
      { title: 'Variables y tipos de datos', objective: 'Declarar variables, elegir el tipo correcto y operar con ellas.', adds: [
        { kind: 'explicacion', title: 'Variables, tipos y operadores' },
        { kind: 'practica', title: 'Declará variables de distintos tipos y mostrá su valor' },
        { kind: 'evaluacion', title: 'Ejercicios de variables' },
      ] },
      { title: 'Condicionales', objective: 'Tomar decisiones con if/else y entender las condiciones booleanas.', adds: [
        { kind: 'explicacion', title: 'Estructuras condicionales' },
        { kind: 'practica', title: 'Programá un "¿es mayor de edad?"' },
        { kind: 'evaluacion', title: 'Ejercicios de condicionales' },
      ] },
      { title: 'Bucles', objective: 'Repetir acciones con for y while.', adds: [
        { kind: 'explicacion', title: 'Bucles for y while' },
        { kind: 'practica', title: 'Mostrá los números del 1 al 10 en un bucle' },
        { kind: 'evaluacion', title: 'Ejercicios de bucles' },
      ] },
      { title: 'Métodos', objective: 'Dividir el código en funciones/métodos reutilizables.', adds: [
        { kind: 'explicacion', title: 'Métodos y parámetros' },
        { kind: 'practica', title: 'Creá un método que sume dos números y usalo' },
        { kind: 'evaluacion', title: 'Ejercicios de métodos' },
      ] },
      { title: 'Arrays', objective: 'Guardar listas de datos y recorrerlas.', adds: [
        { kind: 'explicacion', title: 'Arrays: declaración, acceso y recorrido' },
        { kind: 'practica', title: 'Guardá 5 notas en un array y mostrá el promedio' },
        { kind: 'evaluacion', title: 'Ejercicios de arrays' },
      ] },
      { title: 'Programación orientada a objetos', objective: 'Entender clases, objetos, atributos y métodos.', adds: [
        { kind: 'explicacion', title: 'Clases y objetos' },
        { kind: 'practica', title: 'Modelá una clase Alumno con nombre y nota' },
        { kind: 'evaluacion', title: 'Ejercicios de POO' },
      ] },
      { title: 'Proyecto integrador', objective: 'Aplicar todo lo aprendido en un proyecto pequeño.', adds: [
        { kind: 'proyecto', title: 'Proyecto: agenda de contactos por consola' },
        { kind: 'proyecto', title: 'Proyecto: crear tu propio mini-problema y resolverlo' },
      ] },
    ],
  },
  'html-css': {
    title: 'Crear páginas web (HTML y CSS)',
    match: ['html'],
    modules: [
      { title: 'Cómo funciona la web', objective: 'Entender qué pasa al abrir una página y qué hace el navegador.', adds: [
        { kind: 'explicacion', title: 'Navegador, servidor y HTML' },
        { kind: 'practica', title: 'Abrí el código de una página que conozcas (clic derecho > inspeccionar)' },
      ] },
      { title: 'Primeras etiquetas', objective: 'Escribir textos, títulos, listas y enlaces.', adds: [
        { kind: 'explicacion', title: 'Texto, títulos, listas y enlaces' },
        { kind: 'practica', title: 'Creá tu primera página con un encabezado y una lista' },
        { kind: 'evaluacion', title: 'Mini-evaluación de HTML básico' },
      ] },
      { title: 'Imágenes y accesibilidad', objective: 'Insertar imágenes y usar texto alternativo.', adds: [
        { kind: 'explicacion', title: 'Imágenes, atributos y accesibilidad' },
        { kind: 'practica', title: 'Agregale una imagen a tu página con texto alternativo' },
      ] },
      { title: 'CSS: color y tipografía', objective: 'Darle estilo al texto con CSS.', adds: [
        { kind: 'explicacion', title: 'Selectores, color y tipografía' },
        { kind: 'practica', title: 'Estilizá tus títulos y párrafos' },
      ] },
      { title: 'El modelo de caja', objective: 'Entender margen, borde y padding para acomodar elementos.', adds: [
        { kind: 'explicacion', title: 'Modelo de caja y espaciado' },
        { kind: 'practica', title: 'Dale márgenes y bordes a tus secciones' },
      ] },
      { title: 'Flexbox y layout', objective: 'Distribuir elementos en filas y columnas.', adds: [
        { kind: 'explicacion', title: 'Flexbox: alinear y distribuir' },
        { kind: 'practica', title: 'Armá una barra de navegación con flexbox' },
      ] },
      { title: 'Proyecto: página personal', objective: 'Integrar todo en una página personal completa.', adds: [
        { kind: 'proyecto', title: 'Proyecto: página personal responsiva' },
      ] },
    ],
  },
  js: {
    title: 'JavaScript desde cero',
    match: ['js'],
    modules: [
      { title: 'Variables y datos', objective: 'Guardar valores con let y const.', adds: [
        { kind: 'explicacion', title: 'Variables, tipos y consola' },
        { kind: 'practica', title: 'Declará variables y mostrálas en la consola' },
        { kind: 'evaluacion', title: 'Mini-evaluación de variables' },
      ] },
      { title: 'Operadores y condiciones', objective: 'Comparar valores y tomar decisiones.', adds: [
        { kind: 'explicacion', title: 'Operadores, if y comparaciones' },
        { kind: 'practica', title: 'Programá una calculadora de propinas con if' },
      ] },
      { title: 'Bucles y arrays', objective: 'Repetir tareas y recorrer listas.', adds: [
        { kind: 'explicacion', title: 'Bucles, arrays y métodos de array' },
        { kind: 'practica', title: 'Recorré un array y sumá sus valores' },
        { kind: 'evaluacion', title: 'Ejercicios de bucles y arrays' },
      ] },
      { title: 'Funciones', objective: 'Escribir código reutilizable.', adds: [
        { kind: 'explicacion', title: 'Funciones, parámetros y return' },
        { kind: 'practica', title: 'Creá una función que convierta kilómetros a millas' },
      ] },
      { title: 'DOM y eventos', objective: 'Manipular la página desde JavaScript.', adds: [
        { kind: 'explicacion', title: 'El DOM, querySelector y eventos' },
        { kind: 'practica', title: 'Hacé un botón que cambie el color de fondo' },
      ] },
      { title: 'Proyecto: lista de tareas', objective: 'Integrar todo en una app de tareas.', adds: [
        { kind: 'proyecto', title: 'Proyecto: lista de tareas interactiva' },
      ] },
    ],
  },
  sql: {
    title: 'Bases de datos con SQL',
    match: ['sql'],
    modules: [
      { title: '¿Qué es una base de datos?', objective: 'Entender tablas, filas y columnas.', adds: [
        { kind: 'explicacion', title: 'Modelo relacional' },
        { kind: 'practica', title: 'Pensá cómo modelarías el listado del curso en tablas' },
      ] },
      { title: 'Consultas básicas', objective: 'Leer datos con SELECT.', adds: [
        { kind: 'explicacion', title: 'SELECT, columnas y aliases' },
        { kind: 'practica', title: 'Escribí consultas SELECT sobre una tabla de alumnos' },
        { kind: 'evaluacion', title: 'Mini-evaluación de SELECT' },
      ] },
      { title: 'Filtros y orden', objective: 'Traer solo lo que necesitás.', adds: [
        { kind: 'explicacion', title: 'WHERE, ORDER BY y LIMIT' },
        { kind: 'practica', title: 'Filtrá alumnos por ciudad y ordenalos por nota' },
      ] },
      { title: 'Claves e integridad', objective: 'Entender claves primarias y foráneas.', adds: [
        { kind: 'explicacion', title: 'Claves, índices e integridad' },
        { kind: 'practica', title: 'Diseñá una tabla de pedidos con claves' },
      ] },
      { title: 'JOINs', objective: 'Combinar tablas relacionadas.', adds: [
        { kind: 'explicacion', title: 'INNER JOIN, LEFT JOIN' },
        { kind: 'practica', title: 'Uní alumnos con cursos y mostrá quién cursa qué' },
        { kind: 'evaluacion', title: 'Ejercicios de JOIN' },
      ] },
      { title: 'Agregación', objective: 'Resumir datos con COUNT, SUM, AVG y GROUP BY.', adds: [
        { kind: 'explicacion', title: 'Funciones de agregación' },
        { kind: 'practica', title: 'Contá alumnos por curso con GROUP BY' },
      ] },
      { title: 'Proyecto: mini sistema de biblioteca', objective: 'Aplicar todo en un proyecto.', adds: [
        { kind: 'proyecto', title: 'Proyecto: consultas para una biblioteca' },
      ] },
    ],
  },
  mate: {
    title: 'Matemática nivel secundario',
    match: ['mate', 'matematica', 'matemáticas'],
    modules: [
      { title: 'Números enteros y racionales', objective: 'Operar con negativos, fracciones y decimales.', adds: [
        { kind: 'explicacion', title: 'Enteros y racionales' },
        { kind: 'practica', title: 'Resolvé operaciones combinadas con fracciones' },
        { kind: 'evaluacion', title: 'Mini-evaluación de racionales' },
      ] },
      { title: 'Porcentajes y proporciones', objective: 'Resolver problemas de porcentaje, regla de tres simple y proporcionalidad.', adds: [
        { kind: 'explicacion', title: 'Porcentajes y regla de tres' },
        { kind: 'practica', title: 'Resolvé problemas de descuentos y aumentos' },
      ] },
      { title: 'Álgebra: ecuaciones', objective: 'Plantear y resolver ecuaciones lineales.', adds: [
        { kind: 'explicacion', title: 'Lenguaje algebraico y ecuaciones' },
        { kind: 'practica', title: 'Resolvé y verificá ecuaciones lineales' },
        { kind: 'evaluacion', title: 'Ejercicios de ecuaciones' },
      ] },
      { title: 'Funciones', objective: 'Entender el concepto de función y leer gráficos.', adds: [
        { kind: 'explicacion', title: 'Función, dominio y gráficos' },
        { kind: 'practica', title: 'Interpretá un gráfico de una función afín' },
      ] },
      { title: 'Geometría', objective: 'Calcular áreas y perímetros.', adds: [
        { kind: 'explicacion', title: 'Áreas y perímetros' },
        { kind: 'practica', title: 'Calculá áreas de figuras compuestas' },
      ] },
      { title: 'Estadística básica', objective: 'Interpretar datos: promedio, mediana y moda.', adds: [
        { kind: 'explicacion', title: 'Medidas de tendencia central' },
        { kind: 'practica', title: 'Calculá promedio y mediana de un conjunto' },
      ] },
      { title: 'Examen integrador', objective: 'Integrar todos los temas.', adds: [
        { kind: 'evaluacion', title: 'Evaluación integradora' },
      ] },
    ],
  },
  ingles: {
    title: 'Inglés: bases para comunicarte',
    match: ['ingles', 'inglés', 'english'],
    modules: [
      { title: 'Verbo to be y saludos', objective: 'Presentarte y hablar de personas.', adds: [
        { kind: 'explicacion', title: 'To be en presente' },
        { kind: 'practica', title: 'Escribí tu presentación en inglés' },
        { kind: 'evaluacion', title: 'Mini-evaluación de to be' },
      ] },
      { title: 'Vocabulario cotidiano', objective: 'Números, días, colores y objetos.', adds: [
        { kind: 'explicacion', title: 'Vocabulario de la vida diaria' },
        { kind: 'practica', title: 'Armá una lista de 10 objetos de tu cuarto en inglés' },
      ] },
      { title: 'Presente simple', objective: 'Hablar de rutinas y hechos.', adds: [
        { kind: 'explicacion', title: 'Presente simple y la 3ª persona' },
        { kind: 'practica', title: 'Describí tu rutina en presente simple' },
      ] },
      { title: 'Pasado simple', objective: 'Contar cosas que ya pasaron.', adds: [
        { kind: 'explicacion', title: 'Pasado simple: regulares e irregulares' },
        { kind: 'practica', title: 'Contá qué hiciste el fin de semana' },
        { kind: 'evaluacion', title: 'Ejercicios de pasado simple' },
      ] },
      { title: 'Futuro y planes', objective: 'Hablar de planes con going to y will.', adds: [
        { kind: 'explicacion', title: 'going to y will' },
        { kind: 'practica', title: 'Escribí tus planes para la próxima semana' },
      ] },
      { title: 'Conversación', objective: 'Armar diálogos y preguntas.', adds: [
        { kind: 'proyecto', title: 'Proyecto: graba un diálogo de presentación' },
      ] },
    ],
  },
};

export { RANKS, RANK_MIN, rankOf, GOALS, TOPICS, EFF_H, COURSES, TEMPLATES };