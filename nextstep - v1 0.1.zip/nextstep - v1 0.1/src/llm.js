// Capa que separa a NEXTSTEP del proveedor de IA. Cambiando variables en .env se elige quién "piensa"
// por detrás; el profesor (prompt, datos y seguimiento) es siempre el del proyecto.
//
//   PROVIDER=anthropic    -> API de Claude (necesita ANTHROPIC_API_KEY)
//   PROVIDER=openai       -> cualquier servidor compatible con la API de OpenAI:
//                            Ollama (corre en tu compu), Groq, OpenRouter, etc.
//                            (necesita OPENAI_BASE_URL, MODEL y, según el servicio, OPENAI_API_KEY)
import Anthropic from '@anthropic-ai/sdk';

const PROVIDER = (process.env.PROVIDER || 'anthropic').toLowerCase();
export const MODEL = process.env.MODEL || (PROVIDER === 'anthropic' ? 'claude-sonnet-5-5' : '');
const MAX_TOKENS = Number(process.env.MAX_TOKENS) || 2000;

export function providerInfo() {
  const ready = PROVIDER === 'anthropic'
    ? Boolean(process.env.ANTHROPIC_API_KEY)
    : Boolean(process.env.OPENAI_BASE_URL && MODEL);
  return { provider: PROVIDER, model: MODEL || null, ready };
}

export function missingConfigMessage() {
  return PROVIDER === 'anthropic'
    ? 'Falta la ANTHROPIC_API_KEY en el archivo .env del servidor.'
    : 'Falta OPENAI_BASE_URL o MODEL en el archivo .env del servidor.';
}

let anthropic = null;
async function viaAnthropic({ system, messages, signal, onText }) {
  anthropic ??= new Anthropic();
  const stream = anthropic.messages.stream({ model: MODEL, max_tokens: MAX_TOKENS, system, messages }, { signal });
  stream.on('text', onText);
  await stream.finalMessage();
}

async function viaOpenAI({ system, messages, signal, onText }) {
  const base = process.env.OPENAI_BASE_URL.replace(/\/$/, '');
  const headers = { 'Content-Type': 'application/json' };
  if (process.env.OPENAI_API_KEY) headers.Authorization = `Bearer ${process.env.OPENAI_API_KEY}`;
  const r = await fetch(`${base}/chat/completions`, {
    method: 'POST',
    headers,
    signal,
    body: JSON.stringify({
      model: MODEL,
      stream: true,
      max_tokens: MAX_TOKENS,
      messages: [{ role: 'system', content: system }, ...messages],
    }),
  });
  if (!r.ok) {
    const err = new Error(`El servidor de IA respondió ${r.status}`);
    err.status = r.status;
    throw err;
  }
  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) return;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line.startsWith('data:')) continue;
      const data = line.slice(5).trim();
      if (data === '[DONE]') return;
      try {
        const t = JSON.parse(data).choices?.[0]?.delta?.content;
        if (t) onText(t);
      } catch { /* línea incompleta o sin texto: se ignora */ }
    }
  }
}

// Envía la charla y va llamando onText(trozo) a medida que la IA escribe.
export function streamChat(opts) {
  return PROVIDER === 'anthropic' ? viaAnthropic(opts) : viaOpenAI(opts);
}

// Pide un JSON con forma definida (para generar evaluaciones, rutas, etc.) y lo devuelve parseado.
// Si la IA falla o no devuelve JSON válido, lanza error para que la app use una alternativa segura.
export async function completeJson({ system, prompt, signal, attempts = 2 }) {
  let lastErr = null;
  for (let i = 0; i < attempts; i++) {
    let text = '';
    const ac = signal || new AbortController();
    await streamChat({
      system,
      messages: [{ role: 'user', content: prompt }],
      signal: ac.signal,
      onText: t => { text += t; },
    });
    const json = extractJson(text);
    if (json) return json;
    lastErr = new Error('La IA no devolvió un JSON válido.');
  }
  throw lastErr || new Error('No se pudo generar con la IA.');
}

function extractJson(text) {
  const s = String(text || '');
  const fenced = s.match(/```(?:json)?\s*([\s\S]*?)```/);
  const candidate = fenced ? fenced[1] : s;
  const start = candidate.indexOf('{');
  const end = candidate.lastIndexOf('}');
  if (start >= 0 && end > start) {
    try { return JSON.parse(candidate.slice(start, end + 1)); } catch { /* seguir buscando */ }
  }
  try { return JSON.parse(s); } catch { return null; }
}