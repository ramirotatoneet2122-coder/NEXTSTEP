// Persistencia de NEXTSTEP. Usa el módulo SQLite integrado de Node (node:sqlite, Node >= 22.5),
// así no hace falta compilar dependencias nativas. Guarda todo en data/nextstep.db.
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, '..');
const DB_PATH = process.env.DB_PATH
  ? path.resolve(root, process.env.DB_PATH)
  : path.join(root, 'data', 'nextstep.db');

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

export const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

export const now = () => new Date().toISOString();
const n = v => (typeof v === 'bigint' ? Number(v) : v);
const parseJson = (s, fallback) => {
  try { const o = JSON.parse(s); return o && typeof o === 'object' ? o : fallback; } catch { return fallback; }
};

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  pass_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS profiles (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  nickname TEXT,
  xp INTEGER NOT NULL DEFAULT 0,
  level INTEGER NOT NULL DEFAULT 1,
  streak INTEGER NOT NULL DEFAULT 0,
  best_streak INTEGER NOT NULL DEFAULT 1,
  last_study_date TEXT,
  total_minutes INTEGER NOT NULL DEFAULT 0,
  preferences TEXT NOT NULL DEFAULT '{}',
  appearance TEXT NOT NULL DEFAULT '{}',
  settings TEXT NOT NULL DEFAULT '{}',
  onboarding_done INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS subjects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  emoji TEXT NOT NULL DEFAULT '📘',
  goal TEXT,
  current_level TEXT,
  mastery REAL NOT NULL DEFAULT 0,
  xp INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'activa',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS topics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'pendiente',
  evidence INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT,
  UNIQUE(subject_id, name)
);

CREATE TABLE IF NOT EXISTS conversations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
  title TEXT NOT NULL DEFAULT 'Nueva sesión',
  mode TEXT NOT NULL DEFAULT 'explicar',
  summary TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS learning_paths (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  goal TEXT,
  level_start TEXT,
  status TEXT NOT NULL DEFAULT 'activa',
  source TEXT NOT NULL DEFAULT 'plantilla',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS path_modules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  path_id INTEGER NOT NULL REFERENCES learning_paths(id) ON DELETE CASCADE,
  position INTEGER NOT NULL,
  title TEXT NOT NULL,
  objective TEXT,
  state TEXT NOT NULL DEFAULT 'pendiente'
);

CREATE TABLE IF NOT EXISTS path_activities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  module_id INTEGER NOT NULL REFERENCES path_modules(id) ON DELETE CASCADE,
  position INTEGER NOT NULL,
  kind TEXT NOT NULL DEFAULT 'practica',
  title TEXT NOT NULL,
  content TEXT,
  state TEXT NOT NULL DEFAULT 'pendiente',
  score REAL,
  completed_at TEXT
);

CREATE TABLE IF NOT EXISTS activities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
  path_activity_id INTEGER REFERENCES path_activities(id) ON DELETE SET NULL,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  correct INTEGER,
  score REAL,
  xp INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS evaluations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
  kind TEXT NOT NULL DEFAULT 'seguimiento',
  title TEXT,
  status TEXT NOT NULL DEFAULT 'en_curso',
  score REAL,
  summary TEXT,
  source TEXT NOT NULL DEFAULT 'banco',
  created_at TEXT NOT NULL,
  completed_at TEXT
);

CREATE TABLE IF NOT EXISTS eval_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  evaluation_id INTEGER NOT NULL REFERENCES evaluations(id) ON DELETE CASCADE,
  position INTEGER NOT NULL,
  topic TEXT,
  difficulty INTEGER DEFAULT 2,
  question TEXT NOT NULL,
  options TEXT,
  correct_idx INTEGER,
  correct_text TEXT,
  answer_idx INTEGER,
  answer_text TEXT,
  is_correct INTEGER,
  explanation TEXT
);

CREATE TABLE IF NOT EXISTS goals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  description TEXT,
  due_date TEXT,
  status TEXT NOT NULL DEFAULT 'activo',
  progress INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS goal_tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  goal_id INTEGER NOT NULL REFERENCES goals(id) ON DELETE CASCADE,
  position INTEGER NOT NULL,
  title TEXT NOT NULL,
  done INTEGER NOT NULL DEFAULT 0,
  done_at TEXT
);

CREATE TABLE IF NOT EXISTS study_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  conversation_id INTEGER REFERENCES conversations(id) ON DELETE SET NULL,
  subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
  minutes INTEGER NOT NULL DEFAULT 0,
  started_at TEXT NOT NULL,
  ended_at TEXT
);

CREATE TABLE IF NOT EXISTS achievements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  earned_at TEXT NOT NULL,
  UNIQUE(user_id, code)
);

CREATE TABLE IF NOT EXISTS xp_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL,
  reason TEXT NOT NULL,
  source TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS resources (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  url TEXT,
  kind TEXT NOT NULL DEFAULT 'curso',
  note TEXT,
  source TEXT NOT NULL DEFAULT 'manual',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_activities_user ON activities(user_id);
CREATE INDEX IF NOT EXISTS idx_evals_user ON evaluations(user_id);
CREATE INDEX IF NOT EXISTS idx_xp_user ON xp_events(user_id);
`;

db.exec(SCHEMA);
export const getDbPath = () => DB_PATH;

/* ============================ USUARIOS Y SESIONES ============================ */
export function createUser({ name, email, passHash }) {
  const r = db.prepare('INSERT INTO users (name, email, pass_hash, created_at) VALUES (?,?,?,?)')
    .run(name, email, passHash, now());
  const id = n(r.lastInsertRowid);
  ensureProfile(id);
  return id;
}
export const getUserByEmail = email => db.prepare('SELECT * FROM users WHERE email = ?').get(email);
export const getUserById = id => db.prepare('SELECT * FROM users WHERE id = ?').get(id);

export function createSession(token, userId, expiresAt) {
  db.prepare('INSERT INTO sessions (token, user_id, created_at, expires_at) VALUES (?,?,?,?)')
    .run(token, userId, now(), expiresAt);
}
export const getSession = token => db.prepare('SELECT * FROM sessions WHERE token = ?').get(token);
export const deleteSession = token => db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
export const deleteExpiredSessions = () => db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(now());
export const deleteUserSessions = userId => db.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);

/* ============================ PERFIL ============================ */
export function ensureProfile(userId) {
  const p = db.prepare('SELECT user_id FROM profiles WHERE user_id = ?').get(userId);
  if (!p) db.prepare('INSERT INTO profiles (user_id, updated_at) VALUES (?,?)').run(userId, now());
}
export function getProfile(userId) {
  ensureProfile(userId);
  const r = db.prepare('SELECT * FROM profiles WHERE user_id = ?').get(userId);
  return {
    ...r,
    preferences: parseJson(r.preferences, {}),
    appearance: parseJson(r.appearance, {}),
    settings: parseJson(r.settings, {}),
  };
}
export function updateProfile(userId, fields) {
  const allowed = ['nickname', 'onboarding_done', 'last_study_date', 'streak', 'best_streak', 'total_minutes'];
  const sets = [], vals = [];
  for (const k of allowed) if (k in fields) { sets.push(`${k} = ?`); vals.push(fields[k]); }
  for (const k of ['preferences', 'appearance', 'settings']) {
    if (k in fields) { sets.push(`${k} = ?`); vals.push(JSON.stringify(fields[k] ?? {})); }
  }
  if (!sets.length) return;
  sets.push('updated_at = ?'); vals.push(now(), userId);
  db.prepare(`UPDATE profiles SET ${sets.join(', ')} WHERE user_id = ?`).run(...vals);
}
export function levelForXp(xp) {
  let level = 1;
  while (xp >= 100 * level * level) level++;
  return level;
}
export function xpForLevel(level) { return 100 * level * level; }
export function addXp(userId, amount, reason, source = null) {
  if (!amount) return getProfile(userId);
  db.prepare('INSERT INTO xp_events (user_id, amount, reason, source, created_at) VALUES (?,?,?,?,?)')
    .run(userId, amount, reason, source, now());
  db.prepare('UPDATE profiles SET xp = xp + ?, updated_at = ? WHERE user_id = ?').run(amount, now(), userId);
  const p = db.prepare('SELECT xp FROM profiles WHERE user_id = ?').get(userId);
  const level = levelForXp(p.xp);
  db.prepare('UPDATE profiles SET level = ? WHERE user_id = ?').run(level, userId);
  return { xp: p.xp, level };
}

/* ============================ MATERIAS Y TEMAS ============================ */
export function createSubject(userId, { name, emoji = '📘', goal = '', current_level = '' }) {
  const r = db.prepare(`INSERT INTO subjects (user_id, name, emoji, goal, current_level, created_at, updated_at)
    VALUES (?,?,?,?,?,?,?)`).run(userId, name, emoji, goal, current_level, now(), now());
  return n(r.lastInsertRowid);
}
export const listSubjects = userId => db.prepare('SELECT * FROM subjects WHERE user_id = ? ORDER BY status, id').all(userId);
export const getSubject = (userId, id) => db.prepare('SELECT * FROM subjects WHERE id = ? AND user_id = ?').get(id, userId);
export function updateSubject(userId, id, fields) {
  const allowed = ['name', 'emoji', 'goal', 'current_level', 'status', 'mastery', 'xp'];
  const sets = [], vals = [];
  for (const k of allowed) if (k in fields) { sets.push(`${k} = ?`); vals.push(fields[k]); }
  if (!sets.length) return;
  sets.push('updated_at = ?'); vals.push(now(), id, userId);
  db.prepare(`UPDATE subjects SET ${sets.join(', ')} WHERE id = ? AND user_id = ?`).run(...vals);
}
export const deleteSubject = (userId, id) => db.prepare('DELETE FROM subjects WHERE id = ? AND user_id = ?').run(id, userId);
export function upsertTopic(subjectId, name, state, evidenceDelta = 0) {
  const existing = db.prepare('SELECT * FROM topics WHERE subject_id = ? AND name = ?').get(subjectId, name);
  if (existing) {
    db.prepare('UPDATE topics SET state = ?, evidence = MAX(0, evidence + ?), updated_at = ? WHERE id = ?')
      .run(state, evidenceDelta, now(), existing.id);
  } else {
    db.prepare('INSERT INTO topics (subject_id, name, state, evidence, updated_at) VALUES (?,?,?,?,?)')
      .run(subjectId, name, state, Math.max(0, evidenceDelta), now());
  }
}
export const listTopics = subjectId => db.prepare('SELECT * FROM topics WHERE subject_id = ? ORDER BY name').all(subjectId);

/* ============================ CONVERSACIONES ============================ */
export function createConversation(userId, { subjectId = null, title = 'Nueva sesión', mode = 'explicar' } = {}) {
  const r = db.prepare(`INSERT INTO conversations (user_id, subject_id, title, mode, created_at, updated_at)
    VALUES (?,?,?,?,?,?)`).run(userId, subjectId, title, mode, now(), now());
  return n(r.lastInsertRowid);
}
export const listConversations = userId =>
  db.prepare(`SELECT c.*, (SELECT COUNT(*) FROM messages m WHERE m.conversation_id = c.id) AS message_count
    FROM conversations c WHERE c.user_id = ? ORDER BY c.updated_at DESC`).all(userId);
export const getConversation = (userId, id) =>
  db.prepare('SELECT * FROM conversations WHERE id = ? AND user_id = ?').get(id, userId);
export function updateConversation(userId, id, fields) {
  const allowed = ['title', 'subject_id', 'mode', 'summary'];
  const sets = [], vals = [];
  for (const k of allowed) if (k in fields) { sets.push(`${k} = ?`); vals.push(fields[k]); }
  if (!sets.length) return;
  sets.push('updated_at = ?'); vals.push(now(), id, userId);
  db.prepare(`UPDATE conversations SET ${sets.join(', ')} WHERE id = ? AND user_id = ?`).run(...vals);
}
export const deleteConversation = (userId, id) => db.prepare('DELETE FROM conversations WHERE id = ? AND user_id = ?').run(id, userId);
export function addMessage(conversationId, role, content) {
  const r = db.prepare('INSERT INTO messages (conversation_id, role, content, created_at) VALUES (?,?,?,?)')
    .run(conversationId, role, String(content).slice(0, 12000), now());
  db.prepare('UPDATE conversations SET updated_at = ? WHERE id = ?').run(now(), conversationId);
  return n(r.lastInsertRowid);
}
export const listMessages = conversationId =>
  db.prepare('SELECT id, role, content, created_at FROM messages WHERE conversation_id = ? ORDER BY id').all(conversationId);

/* ============================ RUTAS DE APRENDIZAJE ============================ */
export function createPath(userId, { subjectId = null, title, goal = '', levelStart = '', source = 'plantilla' }) {
  const r = db.prepare(`INSERT INTO learning_paths (user_id, subject_id, title, goal, level_start, source, created_at, updated_at)
    VALUES (?,?,?,?,?,?,?,?)`).run(userId, subjectId, title, goal, levelStart, source, now(), now());
  return n(r.lastInsertRowid);
}
export function addModule(pathId, { position, title, objective = '' }) {
  const r = db.prepare('INSERT INTO path_modules (path_id, position, title, objective) VALUES (?,?,?,?)')
    .run(pathId, position, title, objective);
  return n(r.lastInsertRowid);
}
export function addPathActivity(moduleId, { position, kind = 'practica', title, content = '' }) {
  const r = db.prepare('INSERT INTO path_activities (module_id, position, kind, title, content) VALUES (?,?,?,?,?)')
    .run(moduleId, position, kind, title, content);
  return n(r.lastInsertRowid);
}
export const listPaths = userId =>
  db.prepare('SELECT * FROM learning_paths WHERE user_id = ? ORDER BY status, id DESC').all(userId);
export const getPath = (userId, id) => db.prepare('SELECT * FROM learning_paths WHERE id = ? AND user_id = ?').get(id, userId);
export const listModules = pathId => db.prepare('SELECT * FROM path_modules WHERE path_id = ? ORDER BY position').all(pathId);
export const getModule = moduleId => db.prepare('SELECT * FROM path_modules WHERE id = ?').get(moduleId);
export const listPathActivities = moduleId => db.prepare('SELECT * FROM path_activities WHERE module_id = ? ORDER BY position').all(moduleId);
export function updatePathStatus(id, status) {
  if (!['activa', 'pausada', 'finalizada'].includes(status)) return;
  db.prepare('UPDATE learning_paths SET status = ?, updated_at = ? WHERE id = ?').run(status, now(), id);
}
export const getPathActivity = id => db.prepare('SELECT * FROM path_activities WHERE id = ?').get(id);
export function updateModule(id, fields) {
  const sets = [], vals = [];
  for (const k of ['state', 'title', 'objective', 'position']) if (k in fields) { sets.push(`${k} = ?`); vals.push(fields[k]); }
  if (!sets.length) return;
  vals.push(id);
  db.prepare(`UPDATE path_modules SET ${sets.join(', ')} WHERE id = ?`).run(...vals);
}
export function setPathActivity(id, fields) {
  const sets = [], vals = [];
  for (const k of ['state', 'score', 'title', 'content', 'kind']) if (k in fields) { sets.push(`${k} = ?`); vals.push(fields[k]); }
  if ('state' in fields) { sets.push('completed_at = ?'); vals.push(fields.state === 'completado' ? now() : null); }
  if (!sets.length) return;
  vals.push(id);
  db.prepare(`UPDATE path_activities SET ${sets.join(', ')} WHERE id = ?`).run(...vals);
}
// Recalcula el estado de módulos y la ruta según actividades completadas (sin porcentajes arbitrarios).
export function recalcModule(moduleId) {
  const acts = listPathActivities(moduleId);
  if (!acts.length) return;
  const done = acts.filter(a => a.state === 'completado').length;
  const state = done === 0 ? 'pendiente' : done === acts.length ? 'completado' : 'en_curso';
  updateModule(moduleId, { state });
}
export function deletePath(userId, id) { db.prepare('DELETE FROM learning_paths WHERE id = ? AND user_id = ?').run(id, userId); }

/* ============================ ACTIVIDADES ============================ */
export function logActivity(userId, { subjectId = null, pathActivityId = null, kind, title, correct = null, score = null, xp = 0 }) {
  const r = db.prepare(`INSERT INTO activities (user_id, subject_id, path_activity_id, kind, title, correct, score, xp, created_at)
    VALUES (?,?,?,?,?,?,?,?,?)`).run(userId, subjectId, pathActivityId, kind, title, correct, score, xp, now());
  return n(r.lastInsertRowid);
}
export const listActivities = (userId, limit = 50) =>
  db.prepare('SELECT * FROM activities WHERE user_id = ? ORDER BY id DESC LIMIT ?').all(userId, limit);

/* ============================ EVALUACIONES ============================ */
export function createEvaluation(userId, { subjectId = null, kind = 'seguimiento', title = '', source = 'banco' }) {
  const r = db.prepare(`INSERT INTO evaluations (user_id, subject_id, kind, title, source, created_at)
    VALUES (?,?,?,?,?,?)`).run(userId, subjectId, kind, title, source, now());
  return n(r.lastInsertRowid);
}
export function addEvalItem(evaluationId, { position, topic = '', difficulty = 2, question, options = null, correctIdx = null, correctText = null, explanation = '' }) {
  const r = db.prepare(`INSERT INTO eval_items (evaluation_id, position, topic, difficulty, question, options, correct_idx, correct_text, explanation)
    VALUES (?,?,?,?,?,?,?,?,?)`)
    .run(evaluationId, position, topic, difficulty, question, options ? JSON.stringify(options) : null, correctIdx, correctText, explanation);
  return n(r.lastInsertRowid);
}
export const listEvalItems = evalId => db.prepare('SELECT * FROM eval_items WHERE evaluation_id = ? ORDER BY position').all(evalId).map(i => ({
  ...i, options: parseJson(i.options, null),
}));
export const getEvalItem = id => db.prepare('SELECT * FROM eval_items WHERE id = ?').get(id);
export const getEvaluation = (userId, id) => db.prepare('SELECT * FROM evaluations WHERE id = ? AND user_id = ?').get(id, userId);
export function saveEvalAnswer(itemId, { answerIdx = null, answerText = null, isCorrect = null }) {
  db.prepare('UPDATE eval_items SET answer_idx = ?, answer_text = ?, is_correct = ? WHERE id = ?')
    .run(answerIdx, answerText, isCorrect, itemId);
}
export function completeEvaluation(id, { score, summary }) {
  db.prepare('UPDATE evaluations SET status = ?, score = ?, summary = ?, completed_at = ? WHERE id = ?')
    .run('completada', score, summary, now(), id);
}
export const setEvalSource = (id, source) => db.prepare('UPDATE evaluations SET source = ? WHERE id = ?').run(source, id);
export const listEvaluations = userId =>
  db.prepare('SELECT * FROM evaluations WHERE user_id = ? ORDER BY id DESC').all(userId);

/* ============================ OBJETIVOS ============================ */
export function createGoal(userId, { subjectId = null, title, description = '', dueDate = null }) {
  const r = db.prepare(`INSERT INTO goals (user_id, subject_id, title, description, due_date, created_at, updated_at)
    VALUES (?,?,?,?,?,?,?)`).run(userId, subjectId, title, description, dueDate, now(), now());
  return n(r.lastInsertRowid);
}
export const listGoals = userId => db.prepare('SELECT * FROM goals WHERE user_id = ? ORDER BY status, id DESC').all(userId);
export const getGoal = (userId, id) => db.prepare('SELECT * FROM goals WHERE id = ? AND user_id = ?').get(id, userId);
export function updateGoal(userId, id, fields) {
  const sets = [], vals = [];
  for (const k of ['title', 'description', 'due_date', 'status', 'progress', 'subject_id']) if (k in fields) { sets.push(`${k} = ?`); vals.push(fields[k]); }
  if (!sets.length) return;
  sets.push('updated_at = ?'); vals.push(now(), id, userId);
  db.prepare(`UPDATE goals SET ${sets.join(', ')} WHERE id = ? AND user_id = ?`).run(...vals);
}
export const deleteGoal = (userId, id) => db.prepare('DELETE FROM goals WHERE id = ? AND user_id = ?').run(id, userId);
export function addGoalTask(goalId, { position, title }) {
  const r = db.prepare('INSERT INTO goal_tasks (goal_id, position, title) VALUES (?,?,?)').run(goalId, position, title);
  return n(r.lastInsertRowid);
}
export const listGoalTasks = goalId => db.prepare('SELECT * FROM goal_tasks WHERE goal_id = ? ORDER BY position').all(goalId);
export const getGoalTask = id => db.prepare('SELECT * FROM goal_tasks WHERE id = ?').get(id);
export function setGoalTask(id, done) {
  db.prepare('UPDATE goal_tasks SET done = ?, done_at = ? WHERE id = ?').run(done ? 1 : 0, done ? now() : null, id);
}
export function deleteGoalTask(id) { db.prepare('DELETE FROM goal_tasks WHERE id = ?').run(id); }
export function recalcGoal(goalId) {
  const tasks = listGoalTasks(goalId);
  if (!tasks.length) return 0;
  const done = tasks.filter(t => t.done).length;
  const progress = Math.round((done / tasks.length) * 100);
  db.prepare('UPDATE goals SET progress = ?, status = CASE WHEN ? = 100 THEN \'logrado\' ELSE status END, updated_at = ? WHERE id = ?')
    .run(progress, progress, now(), goalId);
  return progress;
}

/* ============================ SESIONES DE ESTUDIO ============================ */
export function startStudySession(userId, { conversationId = null, subjectId = null }) {
  const r = db.prepare('INSERT INTO study_sessions (user_id, conversation_id, subject_id, started_at) VALUES (?,?,?,?)')
    .run(userId, conversationId, subjectId, now());
  return n(r.lastInsertRowid);
}
export function endStudySession(id, minutes) {
  db.prepare('UPDATE study_sessions SET minutes = ?, ended_at = ? WHERE id = ?').run(Math.max(0, Math.min(minutes, 600)), now(), id);
}
export const listStudySessions = (userId, limit = 60) =>
  db.prepare('SELECT * FROM study_sessions WHERE user_id = ? ORDER BY id DESC LIMIT ?').all(userId, limit);

/* ============================ LOGROS ============================ */
export const listAchievements = userId => db.prepare('SELECT * FROM achievements WHERE user_id = ? ORDER BY earned_at DESC').all(userId);
export const hasAchievement = (userId, code) => Boolean(db.prepare('SELECT 1 FROM achievements WHERE user_id = ? AND code = ?').get(userId, code));
export function awardAchievement(userId, code, title, description = '') {
  if (hasAchievement(userId, code)) return false;
  db.prepare('INSERT INTO achievements (user_id, code, title, description, earned_at) VALUES (?,?,?,?,?)')
    .run(userId, code, title, description, now());
  return true;
}

/* ============================ RECURSOS ============================ */
export function createResource(userId, { subjectId = null, title, url = '', kind = 'curso', note = '', source = 'manual' }) {
  const r = db.prepare(`INSERT INTO resources (user_id, subject_id, title, url, kind, note, source, created_at)
    VALUES (?,?,?,?,?,?,?,?)`).run(userId, subjectId, title, url, kind, note, source, now());
  return n(r.lastInsertRowid);
}
export const listResources = userId => db.prepare('SELECT * FROM resources WHERE user_id = ? ORDER BY id DESC').all(userId);
export const deleteResource = (userId, id) => db.prepare('DELETE FROM resources WHERE id = ? AND user_id = ?').run(id, userId);

/* ============================ ESTADÍSTICAS ============================ */
export function statsOverview(userId) {
  const totals = db.prepare(`SELECT
    (SELECT COUNT(*) FROM activities WHERE user_id = ?) AS activities,
    (SELECT COUNT(*) FROM activities WHERE user_id = ? AND correct = 1) AS correct,
    (SELECT COUNT(*) FROM evaluations WHERE user_id = ? AND status = 'completada') AS evaluations,
    (SELECT COUNT(*) FROM study_sessions WHERE user_id = ?) AS sessions,
    (SELECT COALESCE(SUM(minutes),0) FROM study_sessions WHERE user_id = ?) AS minutes
  `).get(userId, userId, userId, userId, userId);
  return totals;
}
export function minutesByDay(userId, days = 14) {
  const rows = db.prepare(`SELECT substr(ended_at,1,10) AS day, SUM(minutes) AS minutes
    FROM study_sessions WHERE user_id = ? AND ended_at IS NOT NULL
    GROUP BY day ORDER BY day DESC LIMIT ?`).all(userId, days);
  return rows.reverse();
}
export function xpByDay(userId, days = 14) {
  const rows = db.prepare(`SELECT substr(created_at,1,10) AS day, SUM(amount) AS xp
    FROM xp_events WHERE user_id = ? GROUP BY day ORDER BY day DESC LIMIT ?`).all(userId, days);
  return rows.reverse();
}

export function purgeUserData(userId) {
  const t = ['messages', 'conversations', 'activities', 'eval_items', 'evaluations', 'path_activities', 'path_modules', 'learning_paths', 'topics', 'subjects', 'goal_tasks', 'goals', 'study_sessions', 'achievements', 'xp_events', 'resources'];
  db.exec('BEGIN');
  try {
    // messages cuelgan de conversations; borramos por subconsulta cuando no hay user_id directo
    db.prepare('DELETE FROM messages WHERE conversation_id IN (SELECT id FROM conversations WHERE user_id = ?)').run(userId);
    db.prepare('DELETE FROM eval_items WHERE evaluation_id IN (SELECT id FROM evaluations WHERE user_id = ?)').run(userId);
    db.prepare('DELETE FROM path_activities WHERE module_id IN (SELECT m.id FROM path_modules m JOIN learning_paths p ON m.path_id = p.id WHERE p.user_id = ?)').run(userId);
    db.prepare('DELETE FROM path_modules WHERE path_id IN (SELECT id FROM learning_paths WHERE user_id = ?)').run(userId);
    db.prepare('DELETE FROM goal_tasks WHERE goal_id IN (SELECT id FROM goals WHERE user_id = ?)').run(userId);
    for (const table of ['conversations', 'activities', 'evaluations', 'learning_paths', 'topics_placeholder']) {
      if (table === 'topics_placeholder') continue;
      db.prepare(`DELETE FROM ${table} WHERE user_id = ?`).run(userId);
    }
    db.prepare('DELETE FROM topics WHERE subject_id IN (SELECT id FROM subjects WHERE user_id = ?)').run(userId);
    db.prepare('DELETE FROM subjects WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM goals WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM study_sessions WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM achievements WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM xp_events WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM resources WHERE user_id = ?').run(userId);
    db.prepare("UPDATE profiles SET xp = 0, level = 1, streak = 0, best_streak = 1, last_study_date = NULL, total_minutes = 0, updated_at = ? WHERE user_id = ?").run(now(), userId);
    db.exec('COMMIT');
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
}
